<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: logon.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$error = '';

// Show the Private Projects button only when this account has access
// to at least one project. Admins can always access it as well.
$has_project_access = !empty($_SESSION['is_admin']);

if (!$has_project_access) {
    try {
        $accessStmt = $pdo->prepare("SELECT 1 FROM project_access WHERE user_id = ? AND access = 1 LIMIT 1");
        $accessStmt->execute([$user_id]);
        $has_project_access = (bool)$accessStmt->fetchColumn();
    } catch (PDOException $e) {
        // If the access table is unavailable, do not show the button.
        $has_project_access = false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_portfolio'])) {
        $title = trim($_POST['title']);
        $slug  = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['slug'])));
        $contact = isset($_POST['contact_enabled']) ? 1 : 0;
        if (!empty($title) && !empty($slug)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO portfolios (user_id, title, slug, contact_enabled) VALUES (?, ?, ?, ?)");
                $stmt->execute([$user_id, $title, $slug, $contact]);
                header('Location: manage.php');
                exit;
            } catch (PDOException $e) {
                $error = "Slug already in use.";
            }
        }
    } elseif (isset($_POST['update_portfolio'])) {
        $port_id = $_POST['portfolio_id'];
        $title   = trim($_POST['title']);
        $slug    = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['slug'])));
        $contact = isset($_POST['contact_enabled']) ? 1 : 0;
        if (!empty($title) && !empty($slug)) {
            try {
                $stmt = $pdo->prepare("UPDATE portfolios SET title = ?, slug = ?, contact_enabled = ? WHERE id = ? AND user_id = ?");
                $stmt->execute([$title, $slug, $contact, $port_id, $user_id]);
                header('Location: manage.php');
                exit;
            } catch (PDOException $e) {
                $error = "Could not update portfolio.";
            }
        }
    } elseif (isset($_POST['delete_portfolio'])) {
        $port_id = $_POST['portfolio_id'];
        $stmt = $pdo->prepare("DELETE FROM portfolios WHERE id = ? AND user_id = ?");
        $stmt->execute([$port_id, $user_id]);
        header('Location: manage.php');
        exit;
    } elseif (isset($_POST['add_block'])) {
        $port_id  = $_POST['portfolio_id'];
        $types    = $_POST['block_type'] ?? [];
        $contents = $_POST['content'] ?? [];

        $stmt = $pdo->prepare("SELECT id FROM portfolios WHERE id = ? AND user_id = ?");
        $stmt->execute([$port_id, $user_id]);
        if ($stmt->fetch()) {
            $group_id = count($types) > 1 ? uniqid('grp_', true) : null;
            $insertStmt = $pdo->prepare("INSERT INTO blocks (portfolio_id, block_type, content, group_id) VALUES (?, ?, ?, ?)");
            for ($i = 0; $i < count($types); $i++) {
                $type = $types[$i];
                $content = trim($contents[$i] ?? '');
                if (!empty($content)) {
                    $insertStmt->execute([$port_id, $type, $content, $group_id]);
                }
            }
        }
        header('Location: manage.php');
        exit;
    } elseif (isset($_POST['update_block'])) {
        $block_id = $_POST['block_id'];
        $type     = $_POST['block_type_single'];
        $content  = trim($_POST['content_single']);

        $stmt = $pdo->prepare("
            UPDATE blocks 
            JOIN portfolios ON blocks.portfolio_id = portfolios.id 
            SET blocks.block_type = ?, blocks.content = ? 
            WHERE blocks.id = ? AND portfolios.user_id = ?
        ");
        $stmt->execute([$type, $content, $block_id, $user_id]);
        header('Location: manage.php');
        exit;
    } elseif (isset($_POST['delete_block'])) {
        $block_id = $_POST['block_id'];
        $stmt = $pdo->prepare("
            DELETE blocks FROM blocks 
            JOIN portfolios ON blocks.portfolio_id = portfolios.id 
            WHERE blocks.id = ? AND portfolios.user_id = ?
        ");
        $stmt->execute([$block_id, $user_id]);
        header('Location: manage.php');
        exit;
    } elseif (isset($_POST['delete_account'])) {
        $pdo->prepare("DELETE blocks FROM blocks JOIN portfolios ON blocks.portfolio_id = portfolios.id WHERE portfolios.user_id = ?")->execute([$user_id]);
        $pdo->prepare("DELETE FROM portfolios WHERE user_id = ?")->execute([$user_id]);
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]);

        session_unset();
        session_destroy();
        header('Location: logon.php');
        exit;
    }
}

$stmt = $pdo->prepare("SELECT * FROM portfolios WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$portfolios = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Manage Portfolios</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .nav-btn { background-color: #18181b; color: #ffffff; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem; transition: background-color 0.15s ease; display: inline-block; }
        .nav-btn:hover { background-color: #27272a; color: #ffffff; }
        .nav-btn-secondary { background-color: #e4e4e7; color: #18181b; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem; transition: background-color 0.15s ease; display: inline-block; }
        .nav-btn-secondary:hover { background-color: #d4d4d8; color: #18181b; }
        .portfolio-section { border: 2px solid #e4e4e7; background: #ffffff; border-radius: 8px; padding: 1rem 1.5rem; margin-bottom: 1.5rem; }
        summary.portfolio-summary { cursor: pointer; font-weight: bold; font-size: 1.2rem; display: flex; justify-content: space-between; align-items: center; user-select: none; padding: 0.5rem 0; }
        .filegarden-banner { background-color: #eff6ff; border: 1px solid #bfdbfe; color: #1e40af; padding: 0.85rem 1rem; border-radius: 6px; margin-bottom: 1.5rem; font-size: 0.9rem; }
        .block-card { background: #f4f4f5; border: 1px solid #d4d4d8; border-radius: 6px; padding: 1rem; margin-bottom: 1rem; }
        .block-actions { display: flex; gap: 10px; margin-top: 0.5rem; }
        .admin-footer-btn { display: inline-block; padding: 0.35rem 0.75rem; font-size: 0.8rem; font-weight: 600; color: #dc2626; border: 1px solid #fca5a5; background-color: #fef2f2; border-radius: 4px; text-decoration: none; }
        .admin-footer-btn:hover { background-color: #dc2626; color: #ffffff; }
        .private-projects-btn { display: inline-block; padding: 0.35rem 0.75rem; font-size: 0.8rem; font-weight: 600; color: #7c3aed; border: 1px solid #c4b5fd; background-color: #f5f3ff; border-radius: 4px; text-decoration: none; }
        .private-projects-btn:hover { background-color: #7c3aed; color: #ffffff; }
    </style>
</head>
<body>
<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 2rem;">
        <h1 style="margin:0;">Your Dashboard</h1>
        <div style="display:flex; gap:10px;">
            <a href="settings.php" class="nav-btn">Settings</a>
            <a href="index.php" class="nav-btn-secondary">← Public Home</a>
        </div>
    </div>

    <div class="filegarden-banner">
        <strong>Hosting Tip:</strong> You can host your files and images for portfolio links on <a href="https://filegarden.com" target="_blank" rel="noopener" style="color:#2563eb; font-weight:bold; text-decoration:underline;">File Garden</a>.
    </div>

    <?php if ($error): ?><p style="color:#ef4444; font-weight:bold;"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <div class="block">
        <h3>Create New Portfolio</h3>
        <form method="POST">
            <input type="text" name="title" placeholder="Portfolio Title" required>
            <input type="text" name="slug" placeholder="URL Slug" required>
            <label style="display:block; margin: 0.5rem 0;">
                <input type="checkbox" name="contact_enabled" value="1"> Enable Contact Button on this Portfolio
            </label>
            <button type="submit" name="create_portfolio">Create Portfolio</button>
        </form>
    </div>

    <h2>Your Portfolios & Blocks</h2>
    <?php if (empty($portfolios)): ?>
        <p>No portfolios created yet.</p>
    <?php else: ?>
        <?php foreach ($portfolios as $p): ?>
            <details class="portfolio-section" open>
                <summary class="portfolio-summary">
                    <span>📁 <?= htmlspecialchars($p['title']) ?> <small style="font-size:0.85rem; color:#6b7280; font-weight:normal;">(/<?= htmlspecialchars($p['slug']) ?>)</small></span>
                    <span style="font-size:0.85rem; color:#2563eb;">(Click to Expand/Collapse)</span>
                </summary>

                <div style="margin-top: 1rem; border-top: 1px solid #e4e4e7; padding-top: 1rem;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 1rem;">
                        <small>Public Link: <a href="<?= htmlspecialchars($p['slug']) ?>" target="_blank">/<?= htmlspecialchars($p['slug']) ?></a></small>
                        <form method="POST" onsubmit="return confirm('Delete this portfolio and ALL its blocks?');">
                            <input type="hidden" name="portfolio_id" value="<?= $p['id'] ?>">
                            <button type="submit" name="delete_portfolio" style="background:#ef4444; color:white; width:auto;">Delete Portfolio</button>
                        </form>
                    </div>

                    <details style="margin-bottom: 1.5rem;">
                        <summary style="cursor:pointer; color:#2563eb; font-weight:bold;">Edit Portfolio Details</summary>
                        <form method="POST" style="margin-top: 0.5rem;">
                            <input type="hidden" name="portfolio_id" value="<?= $p['id'] ?>">
                            <input type="text" name="title" value="<?= htmlspecialchars($p['title']) ?>" required>
                            <input type="text" name="slug" value="<?= htmlspecialchars($p['slug']) ?>" required>
                            <label style="display:block; margin: 0.5rem 0;">
                                <input type="checkbox" name="contact_enabled" value="1" <?= $p['contact_enabled'] ? 'checked' : '' ?>> Show Contact Button
                            </label>
                            <button type="submit" name="update_portfolio" style="background:#2563eb; color:white;">Save Changes</button>
                        </form>
                    </details>

                    <div style="background:#f4f4f5; padding: 1rem; border-radius:6px; margin-bottom: 1.5rem;">
                        <h5 style="margin: 0 0 0.5rem 0;">+ Add New Block / Sections</h5>
                        <form method="POST">
                            <input type="hidden" name="portfolio_id" value="<?= $p['id'] ?>">
                            <div id="section-container-<?= $p['id'] ?>">
                                <div class="section-row" style="display:flex; gap:10px; margin-bottom: 0.5rem;">
                                    <select name="block_type[]" style="width: 30%;">
                                        <option value="text">Text Block</option>
                                        <option value="image">Image URL</option>
                                        <option value="link">External Link</option>
                                    </select>
                                    <textarea name="content[]" placeholder="Content text, image URL, or link..." required style="width:70%;"></textarea>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px; margin-top:0.5rem;">
                                <button type="button" onclick="addSectionRow(<?= $p['id'] ?>)" style="background:#4b5563; color:white; width:auto; padding:0.4rem 0.8rem;">+ Add Another Section</button>
                                <button type="submit" name="add_block" style="background:#2563eb; color:white; width:auto; padding:0.4rem 0.8rem;">Save Block</button>
                            </div>
                        </form>
                    </div>

                    <h4>Existing Blocks</h4>
                    <?php
                    $stmt_blocks = $pdo->prepare("SELECT * FROM blocks WHERE portfolio_id = ? ORDER BY id DESC");
                    $stmt_blocks->execute([$p['id']]);
                    $raw_blocks = $stmt_blocks->fetchAll();

                    $grouped_blocks = [];
                    foreach ($raw_blocks as $b) {
                        $key = !empty($b['group_id']) ? $b['group_id'] : 'single_' . $b['id'];
                        $grouped_blocks[$key][] = $b;
                    }
                    ?>

                    <?php foreach ($grouped_blocks as $group_sections): ?>
                        <div class="block-card">
                            <small style="color:#71717a; display:block; margin-bottom:0.75rem; font-size:0.8rem;">
                                Added: <?= date('M j, Y g:i a', strtotime($group_sections[0]['created_at'])) ?>
                            </small>

                            <?php foreach ($group_sections as $index => $b): ?>
                                <form method="POST" style="<?= $index < count($group_sections) - 1 ? 'border-bottom: 1px dashed #d4d4d8; padding-bottom: 0.75rem; margin-bottom: 0.75rem;' : '' ?>">
                                    <input type="hidden" name="block_id" value="<?= $b['id'] ?>">
                                    <div style="display:flex; gap:10px;">
                                        <select name="block_type_single" style="width: 30%;">
                                            <option value="text" <?= $b['block_type'] === 'text' ? 'selected' : '' ?>>Text Block</option>
                                            <option value="image" <?= $b['block_type'] === 'image' ? 'selected' : '' ?>>Image URL</option>
                                            <option value="link" <?= $b['block_type'] === 'link' ? 'selected' : '' ?>>External Link</option>
                                        </select>
                                        <textarea name="content_single" required style="width:70%;"><?= htmlspecialchars($b['content']) ?></textarea>
                                    </div>
                                    <div class="block-actions">
                                        <button type="submit" name="update_block" style="background:#16a34a; color:white; width:auto;">Update Section</button>
                                        <button type="submit" name="delete_block" onclick="return confirm('Delete section?');" style="background:#ef4444; color:white; width:auto;">Delete Section</button>
                                    </div>
                                </form>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </details>
        <?php endforeach; ?>
    <?php endif; ?>

    <div style="text-align: center; margin-top: 2.5rem; padding-bottom: 1rem;">
        <?php if (!empty($_SESSION['is_admin'])): ?>
            <a href="admin.php" class="admin-footer-btn" style="margin-right: 15px;">Admin Panel</a>
        <?php endif; ?>

        <?php if ($has_project_access): ?>
            <a href="other/private.php" class="private-projects-btn" style="margin-right: 15px;">Private Projects</a>
        <?php endif; ?>
        <a href="logout.php" style="color: #71717a; text-decoration: underline; font-size: 0.9rem; margin-right: 15px;">Log Out</a>
        
        <form method="POST" style="display:inline;" onsubmit="return confirm('Permanently delete your account and all your portfolios?');">
            <button type="submit" name="delete_account" style="background:none; border:none; color:#ef4444; text-decoration:underline; font-size:0.9rem; cursor:pointer; width:auto; padding:0;">Delete Account</button>
        </form>
    </div>
</div>

<script>
function addSectionRow(portfolioId) {
    const container = document.getElementById('section-container-' + portfolioId);
    const newRow = document.createElement('div');
    newRow.className = 'section-row';
    newRow.style = 'display:flex; gap:10px; margin-bottom: 0.5rem;';
    newRow.innerHTML = `
        <select name="block_type[]" style="width: 30%;">
            <option value="text">Text Block</option>
            <option value="image">Image URL</option>
            <option value="link">External Link</option>
        </select>
        <textarea name="content[]" placeholder="Content text, image URL, or link..." required style="width:65%;"></textarea>
        <button type="button" onclick="this.parentElement.remove()" style="background:#ef4444; color:white; width:auto; padding:0.2rem 0.5rem;">✕</button>
    `;
    container.appendChild(newRow);
}
</script>
</body>
</html>
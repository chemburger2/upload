<?php
require 'config.php';

$slug = $_GET['slug'] ?? '';

$stmt = $pdo->prepare("
    SELECT portfolios.*, users.username 
    FROM portfolios 
    JOIN users ON portfolios.user_id = users.id 
    WHERE portfolios.slug = ?
");
$stmt->execute([$slug]);
$portfolio = $stmt->fetch();

if (!$portfolio) {
    header("HTTP/1.0 404 Not Found");
    echo "Portfolio not found.";
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM blocks WHERE portfolio_id = ? ORDER BY id DESC");
$stmt->execute([$portfolio['id']]);
$raw_blocks = $stmt->fetchAll();

$grouped_blocks = [];
foreach ($raw_blocks as $b) {
    $key = !empty($b['group_id']) ? $b['group_id'] : 'single_' . $b['id'];
    $grouped_blocks[$key][] = $b;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($portfolio['title']) ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .nav-btn { background-color: #18181b; color: #ffffff; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem; transition: background-color 0.15s ease; display: inline-block; }
        .nav-btn:hover { background-color: #27272a; color: #ffffff; }
        .contact-btn { background-color: #2563eb; color: #ffffff; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem; transition: background-color 0.15s ease; display: inline-block; }
        .contact-btn:hover { background-color: #1d4ed8; color: #ffffff; }
        .admin-footer-btn { display: inline-block; padding: 0.35rem 0.75rem; font-size: 0.8rem; font-weight: 600; color: #dc2626; border: 1px solid #fca5a5; background-color: #fef2f2; border-radius: 4px; text-decoration: none; }
        .admin-footer-btn:hover { background-color: #dc2626; color: #ffffff; }
        .block-section { margin-bottom: 1.25rem; }
        .block-section:last-child { margin-bottom: 0; }
    </style>
</head>
<body>
<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 2rem;">
        <a href="index.php" class="nav-btn">← Back to Home</a>
        <?php if (!empty($portfolio['contact_enabled'])): ?>
            <a href="user/<?= urlencode($portfolio['username']) ?>" class="contact-btn">📩 Contact Creator</a>
        <?php endif; ?>
    </div>

    <h1><?= htmlspecialchars($portfolio['title']) ?></h1>
    <p>By <strong><a href="user/<?= urlencode($portfolio['username']) ?>"><?= htmlspecialchars($portfolio['username']) ?></a></strong></p>
    
    <div class="stream">
        <?php foreach ($grouped_blocks as $group): ?>
            <div class="block">
                <small style="color:#71717a; display:block; margin-bottom:0.75rem; font-size:0.8rem;">
                    Added: <?= date('M j, Y g:i a', strtotime($group[0]['created_at'])) ?>
                </small>
                
                <?php foreach ($group as $b): ?>
                    <div class="block-section">
                        <?php if ($b['block_type'] === 'image'): ?>
                            <img src="<?= htmlspecialchars($b['content']) ?>" style="max-width:100%; border-radius:6px;">
                        <?php elseif ($b['block_type'] === 'link'): ?>
                            <a href="<?= htmlspecialchars($b['content']) ?>" target="_blank" rel="noopener"><?= htmlspecialchars($b['content']) ?></a>
                        <?php else: ?>
                            <p style="margin:0;"><?= nl2br(htmlspecialchars($b['content'])) ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if (!empty($_SESSION['is_admin'])): ?>
        <div style="text-align: center; margin-top: 2.5rem; padding-bottom: 1rem;">
            <a href="admin.php" class="admin-footer-btn">Admin Panel</a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
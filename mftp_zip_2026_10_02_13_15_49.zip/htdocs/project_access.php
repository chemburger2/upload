<?php
declare(strict_types=1);

/*
 * Central project access control.
 *
 * project_access table:
 *   user_id       = users.id
 *   project_name  = folder name under /other/
 *   access        = 1 allowed, 0 denied
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function isAdminUser(PDO $pdo, int $userId): bool
{
    if ($userId <= 0) {
        return false;
    }

    $stmt = $pdo->prepare(
        'SELECT is_admin FROM users WHERE id = ? LIMIT 1'
    );
    $stmt->execute([$userId]);

    return (int)$stmt->fetchColumn() === 1;
}

function projectAccess(PDO $pdo, int $userId, string $projectName): bool
{
    if ($userId <= 0 || $projectName === '') {
        return false;
    }

    if (isAdminUser($pdo, $userId)) {
        return true;
    }

    $stmt = $pdo->prepare(
        'SELECT access
         FROM project_access
         WHERE user_id = ? AND project_name = ?
         LIMIT 1'
    );
    $stmt->execute([$userId, $projectName]);

    return (int)$stmt->fetchColumn() === 1;
}

function userHasAnyProjectAccess(PDO $pdo, int $userId): bool
{
    if ($userId <= 0) {
        return false;
    }

    if (isAdminUser($pdo, $userId)) {
        return true;
    }

    $stmt = $pdo->prepare(
        'SELECT 1
         FROM project_access
         WHERE user_id = ? AND access = 1
         LIMIT 1'
    );
    $stmt->execute([$userId]);

    return (bool)$stmt->fetchColumn();
}

function requireProjectAccess(PDO $pdo, string $projectName): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: /logon.php');
        exit;
    }

    if (!projectAccess($pdo, (int)$_SESSION['user_id'], $projectName)) {
        http_response_code(403);
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Access Denied</title><style>body{margin:0;background:#121214;color:#e1e1e6;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;min-height:100vh;display:grid;place-items:center}.box{max-width:480px;text-align:center;padding:32px}.box h1{margin:0 0 10px}.box p{color:#a8a8b3;line-height:1.5}.box a{display:inline-block;margin-top:12px;padding:10px 16px;border-radius:8px;background:#29292e;color:#fff;text-decoration:none}</style></head><body><div class="box"><h1>Access denied</h1><p>You do not have permission to access this project.</p><a href="/other/private.php">Back to Private Pages</a></div></body></html>';
        exit;
    }
}

function userHasProjectAccess(PDO $pdo, int $userId, string $projectName): bool
{
    return projectAccess($pdo, $userId, $projectName);
}

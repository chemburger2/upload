<?php
require 'config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $action   = $_POST['action'] ?? '';

    if (!empty($username) && !empty($password)) {
        if ($action === 'register') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            try {
                $stmt->execute([$username, $hash]);
                $_SESSION['user_id'] = $pdo->lastInsertId();
                $_SESSION['is_admin'] = 0;
                header('Location: manage.php');
                exit;
            } catch (PDOException $e) {
                $error = "Username already taken.";
            }
        } elseif ($action === 'login') {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['is_admin'] = $user['is_admin'];
                header('Location: manage.php');
                exit;
            } else {
                $error = "Invalid username or password.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logon</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-box">
    <h2>Account Access</h2>
    <?php if ($error): ?><p style="color:#ef4444;"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <div style="display:flex; gap:10px; margin-top:10px;">
            <button type="submit" name="action" value="login">Log In</button>
            <button type="submit" name="action" value="register">Register</button>
        </div>
    </form>
</div>
</body>
</html>
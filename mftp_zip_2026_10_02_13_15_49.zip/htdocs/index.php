<?php
require 'config.php';

$stmt = $pdo->prepare("
    SELECT portfolios.title, portfolios.slug, users.username 
    FROM portfolios 
    JOIN users ON portfolios.user_id = users.id 
    ORDER BY portfolios.id DESC
");
$stmt->execute();
$portfolios = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Explore Portfolios</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .header-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
        .login-btn { background-color: #18181b; color: white; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; }
        .login-btn:hover { background-color: #27272a; }
        .portfolio-card { display: block; text-decoration: none; color: inherit; transition: transform 0.15s ease; }
        .portfolio-card:hover { transform: translateY(-2px); }
        .author { margin: 0; color: #71717a; font-size: 0.9rem; }
        .admin-footer-btn { display: inline-block; padding: 0.35rem 0.75rem; font-size: 0.8rem; font-weight: 600; color: #dc2626; border: 1px solid #fca5a5; background-color: #fef2f2; border-radius: 4px; text-decoration: none; }
        .admin-footer-btn:hover { background-color: #dc2626; color: #ffffff; }
    </style>
</head>
<body>
<div class="container">
    <div class="header-bar">
        <h2>Explore Portfolios</h2>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="manage.php" class="login-btn">Dashboard</a>
        <?php else: ?>
            <a href="logon.php" class="login-btn">Log In</a>
        <?php endif; ?>
    </div>

    <div class="stream">
        <?php if (empty($portfolios)): ?>
            <div class="block"><p>No portfolios available yet.</p></div>
        <?php else: ?>
            <?php foreach ($portfolios as $p): ?>
                <a href="<?= htmlspecialchars($p['slug']) ?>" class="block portfolio-card">
                    <h3><?= htmlspecialchars($p['title']) ?></h3>
                    <p class="author">By <strong><?= htmlspecialchars($p['username']) ?></strong></p>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <?php if (!empty($_SESSION['is_admin'])): ?>
        <div style="text-align: center; margin-top: 2.5rem; padding-bottom: 1rem;">
            <a href="admin.php" class="admin-footer-btn">Admin Panel</a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
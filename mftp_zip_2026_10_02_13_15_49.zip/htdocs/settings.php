<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: logon.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $theme = $_POST['theme'] ?? 'light';
    $stmt = $pdo->prepare("UPDATE users SET theme = ? WHERE id = ?");
    $stmt->execute([$theme, $user_id]);
    $message = "Settings saved!";
}

$stmt = $pdo->prepare("SELECT username, theme FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Settings</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="theme-<?= htmlspecialchars($user['theme'] ?? 'light') ?>">
<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <h1>Settings</h1>
        <a href="manage.php">← Back to Dashboard</a>
    </div>

    <!-- Top Profile Editor Link -->
    <div style="background:#f4f4f5; border:1px solid #d4d4d8; padding:1.25rem; border-radius:8px; margin-bottom:1.5rem; display:flex; justify-content:space-between; align-items:center;">
        <div>
            <strong>Your Public Profile</strong>
            <p style="margin:0; font-size:0.85rem; color:#52525b;">Customize your bio, email, and public appearance.</p>
        </div>
        <a href="user/<?= urlencode($user['username']) ?>?edit=1" style="background:#2563eb; color:white; padding:0.5rem 1rem; border-radius:6px; text-decoration:none; font-weight:bold;">Update Profile</a>
    </div>

    <?php if ($message): ?>
        <p style="color:#16a34a; font-weight:bold;"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="POST" style="background:#ffffff; padding:1.5rem; border-radius:8px; border:1px solid #e4e4e7;">
        <h3>Site Preferences</h3>
        
        <label style="display:block; margin-bottom:0.5rem; font-weight:bold;">Appearance Theme</label>
        <select name="theme" style="width:100%; margin-bottom:1.5rem;">
            <option value="light" <?= ($user['theme'] ?? 'light') === 'light' ? 'selected' : '' ?>>Light</option>
            <option value="dark" <?= ($user['theme'] ?? '') === 'dark' ? 'selected' : '' ?>>Dark</option>
        </select>

        <button type="submit" name="save_settings" style="background:#4b5563; color:white; width:auto; padding:0.5rem 1.2rem;">Save Preferences</button>
    </form>
</div>
</body>
</html>
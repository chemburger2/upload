```php
<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WorldGuessr</title>

    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background: #000;
        }

        iframe {
            display: block;
            width: 100%;
            height: 100vh;
            border: 0;
        }
    </style>
</head>
<body>

<iframe
    src="https://worldguessr.com/"
    allow="fullscreen; geolocation"
    allowfullscreen
></iframe>

</body>
</html>
```

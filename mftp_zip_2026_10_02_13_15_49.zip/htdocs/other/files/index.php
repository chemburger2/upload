<?php

require_once __DIR__ . '/../../config.php';

if (empty($_SESSION['is_admin'])) {
    header('Location: ../../manage.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Files</title>
<style>
:root{color-scheme:dark;--bg:#0f1012;--panel:#181a1f;--panel2:#22252b;--line:#30343d;--text:#f1f3f5;--muted:#9aa1ab;--accent:#6ea8fe;--sel:#2b3d57}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
header{height:58px;background:#17191d;border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 18px;gap:12px}.brand{font-size:17px;font-weight:700;margin-right:auto}.status{color:var(--muted);font-size:12px}
main{max-width:1180px;margin:auto;padding:20px 18px}.center{min-height:calc(100vh - 58px);display:grid;place-items:center}.card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:24px;width:min(590px,100%);box-shadow:0 12px 40px #0004}
h1,h2,h3{margin:0 0 10px}p{color:var(--muted);line-height:1.5}.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.drop{margin-top:16px;padding:26px;border:1px dashed #4b515c;border-radius:9px;text-align:center;color:var(--muted)}
.toolbar{display:flex;gap:7px;align-items:center;flex-wrap:wrap;margin-bottom:10px}.path{color:var(--muted);margin-left:auto;min-width:180px;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.list{border:1px solid var(--line);border-radius:9px;overflow:hidden;background:var(--panel)}.item{display:flex;align-items:center;gap:12px;padding:11px 13px;border-bottom:1px solid var(--line);cursor:pointer;user-select:none}.item:last-child{border:0}.item:hover{background:#202329}.item.selected{background:var(--sel)}.icon{width:24px;text-align:center;color:#c5cad1}.name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.meta{font-size:12px;color:var(--muted);min-width:100px;text-align:right}.empty{padding:55px;text-align:center;color:var(--muted)}
.modal{position:fixed;inset:0;background:#000a;display:grid;place-items:center;padding:18px;z-index:10}.hidden{display:none!important}.modal .card{max-height:92vh;overflow:auto}.field{margin:15px 0}.field label{display:block;margin-bottom:7px}.field input,.field textarea{width:100%;background:#0d0f12;color:var(--text);border:1px solid var(--line);border-radius:7px;padding:10px}.field textarea{min-height:400px;resize:vertical;font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.small{font-size:12px;color:var(--muted)}.error{color:#ff9fa5;margin-top:10px}.ok{color:#8fdda1;margin-top:10px}
.context{position:fixed;z-index:30;background:#1b1e23;border:1px solid #3a3f48;border-radius:8px;box-shadow:0 12px 30px #0008;min-width:170px;padding:5px}.context button{display:block;width:100%;border:0;background:transparent;text-align:left;border-radius:5px}.context button:hover{background:#2a2e35}
.progress{height:7px;background:#0c0d0f;border-radius:99px;overflow:hidden;margin:14px 0}.progress>div{height:100%;width:0;background:var(--accent);transition:width .1s}.chips{display:flex;gap:6px;flex-wrap:wrap}.chip{background:#22262c;border:1px solid var(--line);padding:5px 8px;border-radius:99px;font-size:12px}
</style>
</head>
<body>
<header>
    <div class="brand">Files</div>
    <div id="status" class="status">No container open</div>
    <button id="lock" class="hidden">Lock</button>
</header>

<main id="home" class="center">
<section class="card">
<h1>Files</h1>
<p>Open a container to browse, create, edit, import, and export files.</p>
<div class="row">
    <button id="openBtn" class="primary">Open file.file</button>
    <button id="createBtn">Create file.file</button>
</div>
<div id="homeMsg" class="small" style="margin-top:14px"></div>
</section>
</main>

<main id="app" class="hidden">
<div class="toolbar">
<button id="backBtn">Back</button>
<button id="forwardBtn">Forward</button>
<button id="upBtn">Up</button>
<button id="newFolderBtn">New folder</button>
<button id="newFileBtn">New file</button>
<button id="importFilesBtn">Import files</button>
<button id="importFolderBtn">Import folder</button>
<button id="refreshBtn">Refresh</button>
<div id="path" class="path">/</div>
</div>

<div class="toolbar">
<button id="renameBtn" disabled>Rename</button>
<button id="deleteBtn" disabled>Delete</button>
<button id="exportBtn" disabled>Export</button>
<span class="small">Double-click to open. Right-click for options.</span>
</div>

<div id="list" class="list"></div>
</main>

<div id="createModal" class="modal hidden">
<section class="card">
<h2>Create file.file</h2>
<p>Choose the password used to open this file. Keep it somewhere safe; it cannot be recovered if forgotten.</p>

<div class="field">
<label>Password</label>
<input id="createPass" type="password" autocomplete="new-password">
</div>

<div class="field">
<label>Confirm password</label>
<input id="createConfirm" type="password" autocomplete="new-password">
</div>

<div class="row">
<button id="createGo" class="primary">Create</button>
<button class="cancel">Cancel</button>
</div>

<div id="createMsg" class="error"></div>
</section>
</div>

<div id="unlockModal" class="modal hidden">
<section class="card">
<h2>Open file</h2>

<div class="field">
<label>Password</label>
<input id="unlockPass" type="password" autocomplete="off">
</div>

<div class="row">
<button id="unlockGo" class="primary">Open</button>
<button class="cancel">Cancel</button>
</div>

<div id="unlockMsg" class="error"></div>
</section>
</div>

<div id="editorModal" class="modal hidden">
<section class="card" style="width:min(900px,100%)">
<h2 id="editorTitle"></h2>

<div class="field">
<textarea id="editor" spellcheck="false"></textarea>
</div>

<div class="row">
<button id="saveEdit" class="primary">Save</button>
<button id="exportEdit">Export copy</button>
<button class="cancel">Close</button>
</div>

<div id="editorMsg" class="small"></div>
</section>
</div>

<div id="newFileModal" class="modal hidden">
<section class="card">
<h2>New file</h2>

<div class="field">
<label>Name</label>
<input id="newFileName" value="New File.txt">
</div>

<div class="row">
<button id="newFileGo" class="primary">Create</button>
<button class="cancel">Cancel</button>
</div>

<div id="newFileMsg" class="error"></div>
</section>
</div>

<div id="newFolderModal" class="modal hidden">
<section class="card">
<h2>New folder</h2>

<div class="field">
<label>Name</label>
<input id="newFolderName" value="New Folder">
</div>

<div class="row">
<button id="newFolderGo" class="primary">Create</button>
<button class="cancel">Cancel</button>
</div>

<div id="newFolderMsg" class="error"></div>
</section>
</div>

<div id="progressModal" class="modal hidden">
<section class="card">
<h2 id="progressTitle">Importing</h2>
<div id="progressText" class="small">Preparing…</div>
<div class="progress">
<div id="progressBar"></div>
</div>
<div id="progressCount" class="small"></div>
<div id="progressMsg" class="error"></div>
</section>
</div>

<div id="menu" class="context hidden">
<button id="menuOpen">Open</button>
<button id="menuRename">Rename</button>
<button id="menuDelete">Delete</button>
<button id="menuExport">Export</button>
</div>

<script>
"use strict";

/*
  Container format:
  - Fixed header with salts.
  - Encrypted data records appended to the file.
  - Encrypted filesystem index appended after imports/changes.
  - Fixed footer points to the latest index.
  - File contents are never represented as Base64 or JSON.
*/

const MAGIC="FLS4";
const VERSION=4;
const HEADER_SIZE=64;
const FOOTER_SIZE=44;
const CHUNK=4*1024*1024;
const ITER=600000;

const te=new TextEncoder();
const td=new TextDecoder();

let rootHandle=null;
let containerHandle=null;
let sessionKey=null;
let activeSide=0;
let fs=null;
let cwd=[];
let selectedPath=null;
let selectedNode=null;
let editing=null;
let backStack=[];
let forwardStack=[];

const $=id=>document.getElementById(id);
const show=x=>x.classList.remove("hidden");
const hide=x=>x.classList.add("hidden");

const rnd=n=>{
    const a=new Uint8Array(n);
    crypto.getRandomValues(a);
    return a;
};

const u32=n=>{
    const a=new Uint8Array(4);
    new DataView(a.buffer).setUint32(0,n,true);
    return a;
};

const u64=n=>{
    const a=new Uint8Array(8);
    new DataView(a.buffer).setBigUint64(0,BigInt(n),true);
    return a;
};

const readU32=a=>
    new DataView(a.buffer,a.byteOffset,a.byteLength).getUint32(0,true);

const readU64=a=>
    Number(new DataView(a.buffer,a.byteOffset,a.byteLength).getBigUint64(0,true));

const cat=(...xs)=>{
    let n=xs.reduce((a,x)=>a+x.length,0);
    let o=new Uint8Array(n);
    let p=0;

    for(const x of xs){
        o.set(x,p);
        p+=x.length;
    }

    return o;
};

const AAD=(side,type)=>
    te.encode(MAGIC+"|"+VERSION+"|"+side+"|"+type);

const EMPTY=()=>({
    type:"dir",
    name:"",
    children:{}
});

function passwords(s){
    if(!s || !s.length)
        return null;

    const parts=s.split(",");

    if(parts.length===1)
        return [s];

    if(parts.length!==2 ||
       !parts[0].length ||
       !parts[1].length)
        return null;

    return parts;
}

async function derive(pass,salt){
    const b=await crypto.subtle.importKey(
        "raw",
        te.encode(pass),
        "PBKDF2",
        false,
        ["deriveKey"]
    );

    return crypto.subtle.deriveKey(
        {
            name:"PBKDF2",
            salt,
            iterations:ITER,
            hash:"SHA-256"
        },
        b,
        {
            name:"AES-GCM",
            length:256
        },
        false,
        ["encrypt","decrypt"]
    );
}

async function enc(k,data,iv,aad){
    return new Uint8Array(
        await crypto.subtle.encrypt(
            {
                name:"AES-GCM",
                iv,
                additionalData:aad
            },
            k,
            data
        )
    );
}

async function dec(k,data,iv,aad){
    return new Uint8Array(
        await crypto.subtle.decrypt(
            {
                name:"AES-GCM",
                iv,
                additionalData:aad
            },
            k,
            data
        )
    );
}

function setStatus(s){
    $("status").textContent=s;
}

function formatBytes(n){
    if(n<1024)return n+" B";
    if(n<1048576)return(n/1024).toFixed(1)+" KB";
    if(n<1073741824)return(n/1048576).toFixed(1)+" MB";
    return(n/1073741824).toFixed(2)+" GB";
}

function validName(n){
    return n &&
           n.trim() &&
           !/[\/\\]/.test(n) &&
           n!=="." &&
           n!=="..";
}

function unique(d,n){
    if(!d.children[n])return n;

    const j=n.lastIndexOf(".");
    const b=j>0?n.slice(0,j):n;
    const e=j>0?n.slice(j):"";

    let i=2;

    while(d.children[b+" ("+i+")"+e])
        i++;

    return b+" ("+i+")"+e;
}

function getNode(p){
    let n=fs;

    for(const x of p){
        if(!n.children?.[x])
            throw Error("Path not found");

        n=n.children[x];
    }

    return n;
}

function currentDir(){
    return getNode(cwd);
}

function parentNode(p){
    return p.length
        ? getNode(p.slice(0,-1))
        : null;
}

function pathText(){
    return "/"+cwd.join("/");
}

function clearSelection(){
    selectedPath=null;
    selectedNode=null;

    $("renameBtn").disabled=true;
    $("deleteBtn").disabled=true;
    $("exportBtn").disabled=true;
}

function select(p,n,e){
    selectedPath=p;
    selectedNode=n;

    document
        .querySelectorAll(".item")
        .forEach(x=>x.classList.remove("selected"));

    e?.classList.add("selected");

    $("renameBtn").disabled=false;
    $("deleteBtn").disabled=false;
    $("exportBtn").disabled=n.type==="dir";
}

function navigate(to,record=true){
    if(record)
        backStack.push([...cwd]);

    forwardStack=[];
    cwd=[...to];

    clearSelection();
    render();
}

function render(){
    const d=currentDir();
    const list=$("list");

    $("path").textContent=pathText();
    list.innerHTML="";

    if(cwd.length){
        const e=document.createElement("div");

        e.className="item";
        e.innerHTML=
            '<span class="icon">↑</span>'+
            '<span class="name">..</span>'+
            '<span class="meta">Folder</span>';

        e.ondblclick=()=>{
            navigate(cwd.slice(0,-1));
        };

        list.append(e);
    }

    const names=Object.keys(d.children).sort((a,b)=>
        d.children[a].type!==d.children[b].type
            ?(d.children[a].type==="dir"?-1:1)
            :a.localeCompare(b)
    );

    if(!names.length){
        const e=document.createElement("div");

        e.className="empty";
        e.textContent="This folder is empty.";

        list.append(e);
        return;
    }

    for(const name of names){
        const n=d.children[name];
        const p=[...cwd,name];

        const e=document.createElement("div");
        e.className="item";

        e.innerHTML=
            '<span class="icon">'+
            (n.type==="dir"?"▰":"□")+
            '</span>'+
            '<span class="name"></span>'+
            '<span class="meta">'+
            (n.type==="dir"
                ?"Folder"
                :formatBytes(n.size||0))+
            '</span>';

        e.querySelector(".name").textContent=name;

        e.onclick=q=>{
            select(p,n,e);
        };

        e.ondblclick=()=>{
            n.type==="dir"
                ?navigate(p)
                :openFile(p,n);
        };

        e.oncontextmenu=q=>{
            q.preventDefault();

            select(p,n,e);
            openMenu(q.clientX,q.clientY);
        };

        list.append(e);
    }
}

function showProgress(title,total){
    $("progressTitle").textContent=title;
    $("progressText").textContent="Preparing…";
    $("progressBar").style.width="0%";
    $("progressCount").textContent="0 / "+total;
    $("progressMsg").textContent="";

    show($("progressModal"));
}

function progress(done,total,name,bytes=0,totalBytes=0){
    const percent=total
        ?Math.min(100,(done/total)*100)
        :0;

    $("progressText").textContent=name;
    $("progressBar").style.width=percent+"%";

    $("progressCount").textContent=
        done+" / "+total+
        (totalBytes
            ?" • "+formatBytes(bytes)+" / "+formatBytes(totalBytes)
            :"");
}

function finishProgress(){
    $("progressBar").style.width="100%";
    $("progressText").textContent="Import complete.";
    $("progressCount").textContent="Done";

    setTimeout(()=>{
        hide($("progressModal"));
    },400);
}

function failProgress(message){
    $("progressText").textContent="Import failed.";
    $("progressMsg").textContent=message;
    $("progressBar").style.width="0%";

    setTimeout(()=>{
        hide($("progressModal"));
    },2500);
}

async function createNewFile(){
    const n=$("newFileName").value.trim();

    if(!validName(n)){
        $("newFileMsg").textContent="Enter a valid name.";
        return;
    }

    const d=currentDir();
    const name=unique(d,n);

    d.children[name]={
        type:"file",
        name,
        size:0,
        mime:"text/plain",
        chunks:[],
        created:Date.now()
    };

    hide($("newFileModal"));

    await saveIndex();
    render();
}

async function createNewFolder(){
    const n=$("newFolderName").value.trim();

    if(!validName(n)){
        $("newFolderMsg").textContent="Enter a valid name.";
        return;
    }

    const d=currentDir();
    const name=unique(d,n);

    d.children[name]={
        type:"dir",
        name,
        children:{},
        created:Date.now()
    };

    hide($("newFolderModal"));

    await saveIndex();
    render();
}

async function openFile(p,n){
    if(n.size>25*1024*1024){
        alert(
            "This file is too large to open in the text editor. "+
            "Use Export instead."
        );
        return;
    }

    if(
        n.mime?.startsWith("text/") ||
        n.mime==="application/json" ||
        n.mime==="application/javascript" ||
        n.mime==="application/xml"
    ){
        try{
            const data=await readFile(n);

            editing=n;

            $("editorTitle").textContent=p.at(-1);
            $("editor").value=td.decode(data);

            show($("editorModal"));
        }catch(e){
            alert("Could not read file: "+e.message);
        }
    }else{
        exportNode(n,p.at(-1));
    }
}

async function readAt(offset,length){
    const f=await containerHandle.getFile();

    return new Uint8Array(
        await f
            .slice(offset,offset+length)
            .arrayBuffer()
    );
}

async function append(bytes){
    const file=await containerHandle.getFile();
    const size=file.size;

    const w=await containerHandle.createWritable({
        keepExistingData:true
    });

    await w.seek(size);
    await w.write(bytes);
    await w.close();

    return size;
}

async function appendEncryptedChunk(bytes,side){
    const iv=rnd(12);

    const cipher=await enc(
        sessionKey,
        bytes,
        iv,
        AAD(side,"DATA")
    );

    const header=cat(
        te.encode("DAT2"),
        u32(bytes.length),
        iv,
        u64(cipher.length)
    );

    const off=await append(
        cat(header,cipher)
    );

    return{
        offset:off+header.length,
        length:cipher.length,
        plain:bytes.length,
        iv:b64(iv)
    };
}

function b64(a){
    let s="";

    for(let i=0;i<a.length;i+=32768)
        s+=String.fromCharCode(
            ...a.subarray(i,i+32768)
        );

    return btoa(s);
}

function ub64(s){
    const x=atob(s);
    const a=new Uint8Array(x.length);

    for(let i=0;i<x.length;i++)
        a[i]=x.charCodeAt(i);

    return a;
}

async function readChunk(c){
    const headerSize=4+4+12+8;

    const h=await readAt(
        c.offset-headerSize,
        headerSize
    );

    if(td.decode(h.slice(0,4))!=="DAT2")
        throw Error("Bad data record");

    const cipher=await readAt(
        c.offset,
        c.length
    );

    return await dec(
        sessionKey,
        cipher,
        ub64(c.iv),
        AAD(activeSide,"DATA")
    );
}

async function readFile(n){
    const out=new Uint8Array(n.size);
    let pos=0;

    for(const c of n.chunks){
        const d=await readChunk(c);

        out.set(d,pos);
        pos+=d.length;
    }

    return out;
}

async function writeIndex(){
    const plain=te.encode(
        JSON.stringify(fs)
    );

    const iv=rnd(12);

    const cipher=await enc(
        sessionKey,
        plain,
        iv,
        AAD(activeSide,"INDEX")
    );

    const rec=cat(
        te.encode("IDX2"),
        new Uint8Array([activeSide]),
        new Uint8Array([0]),
        u64(cipher.length),
        iv,
        cipher
    );

    const off=await append(rec);

    return{
        offset:off,
        length:rec.length
    };
}

/*
 * FIX:
 * The old code called saveIndex(), but saveIndex()
 * did not exist. This is the missing function that
 * caused imports to reach 100% and then remain stuck.
 */
async function saveIndex(){
    const idx=await writeIndex();

    containerIndexes[activeSide]=idx;

    await writeFooter(containerIndexes);

    return idx;
}

async function writeFooter(indexes){
    const a=
        indexes[0] ||
        {offset:0,length:0};

    const b=
        indexes[1] ||
        {offset:0,length:0};

    const footer=cat(
        te.encode("END4"),
        u64(a.offset),
        u64(a.length),
        u64(b.offset),
        u64(b.length),
        u64(Date.now())
    );

    await append(footer);
}

let containerIndexes=[null,null];

async function makeContainer(ps){
    // Each side gets its own salt and therefore its own independent key.
    // Header layout: MAGIC(4) VERSION(4) SALT0(16) SALT1(16) reserved(24).
    const salts=[rnd(16),rnd(16)];
    const keys=[];

    for(let side=0;side<ps.length;side++){
        keys.push(await derive(ps[side],salts[side]));
    }

    const header=new Uint8Array(HEADER_SIZE);

    header.set(te.encode(MAGIC),0);

    new DataView(header.buffer)
        .setUint32(4,VERSION,true);

    header.set(salts[0],8);
    header.set(salts[1],24);
    header.set(rnd(24),40);

    containerHandle=null;

    return{
        header,
        salts,
        keys
    };
}

async function initializeContainer(ps){
    const x=await makeContainer(ps);

    containerHandle=
        await rootHandle.getFileHandle(
            "file.file",
            {create:true}
        );

    const w=await containerHandle.createWritable();

    await w.write(x.header);
    await w.close();

    containerIndexes=[null,null];

    activeSide=0;
    sessionKey=x.keys[0];
    fs=EMPTY();

    containerIndexes[0]=await writeIndex();

    if(x.keys.length===2){
        activeSide=1;
        sessionKey=x.keys[1];
        fs=EMPTY();

        containerIndexes[1]=await writeIndex();

        activeSide=0;
        sessionKey=x.keys[0];
        fs=EMPTY();
    }

    await writeFooter(containerIndexes);
}

async function unlockContainer(password){
    if(!password || !password.length)
        throw Error("Wrong password.");

    const f=await containerHandle.getFile();
    const size=f.size;

    if(size<HEADER_SIZE+FOOTER_SIZE)
        throw Error("Container is incomplete.");

    const header=new Uint8Array(
        await f
            .slice(0,HEADER_SIZE)
            .arrayBuffer()
    );

    if(td.decode(header.slice(0,4))!==MAGIC)
        throw Error("Unsupported container.");

    const salts=[
        header.slice(8,24),
        header.slice(24,40)
    ];

    const footer=new Uint8Array(
        await f
            .slice(size-FOOTER_SIZE,size)
            .arrayBuffer()
    );

    const footerMagic=td.decode(footer.slice(0,4));

    if(footerMagic!=="END4")
        throw Error("Invalid container footer.");

    const indexes=[
        {
            offset:readU64(footer.slice(4,12)),
            length:readU64(footer.slice(12,20))
        },
        {
            offset:readU64(footer.slice(20,28)),
            length:readU64(footer.slice(28,36))
        }
    ];

    containerIndexes=[null,null];

    async function trySide(side,key){
        const idx=indexes[side];

        if(!idx.offset || !idx.length)
            return null;

        const rec=new Uint8Array(
            await f
                .slice(idx.offset,idx.offset+idx.length)
                .arrayBuffer()
        );

        if(td.decode(rec.slice(0,4))!=="IDX2")
            return null;

        if(rec[4]!==side)
            return null;

        const cipherLen=readU64(rec.slice(6,14));
        const niv=rec.slice(14,26);

        if(26+cipherLen>rec.length)
            return null;

        const cipher=rec.slice(26,26+cipherLen);

        const plain=await dec(
            key,
            cipher,
            niv,
            AAD(side,"INDEX")
        );

        const tree=JSON.parse(td.decode(plain));

        if(!tree || tree.type!=="dir")
            return null;

        return tree;
    }

    // Each side has a separate salt/key. Try side 0 first so the
    // beginning password always wins when a dual-sided container opens.
    for(let side=0;side<2;side++){
        const idx=indexes[side];

        if(!idx.offset || !idx.length)
            continue;

        try{
            const key=await derive(password,salts[side]);
            const tree=await trySide(side,key);

            if(tree){
                activeSide=side;
                sessionKey=key;
                fs=tree;
                containerIndexes[side]=idx;
                return true;
            }
        }catch(e){
            // Wrong password for this side; try the other side.
        }
    }

    throw Error("Wrong password.");
}
async function choose(){
    try{
        rootHandle=await showDirectoryPicker({
            mode:"readwrite"
        });

        await permission(rootHandle);

        containerHandle=
            await rootHandle.getFileHandle(
                "file.file"
            );

        show($("unlockModal"));
        $("unlockPass").focus();

    }catch(e){
        if(e.name!=="AbortError")
            $("homeMsg").textContent=e.message;
    }
}

async function createContainer(){
    const ps=passwords(
        $("createPass").value
    );

    if(!ps){
        $("createMsg").textContent=
            "Enter a valid password.";
        return;
    }

    if(
        $("createPass").value!==
        $("createConfirm").value
    ){
        $("createMsg").textContent=
            "Passwords do not match.";
        return;
    }

    try{
        if(!rootHandle){
            rootHandle=
                await showDirectoryPicker({
                    mode:"readwrite"
                });

            await permission(rootHandle);
        }

        await initializeContainer(ps);

        hide($("createModal"));

        enter();

    }catch(e){
        $("createMsg").textContent=
            "Could not create the container: "+
            e.message;
    }
}

async function unlock(){
    try{
        await unlockContainer(
            $("unlockPass").value
        );

        hide($("unlockModal"));

        $("unlockPass").value="";
        $("unlockMsg").textContent="";

        enter();

    }catch(e){
        $("unlockMsg").textContent=
            "Incorrect password or unreadable file.";
    }
}

function enter(){
    hide($("home"));
    show($("app"));
    show($("lock"));

    setStatus("file.file");

    cwd=[];
    backStack=[];
    forwardStack=[];

    clearSelection();
    render();
}

async function permission(h){
    if(
        h.queryPermission &&
        await h.queryPermission({
            mode:"readwrite"
        })!=="granted"
    ){
        if(
            await h.requestPermission({
                mode:"readwrite"
            })!=="granted"
        ){
            throw Error("Permission denied");
        }
    }
}

async function importFiles(files){
    if(!files.length)
        return;

    const total=files.length;
    let done=0;
    let bytesDone=0;

    const totalBytes=[...files]
        .reduce((a,f)=>a+f.size,0);

    showProgress(
        "Importing files",
        total
    );

    try{
        for(const f of files){
            const rel=
                f.webkitRelativePath ||
                f.name;

            const base=bytesDone;

            await importOneFile(
                f,
                rel,
                doneBytes=>{
                    progress(
                        done,
                        total,
                        rel,
                        base+doneBytes,
                        totalBytes
                    );
                }
            );

            bytesDone+=f.size;
            done++;

            progress(
                done,
                total,
                rel,
                bytesDone,
                totalBytes
            );
        }

        /*
         * This used to throw because saveIndex()
         * was missing.
         */
        await saveIndex();

        render();
        finishProgress();

    }catch(e){
        console.error("File import failed:",e);

        failProgress(
            e?.message ||
            "An unknown error occurred."
        );
    }
}

async function importOneFile(file,rel,cb){
    const parts=rel
        .split("/")
        .filter(Boolean);

    const name=parts.pop();

    let n=currentDir();

    for(const part of parts){
        if(!n.children[part]){
            n.children[part]={
                type:"dir",
                name:part,
                children:{},
                created:Date.now()
            };
        }

        n=n.children[part];
    }

    const final=unique(n,name);

    const node={
        type:"file",
        name:final,
        size:file.size,
        mime:file.type||
            "application/octet-stream",
        chunks:[],
        created:Date.now()
    };

    n.children[final]=node;

    let pos=0;

    while(pos<file.size){
        const end=Math.min(
            pos+CHUNK,
            file.size
        );

        const buf=new Uint8Array(
            await file
                .slice(pos,end)
                .arrayBuffer()
        );

        const c=
            await appendEncryptedChunk(
                buf,
                activeSide
            );

        node.chunks.push(c);

        pos=end;

        cb?.(pos);
    }
}

async function importFolder(){
    try{
        const h=
            await showDirectoryPicker({
                mode:"read"
            });

        const entries=[];

        await collect(
            h,
            [],
            entries
        );

        if(!entries.length){
            alert("The selected folder is empty.");
            return;
        }

        showProgress(
            "Importing folder",
            entries.length
        );

        let i=0;

        for(const x of entries){
            const f=
                await x.handle.getFile();

            await importOneFile(
                f,
                x.path.join("/"),
                doneBytes=>{
                    progress(
                        i,
                        entries.length,
                        x.path.join("/"),
                        doneBytes,
                        f.size
                    );
                }
            );

            i++;

            progress(
                i,
                entries.length,
                x.path.join("/")
            );
        }

        await saveIndex();

        render();
        finishProgress();

    }catch(e){
        console.error("Folder import failed:",e);

        if(e.name!=="AbortError"){
            failProgress(
                e?.message ||
                "Folder import failed."
            );
        }else{
            hide($("progressModal"));
        }
    }
}

async function collect(h,p,out){
    for await(const [name,x] of h.entries()){
        if(
            p.length===0 &&
            name==="file.file"
        ){
            continue;
        }

        if(x.kind==="file"){
            out.push({
                handle:x,
                path:[...p,name]
            });
        }else{
            await collect(
                x,
                [...p,name],
                out
            );
        }
    }
}

async function exportNode(n,name){
    try{
        const chunks=[];

        for(const c of n.chunks){
            chunks.push(
                await readChunk(c)
            );
        }

        const blob=new Blob(
            chunks,
            {
                type:
                    n.mime ||
                    "application/octet-stream"
            }
        );

        const a=document.createElement("a");

        a.href=
            URL.createObjectURL(blob);

        a.download=name;

        a.click();

        setTimeout(()=>{
            URL.revokeObjectURL(a.href);
        },2000);

    }catch(e){
        alert(
            "Export failed: "+
            e.message
        );
    }
}

async function renameSelected(){
    if(!selectedNode)
        return;

    const old=selectedPath.at(-1);

    const n=prompt(
        "New name:",
        old
    );

    if(!validName(n)||n===old)
        return;

    const d=parentNode(selectedPath);
    const name=unique(d,n);

    d.children[name]=d.children[old];
    d.children[name].name=name;

    delete d.children[old];

    clearSelection();

    await saveIndex();
    render();
}

async function deleteSelected(){
    if(
        !selectedNode ||
        !confirm(
            "Delete "+
            selectedPath.at(-1)+
            "?"
        )
    ){
        return;
    }

    delete parentNode(selectedPath)
        .children[selectedPath.at(-1)];

    clearSelection();

    await saveIndex();
    render();
}

function openMenu(x,y){
    const m=$("menu");

    m.style.left=
        Math.min(
            x,
            innerWidth-190
        )+"px";

    m.style.top=
        Math.min(
            y,
            innerHeight-160
        )+"px";

    show(m);
}

function closeMenu(){
    hide($("menu"));
}

$("openBtn").onclick=choose;

$("createBtn").onclick=async()=>{
    try{
        rootHandle=
            await showDirectoryPicker({
                mode:"readwrite"
            });

        await permission(rootHandle);

        show($("createModal"));

        $("createPass").focus();

    }catch(e){}
};

$("createGo").onclick=createContainer;
$("unlockGo").onclick=unlock;

$("newFileBtn").onclick=()=>{
    show($("newFileModal"));
    $("newFileName").focus();
};

$("newFolderBtn").onclick=()=>{
    show($("newFolderModal"));
    $("newFolderName").focus();
};

$("newFileGo").onclick=createNewFile;
$("newFolderGo").onclick=createNewFolder;

$("importFilesBtn").onclick=()=>{
    const i=document.createElement("input");

    i.type="file";
    i.multiple=true;

    i.onchange=async()=>{
        try{
            await importFiles(
                [...i.files]
            );
        }catch(e){
            console.error(e);
        }
    };

    i.click();
};

$("importFolderBtn").onclick=
    importFolder;

$("renameBtn").onclick=
    renameSelected;

$("deleteBtn").onclick=
    deleteSelected;

$("exportBtn").onclick=()=>{
    if(selectedNode)
        exportNode(
            selectedNode,
            selectedPath.at(-1)
        );
};

$("refreshBtn").onclick=render;

$("upBtn").onclick=()=>{
    if(cwd.length)
        navigate(
            cwd.slice(0,-1)
        );
};

$("backBtn").onclick=()=>{
    if(backStack.length){
        forwardStack.push([...cwd]);
        cwd=backStack.pop();

        clearSelection();
        render();
    }
};

$("forwardBtn").onclick=()=>{
    if(forwardStack.length){
        backStack.push([...cwd]);
        cwd=forwardStack.pop();

        clearSelection();
        render();
    }
};

$("saveEdit").onclick=async()=>{
    try{
        const bytes=
            te.encode(
                $("editor").value
            );

        editing.size=bytes.length;
        editing.mime="text/plain";
        editing.chunks=[];

        for(
            let p=0;
            p<bytes.length;
            p+=CHUNK
        ){
            editing.chunks.push(
                await appendEncryptedChunk(
                    bytes.slice(
                        p,
                        p+CHUNK
                    ),
                    activeSide
                )
            );
        }

        hide($("editorModal"));

        await saveIndex();
        render();

    }catch(e){
        $("editorMsg").textContent=
            "Save failed: "+
            e.message;
    }
};

$("exportEdit").onclick=()=>{
    const blob=new Blob(
        [
            te.encode(
                $("editor").value
            )
        ],
        {
            type:"text/plain"
        }
    );

    const a=document.createElement("a");

    a.href=
        URL.createObjectURL(blob);

    a.download=
        $("editorTitle").textContent;

    a.click();

    setTimeout(()=>{
        URL.revokeObjectURL(a.href);
    },1000);
};

$("menuOpen").onclick=()=>{
    closeMenu();

    if(selectedNode?.type==="dir"){
        navigate(selectedPath);
    }else if(selectedNode){
        openFile(
            selectedPath,
            selectedNode
        );
    }
};

$("menuRename").onclick=()=>{
    closeMenu();
    renameSelected();
};

$("menuDelete").onclick=()=>{
    closeMenu();
    deleteSelected();
};

$("menuExport").onclick=()=>{
    closeMenu();

    if(selectedNode?.type==="file"){
        exportNode(
            selectedNode,
            selectedPath.at(-1)
        );
    }
};

document.addEventListener(
    "click",
    e=>{
        if(!e.target.closest("#menu"))
            closeMenu();
    }
);

document
    .querySelectorAll(".cancel")
    .forEach(x=>{
        x.onclick=()=>{
            x.closest(".modal")
             .classList
             .add("hidden");
        };
    });

$("lock").onclick=()=>{
    sessionKey=null;
    fs=null;
    containerHandle=null;
    cwd=[];

    clearSelection();

    hide($("app"));
    hide($("lock"));
    show($("home"));

    setStatus(
        "No container open"
    );
};

$("unlockPass").onkeydown=e=>{
    if(e.key==="Enter")
        unlock();
};

$("createConfirm").onkeydown=e=>{
    if(e.key==="Enter")
        createContainer();
};

if(!window.showDirectoryPicker){
    $("homeMsg").textContent=
        "Use a current Chromium-based browser with local folder access.";
}
</script>
</body>
</html>
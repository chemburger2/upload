<?php

require_once __DIR__ . '/../../config.php';

if (empty($_SESSION['is_admin'])) {
    header('Location: ../../manage.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Encore Music Player</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

:root {
    --bg: #121214;
    --panel: #1e1e24;
    --panel-2: #18181d;
    --border: #29292e;
    --text: #e1e1e6;
    --muted: #a8a8b3;
    --muted-2: #737380;
    --accent: #8257e5;
    --accent-hover: #996dff;
    --danger: #d04444;
    --sidebar-bg: #18181d;
    --button-hover: #35353c;
    --card-hover: #232329;
    --card-active: #29292e;
    --track-border-hover: #44444c;
    --button-bg: #29292e;
    --topbar-bg: rgba(18,18,20,.92);
    --player-bg: rgba(24,24,29,.97);
    --visualizer-bg: #121214;
    --welcome-start: #1e1e24;
    --welcome-end: #18181d;
    --input-bg: #1e1e24;
    --link-hover: #ffffff;
    --button-text: #ffffff;
    --modal-backdrop: rgba(0,0,0,.65);
    --shadow-color: rgba(0,0,0,.30);
    --subtle-shadow-color: rgba(0,0,0,.08);
    --focus-ring: color-mix(in srgb, var(--accent) 35%, transparent);
    --selection-bg: color-mix(in srgb, var(--accent) 28%, transparent);
}

.welcome-folder-buttons {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}

.welcome-folder-buttons .welcome-button {
    margin: 0;
}

.welcome-folder-buttons .welcome-button.hidden {
    display: none;
}

body {
    background: var(--bg);
    color: var(--text);
    font-family:
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        Roboto,
        Helvetica,
        Arial,
        sans-serif;

    min-height: 100vh;
}

button,
input,
select,
textarea {
    font: inherit;
}

button {
    cursor: pointer;
}

button:disabled {
    opacity: .45;
    cursor: not-allowed;
}

.hidden {
    display: none !important;
}


/* =========================
   APP
========================= */

.app {
    min-height: 100vh;
    height: 100vh;
    display: grid;
    grid-template-columns: 300px 1fr;
    overflow: hidden;
}


/* =========================
   SIDEBAR
========================= */

.sidebar {
    background: var(--sidebar-bg);
    border-right: 1px solid var(--border);

    display: flex;
    flex-direction: column;

    min-height: 100vh;
    height: 100vh;
    overflow-y: auto;
    overflow-x: hidden;
    overscroll-behavior: contain;
}

.sidebar-header {
    padding: 22px;
    border-bottom: 1px solid var(--border);
}

.logo {
    font-size: 1.35rem;
    font-weight: 800;
}

.logo span {
    color: var(--accent);
}

.sidebar-actions {
    padding: 15px;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.sidebar-button {
    width: 100%;
    border: none;
    border-radius: 8px;
    padding: 11px 14px;

    background: var(--card-active);
    color: var(--text);

    font-weight: 600;
    text-align: left;
}

.sidebar-button:hover {
    background: var(--button-hover);
}

.sidebar-button.primary {
    background: var(--accent);
    color: var(--button-text);
}

.sidebar-button.primary:hover {
    background: var(--accent-hover);
}

.sidebar-nav {
    padding: 0 15px 15px;
}

.nav-item {
    width: 100%;
    padding: 10px 12px;

    border: none;
    border-radius: 7px;

    background: transparent;
    color: var(--muted);

    text-align: left;
}

.nav-item:hover,
.nav-item.active {
    background: var(--card-active);
    color: var(--text);
}

.library-title {
    padding: 8px 20px;
    color: var(--muted-2);
    font-size: .75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.sidebar-list {
    list-style: none;
    padding: 0 15px 20px;
}

.sidebar-list li {
    padding: 9px 10px;
    border-radius: 6px;

    color: var(--muted);
    font-size: .9rem;

    cursor: pointer;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sidebar-list li:hover {
    background: var(--card-hover);
    color: var(--text);
}

.sidebar-footer {
    padding: 15px;
    border-top: 1px solid var(--border);
}

.sidebar-footer a {
    color: var(--muted);
    text-decoration: none;
    font-size: .85rem;
}

.sidebar-footer a:hover {
    color: var(--button-text);
}


/* =========================
   MAIN
========================= */

.main {
    min-width: 0;
    height: 100vh;
    overflow-y: auto;
    overflow-x: hidden;
    padding-bottom: 150px;
}

.topbar {
    height: 72px;

    display: flex;
    align-items: center;
    gap: 15px;

    padding: 0 25px;

    border-bottom: 1px solid var(--border);
    background: var(--topbar-bg);

    position: sticky;
    top: 0;
    z-index: 30;

    backdrop-filter: blur(15px);
}

.search {
    flex: 1;

    background: var(--input-bg);
    border: 1px solid var(--border);
    color: var(--text);

    padding: 11px 14px;
    border-radius: 8px;

    outline: none;
}

.search:focus {
    border-color: var(--accent);
}

.topbar-buttons {
    display: flex;
    gap: 8px;
}

.icon-button {
    width: 40px;
    height: 40px;

    border: none;
    border-radius: 8px;

    background: var(--card-active);
    color: var(--text);
}

.icon-button:hover {
    background: var(--button-hover);
}

.content {
    padding: 28px;
    max-width: 1500px;
    margin: 0 auto;
}


/* =========================
   WELCOME
========================= */

.welcome {
    min-height: 380px;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    text-align: center;

    background: linear-gradient(
        145deg,
        var(--welcome-start),
        var(--welcome-end)
    );

    border: 1px solid var(--border);
    border-radius: 16px;

    padding: 40px;
}

.welcome h1 {
    font-size: clamp(2rem, 5vw, 3.5rem);
    margin-bottom: 10px;
}

.welcome p {
    color: var(--muted);
    max-width: 600px;
    line-height: 1.6;
    margin-bottom: 25px;
}

.welcome-button {
    border: none;
    border-radius: 9px;

    padding: 13px 22px;

    background: var(--accent);
    color: var(--button-text);

    font-weight: 700;
}

.welcome-button:hover {
    background: var(--accent-hover);
}


/* =========================
   PAGE HEADERS
========================= */

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    gap: 15px;
    margin-bottom: 20px;
}

.page-header h1 {
    font-size: 1.7rem;
}

.page-header p {
    color: var(--muted);
    margin-top: 4px;
}

.header-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}


/* =========================
   BUTTONS
========================= */

.button {
    border: none;
    border-radius: 8px;

    background: var(--card-active);
    color: var(--text);

    padding: 10px 14px;

    font-weight: 600;
}

.button:hover {
    background: var(--button-hover);
}

.button.primary {
    background: var(--accent);
    color: var(--button-text);
}

.button.primary:hover {
    background: var(--accent-hover);
}

.button.danger {
    background: var(--danger);
    color: var(--button-text);
}

.button.small {
    padding: 7px 10px;
    font-size: .82rem;
}


/* =========================
   CARDS
========================= */

.card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 18px;
}

.card + .card {
    margin-top: 15px;
}


/* =========================
   TRACK GRID
========================= */

.track-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
    gap: 15px;
}

.track-card {
    background: var(--panel);
    border: 1px solid var(--border);

    border-radius: 10px;
    overflow: hidden;

    cursor: pointer;

    transition:
        transform .15s,
        border-color .15s;
}

.track-card:hover {
    transform: translateY(-2px);
    border-color: var(--track-border-hover);
}

.track-art {
    width: 100%;
    aspect-ratio: 1;
    background: var(--card-active);

    display: flex;
    align-items: center;
    justify-content: center;

    color: var(--muted-2);
    font-size: 2.5rem;
}

.track-art img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.track-info {
    padding: 12px;
}

.track-name {
    font-weight: 700;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.track-subtitle {
    color: var(--muted);
    font-size: .82rem;

    margin-top: 4px;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}


/* =========================
   LIST
========================= */

.track-list {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 12px;
    overflow: hidden;
}

.track-row {
    display: grid;

    grid-template-columns:
        45px
        minmax(150px, 1fr)
        minmax(100px, .7fr)
        90px
        100px;

    gap: 10px;

    align-items: center;

    padding: 10px 14px;

    border-bottom: 1px solid var(--border);
}

.track-row:last-child {
    border-bottom: none;
}

.track-row:hover {
    background: var(--card-hover);
}

.track-row.active {
    background: var(--card-active);
}

.track-number {
    color: var(--muted-2);
}

.row-title {
    min-width: 0;
}

.row-title strong,
.row-title span {
    display: block;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.row-title span {
    color: var(--muted);
    font-size: .8rem;
    margin-top: 3px;
}

.row-muted {
    color: var(--muted);
    font-size: .85rem;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.row-actions {
    display: flex;
    justify-content: flex-end;
    gap: 5px;
}


/* =========================
   PLAYER
========================= */

.player {
    position: fixed;

    left: 300px;
    right: 0;
    bottom: 0;

    height: 115px;

    background: var(--player-bg);
    border-top: 1px solid var(--border);

    backdrop-filter: blur(20px);

    z-index: 50;

    display: grid;

    grid-template-columns:
        260px
        minmax(300px, 1fr)
        250px;

    gap: 20px;

    align-items: center;

    padding: 15px 22px;
}

.player-track {
    min-width: 0;

    display: flex;
    align-items: center;
    gap: 12px;
}

.player-art {
    width: 58px;
    height: 58px;

    flex-shrink: 0;

    border-radius: 6px;

    background: var(--card-active);

    display: flex;
    align-items: center;
    justify-content: center;

    overflow: hidden;
}

.player-art img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.player-track-info {
    min-width: 0;
}

.player-track-title {
    font-weight: 700;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.player-track-artist {
    color: var(--muted);
    font-size: .82rem;

    margin-top: 3px;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.player-main {
    min-width: 0;
}

.progress {
    display: flex;
    align-items: center;
    gap: 9px;

    font-size: .75rem;
    color: var(--muted);
}

input[type="range"] {
    width: 100%;
    accent-color: var(--accent);
    cursor: pointer;
}

.player-controls {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;

    margin-bottom: 8px;
}

.player-button {
    width: 35px;
    height: 35px;

    border: none;
    border-radius: 50%;

    background: var(--card-active);
    color: var(--text);

    display: flex;
    align-items: center;
    justify-content: center;
}

.player-button:hover {
    background: var(--button-hover);
}

.player-button.active {
    color: var(--accent);
}

.player-button.play {
    width: 46px;
    height: 46px;

    background: var(--accent);
    color: var(--button-text);
}

.player-button.play:hover {
    background: var(--accent-hover);
}

.player-right {
    display: flex;
    align-items: center;
    gap: 10px;
}

.volume {
    flex: 1;
}


/* =========================
   NOW PLAYING
========================= */

.now-playing {
    display: grid;
    grid-template-columns: 340px 1fr;
    gap: 35px;

    background: var(--panel);

    border: 1px solid var(--border);
    border-radius: 16px;

    padding: 30px;

    min-height: 500px;
}

.large-art {
    aspect-ratio: 1;

    background: var(--card-active);

    border-radius: 12px;

    display: flex;
    align-items: center;
    justify-content: center;

    overflow: hidden;
}

.large-art img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.large-art-placeholder {
    font-size: 5rem;
    color: var(--muted-2);
}

.now-playing-details {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.now-playing-label {
    color: var(--muted);
    font-size: .85rem;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.now-playing-title {
    font-size: clamp(1.8rem, 4vw, 3rem);
    font-weight: 800;

    margin-top: 7px;

    word-break: break-word;
}

.now-playing-artist {
    color: var(--muted);
    font-size: 1.1rem;
    margin-top: 7px;
}

.detail-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;

    margin-top: 25px;
}


/* =========================
   VISUALIZER
========================= */

.visualizer {
    width: 100%;
    height: 130px;

    background: var(--visualizer-bg);
    border: 1px solid var(--border);

    border-radius: 10px;

    margin-top: 20px;
}


/* =========================
   PANELS / SETTINGS
========================= */

.settings-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 15px;
}

.setting {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px;
}

.setting h3 {
    font-size: 1rem;
    margin-bottom: 6px;
}

.setting p {
    color: var(--muted);
    font-size: .85rem;
    line-height: 1.5;
    margin-bottom: 12px;
}

.setting select,
.setting input[type="text"],
.setting input[type="number"] {
    width: 100%;

    background: var(--visualizer-bg);
    color: var(--text);

    border: 1px solid var(--border);
    border-radius: 7px;

    padding: 9px;
}

.checkbox-row {
    display: flex;
    align-items: center;
    gap: 8px;

    color: var(--muted);
    font-size: .9rem;

    margin-top: 8px;
}


/* =========================
   EQ
========================= */

.eq {
    display: grid;
    grid-template-columns: repeat(10, 1fr);
    gap: 10px;

    align-items: end;

    min-height: 260px;
}

.eq-band {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;

    height: 220px;
}

.eq-band input {
    writing-mode: vertical-lr;
    direction: rtl;

    height: 180px;
}

.eq-band span {
    font-size: .72rem;
    color: var(--muted);
}


/* =========================
   MODAL
========================= */

.modal-backdrop {
    position: fixed;

    inset: 0;

    background: var(--modal-backdrop);

    display: flex;
    align-items: center;
    justify-content: center;

    z-index: 100;

    padding: 20px;
}

.modal {
    width: 100%;
    max-width: 600px;

    max-height: 90vh;
    overflow-y: auto;

    background: var(--panel);

    border: 1px solid var(--border);
    border-radius: 14px;

    padding: 22px;
}

.modal h2 {
    margin-bottom: 15px;
}

.modal textarea {
    width: 100%;
    min-height: 180px;

    background: var(--visualizer-bg);
    color: var(--text);

    border: 1px solid var(--border);
    border-radius: 8px;

    padding: 12px;

    resize: vertical;
}

.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;

    margin-top: 15px;
}


/* =========================
   TOAST
========================= */

.toast-container {
    position: fixed;

    right: 20px;
    top: 85px;

    z-index: 200;

    display: flex;
    flex-direction: column;
    gap: 8px;
}

.toast {
    background: var(--card-active);
    color: var(--text);

    border: 1px solid var(--border);

    border-radius: 8px;

    padding: 11px 15px;

    box-shadow: 0 10px 30px var(--shadow-color);

    animation: toastIn .2s ease;
}

@keyframes toastIn {
    from {
        transform: translateY(-8px);
        opacity: 0;
    }

    to {
        transform: translateY(0);
        opacity: 1;
    }
}


/* =========================
   COMMAND PALETTE
========================= */

.command-list {
    margin-top: 12px;
}

.command-item {
    padding: 11px 12px;

    border-radius: 7px;

    cursor: pointer;

    display: flex;
    justify-content: space-between;
}

.command-item:hover,
.command-item.selected {
    background: var(--card-active);
}

.command-key {
    color: var(--muted);
    font-size: .8rem;
}


/* =========================
   QUEUE
========================= */

.queue-list {
    list-style: none;
}

.queue-item {
    display: flex;
    justify-content: space-between;
    align-items: center;

    gap: 10px;

    padding: 10px;

    border-bottom: 1px solid var(--border);
}

.queue-item:last-child {
    border-bottom: none;
}

.queue-item-title {
    min-width: 0;
}

.queue-item-title strong,
.queue-item-title span {
    display: block;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.queue-item-title span {
    color: var(--muted);
    font-size: .8rem;
}


/* =========================
   LYRICS
========================= */

.lyrics {
    white-space: pre-wrap;

    color: var(--muted);

    line-height: 1.8;

    text-align: center;

    max-height: 400px;

    overflow-y: auto;

    padding: 15px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 1100px) {

    .app {
        grid-template-columns: 230px 1fr;
    }

    .player {
        left: 230px;
        grid-template-columns: 220px 1fr 180px;
    }

    .now-playing {
        grid-template-columns: 260px 1fr;
    }
}

@media (max-width: 800px) {

    .app {
        display: block;
    }

    .app {
        height: auto;
        min-height: 100vh;
        overflow: visible;
    }

    .sidebar {
        min-height: auto;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--border);
    }

    .main {
        height: auto;
        overflow: visible;
    }

    .sidebar-list {
        max-height: 150px;
    }

    .main {
        padding-bottom: 230px;
    }

    .player {
        left: 0;
        height: auto;

        grid-template-columns: 1fr;

        gap: 10px;

        padding: 12px;
    }

    .player-right {
        display: none;
    }

    .now-playing {
        grid-template-columns: 1fr;
    }

    .large-art {
        max-width: 350px;
        width: 100%;
        margin: auto;
    }

    .track-row {
        grid-template-columns: 35px 1fr 80px;
    }

    .track-row > :nth-child(3),
    .track-row > :nth-child(4) {
        display: none;
    }

    .content {
        padding: 15px;
    }

    .topbar {
        padding: 0 15px;
    }
}


.icon-sprite { position:absolute; width:0; height:0; overflow:hidden; }
.icon { width:1.05em; height:1.05em; display:inline-block; vertical-align:-0.16em; fill:none; stroke:currentColor; stroke-width:1.8; stroke-linecap:round; stroke-linejoin:round; flex-shrink:0; }
.button, .sidebar-button, .nav-item, .icon-button, .player-button { display:inline-flex; align-items:center; gap:8px; }
.nav-item { justify-content:flex-start; }
.album-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(210px,1fr)); gap:16px; }
.album-grid.album-size-compact { grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); }
.album-grid.album-size-large { grid-template-columns:repeat(auto-fill,minmax(270px,1fr)); }
.album-list { display:flex; flex-direction:column; gap:10px; }
.album-list .album-card { display:flex; align-items:center; }
.album-list .album-art { width:96px; min-width:96px; height:96px; aspect-ratio:auto; }
.album-list .album-info { flex:1; min-width:0; }
.album-list .album-actions { width:220px; margin-top:0; }
.album-list.album-size-compact .album-art { width:72px; min-width:72px; height:72px; }
.album-list.album-size-large .album-art { width:128px; min-width:128px; height:128px; }
@media (max-width:700px) { .album-list .album-actions { width:auto; } }
.album-card { background:var(--panel); border:1px solid var(--border); border-radius:12px; overflow:hidden; transition:transform .15s,border-color .15s; }
.album-card:hover { transform:translateY(-2px); border-color:var(--track-border-hover); }
.album-art { width:100%; aspect-ratio:1; background:var(--card-active); display:flex; align-items:center; justify-content:center; color:var(--muted-2); overflow:hidden; }
.album-art img { width:100%; height:100%; object-fit:cover; }
.album-art-placeholder { width:64px; height:64px; }
.album-art-placeholder .icon { width:100%; height:100%; }
.album-info { padding:13px; }
.album-title { font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.album-meta { color:var(--muted); font-size:.82rem; margin-top:4px; }
.album-actions { display:flex; flex-wrap:wrap; gap:7px; margin-top:11px; }
.album-actions .button { flex:1 1 calc(50% - 4px); min-width:0; justify-content:center; white-space:nowrap; overflow:hidden; }
.album-actions .album-ai-button { flex-basis:100%; }
.album-loading { padding:30px; text-align:center; color:var(--muted); }


/* =========================
   MUSICBRAINZ ALBUM PICKER
========================= */

.musicbrainz-wide-modal {
    max-width: 1100px !important;
}

.ai-cleanup-modal {
    max-width: 1050px !important;
}

.ai-cleanup-source {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
    margin: 12px 0 18px;
}

.ai-cleanup-stat {
    background: var(--panel-2);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px;
}

.ai-cleanup-stat strong {
    display: block;
    color: var(--muted-2);
    font-size: .72rem;
    text-transform: uppercase;
    letter-spacing: .06em;
    margin-bottom: 4px;
}

.ai-cleanup-fields {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 16px;
}

.ai-cleanup-field label {
    display: block;
    color: var(--muted);
    font-size: .8rem;
    margin-bottom: 5px;
}

.ai-cleanup-field input {
    width: 100%;
    padding: 10px 11px;
    background: var(--input-bg);
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 7px;
    outline: none;
}

.ai-cleanup-field input:focus {
    border-color: var(--accent);
}

.ai-cleanup-field-note {
    margin-top: 5px;
    color: var(--muted-2);
    font-size: .75rem;
    line-height: 1.35;
}

.ai-cleanup-songs {
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: auto;
    max-height: 48vh;
}

.ai-cleanup-song {
    display: grid;
    grid-template-columns: 62px 85px minmax(180px, .85fr) minmax(180px, 1fr) minmax(180px, 1fr);
    gap: 10px;
    align-items: center;
    padding: 8px 10px;
    border-bottom: 1px solid var(--border);
    min-width: 760px;
}

.ai-cleanup-song:last-child {
    border-bottom: none;
}

.ai-cleanup-song-head {
    background: var(--panel-2);
    color: var(--muted);
    font-size: .75rem;
    font-weight: 700;
}

.ai-cleanup-song input {
    width: 100%;
    min-width: 0;
    padding: 8px 9px;
    background: var(--input-bg);
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 6px;
}

.ai-cleanup-original {
    color: var(--muted);
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.ai-cleanup-source-index {
    color: var(--muted);
    font-variant-numeric: tabular-nums;
    text-align: center;
}

.ai-cleanup-note {
    color: var(--muted);
    font-size: .82rem;
    line-height: 1.5;
    margin-bottom: 12px;
}

@media (max-width: 800px) {
    .ai-cleanup-source,
    .ai-cleanup-fields {
        grid-template-columns: 1fr 1fr;
    }

    .ai-cleanup-song {
        grid-template-columns: 52px 75px 1fr;
        min-width: 0;
    }

    .ai-cleanup-song-head {
        display: none;
    }

    .ai-cleanup-song > div:nth-child(3) {
        grid-column: 3;
    }

    .ai-cleanup-song > [data-ai-title],
    .ai-cleanup-song > [data-ai-artist] {
        grid-column: 3;
    }
}

.musicbrainz-album-grid {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 10px;
}

.musicbrainz-album-option {
    min-width: 0;
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 8px;
    background: var(--panel-2);
    color: var(--text);
    text-align: left;
    cursor: pointer;
    transition: transform .15s ease, border-color .15s ease, background .15s ease;
}

.musicbrainz-album-option:hover {
    transform: translateY(-2px);
    border-color: var(--accent);
    background: var(--card-active);
}

.musicbrainz-cover {
    width: 100%;
    aspect-ratio: 1;
    border-radius: 7px;
    overflow: hidden;
    background: var(--card-active);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--muted-2);
}

.musicbrainz-cover img,
.musicbrainz-selected-cover img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.musicbrainz-title {
    display: block;
    margin-top: 7px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.musicbrainz-meta {
    display: block;
    margin-top: 3px;
    color: var(--muted);
    font-size: .72rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.musicbrainz-confirm {
    display: grid;
    grid-template-columns: 180px 1fr;
    gap: 20px;
    align-items: start;
}

.musicbrainz-selected-cover {
    width: 180px;
    aspect-ratio: 1;
    border-radius: 10px;
    overflow: hidden;
    background: var(--card-active);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--muted-2);
}

.metadata-preview-row {
    display: flex;
    flex-direction: column;
    gap: 3px;
    margin-bottom: 12px;
}

.metadata-preview-row span {
    color: var(--muted);
}

.metadata-update-options {
    border-top: 1px solid var(--border);
    margin-top: 16px;
    padding-top: 14px;
    display: flex;
    flex-direction: column;
    gap: 9px;
}

.metadata-update-options label {
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--muted);
    font-size: .85rem;
}

.musicbrainz-song-list {
    max-height: 230px;
    overflow-y: auto;
    border: 1px solid var(--border);
    border-radius: 8px;
}

.musicbrainz-song-row {
    display: grid;
    grid-template-columns: 1fr 25px 1fr;
    gap: 8px;
    padding: 9px 10px;
    border-bottom: 1px solid var(--border);
    font-size: .8rem;
}

.musicbrainz-arrow {
    text-align: center;
    color: var(--muted-2);
}

.musicbrainz-match {
    color: var(--muted);
}

@media (max-width: 800px) {
    .musicbrainz-album-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .musicbrainz-confirm {
        grid-template-columns: 1fr;
    }

    .musicbrainz-selected-cover {
        width: 220px;
        max-width: 100%;
        margin: 0 auto;
    }
}



/* Theme-aware native controls and browser-rendered surfaces */
html[data-theme="light"] { color-scheme: light; }
html[data-theme="dark"], html[data-theme="purple"], html[data-theme="midnight"] { color-scheme: dark; }

select,
input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),
textarea {
    background-color: var(--input-bg);
    color: var(--text);
    border-color: var(--border);
}

select option {
    background: var(--panel);
    color: var(--text);
}

input::placeholder, textarea::placeholder {
    color: var(--muted-2);
}

.sidebar-footer a:hover { color: var(--link-hover); }

.welcome-button, .button.primary, .sidebar-button.primary, .player-button.play {
    color: var(--button-text);
}

html[data-theme="light"] .topbar { box-shadow: 0 1px 8px var(--subtle-shadow-color); }
html[data-theme="light"] .player { box-shadow: 0 -2px 12px var(--subtle-shadow-color); }
html[data-theme="light"] .setting input[type="color"] { background: var(--panel); }

/* Complete theme-aware surfaces */
::selection {
    background: var(--selection-bg);
    color: var(--text);
}

button:focus-visible,
input:focus-visible,
select:focus-visible,
textarea:focus-visible,
[contenteditable="true"]:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
}

input[type="range"] {
    accent-color: var(--accent);
}

input[type="checkbox"],
input[type="radio"] {
    accent-color: var(--accent);
}

html {
    scrollbar-color: var(--border) var(--bg);
}

html[data-theme="light"] {
    scrollbar-color: var(--border) var(--bg);
}

html[data-theme="light"] .track-row:hover,
html[data-theme="light"] .album-card:hover {
    background: var(--card-hover);
}

html[data-theme="light"] .button:hover,
html[data-theme="light"] .sidebar-button:hover,
html[data-theme="light"] .icon-button:hover,
html[data-theme="light"] .player-button:hover {
    background: var(--button-hover);
}

html[data-theme="light"] .button.primary:hover,
html[data-theme="light"] .sidebar-button.primary:hover,
html[data-theme="light"] .player-button.play:hover {
    background: var(--accent-hover);
}

</style>
</head>

<body>
<svg class="icon-sprite" aria-hidden="true" focusable="false">
    <symbol id="i-folder" viewBox="0 0 24 24"><path d="M3 6.5A2.5 2.5 0 0 1 5.5 4H10l2 2h6.5A2.5 2.5 0 0 1 21 8.5v9A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5z"/></symbol>
    <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
    <symbol id="i-music" viewBox="0 0 24 24"><path d="M9 18V5l11-2v13M9 18a3 3 0 1 1-3-3 3 3 0 0 1 3 3Zm11-2a3 3 0 1 1-3-3 3 3 0 0 1 3 3Z"/></symbol>
    <symbol id="i-star" viewBox="0 0 24 24"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9z"/></symbol>
    <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></symbol>
    <symbol id="i-chart" viewBox="0 0 24 24"><path d="M4 19V9M10 19V5M16 19v-8M22 19V3"/></symbol>
    <symbol id="i-playlist" viewBox="0 0 24 24"><path d="M4 6h11M4 12h11M4 18h7M18 13v7M15 17h6"/></symbol>
    <symbol id="i-queue" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h10"/></symbol>
    <symbol id="i-play" viewBox="0 0 24 24"><path d="m8 5 11 7-11 7z"/></symbol>
    <symbol id="i-pause" viewBox="0 0 24 24"><path d="M7 5v14M17 5v14"/></symbol>
    <symbol id="i-prev" viewBox="0 0 24 24"><path d="M6 5v14M19 6l-9 6 9 6z"/></symbol>
    <symbol id="i-next" viewBox="0 0 24 24"><path d="M18 5v14M5 6l9 6-9 6z"/></symbol>
    <symbol id="i-rewind" viewBox="0 0 24 24"><path d="m13 7-7 5 7 5M19 7l-7 5 7 5"/></symbol>
    <symbol id="i-forward" viewBox="0 0 24 24"><path d="m11 7 7 5-7 5M5 7l7 5-7 5"/></symbol>
    <symbol id="i-shuffle" viewBox="0 0 24 24"><path d="M4 7h3c4 0 6 10 10 10h3M17 5l3 2-3 2M17 15l3 2-3 2M4 17h3c1.5 0 2.5-.7 3.3-1.7M10.7 8.7C11.5 7.7 12.5 7 14 7h3"/></symbol>
    <symbol id="i-repeat" viewBox="0 0 24 24"><path d="M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3"/></symbol>
    <symbol id="i-volume" viewBox="0 0 24 24"><path d="M4 10v4h4l5 4V6l-5 4zM17 9a5 5 0 0 1 0 6M19.5 6.5a9 9 0 0 1 0 11"/></symbol>
    <symbol id="i-command" viewBox="0 0 24 24"><circle cx="7" cy="7" r="3"/><circle cx="17" cy="17" r="3"/><path d="M10 7h4a3 3 0 0 1 3 3v4M14 17h-4a3 3 0 0 1-3-3v-4"/></symbol>
    <symbol id="i-settings" viewBox="0 0 24 24"><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/><circle cx="12" cy="12" r="4"/></symbol>
    <symbol id="i-eq" viewBox="0 0 24 24"><path d="M6 4v16M12 4v16M18 4v16M3 9h6M9 15h6M15 7h6"/></symbol>
    <symbol id="i-edit" viewBox="0 0 24 24"><path d="m4 20 4.2-1 10-10a2.8 2.8 0 0 0-4-4l-10 10zM13 6l5 5"/></symbol>
    <symbol id="i-art" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8" cy="9" r="1.5"/><path d="m5 17 5-5 3 3 2-2 4 4"/></symbol>
    <symbol id="i-back" viewBox="0 0 24 24"><path d="m14 5-7 7 7 7M7 12h13"/></symbol>
    <symbol id="i-grid" viewBox="0 0 24 24"><rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><rect x="14" y="14" width="6" height="6"/></symbol>
    <symbol id="i-more" viewBox="0 0 24 24"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></symbol>
    <symbol id="i-close" viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></symbol>
    <symbol id="i-trash" viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v5M14 11v5"/></symbol>
    <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/></symbol>
    <symbol id="i-tag" viewBox="0 0 24 24"><path d="M4 5v6l9 9 7-7-9-9z"/><circle cx="8" cy="8" r="1"/></symbol>
    <symbol id="i-folder-music" viewBox="0 0 24 24"><path d="M3 6.5A2.5 2.5 0 0 1 5.5 4H10l2 2h6.5A2.5 2.5 0 0 1 21 8.5v4"/><path d="M3 9h18M9 18v-5l5-1v5M9 18a2 2 0 1 1-2-2 2 2 0 0 1 2 2Zm5-1a2 2 0 1 1-2-2 2 2 0 0 1 2 2Z"/></symbol>
</svg>


<div class="app">

    <!-- =========================
         SIDEBAR
    ========================== -->

    <aside class="sidebar">

        <div class="sidebar-header">
            <div class="logo">
                Encore<span> Music</span>
            </div>
        </div>


        <div class="sidebar-actions">

            <label
                class="sidebar-button primary"
                for="folderInput"
            >
                <svg class="icon"><use href="#i-folder"/></svg> Select Music Folder
            </label>

            <input
                type="file"
                id="folderInput"
                webkitdirectory
                directory
                multiple
                accept="audio/*,.lrc,image/*"
                style="display:none;"
            >

            <button
                class="sidebar-button"
                id="addFilesButton"
            >
                <svg class="icon"><use href="#i-plus"/></svg> Add Music Files
            </button>

            <input
                type="file"
                id="filesInput"
                multiple
                accept="audio/*"
                style="display:none;"
            >

        </div>


        <div class="sidebar-nav">

            <button
                class="nav-item active"
                data-page="library"
            >
                <svg class="icon"><use href="#i-music"/></svg> Library
            </button>

            <button
                class="nav-item"
                data-page="favorites"
            >
                <svg class="icon"><use href="#i-star"/></svg> Favorites
            </button>

            <button
                class="nav-item"
                data-page="recent"
            >
                <svg class="icon"><use href="#i-clock"/></svg> Recently Played
            </button>

            <button
                class="nav-item"
                data-page="most-played"
            >
                <svg class="icon"><use href="#i-chart"/></svg> Most Played
            </button>

            <button
                class="nav-item"
                data-page="recently-added"
            >
                <svg class="icon"><use href="#i-music"/></svg> Recently Added
            </button>

            <button
                class="nav-item"
                data-page="playlists"
            >
                <svg class="icon"><use href="#i-playlist"/></svg> Playlists
            </button>

            <button
                class="nav-item"
                data-page="queue"
            >
                <svg class="icon"><use href="#i-queue"/></svg> Queue
            </button>

            <button
                class="nav-item"
                data-page="now-playing"
            >
                <svg class="icon"><use href="#i-play"/></svg> Now Playing
            </button>

            <button
                class="nav-item"
                data-page="equalizer"
            >
                <svg class="icon"><use href="#i-eq"/></svg> Equalizer
            </button>

            <button
                class="nav-item"
                data-page="statistics"
            >
                <svg class="icon"><use href="#i-chart"/></svg> Statistics
            </button>

            <button
                class="nav-item"
                data-page="settings"
            >
                <svg class="icon"><use href="#i-settings"/></svg> Settings
            </button>

        </div>


        <div class="library-title">
            Artists
        </div>

        <ul
            class="sidebar-list"
            id="artistList"
        ></ul>


        <div class="sidebar-footer">

            <a href="../private.php">
                <svg class="icon"><use href="#i-back"/></svg> Private Pages
            </a>

            <br><br>

            <a href="../../admin.php">
                Admin Panel
            </a>

        </div>

    </aside>


    <!-- =========================
         MAIN
    ========================== -->

    <main class="main">

        <header class="topbar">

            <input
                type="search"
                class="search"
                id="searchInput"
                placeholder="Search songs, artists, albums..."
            >

            <div class="topbar-buttons">

                <button
                    class="icon-button"
                    id="randomButton"
                    title="Surprise Me"
                >
                    <svg class="icon"><use href="#i-shuffle"/></svg>
                </button>

                <button
                    class="icon-button"
                    id="queueButton"
                    title="Queue"
                >
                    <svg class="icon"><use href="#i-queue"/></svg>
                </button>

                <button
                    class="icon-button"
                    id="commandButton"
                    title="Command Palette"
                >
                    <svg class="icon"><use href="#i-command"/></svg>
                </button>

            </div>

        </header>


        <div class="content">


            <!-- =========================
                 WELCOME
            ========================== -->

            <section
                id="welcomePage"
                class="welcome"
            >

                <h1>Your Music.</h1>

                <p>
                    Select a music folder from your computer to build
                    your personal music library. Your music stays in
                    your browser and is never uploaded to this website.
                </p>

                <div class="welcome-folder-buttons">

    <button
        class="welcome-button"
        id="selectFolderButton"
        type="button"
    >
        <svg class="icon"><use href="#i-folder"/></svg>
        Select Music Folder
    </button>

    <button
        class="welcome-button hidden"
        id="recallFolderButton"
        type="button"
    >
        <svg class="icon"><use href="#i-back"/></svg>
        Recall Last Folder
    </button>

</div>

            </section>

            <!-- =========================
                 LIBRARY
            ========================== -->

            <section
                id="libraryPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Library</h1>

                        <p id="libraryCount">
                            No tracks loaded
                        </p>
                    </div>

                    <div class="header-actions">

                        <button
                            class="button hidden"
                            id="albumBackButton"
                            onclick="showAlbumLibrary()"
                        >
                            <svg class="icon"><use href="#i-back"/></svg> Albums
                        </button>

                        <select
                            id="sortSelect"
                            class="button"
                        >
                            <option value="track">
                                Sort: Track Order
                            </option>

                            <option value="name">
                                Sort: Name
                            </option>

                            <option value="artist">
                                Sort: Artist
                            </option>

                            <option value="album">
                                Sort: Album
                            </option>

                            <option value="duration">
                                Sort: Duration
                            </option>

                            <option value="recent">
                                Sort: Recently Added
                            </option>

                            <option value="plays">
                                Sort: Most Played
                            </option>
                        </select>

                        <button
                            class="button"
                            id="viewToggle"
                        >
                            <svg class="icon"><use href="#i-grid"/></svg> Grid
                        </button>

                    </div>

                </div>


                <div
                    id="libraryContainer"
                    class="track-list"
                ></div>

            </section>


            <!-- =========================
                 NOW PLAYING
            ========================== -->

            <section
                id="now-playingPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Now Playing</h1>
                        <p>Everything about the current track.</p>
                    </div>

                </div>


                <div class="now-playing">

                    <div
                        class="large-art"
                        id="largeArt"
                    >
                        <div class="large-art-placeholder"><svg class="icon"><use href="#i-music"/></svg></div>
                    </div>


                    <div class="now-playing-details">

                        <div class="now-playing-label">
                            Now Playing
                        </div>

                        <div
                            class="now-playing-title"
                            id="largeTitle"
                        >
                            Nothing playing
                        </div>

                        <div
                            class="now-playing-artist"
                            id="largeArtist"
                        >
                            Select a song
                        </div>


                        <div class="detail-buttons">

                            <button
                                class="button"
                                id="largeFavorite"
                            >
                                <svg class="icon"><use href="#i-star"/></svg> Favorite
                            </button>

                            <button
                                class="button"
                                id="largeQueue"
                            >
                                + Queue
                            </button>

                            <button
                                class="button"
                                id="editMetadata"
                            >
                                <svg class="icon"><use href="#i-edit"/></svg> Edit Metadata
                            </button>

                        </div>


                        <div
                            class="card"
                            style="margin-top:20px;"
                        >

                            <strong>
                                Track Information
                            </strong>

                            <div
                                id="trackDetails"
                                style="
                                    color:var(--muted);
                                    margin-top:10px;
                                    line-height:1.8;
                                "
                            >
                                No track selected.
                            </div>

                        </div>


                        <canvas
                            id="visualizer"
                            class="visualizer"
                        ></canvas>

                    </div>

                </div>

            </section>


            <!-- =========================
                 FAVORITES
            ========================== -->

            <section
                id="favoritesPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1><svg class="icon"><use href="#i-star"/></svg> Favorites</h1>
                        <p>Your favorite tracks.</p>
                    </div>

                </div>

                <div
                    id="favoritesContainer"
                    class="track-list"
                ></div>

            </section>


            <!-- =========================
                 RECENT
            ========================== -->

            <section
                id="recentPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Recently Played</h1>
                        <p>Your listening history.</p>
                    </div>

                </div>

                <div
                    id="recentContainer"
                    class="track-list"
                ></div>

            </section>


            <!-- =========================
                 MOST PLAYED
            ========================== -->

            <section
                id="most-playedPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Most Played</h1>
                        <p>Your most-played music.</p>
                    </div>

                </div>

                <div
                    id="mostPlayedContainer"
                    class="track-list"
                ></div>

            </section>


            <!-- =========================
                 RECENTLY ADDED
            ========================== -->

            <section
                id="recently-addedPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Recently Added</h1>
                        <p>Music you've recently loaded.</p>
                    </div>

                </div>

                <div
                    id="recentlyAddedContainer"
                    class="track-list"
                ></div>

            </section>


            <!-- =========================
                 PLAYLISTS
            ========================== -->

            <section
                id="playlistsPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Playlists</h1>
                        <p>Create and manage custom playlists.</p>
                    </div>

                    <button
                        class="button primary"
                        id="newPlaylistButton"
                    >
                        + New Playlist
                    </button>

                </div>

                <div
                    id="playlistsContainer"
                    class="settings-grid"
                ></div>

            </section>


            <!-- =========================
                 QUEUE
            ========================== -->

            <section
                id="queuePage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Queue</h1>
                        <p>Tracks waiting to play.</p>
                    </div>

                    <button
                        class="button danger"
                        id="clearQueue"
                    >
                        Clear Queue
                    </button>

                </div>


                <div class="card">

                    <ul
                        class="queue-list"
                        id="queueList"
                    ></ul>

                </div>

            </section>


            <!-- =========================
                 EQUALIZER
            ========================== -->

            <section
                id="equalizerPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Equalizer</h1>
                        <p>Adjust your audio.</p>
                    </div>

                </div>


                <div class="card">

                    <div
                        style="
                            display:flex;
                            gap:8px;
                            flex-wrap:wrap;
                            margin-bottom:20px;
                        "
                    >

                        <button
                            class="button"
                            data-eq-preset="flat"
                        >
                            Flat
                        </button>

                        <button
                            class="button"
                            data-eq-preset="rock"
                        >
                            Rock
                        </button>

                        <button
                            class="button"
                            data-eq-preset="pop"
                        >
                            Pop
                        </button>

                        <button
                            class="button"
                            data-eq-preset="classical"
                        >
                            Classical
                        </button>

                        <button
                            class="button"
                            data-eq-preset="bass"
                        >
                            Bass Boost
                        </button>

                        <button
                            class="button"
                            data-eq-preset="treble"
                        >
                            Treble Boost
                        </button>

                    </div>


                    <div
                        class="eq"
                        id="eqContainer"
                    ></div>

                </div>

            </section>


            <!-- =========================
                 STATISTICS
            ========================== -->

            <section
                id="statisticsPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Statistics</h1>
                        <p>Your local listening statistics.</p>
                    </div>

                </div>


                <div class="settings-grid">

                    <div class="setting">

                        <h3>Total Plays</h3>

                        <p id="statPlays">
                            0
                        </p>

                    </div>

                    <div class="setting">

                        <h3>Listening Time</h3>

                        <p id="statTime">
                            0 minutes
                        </p>

                    </div>

                    <div class="setting">

                        <h3>Library Size</h3>

                        <p id="statLibrary">
                            0 tracks
                        </p>

                    </div>

                    <div class="setting">

                        <h3>Favorites</h3>

                        <p id="statFavorites">
                            0 tracks
                        </p>

                    </div>

                </div>


                <div class="card">

                    <h3>
                        Listening History
                    </h3>

                    <canvas
                        id="statsCanvas"
                        style="
                            width:100%;
                            height:220px;
                            margin-top:15px;
                        "
                    ></canvas>

                </div>

            </section>


            <!-- =========================
                 SETTINGS
            ========================== -->

            <section
                id="settingsPage"
                class="page hidden"
            >

                <div class="page-header">

                    <div>
                        <h1>Settings</h1>
                        <p>Customize your player.</p>
                    </div>

                </div>


                <div class="settings-grid">


                    <div class="setting">

                        <h3>
                            Theme
                        </h3>

                        <p>
                            Choose the appearance of the player.
                        </p>

                        <select id="themeSelect">

                            <option value="dark">
                                Dark
                            </option>

                            <option value="light">
                                Light
                            </option>

                            <option value="purple">
                                Purple
                            </option>

                            <option value="midnight">
                                Midnight
                            </option>

                        </select>

                    </div>


                    <div class="setting">

                        <h3>
                            Accent Color
                        </h3>

                        <p>
                            Customize the player accent.
                        </p>

                        <input
                            type="color"
                            id="accentColor"
                            value="#8257e5"
                        >

                    </div>


                    <div class="setting">

                        <h3>
                            Playback Speed
                        </h3>

                        <p>
                            Change playback speed.
                        </p>

                        <select id="speedSelect">

                            <option value=".5">
                                0.5<svg class="icon"><use href="#i-close"/></svg>
                            </option>

                            <option value=".75">
                                0.75<svg class="icon"><use href="#i-close"/></svg>
                            </option>

                            <option value="1" selected>
                                1<svg class="icon"><use href="#i-close"/></svg>
                            </option>

                            <option value="1.25">
                                1.25<svg class="icon"><use href="#i-close"/></svg>
                            </option>

                            <option value="1.5">
                                1.5<svg class="icon"><use href="#i-close"/></svg>
                            </option>

                            <option value="2">
                                2<svg class="icon"><use href="#i-close"/></svg>
                            </option>

                        </select>

                    </div>


                    <div class="setting">

                        <h3>
                            Playback
                        </h3>

                        <p>
                            Automatic playback behavior.
                        </p>

                        <label class="checkbox-row">

                            <input
                                type="checkbox"
                                id="crossfadeToggle"
                            >

                            Crossfade tracks

                        </label>


                        <label class="checkbox-row">

                            <input
                                type="checkbox"
                                id="gaplessToggle"
                                checked
                            >

                            Gapless-style transitions

                        </label>


                        <label class="checkbox-row">

                            <input
                                type="checkbox"
                                id="autoplayToggle"
                                checked
                            >

                            Automatically play next

                        </label>

                    </div>


                    <div class="setting">

                        <h3>
                            Album Display
                        </h3>

                        <p>
                            Choose how your albums are displayed in the library.
                        </p>

                        <select id="albumLayoutSelect">
                            <option value="grid">Grid</option>
                            <option value="list">List</option>
                        </select>

                        <select id="albumCardSizeSelect" style="margin-top:8px;">
                            <option value="compact">Compact</option>
                            <option value="standard">Standard</option>
                            <option value="large">Large</option>
                        </select>

                    </div>


                    <div class="setting">

                        <h3>
                            Library
                        </h3>

                        <p>
                            Music library options.
                        </p>

                        <button
                            class="button"
                            id="refreshLibrary"
                        >
                            Refresh Library
                        </button>

                        <button
                            class="button danger"
                            id="clearLocalData"
                            style="margin-top:8px;"
                        >
                            Clear Saved Data
                        </button>

                    </div>


                    <div class="setting">

                        <h3>
                            Sleep Timer
                        </h3>

                        <p>
                            Stop playback automatically.
                        </p>

                        <select id="sleepTimer">

                            <option value="0">
                                Off
                            </option>

                            <option value="5">
                                5 minutes
                            </option>

                            <option value="10">
                                10 minutes
                            </option>

                            <option value="15">
                                15 minutes
                            </option>

                            <option value="30">
                                30 minutes
                            </option>

                            <option value="60">
                                1 hour
                            </option>

                        </select>

                    </div>


                    <div class="setting">

                        <h3>
                            Notifications
                        </h3>

                        <p>
                            Show a browser notification when tracks change.
                        </p>

                        <button
                            class="button"
                            id="notificationButton"
                        >
                            Notifications: Off
                        </button>

                    </div>


                    <div class="setting">

                        <h3>
                            Keyboard Shortcuts
                        </h3>

                        <p>
                            Space: Play/Pause<br>
                            Left / Right: Seek<br>
                            Up / Down: Volume<br>
                            N: Next<br>
                            P: Previous<br>
                            S: Shuffle
                        </p>

                    </div>

                </div>

            </section>

        </div>

    </main>

</div>


<!-- =========================
     PLAYER
========================== -->

<div class="player">


    <div class="player-track">

        <div
            class="player-art"
            id="playerArt"
        >
            <svg class="icon"><use href="#i-music"/></svg>
        </div>

        <div class="player-track-info">

            <div
                class="player-track-title"
                id="playerTitle"
            >
                Nothing playing
            </div>

            <div
                class="player-track-artist"
                id="playerArtist"
            >
                Select a song
            </div>

        </div>

    </div>


    <div class="player-main">

        <div class="player-controls">

            <button
                class="player-button"
                id="shuffleButton"
                title="Shuffle"
            >
                <svg class="icon"><use href="#i-shuffle"/></svg>
            </button>

            <button
                class="player-button"
                id="prevButton"
                title="Previous"
            >
                <svg class="icon"><use href="#i-prev"/></svg>
            </button>

            <button
                class="player-button"
                id="rewindButton"
                title="Rewind 10 seconds"
            >
                -10
            </button>

            <button
                class="player-button play"
                id="playButton"
                title="Play/Pause"
            >
                <svg class="icon"><use href="#i-play"/></svg>
            </button>

            <button
                class="player-button"
                id="forwardButton"
                title="Forward 10 seconds"
            >
                +10
            </button>

            <button
                class="player-button"
                id="nextButton"
                title="Next"
            >
                <svg class="icon"><use href="#i-next"/></svg>
            </button>

            <button
                class="player-button"
                id="repeatButton"
                title="Repeat"
            >
                <svg class="icon"><use href="#i-repeat"/></svg>
            </button>

        </div>


        <div class="progress">

            <span id="currentTime">
                0:00
            </span>

            <input
                type="range"
                id="progressBar"
                min="0"
                max="100"
                value="0"
            >

            <span id="duration">
                0:00
            </span>

        </div>

    </div>


    <div class="player-right">

        <button
            class="player-button"
            id="lyricsButton"
            title="Lyrics"
        >
            <svg class="icon"><use href="#i-music"/></svg>
        </button>

        <button
            class="player-button"
            id="miniQueueButton"
            title="Queue"
        >
            <svg class="icon"><use href="#i-queue"/></svg>
        </button>

        <button
            class="player-button"
            id="favoriteButton"
            title="Favorite"
        >
            <svg class="icon"><use href="#i-star"/></svg>
        </button>

        <span>
            <svg class="icon"><use href="#i-volume"/></svg>
        </span>

        <input
            class="volume"
            type="range"
            id="volumeSlider"
            min="0"
            max="100"
            value="100"
        >

    </div>

</div>


<!-- =========================
     MODAL
========================== -->

<div
    class="modal-backdrop hidden"
    id="modalBackdrop"
>

    <div
        class="modal"
        id="modal"
    ></div>

</div>


<div
    class="toast-container"
    id="toastContainer"
></div>


<audio id="audioPlayer"></audio>

<script>

/* =========================================================
   CORE STATE
========================================================= */

const folderInput = document.getElementById('folderInput');
const filesInput = document.getElementById('filesInput');

const audio = document.getElementById('audioPlayer');

/*
 * BACKGROUND AUDIO PROTECTION
 *
 * The page may pause/change volume through its own controls, but losing
 * focus, switching tabs, or an unexpected script/browser event must not
 * silently stop this player.
 *
 * A webpage cannot override OS-level audio ducking performed by Windows,
 * ChromeOS, or the browser itself.
 */
let websiteRequestedPause = false;
let websiteRequestedVolumeChange = false;
let lastWebsiteVolume = 1;
let changingTrack = false;
let backgroundPlaybackRecovery = null;

// True when the user intentionally paused playback.
// This prevents background recovery from restarting the music.
let userPausedPlayback = false;

function pauseAudioByWebsite() {
    websiteRequestedPause = true;
    userPausedPlayback = true;

    clearTimeout(backgroundPlaybackRecovery);
    backgroundPlaybackRecovery = null;

    audio.pause();
}

function setAudioVolumeByWebsite(value) {
    const volume = Math.max(0, Math.min(1, Number(value) || 0));

    websiteRequestedVolumeChange = true;
    lastWebsiteVolume = volume;
    audio.muted = false;
    audio.volume = volume;

    setTimeout(() => {
        websiteRequestedVolumeChange = false;
    }, 0);
}

function protectBackgroundPlayback() {
    if (!currentTrack || !audio.src) {
        return;
    }

    // The user intentionally paused the music. Never restart it automatically.
    if (userPausedPlayback) {
        clearTimeout(backgroundPlaybackRecovery);
        backgroundPlaybackRecovery = null;
        websiteRequestedPause = false;
        return;
    }

    if (websiteRequestedPause) {
        websiteRequestedPause = false;
        return;
    }

    if (changingTrack) {
        return;
    }

    if (audio.muted) {
        audio.muted = false;
    }

    if (Math.abs(audio.volume - lastWebsiteVolume) > 0.001) {
        websiteRequestedVolumeChange = true;
        audio.volume = lastWebsiteVolume;

        setTimeout(() => {
            websiteRequestedVolumeChange = false;
        }, 0);
    }

    if (audio.paused) {
        clearTimeout(backgroundPlaybackRecovery);

        backgroundPlaybackRecovery = setTimeout(() => {
            if (
                currentTrack &&
                audio.paused &&
                !userPausedPlayback &&
                !websiteRequestedPause &&
                !changingTrack
            ) {
                audio.play().catch(() => {});
            }
        }, 0);
    }
}

audio.addEventListener('pause', protectBackgroundPlayback);

document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        protectBackgroundPlayback();
    }
});

window.addEventListener('focus', protectBackgroundPlayback);
window.addEventListener('pageshow', protectBackgroundPlayback);

audio.addEventListener('volumechange', () => {
    if (websiteRequestedVolumeChange) {
        return;
    }

    if (audio.muted) {
        audio.muted = false;
    }

    if (Math.abs(audio.volume - lastWebsiteVolume) > 0.001) {
        audio.volume = lastWebsiteVolume;
    }
});

document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        protectBackgroundPlayback();
    }
});

window.addEventListener('focus', protectBackgroundPlayback);
window.addEventListener('pageshow', protectBackgroundPlayback);


/* =========================================================
   REMEMBER LAST MUSIC FOLDER
========================================================= */

const selectFolderButton =
    document.getElementById('selectFolderButton');

const recallFolderButton =
    document.getElementById('recallFolderButton');

const FOLDER_DB_NAME = 'encore_folder_memory';
const FOLDER_STORE_NAME = 'folders';
const FOLDER_KEY = 'lastMusicFolder';


function openFolderDatabase() {
    return new Promise((resolve, reject) => {

        const request = indexedDB.open(
            FOLDER_DB_NAME,
            1
        );

        request.onupgradeneeded = () => {

            const db = request.result;

            if (!db.objectStoreNames.contains(FOLDER_STORE_NAME)) {
                db.createObjectStore(FOLDER_STORE_NAME);
            }
        };

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}


async function saveFolderHandle(handle) {

    try {

        const db =
            await openFolderDatabase();

        await new Promise((resolve, reject) => {

            const transaction =
                db.transaction(
                    FOLDER_STORE_NAME,
                    'readwrite'
                );

            transaction
                .objectStore(FOLDER_STORE_NAME)
                .put(handle, FOLDER_KEY);

            transaction.oncomplete = resolve;

            transaction.onerror = () => {
                reject(transaction.error);
            };
        });

        updateRecallFolderButton();

    } catch (error) {

        console.error(
            'Could not save folder handle:',
            error
        );
    }
}


async function getSavedFolderHandle() {

    try {

        const db =
            await openFolderDatabase();

        return await new Promise((resolve, reject) => {

            const transaction =
                db.transaction(
                    FOLDER_STORE_NAME,
                    'readonly'
                );

            const request =
                transaction
                    .objectStore(FOLDER_STORE_NAME)
                    .get(FOLDER_KEY);

            request.onsuccess = () => {
                resolve(request.result || null);
            };

            request.onerror = () => {
                reject(request.error);
            };
        });

    } catch (error) {

        console.error(
            'Could not retrieve folder handle:',
            error
        );

        return null;
    }
}


async function updateRecallFolderButton() {

    if (!recallFolderButton) {
        return;
    }

    getSavedFolderHandle()
        .then(handle => {
            if (!handle) {
                recallFolderButton.classList.add('hidden');
                return;
            }

            recallFolderButton.classList.remove('hidden');

            recallFolderButton.innerHTML = `
                <svg class="icon"><use href="#i-back"/></svg>
                Recall "${escapeHTML(handle.name)}"
            `;
        })
        .catch(error => {
            console.error('Could not update recall folder button:', error);
            recallFolderButton.classList.add('hidden');
        });
}

/* =========================================================
   REMEMBERED FOLDER FILE ACCESS
========================================================= */

async function readDirectoryAudioFiles(directoryHandle, parentPath = '') {
    const files = [];

    for await (const entry of directoryHandle.values()) {
        const relativePath = parentPath
            ? `${parentPath}/${entry.name}`
            : entry.name;

        if (entry.kind === 'file') {
            try {
                const file = await entry.getFile();

                if (isAudioFile(file) || /\.lrc$/i.test(file.name)) {
                    Object.defineProperty(file, 'webkitRelativePath', {
                        value: relativePath,
                        configurable: true
                    });
                    Object.defineProperty(file, '__encoreFileHandle', {
                        value: entry,
                        configurable: true
                    });
                    files.push(file);
                }
            } catch (error) {
                console.warn(`Could not read ${relativePath}:`, error);
            }
        } else if (entry.kind === 'directory') {
            const nested = await readDirectoryAudioFiles(entry, relativePath);
            files.push(...nested);
        }
    }

    return files;
}

async function readDirectoryArtworkFiles(directoryHandle, parentPath = '') {
    const files = [];

    for await (const entry of directoryHandle.values()) {
        const relativePath = parentPath
            ? `${parentPath}/${entry.name}`
            : entry.name;

        if (entry.kind === 'file') {
            try {
                const file = await entry.getFile();
                if (isArtworkFile(file)) {
                    Object.defineProperty(file, 'webkitRelativePath', {
                        value: relativePath,
                        configurable: true
                    });
                    files.push(file);
                }
            } catch (error) {
                console.warn(`Could not read artwork ${relativePath}:`, error);
            }
        } else if (entry.kind === 'directory') {
            const nested = await readDirectoryArtworkFiles(entry, relativePath);
            files.push(...nested);
        }
    }

    return files;
}

async function selectMusicFolder() {
    try {
        if (typeof window.showDirectoryPicker !== 'function') {
            folderInput.click();
            return;
        }

        const handle = await window.showDirectoryPicker({ mode: 'readwrite' });
        await saveFolderHandle(handle);
        toast(`Loading ${handle.name}...`);

        const files = await readDirectoryAudioFiles(handle, handle.name);

        if (!files.some(isAudioFile)) {
            toast('No supported music files found in that folder.');
            return;
        }

        // Render the album blocks first. Artwork and MP3 metadata writing
        // deliberately happen later in the background.
        loadFiles(files, true);

        setTimeout(() => {
            autoEmbedAlbumArtwork();
        }, 0);
    } catch (error) {
        if (error?.name === 'AbortError') return;
        console.error('Select folder error:', error);
        toast(`Could not open that folder: ${error?.message || error}`);
    }
}

async function recallLastFolder() {
    try {
        const handle = await getSavedFolderHandle();
        if (!handle) {
            toast('No previous music folder has been saved.');
            return;
        }

        let permission = await handle.queryPermission({ mode: 'readwrite' });
        if (permission !== 'granted') {
            permission = await handle.requestPermission({ mode: 'readwrite' });
        }

        if (permission !== 'granted') {
            toast('Permission to access the previous folder was denied.');
            return;
        }

        toast(`Loading ${handle.name}...`);

        const files = await readDirectoryAudioFiles(handle, handle.name);
        if (!files.some(isAudioFile)) {
            toast('The previous folder contains no supported music files.');
            return;
        }

        loadFiles(files, true);

        setTimeout(() => {
            autoEmbedAlbumArtwork();
        }, 0);
    } catch (error) {
        console.error('Recall folder error:', error);
        toast(`Could not access the previous folder: ${error?.message || error}`);
    }
}

if (selectFolderButton) {
    selectFolderButton.addEventListener('click', selectMusicFolder);
}

if (recallFolderButton) {
    recallFolderButton.addEventListener('click', recallLastFolder);
}

let tracks = [];
let currentIndex = -1;
let currentTrack = null;

// Every loaded track is kept here so playback/queue state does not depend
// on whichever album is currently open in the library.
let trackRegistry = new Map();

// Album folders are indexed without loading their songs.
let albums = new Map();
let activeAlbumKey = null;
let albumArtUrls = new Map();

let queue = [];
let playlists = {};

let favorites = new Set();
let history = [];

let shuffle = false;
let repeatMode = 'off';

let isDraggingProgress = false;

let objectUrls = new Map();

let settings = {
    theme: 'dark',
    accent: '#8257e5',
    speed: 1,
    crossfade: false,
    gapless: true,
    autoplay: true,
    sleepTimer: 0,
    notifications: false,
    albumLayout: 'grid',
    albumCardSize: 'standard'
};

let sleepTimerHandle = null;


/* =========================================================
   STORAGE
========================================================= */

function savePreferences() {
    try {
        localStorage.setItem(
            'encore_preferences',
            JSON.stringify({
                settings,
                volume: volumeSlider ? volumeSlider.value : Math.round((audio.volume || 1) * 100),
                shuffle,
                repeatMode
            })
        );
    } catch (error) {
        console.warn('Could not save Encore preferences.', error);
    }
}

function loadPreferences() {
    try {
        const saved = JSON.parse(
            localStorage.getItem('encore_preferences') || '{}'
        );

        if (saved.settings && typeof saved.settings === 'object') {
            settings = {
                ...settings,
                ...saved.settings
            };
        }

        if (saved.volume !== undefined && volumeSlider) {
            const volume = Math.max(0, Math.min(100, Number(saved.volume)));
            if (Number.isFinite(volume)) {
                volumeSlider.value = volume;
                audio.volume = volume / 100;
            }
        }

        if (typeof saved.shuffle === 'boolean') {
            shuffle = saved.shuffle;
        }

        if (['off', 'all', 'one'].includes(saved.repeatMode)) {
            repeatMode = saved.repeatMode;
        }
    } catch (error) {
        console.warn('Could not load Encore preferences.', error);
    }
}

function saveUIState() {
    try {
        const activePage = document.querySelector('.nav-item.active')?.dataset.page || 'library';
        localStorage.setItem(
            'encore_ui_state',
            JSON.stringify({ activePage })
        );
    } catch (error) {
        console.warn('Could not save Encore UI state.', error);
    }
}

function loadUIState() {
    try {
        return JSON.parse(
            localStorage.getItem('encore_ui_state') || '{}'
        );
    } catch (error) {
        return {};
    }
}

function saveState() {

    const trackData = {
        ...(window.savedTrackState || {})
    };

    tracks.forEach(track => {

        trackData[track.id] = {
            ...(trackData[track.id] || {}),
            favorite: track.favorite || false,
            plays: track.plays || 0,
            metadata: track.metadata || {},
            mood: track.mood || '',
            added: track.added || Date.now()
        };

    });


    function saveMusicState() {
    try {

        const safeAlbums = {};

        albums.forEach((album, key) => {

            safeAlbums[key] = {
                name: album.name,
                path: album.path,
                artist: album.artist || '',
                album: album.album || '',
                cover: album.cover || ''
            };

        });

        const state = {
            albums: safeAlbums,
            settings: musicSettings || {}
        };

        localStorage.setItem(
            'encore_music_state',
            JSON.stringify(state)
        );

    } catch (error) {

        if (
            error &&
            error.name === 'QuotaExceededError'
        ) {

            console.warn(
                'Encore library is too large for localStorage. Library state was not saved.'
            );

            return;

        }

        console.error(
            'Could not save Encore music state:',
            error
        );

    }
}


    const albumState = {};

    albums.forEach((album, key) => {
        albumState[key] = {
            name: album.name,
            artworkData: album.artworkData || '',
            musicbrainzReleaseId: album.musicbrainzReleaseId || ''
        };
    });

    localStorage.setItem(
        'encore_music_albums',
        JSON.stringify(albumState)
    );


    localStorage.setItem(
        'encore_music_playlists',
        JSON.stringify(playlists)
    );


    localStorage.setItem(
        'encore_music_history',
        JSON.stringify(history)
    );


    localStorage.setItem(
        'encore_music_queue',
        JSON.stringify(queue.map(item => typeof item === 'string' ? item : item.id))
    );


    localStorage.setItem(
        'encore_music_settings',
        JSON.stringify(settings)
    );

    savePreferences();
}


function loadState() {

    try {

        loadPreferences();

        const state =
            JSON.parse(
                localStorage.getItem(
                    'encore_music_state'
                ) || '{}'
            );


        const savedPlaylists =
            JSON.parse(
                localStorage.getItem(
                    'encore_music_playlists'
                ) || '{}'
            );


        const savedHistory =
            JSON.parse(
                localStorage.getItem(
                    'encore_music_history'
                ) || '[]'
            );

        const savedQueue =
            JSON.parse(
                localStorage.getItem(
                    'encore_music_queue'
                ) || '[]'
            );


        const savedAlbums =
            JSON.parse(
                localStorage.getItem(
                    'encore_music_albums'
                ) || '{}'
            );

        const savedSettings =
            JSON.parse(
                localStorage.getItem(
                    'encore_music_settings'
                ) || '{}'
            );


        playlists = savedPlaylists;
        history = savedHistory;
        queue = Array.isArray(savedQueue) ? savedQueue : [];

        settings = {
            ...settings,
            ...savedSettings
        };


        window.savedTrackState = state;
        window.savedAlbumState = savedAlbums;

    } catch (e) {

        console.warn(
            'Could not load saved player state.',
            e
        );

    }

}


/* =========================================================
   TRACK HELPERS
========================================================= */

function trackId(file) {

    return [
        file.webkitRelativePath || file.name,
        file.size,
        file.lastModified
    ].join('|');

}


function getFilenameTrackNumber(fileOrName) {
    const name = typeof fileOrName === 'string'
        ? fileOrName
        : (fileOrName?.name || '');

    const withoutExtension = String(name).replace(/\.[^/.]+$/, '');

    /*
     * Recognize common prefixes such as:
     *   001 - Song
     *   01 - Artist - Song
     *   Track 07 - Song
     *   7. Song
     *
     * The filename number is deterministic evidence and is intentionally
     * kept separate from AI-proposed metadata.
     */
    const match = withoutExtension.match(
        /^\s*(?:(?:track|song|audio)\s*)?0*(\d{1,3})(?=\s*(?:[-_.):]|\s))/i
    );

    if (!match) return null;

    const number = Number(match[1]);
    return Number.isFinite(number) && number > 0
        ? Math.trunc(number)
        : null;
}

function getFilenameCleanTitle(fileOrName, albumName = '') {
    const rawName = typeof fileOrName === 'string'
        ? fileOrName
        : (fileOrName?.name || '');

    let title = String(rawName).replace(/\.[^/.]+$/, '').trim();

    /* Remove a leading track number. */
    title = title.replace(
        /^\s*(?:(?:track|song|audio)\s*)?0*\d{1,3}\s*(?:[-_.):]+\s*)?/i,
        ''
    ).trim();

    const album = String(albumName || '').trim();
    if (album) {
        const escapedAlbum = album.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        title = title.replace(
            new RegExp('^' + escapedAlbum + '\\s*[-–—:]\\s*', 'i'),
            ''
        ).trim();
    }

    return title;
}

function getTrackTitle(track) {

    return (
        track.metadata?.title ||
        track.title ||
        getFilenameCleanTitle(track.file, track.album || track.albumName || '')
    );

}


function getTrackArtist(track) {

    return (
        track.metadata?.artist ||
        track.artist ||
        'Unknown Artist'
    );

}


function getTrackAlbum(track) {

    return (
        track.metadata?.album ||
        track.album ||
        track.albumName ||
        'Unknown Album'
    );

}


function getTrackMood(track) {

    return (
        track.mood ||
        track.metadata?.mood ||
        ''
    );

}


function formatTime(seconds) {

    if (!Number.isFinite(seconds)) {
        return '0:00';
    }

    const mins =
        Math.floor(seconds / 60);

    const secs =
        Math.floor(seconds % 60);

    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;

}


function escapeHTML(value) {

    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');

}


/* =========================================================
   LOAD FILES / ALBUM INDEXING
========================================================= */

folderInput.addEventListener(
    'change',
    event => {
        loadFiles(Array.from(event.target.files), true);
        event.target.value = '';
    }
);


document
    .getElementById('addFilesButton')
    .addEventListener(
        'click',
        () => filesInput.click()
    );


filesInput.addEventListener(
    'change',
    event => {
        loadFiles(Array.from(event.target.files), false);
        event.target.value = '';
    }
);


function isAudioFile(file) {
    return file.type.startsWith('audio/') ||
        /\.(mp3|wav|ogg|flac|m4a|aac|opus)$/i.test(file.name);
}


function getAlbumKey(file, fromFolderPicker) {

    const relative = file.webkitRelativePath || '';
    const parts = relative.split('/').filter(Boolean);

    // Music/Album/Song.mp3 -> Music/Album
    if (fromFolderPicker && parts.length >= 3) {
        return parts.slice(0, 2).join('/');
    }

    // Album/Song.mp3 -> Album
    if (fromFolderPicker && parts.length === 2) {
        return parts[0];
    }

    // A file selected directly has no album folder.
    return '__added_files__';
}


function getAlbumNameFromKey(key) {
    if (key === '__added_files__') {
        return 'Added Music';
    }

    const parts = key.split('/');
    return parts[parts.length - 1] || key;
}


function isArtworkFile(file) {
    if (!file) return false;

    return (
        String(file.type || '').toLowerCase().startsWith('image/') ||
        /\.(jpg|jpeg|png|webp|gif|bmp|avif)$/i.test(file.name || '')
    );
}

function findAlbumArtwork(files) {
    return files.find(file =>
        isArtworkFile(file) &&
        /^(cover|folder|album|front)\./i.test(file.name)
    ) || files.find(isArtworkFile) || null;
}


function findAlbumLyrics(files) {
    return files.filter(file => /\.lrc$/i.test(file.name));
}


function loadFiles(files, fromFolderPicker = false) {

    const audioFiles = files.filter(isAudioFile);

    if (!audioFiles.length) {
        toast('No supported audio files found.');
        return;
    }

    const grouped = new Map();

    audioFiles.forEach(file => {
        const key = getAlbumKey(file, fromFolderPicker);
        if (!grouped.has(key)) grouped.set(key, []);
        grouped.get(key).push(file);
    });

    grouped.forEach((albumFiles, key) => {

        if (!albums.has(key)) {
            const saved = window.savedAlbumState?.[key] || {};

            albums.set(key, {
                key,
                name: saved.name || getAlbumNameFromKey(key),
                files: [],
                artworkFile: null,
                artworkData: saved.artworkData || '',
                musicbrainzReleaseId: saved.musicbrainzReleaseId || '',
                added: Date.now()
            });
        }

        const album = albums.get(key);

        const existingIds = new Set(
            album.files.map(file => trackId(file))
        );

        albumFiles.forEach(file => {
            if (!existingIds.has(trackId(file))) {
                album.files.push(file);
            }
        });

        // If artwork was already supplied with the selected files, keep it
        // available immediately. The separate automatic artwork scan will
        // replace/update this later without delaying the album list.
        const allAlbumFiles = album.files;
        const localArtwork = findAlbumArtwork(allAlbumFiles);

        if (localArtwork) {
            album.artworkFile = localArtwork;
        }
    });

    /*
     * IMPORTANT:
     * Render the album library FIRST.
     * Do not make album loading wait for artwork, metadata probing,
     * statistics, or any of the other secondary renderers.
     */
    saveState();
    showPage('library');
    renderLibrary();

    toast(
        `${grouped.size} album${grouped.size === 1 ? '' : 's'} indexed. Select an album to load its tracks.`
    );

    /*
     * Everything else can happen after the browser has painted the album
     * blocks. A failure in a secondary renderer must never prevent the
     * album library from appearing.
     */
    setTimeout(() => {
        try {
            renderEverything();
        } catch (error) {
            console.error('Secondary library rendering error:', error);
        }
    }, 0);
}


function clearActiveAlbum() {

    objectUrls.forEach(url => {
        try { URL.revokeObjectURL(url); } catch (e) {}
    });

    objectUrls.clear();
    tracks = [];
    currentIndex = -1;
    currentTrack = null;
    trackRegistry.clear();
    queue = [];
    localStorage.removeItem('encore_music_queue');
    activeAlbumKey = null;

    if (audio.src) {
        audio.pause();
        audio.removeAttribute('src');
        audio.load();
    }
}


function loadAlbum(key) {
    const album = albums.get(key);

    if (!album || !album.files.length) {
        return;
    }

    // Opening an album should always show/play it in its metadata track order.
    // The user can still choose another sort mode manually afterward.
    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) {
        sortSelect.value = 'track';
    }

    // Do NOT call clearActiveAlbum() here.
    // Opening another album should not stop the current song.
    activeAlbumKey = key;

    const files = album.files;
    const audioFiles = files.filter(isAudioFile);
    const lyricFiles = findAlbumLyrics(files);

    tracks = audioFiles.map(file => {
        const id = trackId(file);
        const saved = window.savedTrackState?.[id] || {};
        const metadata = { ...(saved.metadata || {}) };

        /*
         * Seed ordering from the filename before asynchronous metadata
         * reading happens. This fixes albums whose embedded TRCK tag is
         * missing or stale while the filename clearly says 001/002/etc.
         */
        const filenameTrackNumber = getFilenameTrackNumber(file);
        if (!metadata.trackNumber && filenameTrackNumber) {
            metadata.trackNumber = filenameTrackNumber;
        }

        if (album.artworkData && !metadata.artworkData) {
            metadata.artworkData = album.artworkData;
        }

        return {
            id,
            file,
            albumKey: key,
            albumName: album.name,
            title: file.name.replace(/\.[^/.]+$/, ''),
            artist: '',
            album: album.name,
            duration: 0,
            plays: saved.plays || 0,
            favorite: saved.favorite || false,
            metadata,
            mood: saved.mood || '',
            added: saved.added || album.added || Date.now(),
            artwork: album.artworkFile || null,
            artworkData: album.artworkData || metadata.artworkData || '',
            lyricsFile: lyricFiles.find(lyric =>
                lyric.name.replace(/\.lrc$/i, '').toLowerCase() ===
                file.name.replace(/\.[^/.]+$/, '').toLowerCase()
            ) || null
        };
    });

    tracks.sort((a, b) => {
        const aNumber = Number(a.metadata?.trackNumber ?? a.trackNumber);
        const bNumber = Number(b.metadata?.trackNumber ?? b.trackNumber);
        const aHas = Number.isFinite(aNumber) && aNumber > 0;
        const bHas = Number.isFinite(bNumber) && bNumber > 0;

        if (aHas && bHas && aNumber !== bNumber) return aNumber - bNumber;
        if (aHas !== bHas) return aHas ? -1 : 1;
        return getTrackTitle(a).localeCompare(getTrackTitle(b));
    });

    // Replace the registry entries for this album, but keep tracks from
    // other albums alive for the queue and current playback.
    tracks.forEach(track => {
        trackRegistry.set(track.id, track);
    });

    // If the currently playing track belongs to this album, reconnect the
    // player state to the newly-created track object instead of using the
    // same numeric index in the new album.
    if (currentTrack && currentTrack.albumKey === key) {
        const matchingTrack = tracks.find(track => track.id === currentTrack.id);

        if (matchingTrack) {
            currentTrack = matchingTrack;
            currentIndex = tracks.indexOf(matchingTrack);
        } else {
            // The visible album was rebuilt, but keep the actual player state.
            currentIndex = -1;
        }
    } else {
        // Opening a different album changes only the library selection.
        currentIndex = -1;
    }

    // Only this album gets metadata/audio probing.
    tracks.forEach(readBasicMetadata);

    renderEverything();
    showPage('library');

    // Changing albums must never change what the audio element is playing.
    updatePlayer();

    toast(
        `${album.name} loaded (${tracks.length} track${tracks.length === 1 ? '' : 's'}).`
    );
}

window.loadAlbum = loadAlbum;

function loadAlbumByEncoded(key) {
    loadAlbum(decodeURIComponent(key));
}

function showAlbumArtPickerByEncoded(key) {
    showAlbumArtPicker(decodeURIComponent(key));
}

window.showAlbumArtPickerByEncoded = showAlbumArtPickerByEncoded;

/* =========================================================
   MUSICBRAINZ + COVER ART ARCHIVE + MP3 ID3 WRITER
========================================================= */

let musicBrainzResults = [];
let musicBrainzAutoResults = [];
let musicBrainzManualResults = [];
let selectedMusicBrainzRelease = null;
let manualMusicBrainzTitles = {};

function musicBrainzRequest(type, params = {}, attempt = 0) {
    const query = new URLSearchParams({
        encore_mb: type,
        ...params
    });

    const url = `musicbrainz.php?${query.toString()}`;

    return fetch(url, {
        credentials: 'same-origin',
        cache: 'no-store'
    }).then(async response => {
        const data = await response.json().catch(() => ({}));

        if ((response.status === 429 || response.status === 502 || response.status === 503 || response.status === 504) && attempt < 3) {
            await new Promise(resolve => setTimeout(resolve, 1500 * (attempt + 1)));
            return musicBrainzRequest(type, params, attempt + 1);
        }

        if (!response.ok) {
            throw new Error(data.error || `MusicBrainz returned HTTP ${response.status}.`);
        }

        return data;
    });
}

function musicBrainzEscape(value) {
    return String(value || '')
        .replaceAll('\\', '\\\\')
        .replaceAll('"', '\\"')
        .trim();
}

function showAlbumArtPicker(key) {
    const album = albums.get(key);

    if (!album) {
        toast('Album not found.');
        return;
    }

    const firstTrack = album.files.find(isAudioFile);
    const guessedArtist = firstTrack
        ? (() => {
            const name = firstTrack.name.replace(/\.[^/.]+$/, '');
            const match = name.match(/^(.+?)\s+(?:-|–|—)\s+(.+)$/);
            return match ? match[1].trim() : '';
        })()
        : '';

    openModal(`
        <h2>Find Album Information</h2>
        <p style="color:var(--muted); margin-bottom:18px;">
            Choose a MusicBrainz release. Nothing is written to your MP3s until you press Apply.
        </p>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start;">
            <div style="border:1px solid var(--border);border-radius:10px;padding:14px;">
                <strong style="display:block;margin-bottom:6px;">Manual Search</strong>
                <p style="color:var(--muted);font-size:.8rem;margin-bottom:12px;">
                    Enter your own search parameters.
                </p>

                <div style="display:flex;flex-direction:column;gap:8px;">
                    <input id="manualLookupArtist" class="button" value="${escapeHTML(guessedArtist)}" placeholder="Artist (optional)">
                    <input id="manualLookupAlbum" class="button" value="${escapeHTML(album.name)}" placeholder="Album">
                    <input id="manualLookupYear" class="button" value="" placeholder="Year (optional)">
                    <input id="manualLookupCountry" class="button" value="" placeholder="Country (optional)">
                </div>

                <button type="button" id="musicBrainzManualSearchButton" class="button primary" style="margin-top:10px;width:100%;">
                    <svg class="icon"><use href="#i-search"/></svg> Search Manually
                </button>

                <div id="musicBrainzManualResults" class="album-loading" style="margin-top:14px;">
                    Enter your parameters and search.
                </div>
            </div>

            <div style="border:1px solid var(--border);border-radius:10px;padding:14px;">
                <strong style="display:block;margin-bottom:6px;">Automatic Search</strong>
                <p style="color:var(--muted);font-size:.8rem;margin-bottom:12px;">
                    Results are based on the album and artist detected from your files.
                </p>

                <div id="musicBrainzAutoResults" class="album-loading">
                    Searching MusicBrainz...
                </div>
            </div>
        </div>

        <div style="border:1px solid var(--border);border-radius:10px;padding:14px;margin-top:14px;">
            <strong style="display:block;margin-bottom:6px;">Open MusicBrainz Link</strong>
            <p style="color:var(--muted);font-size:.8rem;margin-bottom:12px;">
                Paste a MusicBrainz release link to open that release directly.
            </p>

            <div style="display:flex;gap:8px;align-items:center;">
                <input id="musicBrainzReleaseLink" class="button" style="flex:1;" value="" placeholder="https://musicbrainz.org/release/...">
                <button type="button" id="musicBrainzReleaseLinkButton" class="button primary">
                    <svg class="icon"><use href="#i-external"/></svg> Open
                </button>
            </div>

            <div id="musicBrainzLinkStatus" style="margin-top:10px;color:var(--muted);font-size:.82rem;"></div>
        </div>
    `);

    document.getElementById('modal')?.classList.add('musicbrainz-wide-modal');

    // Use real event listeners instead of inline handlers. This keeps album
    // keys containing apostrophes, quotes, ampersands, and other special
    // characters from breaking the MusicBrainz controls.
    const manualSearchButton = document.getElementById('musicBrainzManualSearchButton');
    if (manualSearchButton) {
        manualSearchButton.addEventListener('click', () => {
            searchMusicBrainzManual(key);
        });
    }

    const releaseLinkButton = document.getElementById('musicBrainzReleaseLinkButton');
    if (releaseLinkButton) {
        releaseLinkButton.addEventListener('click', () => {
            openMusicBrainzLink(key);
        });
    }

    searchMusicBrainzAlbum(key);
}

window.showAlbumArtPicker = showAlbumArtPicker;

async function openMusicBrainzLink(encodedKey) {
    const key = String(encodedKey || '');
    const album = albums.get(key);
    const input = document.getElementById('musicBrainzReleaseLink');
    const status = document.getElementById('musicBrainzLinkStatus');

    if (!album) return;

    const value = input?.value.trim() || '';
    if (!value) {
        toast('Enter a MusicBrainz release link.');
        return;
    }

    let releaseId = '';

    try {
        const url = new URL(value);
        const match = url.pathname.match(/\/release\/([0-9a-f-]{36})/i);
        if (match) releaseId = match[1];
    } catch (error) {
        // Also allow pasting the release UUID itself.
        const match = value.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
        if (match) releaseId = match[1];
    }

    if (!releaseId) {
        toast('That does not look like a MusicBrainz release link.');
        return;
    }

    try {
        if (status) status.textContent = 'Loading MusicBrainz release...';
        toast('Loading release details...');

        const detail = await musicBrainzRequest('release', { id: releaseId });

        let coverUrl = '';
        try {
            const cover = await musicBrainzRequest('cover', { id: releaseId });
            const front = Array.isArray(cover.images)
                ? cover.images.find(image => image.front) || cover.images[0]
                : null;

            if (front) {
                coverUrl = `musicbrainz.php?encore_mb=cover_image&id=${encodeURIComponent(releaseId)}`;
            }
        } catch (error) {
            console.warn('Cover lookup failed:', error);
        }

        selectedMusicBrainzRelease = {
            ...detail,
            id: releaseId,
            coverUrl
        };

        if (status) status.textContent = '';
        renderSelectedMusicBrainzRelease(key);
    } catch (error) {
        console.error('MusicBrainz link lookup error:', error);
        if (status) {
            status.textContent = error.message || 'Could not load that MusicBrainz release.';
        }
        toast('Could not load that MusicBrainz release.');
    }
}

window.openMusicBrainzLink = openMusicBrainzLink;

function getMusicBrainzArtist(release) {
    if (release?.['artist-credit']?.length) {
        return release['artist-credit']
            .map(credit => credit.name || credit.artist?.name || '')
            .join('');
    }

    return release?.['artist-credit-phrase'] || 'Unknown Artist';
}

async function searchMusicBrainzAlbum(key) {
    const album = albums.get(key);
    if (!album) return;

    const audioFiles = album.files.filter(isAudioFile);
    if (!audioFiles.length) {
        toast('This album has no audio files.');
        closeModal();
        return;
    }

    const firstFile = audioFiles[0];
    const filename = firstFile.name.replace(/\.[^/.]+$/, '');
    const artistMatch = filename.match(/^(.+?)\s+(?:-|–|—)\s+(.+)$/);
    const detectedArtist = artistMatch ? artistMatch[1].trim() : '';
    const escapedAlbum = musicBrainzEscape(album.name);

    let query = `release:"${escapedAlbum}"`;
    if (detectedArtist) {
        query += ` AND artist:"${musicBrainzEscape(detectedArtist)}"`;
    }

    const container = document.getElementById('musicBrainzAutoResults');

    try {
        if (container) container.innerHTML = '<div class="album-loading">Searching MusicBrainz...</div>';

        let data = await musicBrainzRequest('search', { query, limit: '10' });
        let releases = Array.isArray(data.releases) ? data.releases : [];

        if (!releases.length && detectedArtist) {
            data = await musicBrainzRequest('search', {
                query: `release:"${escapedAlbum}"`,
                limit: '10'
            });
            releases = Array.isArray(data.releases) ? data.releases : [];
        }

        const seen = new Set();
        releases = releases.filter(release => {
            if (!release.id || seen.has(release.id)) return false;
            seen.add(release.id);
            return true;
        }).slice(0, 10);

        await loadMusicBrainzCoverPreviews(releases);

        musicBrainzAutoResults = releases;
        musicBrainzResults = musicBrainzAutoResults;

        renderMusicBrainzResults(key, 'auto');

    } catch (error) {
        console.error('MusicBrainz search error:', error);
        if (container) {
            container.innerHTML = `
                <div class="card" style="text-align:center;">
                    Could not search MusicBrainz.<br>
                    <span style="color:var(--muted);font-size:.82rem;">
                        ${escapeHTML(error.message || 'Unknown error')}
                    </span>
                </div>
            `;
        }
    }
}

window.searchMusicBrainzAlbum = searchMusicBrainzAlbum;

async function searchMusicBrainzManual(encodedKey) {
    const key = String(encodedKey || '');
    const album = albums.get(key);
    if (!album) return;

    const artist = document.getElementById('manualLookupArtist')?.value.trim() || '';
    const albumName = document.getElementById('manualLookupAlbum')?.value.trim() || '';
    const year = document.getElementById('manualLookupYear')?.value.trim() || '';
    const country = document.getElementById('manualLookupCountry')?.value.trim() || '';

    if (!albumName) {
        toast('Enter an album name.');
        return;
    }

    const container = document.getElementById('musicBrainzManualResults');
    if (container) container.innerHTML = '<div class="album-loading">Searching MusicBrainz...</div>';

    try {
        let query = `release:"${musicBrainzEscape(albumName)}"`;
        if (artist) query += ` AND artist:"${musicBrainzEscape(artist)}"`;
        if (year) query += ` AND date:${musicBrainzEscape(year)}*`;
        if (country) query += ` AND country:${musicBrainzEscape(country)}`;

        let data = await musicBrainzRequest('search', { query, limit: '10' });
        let releases = Array.isArray(data.releases) ? data.releases : [];

        // If optional parameters made the search too restrictive, retry using
        // only the required album/artist fields before declaring no results.
        if (!releases.length && (year || country)) {
            query = `release:"${musicBrainzEscape(albumName)}"`;
            if (artist) query += ` AND artist:"${musicBrainzEscape(artist)}"`;

            data = await musicBrainzRequest('search', { query, limit: '10' });
            releases = Array.isArray(data.releases) ? data.releases : [];
        }

        if (!releases.length && artist) {
            data = await musicBrainzRequest('search', {
                query: `release:"${musicBrainzEscape(albumName)}"`,
                limit: '10'
            });
            releases = Array.isArray(data.releases) ? data.releases : [];
        }

        const seen = new Set();
        releases = releases.filter(result => {
            if (!result.id || seen.has(result.id)) return false;
            seen.add(result.id);
            return true;
        }).slice(0, 10);

        await loadMusicBrainzCoverPreviews(releases);

        musicBrainzManualResults = releases;
        musicBrainzResults = musicBrainzManualResults;

        renderMusicBrainzResults(key, 'manual');

    } catch (error) {
        console.error('Manual MusicBrainz search error:', error);
        if (container) {
            container.innerHTML = `
                <div class="card" style="text-align:center;">
                    Search failed.<br>
                    <span style="color:var(--muted);font-size:.82rem;">${escapeHTML(error.message || 'Unknown error')}</span>
                </div>
            `;
        }
    }
}

window.searchMusicBrainzManual = searchMusicBrainzManual;

async function loadMusicBrainzCoverPreviews(releases) {
    if (!Array.isArray(releases) || !releases.length) return;

    /*
     * Do not make a separate MusicBrainz API request for every result.
     * Cover Art Archive exposes the artwork URL directly, so we can test
     * the images in parallel. This makes a 10-result search dramatically
     * faster while still hiding releases that do not actually have artwork.
     */
    const checks = releases.map(release => new Promise(resolve => {
        release.coverUrl = '';

        if (!release?.id) {
            resolve(null);
            return;
        }

        const image = new Image();
        let settled = false;

        const finish = hasArtwork => {
            if (settled) return;
            settled = true;
            release.coverUrl = hasArtwork
                ? `musicbrainz.php?encore_mb=cover_image&id=${encodeURIComponent(release.id)}`
                : '';
            resolve(hasArtwork ? release : null);
        };

        image.onload = () => finish(true);
        image.onerror = () => finish(false);

        /* A small, fast CAA thumbnail is enough to verify artwork exists. */
        image.src = `https://coverartarchive.org/release/${encodeURIComponent(release.id)}/front-250`;

        /* Never let one broken/slow image hold up the whole search. */
        setTimeout(() => finish(false), 5000);
    }));

    await Promise.all(checks);
}

function renderMusicBrainzResults(key, source = 'auto') {
    const container = document.getElementById(
        source === 'manual'
            ? 'musicBrainzManualResults'
            : 'musicBrainzAutoResults'
    );

    if (!container) return;

    const results = source === 'manual'
        ? musicBrainzManualResults
        : musicBrainzAutoResults;

    if (!results.length) {
        container.innerHTML = `
            <div class="card" style="text-align:center;">
                No MusicBrainz releases were found.
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <p style="color:var(--muted);font-size:.85rem;margin-bottom:14px;">
            Choose the correct release. Album art is shown when available.
        </p>
        <div class="musicbrainz-album-grid">
            ${results.map((release, index) => `
                <button type="button" class="musicbrainz-album-option"
                    data-mb-index="${index}"
                    data-mb-source="${escapeHTML(source)}">
                    <div class="musicbrainz-cover">
                        ${release.coverUrl
                            ? `<img src="${escapeHTML(release.coverUrl)}" alt="">`
                            : '<span style="color:var(--muted);font-size:.8rem;">No artwork</span>'}
                    </div>
                    <strong class="musicbrainz-title">${escapeHTML(release.title || 'Unknown Album')}</strong>
                    <span class="musicbrainz-meta">${escapeHTML(getMusicBrainzArtist(release))}</span>
                    <span class="musicbrainz-meta">${escapeHTML(release.date || release.country || 'Release')}</span>
                </button>
            `).join('')}
        </div>
    `;

    // Use normal event listeners instead of inline onclick attributes. This
    // prevents album/folder names containing apostrophes or other special
    // characters from breaking release selection.
    container.querySelectorAll('.musicbrainz-album-option').forEach(button => {
        button.addEventListener('click', () => {
            const index = Number(button.dataset.mbIndex);
            const selectedSource = button.dataset.mbSource || source;
            selectMusicBrainzRelease(encodeURIComponent(key), index, selectedSource);
        });
    });
}
window.renderMusicBrainzResults = renderMusicBrainzResults;

async function selectMusicBrainzRelease(encodedKey, index, source = 'auto') {
    const key = decodeURIComponent(encodedKey);
    const album = albums.get(key);
    const results = source === 'manual'
        ? musicBrainzManualResults
        : musicBrainzAutoResults;
    const release = results[index];

    if (!album || !release) return;

    try {
        toast('Loading release details...');

        const detail = await musicBrainzRequest('release', { id: release.id });

        selectedMusicBrainzRelease = {
            ...release,
            ...detail,
            coverUrl: release.coverUrl || ''
        };

        if (!selectedMusicBrainzRelease.coverUrl) {
            try {
                const cover = await musicBrainzRequest('cover', { id: release.id });
                const front = Array.isArray(cover.images)
                    ? cover.images.find(image => image.front) || cover.images[0]
                    : null;
                if (front) {
                    selectedMusicBrainzRelease.coverUrl =
                        `musicbrainz.php?encore_mb=cover_image&id=${encodeURIComponent(release.id)}`;
                }
            } catch (error) {
                console.warn('Cover lookup failed:', error);
            }
        }

        renderSelectedMusicBrainzRelease(key);

    } catch (error) {
        console.error('MusicBrainz release lookup error:', error);
        toast('Could not load that MusicBrainz release.');
    }
}

window.selectMusicBrainzRelease = selectMusicBrainzRelease;

window.selectMusicBrainzRelease = selectMusicBrainzRelease;

function getMusicBrainzTracks(release) {
    const result = [];

    (release.media || []).forEach((medium, mediumIndex) => {
        (medium.tracks || []).forEach((track, trackIndex) => {
            const recording = track.recording || {};
            result.push({
                title: track.title || recording.title || '',
                number: Number(track.position || trackIndex + 1),
                medium: mediumIndex + 1,
                duration: Number(track.length || recording.length || 0),
                artist: getMusicBrainzArtist(recording) || getMusicBrainzArtist(release)
            });
        });
    });

    return result;
}

function normalizeMusicText(value) {
    return String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/&/g, ' and ')
        .replace(/[^a-z0-9]+/g, ' ')
        .trim();
}

function findBestMusicBrainzTrack(file, apiTracks, fallbackIndex) {
    if (!apiTracks?.length) return null;

    const filename = file.name.replace(/\.[^/.]+$/, '');
    const cleaned = filename
        .replace(/^\s*\d{1,3}[\s._-]+/, '')
        .replace(/^\s*(?:track|song|audio)\s*\d{1,3}[\s._-]*/i, '')
        .trim();

    const localText = normalizeMusicText(cleaned);
    let best = null;
    let bestScore = 0;

    apiTracks.forEach(track => {
        const apiText = normalizeMusicText(track.title);
        if (!apiText) return;

        if (localText === apiText) {
            best = track;
            bestScore = 1;
            return;
        }

        const localWords = new Set(localText.split(/\s+/).filter(word => word.length > 2));
        const apiWords = new Set(apiText.split(/\s+/).filter(word => word.length > 2));
        let overlap = 0;

        localWords.forEach(word => {
            if (apiWords.has(word)) overlap++;
        });

        const score = overlap / Math.max(localWords.size, apiWords.size, 1);
        if (score > bestScore) {
            bestScore = score;
            best = track;
        }
    });

    const numberMatch = filename.match(/^\s*(?:track|song|audio)?\s*0*(\d{1,3})\s*$/i);
    if ((!best || bestScore < 0.35) && numberMatch) {
        const number = Number(numberMatch[1]);
        const numbered = apiTracks.find(track => Number(track.number) === number);
        if (numbered) return numbered;
    }

    return best || apiTracks[fallbackIndex] || null;
}

function saveManualMusicBrainzTitle(element) {
    if (!element) return;

    const fileId = element.dataset.fileId;
    if (!fileId) return;

    const value = element.textContent.trim();
    const defaultTitle = (element.dataset.defaultTitle || '').trim();

    if (value === defaultTitle) {
        delete manualMusicBrainzTitles[fileId];
    } else {
        manualMusicBrainzTitles[fileId] = value;
    }
}

function handleMusicBrainzTitleKey(event, element) {
    if (event.key === 'Enter') {
        event.preventDefault();
        element.blur();
    }
}

window.saveManualMusicBrainzTitle = saveManualMusicBrainzTitle;
window.handleMusicBrainzTitleKey = handleMusicBrainzTitleKey;

function renderSelectedMusicBrainzRelease(key) {
    const release = selectedMusicBrainzRelease;
    const album = albums.get(key);
    if (!release || !album) return;

    const songs = getMusicBrainzTracks(release);
    const localFiles = album.files.filter(isAudioFile);
    const matches = localFiles.map((file, index) => ({
        file,
        match: findBestMusicBrainzTrack(file, songs, index)
    }));

    const artwork = release.coverUrl || '';
    const artist = getMusicBrainzArtist(release);

    openModal(`
        <h2>Confirm Album Information</h2>

        <div class="musicbrainz-confirm">
            <div class="musicbrainz-selected-cover">
                ${artwork
                    ? `<img src="${escapeHTML(artwork)}" alt="">`
                    : `<svg class="icon"><use href="#i-music"/></svg>`
                }
            </div>

            <div>
                <div class="metadata-preview-row"><strong>Artist</strong><span>${escapeHTML(artist)}</span></div>
                <div class="metadata-preview-row"><strong>Album</strong><span>${escapeHTML(release.title || 'Unknown Album')}</span></div>
                <div class="metadata-preview-row"><strong>Release</strong><span>${escapeHTML(release.date || 'Unknown')}</span></div>

                <div class="metadata-update-options">
                    <strong>Update Metadata</strong>
                    <label><input type="checkbox" id="mbUpdateArtist" checked> Update artist for every song</label>
                    <label><input type="checkbox" id="mbUpdateAlbum" checked> Update album for every song</label>
                    <label><input type="checkbox" id="mbUpdateSongs" checked> Correct individual song names</label>
                    <label><input type="checkbox" id="mbUpdateArtwork" checked> Embed album artwork in every MP3</label>
                </div>
            </div>
        </div>

        <div style="margin-top:22px;">
            <strong>Song Matches</strong>
            <p style="color:var(--muted);font-size:.8rem;margin:5px 0 10px;">
                Review the matches before writing the files.
            </p>
            <div class="musicbrainz-song-list">
    ${matches.length
        ? matches.map(({ file, match }, index) => {

            const fileId =
                trackId(file);

            const savedTitle =
                manualMusicBrainzTitles[fileId];

            const suggestedTitle =
                match
                    ? match.title
                    : '';

            const displayedTitle =
                savedTitle !== undefined
                    ? savedTitle
                    : suggestedTitle;

            return `
                <div class="musicbrainz-song-row">

                    <span>
                        ${escapeHTML(file.name)}
                    </span>

                    <span class="musicbrainz-arrow">
                        →
                    </span>

                    <span
                        class="musicbrainz-match editable-musicbrainz-title"
                        contenteditable="true"
                        spellcheck="false"
                        data-file-id="${escapeHTML(fileId)}"
                        data-default-title="${escapeHTML(suggestedTitle)}"
                        onblur="saveManualMusicBrainzTitle(this)"
                        onkeydown="handleMusicBrainzTitleKey(event, this)"
                    >${escapeHTML(displayedTitle)}</span>

                </div>
            `;

        }).join('')
        : `
            <div style="
                padding:14px;
                color:var(--muted);
            ">
                No audio files found.
            </div>
        `
    }
</div>

        <div style="margin-top:14px;padding:12px;border:1px solid var(--border);border-radius:8px;color:var(--muted);font-size:.8rem;">
            Apply will modify the actual MP3 files. Your browser will ask you to select the music folder with read/write permission.
        </div>

        <div class="modal-actions">
            <button id="mbConfirmBackButton" class="button" type="button">Back</button>
            <button id="mbApplyButton" class="button primary" type="button">
                <svg class="icon"><use href="#i-art"/></svg> Apply to MP3 Files
            </button>
        </div>
    `);

    // Do not put the album key into inline JavaScript. Album/folder names can
    // contain apostrophes and other characters that can break an onclick
    // attribute before the handler ever runs.
    document.getElementById('mbConfirmBackButton')?.addEventListener('click', () => {
        renderMusicBrainzResults(key);
    });

    document.getElementById('mbApplyButton')?.addEventListener('click', () => {
        applyMusicBrainzRelease(key);
    });
}

window.renderSelectedMusicBrainzRelease = renderSelectedMusicBrainzRelease;

/* =========================================================
   FILE SYSTEM ACCESS + ID3v2.3 WRITING
========================================================= */

function normalizeMusicPath(path) {
    return String(path || '').replaceAll('\\', '/').replace(/^\/+/, '').toLowerCase();
}

function stripRootFolder(path) {
    const parts = normalizeMusicPath(path).split('/').filter(Boolean);
    return parts.length > 1 ? parts.slice(1).join('/') : parts.join('/');
}

async function collectMP3Handles(directoryHandle, relativePath = '', output = new Map()) {
    for await (const entry of directoryHandle.values()) {
        const nextPath = relativePath ? `${relativePath}/${entry.name}` : entry.name;

        if (entry.kind === 'file' && entry.name.toLowerCase().endsWith('.mp3')) {
            output.set(normalizeMusicPath(nextPath), entry);
        } else if (entry.kind === 'directory') {
            await collectMP3Handles(entry, nextPath, output);
        }
    }

    return output;
}

async function ensureWritableAlbumFiles(album) {
    if (typeof window.showDirectoryPicker !== 'function') {
        throw new Error('Direct MP3 writing requires Chrome or Edge with File System Access support, using HTTPS or localhost.');
    }

    const matched = new Map();
    const mp3Files = album.files.filter(file => /\.mp3$/i.test(file.name));

    // Files loaded from the directory picker carry their exact writable handle.
    // Use it first so metadata writes never depend on path-string matching.
    for (const file of mp3Files) {
        const handle = file.__encoreFileHandle;
        if (handle && typeof handle.createWritable === 'function') {
            matched.set(normalizeMusicPath(file.webkitRelativePath || file.name), handle);
        }
    }

    if (matched.size === mp3Files.length && mp3Files.length) return matched;

    // Fallback for older in-memory files: rediscover the handles from the saved root.
    let root = null;
    try { root = await getSavedFolderHandle(); } catch (error) {
        console.warn('Could not retrieve saved music folder:', error);
    }

    if (root) {
        try {
            let permission = await root.queryPermission({ mode: 'readwrite' });
            if (permission !== 'granted') permission = await root.requestPermission({ mode: 'readwrite' });
            if (permission !== 'granted') root = null;
        } catch (error) {
            console.warn('Could not get write permission for saved folder:', error);
            root = null;
        }
    }

    if (!root) {
        toast('Select your music folder to allow MP3 changes.');
        root = await window.showDirectoryPicker({ mode: 'readwrite' });
        await saveFolderHandle(root);
    }

    const allHandles = await collectMP3Handles(root);
    for (const file of mp3Files) {
        const original = normalizeMusicPath(file.webkitRelativePath || file.name);
        const relative = stripRootFolder(original);
        const filename = normalizeMusicPath(file.name);
        let handle = allHandles.get(original) || allHandles.get(relative);

        if (!handle) {
            const candidates = [...allHandles.entries()].filter(([path]) =>
                path === original || path === relative ||
                path.endsWith('/' + relative) ||
                path.endsWith('/' + filename)
            );
            if (candidates.length === 1) handle = candidates[0][1];
        }
        if (handle) matched.set(original, handle);
    }

    if (!matched.size) {
        throw new Error(`No MP3 files from this album could be opened for writing. The album contains ${mp3Files.length} MP3 file${mp3Files.length === 1 ? '' : 's'}.`);
    }
    return matched;
}

function concatUint8Arrays(...arrays) {
    const total = arrays.reduce((sum, array) => sum + array.length, 0);
    const output = new Uint8Array(total);
    let offset = 0;
    for (const array of arrays) {
        output.set(array, offset);
        offset += array.length;
    }
    return output;
}

function synchsafe32(value) {
    return new Uint8Array([
        (value >>> 21) & 0x7f,
        (value >>> 14) & 0x7f,
        (value >>> 7) & 0x7f,
        value & 0x7f
    ]);
}

function uint32BE(value) {
    return new Uint8Array([
        (value >>> 24) & 0xff,
        (value >>> 16) & 0xff,
        (value >>> 8) & 0xff,
        value & 0xff
    ]);
}

function encodeUTF16LEWithBOM(value) {
    const text = String(value || '');
    const output = new Uint8Array(2 + text.length * 2);
    output[0] = 0xff;
    output[1] = 0xfe;
    const view = new DataView(output.buffer);
    for (let i = 0; i < text.length; i++) {
        view.setUint16(2 + i * 2, text.charCodeAt(i), true);
    }
    return output;
}

function makeID3TextFrame(id, value) {
    if (!value) return new Uint8Array();

    const payload = concatUint8Arrays(
        new Uint8Array([0x01]),
        encodeUTF16LEWithBOM(value),
        new Uint8Array([0x00, 0x00])
    );

    return concatUint8Arrays(
        new TextEncoder().encode(id),
        uint32BE(payload.length),
        new Uint8Array([0x00, 0x00]),
        payload
    );
}

function getImageMimeType(blob) {
    if (blob?.type) return blob.type.toLowerCase();
    return 'image/jpeg';
}

function makeID3APICFrame(imageBytes, mimeType = 'image/jpeg') {
    if (!imageBytes?.length) return new Uint8Array();

    const mime = new TextEncoder().encode(mimeType || 'image/jpeg');

    const payload = concatUint8Arrays(
        new Uint8Array([0x00]),
        mime,
        new Uint8Array([0x00]),
        new Uint8Array([0x03]),
        new Uint8Array([0x00]),
        imageBytes
    );

    return concatUint8Arrays(
        new TextEncoder().encode('APIC'),
        uint32BE(payload.length),
        new Uint8Array([0x00, 0x00]),
        payload
    );
}

function readSynchsafe32(bytes, offset) {
    return (
        ((bytes[offset] & 0x7f) << 21) |
        ((bytes[offset + 1] & 0x7f) << 14) |
        ((bytes[offset + 2] & 0x7f) << 7) |
        (bytes[offset + 3] & 0x7f)
    ) >>> 0;
}

function removeExistingID3v2(bytes) {
    if (
        bytes.length < 10 ||
        bytes[0] !== 0x49 ||
        bytes[1] !== 0x44 ||
        bytes[2] !== 0x33
    ) return bytes;

    const flags = bytes[5];
    let total = 10 + readSynchsafe32(bytes, 6);

    if ((flags & 0x10) !== 0) total += 10;

    return total < bytes.length ? bytes.slice(total) : new Uint8Array();
}

function removeID3v1(bytes) {
    if (bytes.length < 128) return bytes;

    const offset = bytes.length - 128;
    if (
        bytes[offset] === 0x54 &&
        bytes[offset + 1] === 0x41 &&
        bytes[offset + 2] === 0x47
    ) return bytes.slice(0, offset);

    return bytes;
}

function getExistingID3v23Frames(bytes, replaceIds = new Set()) {
    const frames = [];
    const tagEnd = getID3TagEnd(bytes);

    if (!tagEnd || bytes[3] < 3) return frames;

    let offset = 10;
    while (offset + 10 <= tagEnd) {
        const id = String.fromCharCode(...bytes.slice(offset, offset + 4));

        if (!/^[A-Z0-9]{4}$/.test(id)) break;

        const frameSize = getID3FrameSize(bytes, offset + 4, bytes[3]);
        if (frameSize <= 0 || offset + 10 + frameSize > tagEnd) break;

        if (!replaceIds.has(id)) {
            frames.push(bytes.slice(offset, offset + 10 + frameSize));
        }

        offset += 10 + frameSize;
    }

    return frames;
}

function buildID3v23Tag(metadata, originalBytes = null) {
    const replaceIds = new Set(['TIT2', 'TPE1', 'TALB', 'TRCK']);
    const frames = originalBytes
        ? getExistingID3v23Frames(originalBytes, replaceIds)
        : [];

    if (metadata.title !== undefined) {
        frames.push(makeID3TextFrame('TIT2', metadata.title));
    }
    if (metadata.artist !== undefined) {
        frames.push(makeID3TextFrame('TPE1', metadata.artist));
    }
    if (metadata.album !== undefined) {
        frames.push(makeID3TextFrame('TALB', metadata.album));
    }
    if (metadata.trackNumber !== undefined && metadata.trackNumber !== '') {
        frames.push(makeID3TextFrame('TRCK', String(metadata.trackNumber)));
    }
    if (metadata.artwork?.length) {
        frames.push(makeID3APICFrame(metadata.artwork, metadata.artworkMime || 'image/jpeg'));
    }

    const frameBytes = concatUint8Arrays(...frames);
    const padding = new Uint8Array(1024);
    const body = concatUint8Arrays(frameBytes, padding);

    return concatUint8Arrays(
        new Uint8Array([
            0x49, 0x44, 0x33,
            0x03, 0x00,
            0x00,
            ...synchsafe32(body.length)
        ]),
        body
    );
}

async function writeMP3ID3Tag(fileHandle, metadata) {
    if (!fileHandle) throw new Error('No writable MP3 file was found.');

    const file = await fileHandle.getFile();
    const original = new Uint8Array(await file.arrayBuffer());

    let audioBytes = removeExistingID3v2(original);
    audioBytes = removeID3v1(audioBytes);

    // Rewrite the requested fields while preserving every other existing
    // ID3v2.3/v2.4 frame, including embedded album artwork.
    const tag = buildID3v23Tag(metadata, original);
    const output = concatUint8Arrays(tag, audioBytes);
    const writable = await fileHandle.createWritable();

    try {
        await writable.write(output);
        await writable.close();
    } catch (error) {
        try { await writable.abort(); } catch (e) {}
        throw error;
    }
}

function getID3TagEnd(bytes) {
    if (
        bytes.length < 10 ||
        bytes[0] !== 0x49 ||
        bytes[1] !== 0x44 ||
        bytes[2] !== 0x33
    ) {
        return 0;
    }

    let end = 10 + readSynchsafe32(bytes, 6);

    if ((bytes[5] & 0x10) !== 0) {
        end += 10;
    }

    return Math.min(end, bytes.length);
}

function getID3FrameSize(bytes, offset, version) {
    if (version >= 4) {
        return readSynchsafe32(bytes, offset);
    }

    return (
        ((bytes[offset] & 0xff) << 24) |
        ((bytes[offset + 1] & 0xff) << 16) |
        ((bytes[offset + 2] & 0xff) << 8) |
        (bytes[offset + 3] & 0xff)
    ) >>> 0;
}

function makeID3v23ArtworkTag(originalBytes, artworkBytes, artworkMime) {
    const frames = [];
    const tagEnd = getID3TagEnd(originalBytes);

    if (tagEnd) {
        const version = originalBytes[3];
        let offset = 10;

        while (offset + 10 <= tagEnd) {
            const idBytes = originalBytes.slice(offset, offset + 4);
            const id = String.fromCharCode(...idBytes);

            if (!/^[A-Z0-9]{4}$/.test(id)) {
                break;
            }

            const frameSize = getID3FrameSize(
                originalBytes,
                offset + 4,
                version
            );

            if (
                frameSize <= 0 ||
                offset + 10 + frameSize > tagEnd
            ) {
                break;
            }

            // Replace existing album art, but preserve every other tag frame.
            if (id !== 'APIC') {
                frames.push(
                    originalBytes.slice(
                        offset,
                        offset + 10 + frameSize
                    )
                );
            }

            offset += 10 + frameSize;
        }
    }

    const apic = makeID3APICFrame(
        artworkBytes,
        artworkMime || 'image/jpeg'
    );

    const frameBytes = concatUint8Arrays(
        ...frames,
        apic
    );

    const padding = new Uint8Array(1024);
    const body = concatUint8Arrays(frameBytes, padding);

    return concatUint8Arrays(
        new Uint8Array([
            0x49, 0x44, 0x33,
            0x03, 0x00,
            0x00,
            ...synchsafe32(body.length)
        ]),
        body
    );
}

async function writeMP3ArtworkPreservingMetadata(
    fileHandle,
    artworkBytes,
    artworkMime
) {
    const file = await fileHandle.getFile();
    const original = new Uint8Array(await file.arrayBuffer());

    const audioBytes = removeID3v1(
        removeExistingID3v2(original)
    );

    const tag = makeID3v23ArtworkTag(
        original,
        artworkBytes,
        artworkMime
    );

    const output = concatUint8Arrays(
        tag,
        audioBytes
    );

    const writable = await fileHandle.createWritable();

    try {
        await writable.write(output);
        await writable.close();
    } catch (error) {
        try { await writable.abort(); } catch (e) {}
        throw error;
    }
}

async function collectMP3HandlesForArtwork(
    directoryHandle,
    relativePath = '',
    output = new Map()
) {
    for await (const entry of directoryHandle.values()) {
        const nextPath = relativePath
            ? `${relativePath}/${entry.name}`
            : entry.name;

        if (
            entry.kind === 'file' &&
            entry.name.toLowerCase().endsWith('.mp3')
        ) {
            output.set(
                normalizeMusicPath(nextPath),
                entry
            );
        } else if (entry.kind === 'directory') {
            await collectMP3HandlesForArtwork(
                entry,
                nextPath,
                output
            );
        }
    }

    return output;
}

/* =========================================================
   READ EMBEDDED ALBUM ART FROM THE FIRST MP3 IN EACH ALBUM
========================================================= */

function synchsafeToNumber(bytes, offset) {
    return (
        ((bytes[offset] & 0x7f) << 21) |
        ((bytes[offset + 1] & 0x7f) << 14) |
        ((bytes[offset + 2] & 0x7f) << 7) |
        (bytes[offset + 3] & 0x7f)
    ) >>> 0;
}

function bigEndian32(bytes, offset) {
    return (
        ((bytes[offset] & 0xff) << 24) |
        ((bytes[offset + 1] & 0xff) << 16) |
        ((bytes[offset + 2] & 0xff) << 8) |
        (bytes[offset + 3] & 0xff)
    ) >>> 0;
}

function findID3EmbeddedArtwork(bytes) {
    if (
        bytes.length < 10 ||
        bytes[0] !== 0x49 ||
        bytes[1] !== 0x44 ||
        bytes[2] !== 0x33
    ) {
        return null;
    }

    const version = bytes[3];
    const flags = bytes[5];
    let tagEnd = 10 + synchsafeToNumber(bytes, 6);

    if (tagEnd > bytes.length) {
        tagEnd = bytes.length;
    }

    let offset = 10;

    if (flags & 0x40) {
        if (offset + 4 > tagEnd) return null;

        if (version === 3) {
            offset += 4 + bigEndian32(bytes, offset);
        } else if (version === 4) {
            offset += synchsafeToNumber(bytes, offset);
        }
    }

    while (offset + 10 <= tagEnd) {

        const id =
            String.fromCharCode(
                bytes[offset],
                bytes[offset + 1],
                bytes[offset + 2],
                bytes[offset + 3]
            );

        if (
            id === '\0\0\0\0' ||
            !/^[A-Z0-9]{4}$/.test(id)
        ) {
            break;
        }

        const frameSize =
            version >= 4
                ? synchsafeToNumber(bytes, offset + 4)
                : bigEndian32(bytes, offset + 4);

        if (
            frameSize <= 0 ||
            offset + 10 + frameSize > tagEnd
        ) {
            break;
        }

        if (id === 'APIC') {

            let p = offset + 10;
            const payloadEnd = p + frameSize;

            const encoding = bytes[p++];

            const mimeStart = p;

            while (
                p < payloadEnd &&
                bytes[p] !== 0
            ) {
                p++;
            }

            const mime =
                new TextDecoder('latin1')
                    .decode(
                        bytes.slice(
                            mimeStart,
                            p
                        )
                    ) ||
                'image/jpeg';

            p++;

            if (p >= payloadEnd) {
                return null;
            }

            // Picture type.
            p++;

            /*
             * Skip the APIC description.
             * Encoding 0/3 uses a single zero byte.
             * Encoding 1/2 uses UTF-16 and therefore a
             * two-byte zero terminator.
             */
            if (
                encoding === 0 ||
                encoding === 3
            ) {

                while (
                    p < payloadEnd &&
                    bytes[p] !== 0
                ) {
                    p++;
                }

                p++;

            } else {

                while (
                    p + 1 < payloadEnd &&
                    !(
                        bytes[p] === 0 &&
                        bytes[p + 1] === 0
                    )
                ) {
                    p += 2;
                }

                p += 2;
            }

            if (p >= payloadEnd) {
                return null;
            }

            const imageBytes =
                bytes.slice(
                    p,
                    payloadEnd
                );

            if (!imageBytes.length) {
                return null;
            }

            return {
                bytes: imageBytes,
                mime:
                    mime.toLowerCase() === 'image/jpg'
                        ? 'image/jpeg'
                        : mime
            };
        }

        offset += 10 + frameSize;
    }

    return null;
}


async function getEmbeddedArtworkFromTrack(file) {

    if (
        !file ||
        !/\.mp3$/i.test(file.name)
    ) {
        return null;
    }

    try {

        const bytes =
            new Uint8Array(
                await file.arrayBuffer()
            );

        const artwork =
            findID3EmbeddedArtwork(bytes);

        if (!artwork) {
            return null;
        }

        return new Blob(
            [artwork.bytes],
            {
                type:
                    artwork.mime ||
                    'image/jpeg'
            }
        );

    } catch (error) {

        console.warn(
            `Could not read embedded artwork from ${file.name}:`,
            error
        );

        return null;
    }
}


async function autoEmbedAlbumArtwork() {

    /*
     * We only inspect ONE MP3 per album.
     *
     * The first MP3 supplies the album's embedded artwork.
     * We do not scan every song and we do not rewrite any files.
     */

    try {

        let artworkCount = 0;

        for (const [albumKey, album] of albums) {

            const firstMP3 =
                album.files.find(
                    file =>
                        /\.mp3$/i.test(
                            file.name
                        )
                );

            if (!firstMP3) {
                continue;
            }

            /*
             * Read the embedded artwork from this one song.
             */
            const artwork =
                await getEmbeddedArtworkFromTrack(
                    firstMP3
                );

            if (!artwork) {
                continue;
            }

            /*
             * Make a browser URL from the extracted image.
             */
            const artworkUrl =
                getFileObjectUrl(
                    artwork,
                    albumArtUrls
                );

            album.artworkFile =
                artwork;

            album.artworkData =
                artworkUrl;

            artworkCount++;

            /*
             * Update tracks if this album is currently open.
             */
            if (
                activeAlbumKey === albumKey
            ) {

                tracks.forEach(track => {

                    if (
                        track.albumKey === albumKey
                    ) {

                        track.artwork =
                            artwork;

                        track.artworkData =
                            artworkUrl;

                        track.metadata = {
                            ...(track.metadata || {}),
                            artworkData:
                                artworkUrl
                        };
                    }
                });

                updatePlayer();
            }

            /*
             * Re-render after each album so covers appear
             * progressively instead of waiting for all albums.
             */
            renderLibrary();

            await new Promise(
                resolve =>
                    requestAnimationFrame(resolve)
            );
        }

        saveState();

        console.info(
            `Encore: loaded embedded artwork from the first MP3 of ${artworkCount} album${artworkCount === 1 ? '' : 's'}.`
        );

    } catch (error) {

        /*
         * Artwork must never prevent the album library
         * from working.
         */
        console.error(
            'Encore embedded artwork scan error:',
            error
        );
    }
}

function blobToBytes(blob) {
    return blob.arrayBuffer().then(buffer => new Uint8Array(buffer));
}

function blobToAlbumDataURL(blob) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        const url = URL.createObjectURL(blob);

        image.onload = () => {
            try {
                const maxSize = 700;
                const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
                const canvas = document.createElement('canvas');
                canvas.width = Math.max(1, Math.round(image.width * scale));
                canvas.height = Math.max(1, Math.round(image.height * scale));
                const ctx = canvas.getContext('2d');
                ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
                resolve(canvas.toDataURL('image/jpeg', 0.82));
            } catch (error) {
                reject(error);
            } finally {
                URL.revokeObjectURL(url);
            }
        };

        image.onerror = () => {
            URL.revokeObjectURL(url);
            reject(new Error('Could not read album artwork.'));
        };

        image.src = url;
    });
}

async function applyMusicBrainzRelease(encodedKey) {
    const key = decodeURIComponent(encodedKey);
    const album = albums.get(key);
    const release = selectedMusicBrainzRelease;

    if (!album || !release) return;

    const updateArtist = document.getElementById('mbUpdateArtist')?.checked;
    const updateAlbum = document.getElementById('mbUpdateAlbum')?.checked;
    const updateSongs = document.getElementById('mbUpdateSongs')?.checked;
    const updateArtwork = document.getElementById('mbUpdateArtwork')?.checked;

    if (!album.files.some(file => file.name.toLowerCase().endsWith('.mp3'))) {
        toast('This album has no MP3 files. Direct ID3 writing only supports MP3.');
        return;
    }

    try {
        toast('Downloading album artwork...');

        let artworkBytes = null;
        let artworkMime = 'image/jpeg';
        let artworkData = '';

        if (updateArtwork && release.coverUrl) {
            const response = await fetch(release.coverUrl, {
                credentials: 'same-origin',
                cache: 'no-store'
            });

            if (response.ok) {
                const blob = await response.blob();
                artworkMime = getImageMimeType(blob);
                artworkBytes = await blobToBytes(blob);
                artworkData = await blobToAlbumDataURL(blob);
            }
        }

        const artist = getMusicBrainzArtist(release);
        const albumName = release.title || album.name;
        const apiTracks = getMusicBrainzTracks(release);
        const audioFiles = album.files.filter(file => file.name.toLowerCase().endsWith('.mp3'));
        const handles = await ensureWritableAlbumFiles(album);

        let written = 0;
        let skipped = 0;

        window.savedTrackState = window.savedTrackState || {};

        for (let index = 0; index < audioFiles.length; index++) {
            const file = audioFiles[index];
            const fileKey = normalizeMusicPath(file.webkitRelativePath || file.name);
            const relativeKey = stripRootFolder(fileKey);
            const handle = handles.get(fileKey) || handles.get(relativeKey) || file.__encoreFileHandle;

            if (!handle) {
                skipped++;
                continue;
            }

            const match = updateSongs
                ? findBestMusicBrainzTrack(file, apiTracks, index)
                : null;

            const fileId = trackId(file);
            const manualTitle = manualMusicBrainzTitles[fileId];
            const selectedTitle = manualTitle !== undefined
                ? String(manualTitle).trim()
                : (match?.title || '');

            const metadata = {};
            if (updateSongs && selectedTitle) metadata.title = selectedTitle;
            if (updateArtist && artist) metadata.artist = artist;
            if (updateAlbum && albumName) metadata.album = albumName;
            if (artworkBytes) {
                metadata.artwork = artworkBytes;
                metadata.artworkMime = artworkMime;
            }

            await writeMP3ID3Tag(handle, metadata);
            written++;

            const id = trackId(file);
            const saved = window.savedTrackState[id] || {};
            const savedMetadata = { ...(saved.metadata || {}) };

            if (metadata.title) savedMetadata.title = metadata.title;
            if (metadata.artist) savedMetadata.artist = metadata.artist;
            if (metadata.album) savedMetadata.album = metadata.album;
            if (artworkData) savedMetadata.artworkData = artworkData;

            window.savedTrackState[id] = {
                ...saved,
                metadata: savedMetadata
            };
        }

        if (artworkData) {
            album.artworkData = artworkData;
            album.artworkFile = null;
        }

        album.name = albumName || album.name;
        album.musicbrainzReleaseId = release.id;

        if (activeAlbumKey === key) {
            tracks.forEach(track => {
                const trackFileId = trackId(track.file);
                const match = updateSongs
                    ? findBestMusicBrainzTrack(track.file, apiTracks, tracks.indexOf(track))
                    : null;
                const manualTitle = manualMusicBrainzTitles[trackFileId];
                const selectedTitle = manualTitle !== undefined
                    ? String(manualTitle).trim()
                    : (match?.title || '');

                if (updateSongs && selectedTitle) {
                    track.title = selectedTitle;
                    track.metadata = { ...(track.metadata || {}), title: selectedTitle };
                }
                if (updateArtist && artist) {
                    track.artist = artist;
                    track.metadata = { ...(track.metadata || {}), artist };
                }
                if (updateAlbum && albumName) {
                    track.album = albumName;
                    track.metadata = { ...(track.metadata || {}), album: albumName };
                }
                if (artworkData) {
                    track.artworkData = artworkData;
                    track.metadata = { ...(track.metadata || {}), artworkData };
                }
            });
        }

        saveState();
        window.aiCleanupReview = null;
        closeModal();
        renderEverything();

        toast(`Updated ${written} MP3 file${written === 1 ? '' : 's'}${skipped ? `; ${skipped} skipped` : ''}.`);

    } catch (error) {
        console.error('MP3 metadata write error:', error);

        if (error?.name === 'AbortError') {
            toast('MP3 update cancelled. No files were changed.');
        } else {
            toast(error.message || 'Could not write MP3 metadata.');
        }
    }
}

window.applyMusicBrainzRelease = applyMusicBrainzRelease;


/* =========================================================
   BASIC METADATA
========================================================= */

function decodeID3Text(bytes, encoding = 0) {
    if (!bytes?.length) return '';

    let data = bytes;
    let decoder;

    try {
        if (encoding === 0) {
            decoder = new TextDecoder('iso-8859-1');
            return decoder.decode(data).replace(/\0+$/g, '').trim();
        }

        if (encoding === 1) {
            if (data.length >= 2 && data[0] === 0xff && data[1] === 0xfe) {
                data = data.slice(2);
                decoder = new TextDecoder('utf-16le');
            } else if (data.length >= 2 && data[0] === 0xfe && data[1] === 0xff) {
                data = data.slice(2);
                decoder = new TextDecoder('utf-16be');
            } else {
                decoder = new TextDecoder('utf-16');
            }
            return decoder.decode(data).replace(/\0+$/g, '').trim();
        }

        if (encoding === 2) {
            decoder = new TextDecoder('utf-16be');
            return decoder.decode(data).replace(/\0+$/g, '').trim();
        }

        if (encoding === 3) {
            decoder = new TextDecoder('utf-8');
            return decoder.decode(data).replace(/\0+$/g, '').trim();
        }
    } catch (error) {
        console.warn('ID3 text decoding failed:', error);
    }

    try {
        return new TextDecoder().decode(data).replace(/\0+$/g, '').trim();
    } catch (error) {
        return '';
    }
}

function readID3TextFrame(frameBytes) {
    if (!frameBytes?.length) return '';

    const encoding = frameBytes[0];
    let end = frameBytes.length;

    /*
     * ID3 text frames may contain multiple values separated by a null
     * terminator. UTF-16 is especially easy to get wrong here: searching
     * for any 00 00 pair can land on the low byte of the LAST character
     * followed by the first byte of the terminator. That chops the final
     * character in names such as "Green Day" into a replacement character.
     *
     * Find UTF-16 terminators on the correct two-byte boundary instead.
     */
    if (encoding === 1 || encoding === 2) {
        let start = 1;

        // Encoding 1 includes a BOM when present. Skip it before looking
        // for the UTF-16 string terminator.
        if (encoding === 1 && frameBytes.length >= 3) {
            if (
                (frameBytes[1] === 0xff && frameBytes[2] === 0xfe) ||
                (frameBytes[1] === 0xfe && frameBytes[2] === 0xff)
            ) {
                start = 3;
            }
        }

        // A UTF-16 terminator is 00 00 and must begin on the same byte
        // alignment as the UTF-16 code units.
        for (let i = start; i + 1 < frameBytes.length; i += 2) {
            if (frameBytes[i] === 0x00 && frameBytes[i + 1] === 0x00) {
                end = i;
                break;
            }
        }
    } else {
        const separator = frameBytes.indexOf(0x00, 1);
        if (separator !== -1) end = separator;
    }

    let value = frameBytes.slice(1, end);

    // Remove the BOM from encoding 1 here as well; decodeID3Text handles
    // either endian order after this point.
    if (encoding === 1 && value.length >= 2) {
        if (
            (value[0] === 0xff && value[1] === 0xfe) ||
            (value[0] === 0xfe && value[1] === 0xff)
        ) {
            value = value.slice(2);
        }
    }

    return decodeID3Text(value, encoding);
}

function readID3Metadata(bytes) {
    const metadata = {};

    if (
        bytes.length < 10 ||
        bytes[0] !== 0x49 ||
        bytes[1] !== 0x44 ||
        bytes[2] !== 0x33
    ) {
        return metadata;
    }

    const version = bytes[3];
    const flags = bytes[5];
    let tagSize = readSynchsafe32(bytes, 6);
    let offset = 10;

    if (offset + tagSize > bytes.length) {
        tagSize = Math.max(0, bytes.length - offset);
    }

    // Extended headers occur in both v2.3 and v2.4. The exact size encoding
    // differs, so handle each version separately before reading frames.
    if ((flags & 0x40) !== 0) {
        if (version === 3 && offset + 4 <= bytes.length) {
            const extendedSize = new DataView(bytes.buffer, bytes.byteOffset + offset, 4).getUint32(0, false);
            offset += 4 + extendedSize;
        } else if (version >= 4 && offset + 4 <= bytes.length) {
            offset += readSynchsafe32(bytes, offset);
        }
    }

    const end = Math.min(bytes.length, 10 + tagSize);

    while (offset + (version >= 3 ? 10 : 6) <= end) {
        let id;
        let frameSize;
        let headerSize;

        if (version >= 3) {
            id = String.fromCharCode(...bytes.slice(offset, offset + 4));
            if (!/^[A-Z0-9]{4}$/.test(id)) break;

            frameSize = version === 4
                ? readSynchsafe32(bytes, offset + 4)
                : new DataView(bytes.buffer, bytes.byteOffset + offset + 4, 4).getUint32(0, false);
            headerSize = 10;
        } else if (version === 2) {
            id = String.fromCharCode(...bytes.slice(offset, offset + 3));
            if (!/^[A-Z0-9]{3}$/.test(id)) break;

            frameSize = (
                (bytes[offset + 3] << 16) |
                (bytes[offset + 4] << 8) |
                bytes[offset + 5]
            ) >>> 0;
            headerSize = 6;
        } else {
            break;
        }

        if (!frameSize) {
            offset += headerSize;
            continue;
        }

        const dataStart = offset + headerSize;
        const dataEnd = dataStart + frameSize;
        if (dataEnd > end) break;

        const frame = bytes.slice(dataStart, dataEnd);

        if (id === 'TIT2' || id === 'TT2') {
            if (!metadata.title) metadata.title = readID3TextFrame(frame);
        } else if (id === 'TPE1' || id === 'TP1') {
            if (!metadata.artist) metadata.artist = readID3TextFrame(frame);
        } else if (id === 'TALB' || id === 'TAL') {
            if (!metadata.album) metadata.album = readID3TextFrame(frame);
        } else if (id === 'TRCK' || id === 'TRK') {
            if (!metadata.trackNumber) {
                const rawTrack = readID3TextFrame(frame);
                const match = String(rawTrack || '').match(/\d+/);
                if (match) metadata.trackNumber = Number(match[0]);
            }
        }

        if (metadata.title && metadata.artist && metadata.album && metadata.trackNumber) break;
        offset = dataEnd;
    }

    return metadata;
}

function readID3v1Metadata(bytes) {
    const metadata = {};
    if (bytes.length < 128) return metadata;

    const offset = bytes.length - 128;
    if (
        bytes[offset] !== 0x54 ||
        bytes[offset + 1] !== 0x41 ||
        bytes[offset + 2] !== 0x47
    ) return metadata;

    const decode = value => {
        try {
            return new TextDecoder('iso-8859-1')
                .decode(value)
                .replace(/\0+$/g, '')
                .trim();
        } catch (error) {
            return '';
        }
    };

    metadata.title = decode(bytes.slice(offset + 3, offset + 33));
    metadata.artist = decode(bytes.slice(offset + 33, offset + 63));
    metadata.album = decode(bytes.slice(offset + 63, offset + 93));

    return metadata;
}

async function readActualMP3Metadata(file) {
    if (!file?.name?.toLowerCase().endsWith('.mp3')) return {};

    try {
        // Metadata lives at the beginning for ID3v2 and at the very end for
        // ID3v1. Reading only those small sections keeps album loading fast.
        const head = new Uint8Array(await file.slice(0, Math.min(file.size, 512 * 1024)).arrayBuffer());
        const id3v2 = readID3Metadata(head);

        if (id3v2.title || id3v2.artist || id3v2.album) {
            return id3v2;
        }

        const tailStart = Math.max(0, file.size - 128);
        const tail = new Uint8Array(await file.slice(tailStart).arrayBuffer());
        return readID3v1Metadata(tail);
    } catch (error) {
        console.warn(`Could not read MP3 metadata from ${file.name}:`, error);
        return {};
    }
}

async function readBasicMetadata(track) {

    const filename = track.file.name.replace(/\.[^/.]+$/, '').trim();
    const savedMetadata = track.metadata || {};

    // The actual ID3 tags are authoritative. This prevents Encore from
    // swapping Artist/Title based on a filename when the MP3 already has
    // proper metadata, which is how dedicated music players behave.
    const embedded = await readActualMP3Metadata(track.file);

    // Embedded ID3 metadata is authoritative for title/artist/album.
    // For track order, an explicit filename number is more reliable for the
    // cleanup workflow because it commonly reflects the actual source order
    // even when an old/stale TRCK tag is present.
    if (embedded.title) {
        track.metadata = { ...(track.metadata || {}), title: embedded.title };
    } else if (savedMetadata.title) {
        track.metadata = { ...(track.metadata || {}), title: savedMetadata.title };
    }

    if (embedded.artist) {
        track.metadata = { ...(track.metadata || {}), artist: embedded.artist };
    } else if (savedMetadata.artist) {
        track.metadata = { ...(track.metadata || {}), artist: savedMetadata.artist };
    }

    if (embedded.album) {
        track.metadata = { ...(track.metadata || {}), album: embedded.album };
    } else if (savedMetadata.album) {
        track.metadata = { ...(track.metadata || {}), album: savedMetadata.album };
    }

    const filenameTrackNumber = getFilenameTrackNumber(track.file);

    if (filenameTrackNumber) {
        track.metadata = {
            ...(track.metadata || {}),
            trackNumber: filenameTrackNumber
        };
        track.trackNumber = filenameTrackNumber;
    } else if (embedded.trackNumber) {
        track.metadata = {
            ...(track.metadata || {}),
            trackNumber: embedded.trackNumber
        };
        track.trackNumber = embedded.trackNumber;
    } else if (savedMetadata.trackNumber) {
        track.metadata = {
            ...(track.metadata || {}),
            trackNumber: savedMetadata.trackNumber
        };
        track.trackNumber = savedMetadata.trackNumber;
    }

    // Only use the filename when the MP3 does not provide a title tag.
    // The old parser always assumed "Artist - Title", which caused values
    // to appear reversed for filenames using "Title - Artist" and caused
    // filenames to override valid embedded metadata.
    if (!track.metadata?.title) {
        const artistTitleMatch = filename.match(/^(.+?)\s+(?:-|–|—)\s+(.+)$/);

        if (artistTitleMatch && !track.metadata?.artist) {
            track.artist = artistTitleMatch[1].trim();
            track.title = artistTitleMatch[2].trim();
        } else {
            track.title = filename;
        }
    }

    if (!track.metadata?.artist && embedded.artist) {
        track.artist = embedded.artist;
    }

    if (!track.metadata?.album && embedded.album) {
        track.album = embedded.album;
    }

    const url = URL.createObjectURL(track.file);
    objectUrls.set(track.id, url);

    const tempAudio = new Audio();
    tempAudio.src = url;

    tempAudio.addEventListener(
        'loadedmetadata',
        () => {
            track.duration = tempAudio.duration;
            renderLibrary();
            updateStatistics();
        },
        { once: true }
    );
}


/* =========================================================
   PLAY TRACK
========================================================= */

function playTrack(index) {
    if (
        index < 0 ||
        index >= tracks.length
    ) {
        return;
    }

    playTrackObject(tracks[index]);
}


function playTrackObject(track) {
    if (!track || !track.file) {
        return;
    }

    currentTrack = track;
    currentIndex = tracks.indexOf(track);

    changingTrack = true;
    websiteRequestedPause = false;
    userPausedPlayback = false;

    // Keep the registry synchronized even when this track came from the queue.
    trackRegistry.set(track.id, track);

    const url =
        objectUrls.get(
            track.id
        ) ||
        URL.createObjectURL(
            track.file
        );

    objectUrls.set(
        track.id,
        url
    );

    audio.src = url;

    audio.playbackRate =
        Number(settings.speed) || 1;

    audio.muted = false;
    audio.volume = lastWebsiteVolume;
    changingTrack = false;

    audio.play()
        .catch(
            () => {}
        );

    track.plays =
        (track.plays || 0) + 1;

    /*
     * Add to listening history.
     */
    history = [
        track.id,
        ...history.filter(
            id => id !== track.id
        )
    ].slice(0, 100);

    saveState();

    updatePlayer();
    renderLibrary();
    updateStatistics();

    sendNowPlayingNotification(track);
    updateMediaSession(track);
}


function getPlaybackTracks() {
    const sourceTracks = currentTrack
        ? [...trackRegistry.values()].filter(
            track => track.albumKey === currentTrack.albumKey
        )
        : [...tracks];

    if (!sourceTracks.length) {
        return sourceTracks;
    }

    const trackOrderNumber = track => {
        const value = Number(
            track.metadata?.trackNumber ??
            track.trackNumber
        );

        return Number.isFinite(value) && value > 0
            ? value
            : null;
    };

    sourceTracks.sort((a, b) => {
        const aNumber = trackOrderNumber(a);
        const bNumber = trackOrderNumber(b);

        // Use the MP3's track metadata (TRCK) for album playback order.
        // Filename-derived trackNumber is already seeded into metadata by
        // loadAlbum/readBasicMetadata when no usable tag is present.
        if (aNumber !== null && bNumber !== null && aNumber !== bNumber) {
            return aNumber - bNumber;
        }

        if (aNumber !== null && bNumber === null) {
            return -1;
        }

        if (aNumber === null && bNumber !== null) {
            return 1;
        }

        // Stable fallback: preserve the existing array order instead of
        // alphabetizing an album that has no track numbers.
        return 0;
    });

    return sourceTracks;
}


function playCurrent() {
    if (!currentTrack) {
        if (tracks.length) {
            playTrack(0);
        }

        return;
    }

    userPausedPlayback = false;
    websiteRequestedPause = false;

    audio.play()
        .catch(
            () => {}
        );
}


function pauseCurrent() {
    pauseAudioByWebsite();
}


/* =========================================================
   PLAYER CONTROLS
========================================================= */

document
    .getElementById('playButton')
    .addEventListener(
        'click',
        () => {

            if (audio.paused) {
                playCurrent();
            } else {
                pauseCurrent();
            }

        }
    );


document
    .getElementById('prevButton')
    .addEventListener(
        'click',
        previousTrack
    );


document
    .getElementById('nextButton')
    .addEventListener(
        'click',
        nextTrack
    );


document
    .getElementById('rewindButton')
    .addEventListener(
        'click',
        () => {

            audio.currentTime =
                Math.max(
                    0,
                    audio.currentTime - 10
                );

        }
    );


document
    .getElementById('forwardButton')
    .addEventListener(
        'click',
        () => {

            audio.currentTime =
                Math.min(
                    audio.duration || 0,
                    audio.currentTime + 10
                );

        }
    );


document
    .getElementById('shuffleButton')
    .addEventListener(
        'click',
        () => {

            shuffle =
                !shuffle;

            document
                .getElementById('shuffleButton')
                .classList.toggle(
                    'active',
                    shuffle
                );

            savePreferences();

            toast(
                shuffle
                    ? 'Shuffle enabled'
                    : 'Shuffle disabled'
            );

        }
    );


document
    .getElementById('repeatButton')
    .addEventListener(
        'click',
        () => {

            if (repeatMode === 'off') {

                repeatMode = 'all';

            } else if (
                repeatMode === 'all'
            ) {

                repeatMode = 'one';

            } else {

                repeatMode = 'off';

            }


            const button =
                document.getElementById(
                    'repeatButton'
                );


            button.textContent =
                repeatMode === 'one'
                    ? '<svg class="icon"><use href="#i-repeat"/></svg><small>1</small>'
                    : '<svg class="icon"><use href="#i-repeat"/></svg>';


            button.classList.toggle(
                'active',
                repeatMode !== 'off'
            );


            savePreferences();

            toast(
                repeatMode === 'off'
                    ? 'Repeat disabled'
                    : repeatMode === 'one'
                        ? 'Repeat current track'
                        : 'Repeat playlist'
            );

        }
    );


function nextTrack() {
    const playbackTracks = getPlaybackTracks();

    if (!playbackTracks.length) {
        return;
    }

    // Queue entries are global track IDs, not indexes in the currently-open album.
    while (queue.length) {
        const nextId = queue.shift();
        const queuedTrack = trackRegistry.get(nextId);

        if (queuedTrack) {
            saveState();
            renderQueue();
            playTrackObject(queuedTrack);
            return;
        }
    }

    if (repeatMode === 'one' && currentTrack) {
        playTrackObject(currentTrack);
        return;
    }

    const currentId = currentTrack?.id || null;
    const currentPosition = playbackTracks.findIndex(
        track => track.id === currentId
    );

    let nextIndex;

    if (shuffle) {
        const candidates = playbackTracks
            .map((_, index) => index)
            .filter(index => index !== currentPosition);

        nextIndex = candidates.length
            ? candidates[Math.floor(Math.random() * candidates.length)]
            : undefined;
    } else {
        nextIndex = currentPosition + 1;
    }

    if (
        nextIndex >= playbackTracks.length ||
        nextIndex === undefined ||
        currentPosition === -1
    ) {
        if (repeatMode === 'all') {
            nextIndex =
                shuffle
                    ? Math.floor(Math.random() * playbackTracks.length)
                    : 0;
        } else {
            pauseAudioByWebsite();
            return;
        }
    }

    playTrackObject(playbackTracks[nextIndex]);
}


function previousTrack() {
    const playbackTracks = getPlaybackTracks();

    if (!playbackTracks.length || !currentTrack) {
        return;
    }

    if (audio.currentTime > 5) {
        audio.currentTime = 0;
        return;
    }

    let index = playbackTracks.findIndex(
        track => track.id === currentTrack.id
    ) - 1;

    if (index < 0) {
        index =
            repeatMode === 'all'
                ? playbackTracks.length - 1
                : 0;
    }

    playTrackObject(playbackTracks[index]);
}


/* =========================================================
   AUDIO EVENTS
========================================================= */

audio.addEventListener(
    'play',
    updatePlayer
);


audio.addEventListener(
    'pause',
    updatePlayer
);


audio.addEventListener(
    'timeupdate',
    () => {

        if (
            !isDraggingProgress &&
            audio.duration
        ) {

            const percent =
                (
                    audio.currentTime /
                    audio.duration
                ) * 100;


            document
                .getElementById(
                    'progressBar'
                )
                .value = percent;

        }


        document
            .getElementById(
                'currentTime'
            )
            .textContent =
                formatTime(
                    audio.currentTime
                );

    }
);


audio.addEventListener(
    'loadedmetadata',
    () => {

        document
            .getElementById(
                'duration'
            )
            .textContent =
                formatTime(
                    audio.duration
                );

    }
);


audio.addEventListener(
    'ended',
    () => {

        if (settings.autoplay) {
            nextTrack();
        }

    }
);


audio.addEventListener(
    'error',
    () => {

        toast(
            'This audio file could not be played.'
        );

    }
);


/* =========================================================
   PROGRESS
========================================================= */

const progressBar =
    document.getElementById(
        'progressBar'
    );


progressBar.addEventListener(
    'input',
    () => {

        isDraggingProgress = true;


        if (audio.duration) {

            audio.currentTime =
                (
                    Number(
                        progressBar.value
                    ) / 100
                ) *
                audio.duration;

        }

    }
);


progressBar.addEventListener(
    'change',
    () => {

        isDraggingProgress = false;

    }
);


/* =========================================================
   VOLUME
========================================================= */

const volumeSlider =
    document.getElementById(
        'volumeSlider'
    );


volumeSlider.addEventListener(
    'input',
    event => {

        setAudioVolumeByWebsite(
            Number(event.target.value) / 100
        );


        localStorage.setItem(
            'encore_volume',
            event.target.value
        );

        savePreferences();

    }
);


const savedVolume =
    localStorage.getItem(
        'encore_volume'
    );

lastWebsiteVolume =
    savedVolume !== null &&
    Number.isFinite(Number(savedVolume))
        ? Math.max(0, Math.min(1, Number(savedVolume) / 100))
        : Math.max(0, Math.min(1, audio.volume || 1));


if (savedVolume !== null) {

    volumeSlider.value =
        savedVolume;

    setAudioVolumeByWebsite(
        lastWebsiteVolume
    );

}


/* =========================================================
   PLAYER UI
========================================================= */

function updatePlayer() {

    const title =
        document.getElementById(
            'playerTitle'
        );

    const artist =
        document.getElementById(
            'playerArtist'
        );

    const playButton =
        document.getElementById(
            'playButton'
        );


    // currentIndex belongs to the currently open album. It can be -1 while
    // another album is open even though audio is still playing.
    // currentTrack is the source of truth for the player.
    if (!currentTrack) {

        title.textContent =
            'Nothing playing';

        artist.textContent =
            'Select a song';

        playButton.innerHTML =
            '<svg class="icon"><use href="#i-play"/></svg>';

        return;
    }


    const track =
        currentTrack;


    title.textContent =
        getTrackTitle(track);

    artist.textContent =
        getTrackArtist(track);


    playButton.innerHTML =
        audio.paused
            ? '<svg class="icon"><use href="#i-play"/></svg>'
            : '<svg class="icon"><use href="#i-pause"/></svg>';


    updateArtwork(
        document.getElementById(
            'playerArt'
        ),
        track
    );


    document
        .getElementById(
            'largeTitle'
        )
        .textContent =
            getTrackTitle(track);


    document
        .getElementById(
            'largeArtist'
        )
        .textContent =
            getTrackArtist(track);


    updateArtwork(
        document.getElementById(
            'largeArt'
        ),
        track
    );


    updateTrackDetails(track);

    updateFavoriteButton();

    renderLibrary();

}


function updateArtwork(element, track) {

    if (!element) return;

    const source =
        track.artworkData ||
        track.metadata?.artworkData ||
        (track.artwork ? getFileObjectUrl(track.artwork, albumArtUrls) : '');

    element.innerHTML = source
        ? `<img src="${source}" alt="">`
        : '<svg class="icon"><use href="#i-music"/></svg>';
}


function getFileObjectUrl(file, cache) {
    if (!file) return '';
    const key = file.webkitRelativePath || `${file.name}|${file.size}|${file.lastModified}`;
    if (!cache.has(key)) {
        cache.set(key, URL.createObjectURL(file));
    }
    return cache.get(key);
}



function updateTrackDetails(track) {

    document
        .getElementById(
            'trackDetails'
        )
        .innerHTML = `

            <div>
                <strong>Title:</strong>
                ${escapeHTML(getTrackTitle(track))}
            </div>

            <div>
                <strong>Artist:</strong>
                ${escapeHTML(getTrackArtist(track))}
            </div>

            <div>
                <strong>Album:</strong>
                ${escapeHTML(getTrackAlbum(track))}
            </div>

            <div>
                <strong>Duration:</strong>
                ${formatTime(track.duration)}
            </div>

            <div>
                <strong>File:</strong>
                ${escapeHTML(track.file.name)}
            </div>

            <div>
                <strong>Type:</strong>
                ${escapeHTML(track.file.type || 'Unknown')}
            </div>

            <div>
                <strong>Size:</strong>
                ${formatBytes(track.file.size)}
            </div>

            <div>
                <strong>Plays:</strong>
                ${track.plays || 0}
            </div>

            <div>
                <strong>Mood:</strong>
                ${escapeHTML(getTrackMood(track) || 'Not assigned')}
            </div>

            <div>
                <strong>Album Art:</strong>
                ${track.artworkData || track.metadata?.artworkData ? 'Saved in Encore metadata' : 'Not assigned'}
            </div>
        `;

}


function updateFavoriteButton() {

    if (!currentTrack) {
        return;
    }


    const track = currentTrack;


    const button =
        document.getElementById(
            'favoriteButton'
        );


    button.innerHTML =
        '<svg class="icon"><use href="#i-star"/></svg>';


    button.classList.toggle(
        'active',
        track.favorite
    );


    document
        .getElementById(
            'largeFavorite'
        )
        .innerHTML =
            track.favorite
                ? '<svg class="icon"><use href="#i-star"/></svg> Favorited'
                : '<svg class="icon"><use href="#i-star"/></svg> Favorite';

}


/* =========================================================
   FAVORITES
========================================================= */

function toggleFavorite(index) {

    const track =
        tracks[index];


    track.favorite =
        !track.favorite;


    saveState();

    renderEverything();

    updateFavoriteButton();

}


document
    .getElementById(
        'favoriteButton'
    )
    .addEventListener(
        'click',
        () => {

            if (currentTrack) {
                currentTrack.favorite = !currentTrack.favorite;
                saveState();
                renderEverything();
                updateFavoriteButton();
            }

        }
    );


document
    .getElementById(
        'largeFavorite'
    )
    .addEventListener(
        'click',
        () => {

            if (currentTrack) {
                currentTrack.favorite = !currentTrack.favorite;
                saveState();
                renderEverything();
                updateFavoriteButton();
            }

        }
    );


/* =========================================================
   QUEUE
========================================================= */

function addTrackObjectToQueue(track) {
    if (!track || !track.id) {
        return;
    }

    queue.push(track.id);
    saveState();
    renderQueue();

    toast(
        `${getTrackTitle(track)} added to queue`
    );
}


function addToQueue(index) {
    if (
        index < 0 ||
        index >= tracks.length
    ) {
        return;
    }

    addTrackObjectToQueue(tracks[index]);
}


document
    .getElementById(
        'clearQueue'
    )
    .addEventListener(
        'click',
        () => {
            queue = [];
            saveState();
            renderQueue();
        }
    );


function renderQueue() {
    const list =
        document.getElementById(
            'queueList'
        );

    // Queue entries are kept by stable track ID. A queued track may belong
    // to an album that has not been opened yet, so do not delete entries
    // merely because that album is not currently loaded into the registry.

    if (!queue.length) {

        list.innerHTML =
            `<li class="queue-item">
                <span style="color:var(--muted);">
                    Queue is empty.
                </span>
            </li>`;

        return;
    }


    list.innerHTML =
        queue.map(
            (id, index) => {
                const track = trackRegistry.get(id);

                if (!track) {
                    return '';
                }


                return `

                    <li class="queue-item">

                        <div class="queue-item-title">

                            <strong>
                                ${escapeHTML(
                                    getTrackTitle(track)
                                )}
                            </strong>

                            <span>
                                ${escapeHTML(
                                    getTrackArtist(track)
                                )}
                            </span>

                        </div>

                        <div>

                            <button
                                class="button small"
                                onclick="playQueueItem(${index})"
                            >
                                <svg class="icon"><use href="#i-play"/></svg>
                            </button>

                            <button
                                class="button small"
                                onclick="removeQueueItem(${index})"
                            >
                                <svg class="icon"><use href="#i-close"/></svg>
                            </button>

                        </div>

                    </li>

                `;

            }
        ).join('');

}


window.playQueueItem =
    function(index) {

        const id =
            queue[index];

        const track =
            trackRegistry.get(id);

        if (!track) {
            queue.splice(index, 1);
            saveState();
            renderQueue();
            return;
        }

        queue.splice(
            index,
            1
        );

        saveState();
        renderQueue();

        playTrackObject(track);
    };


window.removeQueueItem =
    function(index) {

        queue.splice(
            index,
            1
        );

        saveState();
        renderQueue();

    };


/* =========================================================
   LIBRARY RENDERING
========================================================= */

let gridView = false;


function renderLibrary() {

    const container = document.getElementById('libraryContainer');

    const albumCount = albums.size;

    if (activeAlbumKey === null) {

        const backButton = document.getElementById('albumBackButton');
        if (backButton) backButton.classList.add('hidden');

        document.getElementById('libraryCount').textContent =
            `${albumCount} album${albumCount === 1 ? '' : 's'}`;

        container.className = settings.albumLayout === 'list'
            ? `album-list album-size-${settings.albumCardSize || 'standard'}`
            : `album-grid album-size-${settings.albumCardSize || 'standard'}`;

        const query = document.getElementById('searchInput').value.toLowerCase().trim();

        const visibleAlbums = [...albums.values()]
            .filter(album => album.name.toLowerCase().includes(query))
            .sort((a, b) => a.name.localeCompare(b.name));

        if (!visibleAlbums.length) {
            container.innerHTML = `<div class="card"><span style="color:var(--muted);">No albums found.</span></div>`;
            return;
        }

        container.innerHTML = visibleAlbums.map(album => {
            const art = album.artworkData || (album.artworkFile ? getFileObjectUrl(album.artworkFile, albumArtUrls) : '');

            return `
                <div class="album-card">
                    <div class="album-art">
                        ${art
                            ? `<img src="${art}" alt="">`
                            : `<div class="album-art-placeholder"><svg class="icon"><use href="#i-folder-music"/></svg></div>`
                        }
                    </div>
                    <div class="album-info">
                        <div class="album-title">${escapeHTML(album.name)}</div>
                        <div class="album-meta">${album.files.filter(isAudioFile).length} track${album.files.filter(isAudioFile).length === 1 ? '' : 's'}</div>
                        <div class="album-actions">
                            <button class="button primary album-open-button" data-album-key="${escapeHTML(album.key)}">
                                <svg class="icon"><use href="#i-folder"/></svg> Open
                            </button>
                            <button class="button album-art-button" data-album-key="${escapeHTML(album.key)}" title="Choose album artwork">
                                <svg class="icon"><use href="#i-art"/></svg> Art
                            </button>
                            <button class="button album-ai-button" data-album-key="${escapeHTML(album.key)}" title="Clean up album metadata with AI">
                                <svg class="icon"><use href="#i-edit"/></svg> AI
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Use DOM data attributes instead of inline JavaScript arguments.
        // This keeps album actions reliable when folder/album names contain
        // apostrophes, quotes, percent signs, ampersands, or other characters.
        container.querySelectorAll('.album-open-button').forEach(button => {
            button.addEventListener('click', event => {
                event.stopPropagation();
                loadAlbum(button.dataset.albumKey || '');
            });
        });

        container.querySelectorAll('.album-art-button').forEach(button => {
            button.addEventListener('click', event => {
                event.stopPropagation();
                showAlbumArtPicker(button.dataset.albumKey || '');
            });
        });

        container.querySelectorAll('.album-ai-button').forEach(button => {
            button.addEventListener('click', event => {
                event.stopPropagation();
                cleanAlbumWithAI(button.dataset.albumKey || '');
            });
        });

        return;
    }

    const activeAlbum = albums.get(activeAlbumKey);

    document.getElementById('libraryCount').textContent =
        `${activeAlbum ? activeAlbum.name : 'Album'} — ${tracks.length} track${tracks.length === 1 ? '' : 's'}`;

    container.className = gridView ? 'track-grid' : 'track-list';

    const backButton = document.getElementById('albumBackButton');
    if (backButton) backButton.classList.remove('hidden');

    if (!tracks.length) {
        container.innerHTML = `<div class="card"><span style="color:var(--muted);">This album contains no supported audio files.</span></div>`;
        return;
    }

    const query = document.getElementById('searchInput').value.toLowerCase().trim();

    let visible = tracks.filter(track => {
        const haystack = [
            getTrackTitle(track),
            getTrackArtist(track),
            getTrackAlbum(track),
            track.file.name
        ].join(' ').toLowerCase();
        return haystack.includes(query);
    });

    const sort = document.getElementById('sortSelect').value;

    const trackOrderNumber = track => {
        const value = Number(
            track.metadata?.trackNumber ??
            track.trackNumber
        );

        return Number.isFinite(value) && value > 0
            ? value
            : null;
    };

    const compareTrackOrder = (a, b) => {
        const aNumber = trackOrderNumber(a);
        const bNumber = trackOrderNumber(b);

        // Numbered tracks come first, in metadata TRCK order.
        if (aNumber !== null && bNumber !== null && aNumber !== bNumber) {
            return aNumber - bNumber;
        }

        if (aNumber !== null && bNumber === null) {
            return -1;
        }

        if (aNumber === null && bNumber !== null) {
            return 1;
        }

        // Do not alphabetize unnumbered tracks. Array order is the fallback.
        return 0;
    };

    visible.sort((a, b) => {
        switch (sort) {
            case 'track':
                return compareTrackOrder(a, b);
            case 'artist':
                return getTrackArtist(a).localeCompare(getTrackArtist(b));
            case 'album':
                return getTrackAlbum(a).localeCompare(getTrackAlbum(b));
            case 'duration':
                return a.duration - b.duration;
            case 'recent':
                return b.added - a.added;
            case 'plays':
                return (b.plays || 0) - (a.plays || 0);
            default:
                return getTrackTitle(a).localeCompare(getTrackTitle(b));
        }
    });

    if (gridView) {
        container.innerHTML = visible.map(track => {
            const realIndex = tracks.indexOf(track);
            const art = track.artworkData || activeAlbum?.artworkData || '';
            return `
                <div class="track-card" onclick="playTrack(${realIndex})">
                    <div class="track-art">
                        ${art ? `<img src="${art}" alt="">` : '<svg class="icon"><use href="#i-music"/></svg>'}
                    </div>
                    <div class="track-info">
                        <div class="track-name">${escapeHTML(getTrackTitle(track))}</div>
                        <div class="track-subtitle">${escapeHTML(getTrackArtist(track))}</div>
                    </div>
                </div>
            `;
        }).join('');
        return;
    }

    container.innerHTML = visible.map((track, visibleIndex) => {
        const realIndex = tracks.indexOf(track);
        return `
            <div class="track-row ${currentTrack && track.id === currentTrack.id ? 'active' : ''}">
                <div class="track-number">${visibleIndex + 1}</div>
                <div class="row-title" onclick="playTrack(${realIndex})" style="cursor:pointer;">
                    <strong>${escapeHTML(getTrackTitle(track))}</strong>
                    <span>${escapeHTML(getTrackArtist(track))}</span>
                </div>
                <div class="row-muted">${escapeHTML(getTrackAlbum(track))}</div>
                <div class="row-muted">${formatTime(track.duration)}</div>
                <div class="row-actions">
                    <button class="button small" onclick="toggleFavorite(${realIndex})" title="Favorite">
                        <svg class="icon"><use href="#i-star"/></svg>
                    </button>
                    <button class="button small" onclick="addToQueue(${realIndex})" title="Queue">
                        <svg class="icon"><use href="#i-plus"/></svg>
                    </button>
                    <button class="button small" onclick="editTrackMetadata(${realIndex})" title="Edit Metadata">
                        <svg class="icon"><use href="#i-edit"/></svg>
                    </button>
                    <button class="button small" onclick="showTrackMenu(${realIndex})" title="More">
                        <svg class="icon"><use href="#i-more"/></svg>
                    </button>
                </div>
            </div>
        `;
    }).join('');
}




/* =========================================================
   AI ALBUM METADATA CLEANUP
========================================================= */

function normalizeAIArtistValue(value) {
    return String(value || '')
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ');
}

function getAlbumArtistForAI(album, preparedSongs = []) {
    const albumName = String(album?.name || '').trim();
    const folderName = String(getAlbumNameFromKey(album?.key || '') || '').trim();
    const excluded = new Set([
        normalizeAIArtistValue(albumName),
        normalizeAIArtistValue(folderName),
        'unknown',
        'unknown artist',
        'various artists',
        'va'
    ]);

    const counts = new Map();
    const displayNames = new Map();

    const addCandidate = value => {
        const clean = String(value || '').trim();
        const normalized = normalizeAIArtistValue(clean);
        if (!normalized || excluded.has(normalized)) return;

        counts.set(normalized, (counts.get(normalized) || 0) + 1);
        if (!displayNames.has(normalized)) {
            displayNames.set(normalized, clean);
        }
    };

    preparedSongs.forEach(song => {
        addCandidate(song.artist);
    });

    // Only fall back to in-memory tracks when the prepared MP3 data did not
    // yield any artist candidates. Do not count both sources, because that
    // would make a single artist appear twice and falsely look like a
    // repeated/consensus artist.
    if (!counts.size && (activeAlbumKey === album?.key || tracks?.length)) {
        tracks.forEach(track => {
            if (track?.albumKey && track.albumKey !== album?.key) return;
            addCandidate(track?.metadata?.artist);
            if (!track?.metadata?.artist) addCandidate(track?.artist);
        });
    }

    const candidates = [...counts.entries()]
        .sort((a, b) => b[1] - a[1])
        .map(([normalized, count]) => ({
            artist: displayNames.get(normalized) || normalized,
            count
        }));

    return {
        consensus: candidates.length && candidates[0].count >= 2
            ? candidates[0].artist
            : (candidates.length === 1 ? candidates[0].artist : ''),
        candidates
    };
}

async function buildAIAlbumPayload(album) {
    const audioFiles = album.files.filter(isAudioFile);
    const currentAlbum = String(album.name || '').trim();
    const folderName = getAlbumNameFromKey(album.key || '');

    // Build the album evidence from both the current in-memory track state and
    // the actual MP3 ID3 tags. The old version mostly relied on saved state,
    // which meant the AI could receive an empty artist even though the files
    // already contained one.
    const preparedSongs = await Promise.all(
        audioFiles.map(async (file, index) => {
            const id = trackId(file);
            const saved = window.savedTrackState?.[id] || {};
            const registryTrack = trackRegistry.get(id);
            const currentTrack = registryTrack || tracks.find(t => t.id === id);
            const baseMetadata = {
                ...(saved.metadata || {}),
                ...(currentTrack?.metadata || {})
            };

            let actual = {};
            if (!baseMetadata.artist || !baseMetadata.title || !baseMetadata.album) {
                try {
                    actual = await readActualMP3Metadata(file);
                } catch (error) {
                    console.warn(`Could not read metadata for AI cleanup: ${file.name}`, error);
                }
            }

            const metadata = {
                ...actual,
                ...baseMetadata
            };

            const filenameTrackNumber = getFilenameTrackNumber(file);
            const filenameCleanTitle = getFilenameCleanTitle(file, currentAlbum);
            const rawTitle = String(
                metadata.title ||
                currentTrack?.title ||
                filenameCleanTitle ||
                file.name.replace(/\.[^/.]+$/, '')
            ).trim();

            // Keep the raw embedded artist and a filename hint separate. This
            // prevents a filename pattern from silently becoming the artist.
            const rawArtist = String(
                metadata.artist ||
                currentTrack?.artist ||
                ''
            ).trim();

            const filenameWithoutExtension = file.name.replace(/\.[^/.]+$/, '').trim();
            const filenameWithoutTrack = filenameWithoutExtension.replace(
                /^\s*(?:(?:track|song|audio)\s*)?0*\d{1,3}\s*(?:[-_.):]+\s*)?/i,
                ''
            ).trim();

            let filenameArtistHint = '';
            const artistTitle = filenameWithoutTrack.match(/^(.+?)\s+(?:-|–|—)\s+(.+)$/);
            if (artistTitle) {
                filenameArtistHint = artistTitle[1].trim();
            }

            return {
                source_index: index + 1,
                source_order: index + 1,
                filename: file.name || '',
                relative_path: file.webkitRelativePath || file.name || '',
                filename_track_number: filenameTrackNumber,
                filename_clean_title: filenameCleanTitle,
                filename_artist_hint: filenameArtistHint,
                title: rawTitle,
                artist: rawArtist,
                album: String(metadata.album || currentTrack?.album || currentAlbum).trim(),
                track_number: metadata.trackNumber || metadata.track || '',
                size_bytes: file.size || 0,
                type: file.type || ''
            };
        })
    );

    const artistEvidence = getAlbumArtistForAI(album, preparedSongs);

    return {
        album: {
            current_name: currentAlbum,
            folder_name: folderName,
            folder_path: album.key || '',
            artist: artistEvidence.consensus,
            album_artist: artistEvidence.consensus,
            artist_candidates: artistEvidence.candidates,
            song_count: audioFiles.length,
            musicbrainz_release_id: album.musicbrainzReleaseId || '',
            songs: preparedSongs
        }
    };
}

async function cleanAlbumWithAI(key) {
    const album = albums.get(key);

    if (!album) {
        toast('Album could not be found.');
        return;
    }

    const payload = await buildAIAlbumPayload(album);

    // Clear any previous review while this request is running. The review
    // state is populated only after the AI has returned usable metadata.
    window.aiCleanupReview = null;

    openModal(`
        <div class="ai-cleanup-modal">
            <h2>AI Album Cleanup</h2>
            <p class="ai-cleanup-note">
                Sending ${payload.album.song_count} song${payload.album.song_count === 1 ? '' : 's'} and the album's available metadata to Leanstral 1.5. Nothing will be changed until you review and apply the result.
            </p>
            <div class="album-loading">
                Asking AI to clean up the metadata...
            </div>
        </div>
    `);

    const modal = document.getElementById('modal');
    if (modal) {
        modal.classList.add('ai-cleanup-modal');
    }

    try {
        const response = await fetch('music_ai.php?action=cleanup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const result = await response.json().catch(() => null);

        if (!response.ok || !result || result.error) {
            throw new Error(
                result?.error ||
                `AI request failed with HTTP ${response.status}.`
            );
        }

        showAICleanupReview(key, payload.album, result);
    } catch (error) {
        console.error('AI album cleanup failed:', error);

        openModal(`
            <h2>AI Album Cleanup Failed</h2>
            <p style="color:var(--muted);line-height:1.5;">
                ${escapeHTML(error?.message || 'The AI request failed.')}
            </p>
            <div class="modal-actions">
                <button class="button" onclick="closeModal()">Close</button>
            </div>
        `);
    }
}

window.aiCleanupReview = null;

function showAICleanupReview(key, original, suggestion) {
    const songs = Array.isArray(suggestion.songs)
        ? suggestion.songs
        : [];

    const albumArtist = suggestion.artist || original.artist || '';
    const albumName = suggestion.album || original.current_name || '';

    const sourceMap = new Map(
        original.songs.map(song => [Number(song.index), song])
    );

    /*
     * IMPORTANT: Keep review rows in the original source-file order.
     *
     * The AI is allowed to suggest a new track number, but that number must
     * never change which source MP3 a row refers to. Previously the rows were
     * sorted by the AI's suggested track number, which made a bad AI order
     * look like the files themselves had been remapped.
     *
     * The user can now enter any custom positive whole-number track number
     * they want in the review form. Apply uses sourceIndex to map the edited
     * values back to the correct MP3.
     */
    const normalizedSongs = songs
        .map((song, position) => {
            const sourceIndex = Number(song.source_index ?? song.index);
            const source = sourceMap.get(sourceIndex) || original.songs[position];

            if (!source) return null;

            const filenameTrackNumber = Number(source.filename_track_number);
            const proposedTrackNumber = Number(song.track_number);
            const sourceTrackNumber = Number(source.track_number);
            const fallbackTrackNumber = Number(source.source_index ?? source.index ?? sourceIndex ?? position + 1);

            /*
             * Track order is NOT an AI guessing task when the filename gives
             * us an explicit number. The filename number wins so an album like
             * 010 - ..., 002 - ..., 007 - ... always reviews as 10, 2, 7
             * regardless of what the model happened to output.
             */
            const trackNumber =
                Number.isFinite(filenameTrackNumber) && filenameTrackNumber > 0
                    ? Math.trunc(filenameTrackNumber)
                    : (Number.isFinite(sourceTrackNumber) && sourceTrackNumber > 0
                        ? Math.trunc(sourceTrackNumber)
                        : (Number.isFinite(proposedTrackNumber) && proposedTrackNumber > 0
                            ? Math.trunc(proposedTrackNumber)
                            : Math.max(1, Math.trunc(fallbackTrackNumber))));

            const aiTitle = String(song.title || '').trim();
            const originalTitle = source.title || source.filename || '';
            const filenameCandidate = String(source.filename_clean_title || '').trim();
            const originalLooksLikeFilename = /(^|\s)\d{1,3}\s*[-_.):]/.test(originalTitle);

            const title =
                aiTitle && !(originalLooksLikeFilename && aiTitle === originalTitle)
                    ? aiTitle
                    : (filenameCandidate || aiTitle || originalTitle);

            return {
                sourceIndex: Number(source.source_index ?? source.index ?? sourceIndex),
                trackNumber,
                originalTitle: source.title || source.filename || '',
                originalArtist: source.artist || '',
                originalTrackNumber: source.track_number || '',
                title,
                artist: String(song.artist || source.artist || albumArtist || '').trim()
            };
        })
        .filter(Boolean);

    if (!normalizedSongs.length) {
        throw new Error('The AI returned no usable song metadata.');
    }

    /*
     * Review in deterministic track order. This sort uses the track number
     * established above, where explicit filename numbers take priority.
     * It does not change sourceIndex, so each row remains bound to its MP3.
     */
    normalizedSongs.sort((a, b) => {
        const aHas = Number.isFinite(Number(a.trackNumber)) && Number(a.trackNumber) > 0;
        const bHas = Number.isFinite(Number(b.trackNumber)) && Number(b.trackNumber) > 0;

        if (aHas && bHas && Number(a.trackNumber) !== Number(b.trackNumber)) {
            return Number(a.trackNumber) - Number(b.trackNumber);
        }

        if (aHas !== bHas) return aHas ? -1 : 1;
        return Number(a.sourceIndex) - Number(b.sourceIndex);
    });

    // Keep the exact normalized song list that is shown in the review form.
    // Apply uses this state to map the reviewed values back to the files.
    window.aiCleanupReview = {
        key,
        normalizedSongs
    };

    openModal(`
        <div class="ai-cleanup-modal">
            <h2>Review AI Metadata</h2>

            <p class="ai-cleanup-note">
                Review every proposed value below. Every field is editable, so you can enter your own artist, album, song title, or track number. The rows are shown in the detected track order. Explicit numbers in the original filenames are used first, and every row stays attached to its original MP3. Nothing is changed until you press Apply.
            </p>

            <div class="ai-cleanup-source">
                <div class="ai-cleanup-stat">
                    <strong>Folder</strong>
                    ${escapeHTML(original.folder_name || 'Unknown')}
                </div>
                <div class="ai-cleanup-stat">
                    <strong>Songs</strong>
                    ${original.song_count}
                </div>
                <div class="ai-cleanup-stat">
                    <strong>Original Album</strong>
                    ${escapeHTML(original.current_name || 'Unknown')}
                </div>
                <div class="ai-cleanup-stat">
                    <strong>Original Artist</strong>
                    ${escapeHTML(original.artist || 'Unknown')}
                </div>
                <div class="ai-cleanup-stat">
                    <strong>Artist Evidence</strong>
                    ${escapeHTML((original.artist_candidates || []).map(item => `${item.artist} (${item.count})`).join(', ') || 'None found')}
                </div>
            </div>

            <div class="ai-cleanup-fields">
                <div class="ai-cleanup-field">
                    <label for="aiCleanupArtist">Artist (applies to all songs)</label>
                    <input id="aiCleanupArtist" type="text" value="${escapeHTML(albumArtist)}">
                    <div class="ai-cleanup-field-note">This is the album-level artist. The AI is given the artists found in the MP3 metadata and will prefer a repeated artist instead of guessing from the album name.</div>
                </div>
                <div class="ai-cleanup-field">
                    <label for="aiCleanupAlbum">Album (applies to all songs)</label>
                    <input id="aiCleanupAlbum" type="text" value="${escapeHTML(albumName)}">
                    <div class="ai-cleanup-field-note">This value will be written to the album tag of every song when you press Apply.</div>
                </div>
            </div>

            <div class="ai-cleanup-songs">
                <div class="ai-cleanup-song ai-cleanup-song-head">
                    <div>Source #</div>
                    <div>New track #</div>
                    <div>Original title</div>
                    <div>New title</div>
                    <div>Artist</div>
                </div>

                ${normalizedSongs.map((song, rowIndex) => `
                    <div class="ai-cleanup-song" data-ai-row="${rowIndex}">
                        <div class="ai-cleanup-source-index">${song.sourceIndex}</div>
                        <input
                            type="number"
                            min="1"
                            step="1"
                            inputmode="numeric"
                            data-ai-track-number
                            value="${song.trackNumber}"
                            aria-label="Custom track number for source track ${song.sourceIndex}"
                        >
                        <div class="ai-cleanup-original" title="${escapeHTML(song.originalTitle)}">
                            ${escapeHTML(song.originalTitle)}
                        </div>
                        <input
                            type="text"
                            data-ai-title
                            value="${escapeHTML(song.title)}"
                            aria-label="Custom title for source track ${song.sourceIndex}"
                        >
                        <input
                            type="text"
                            data-ai-artist
                            value="${escapeHTML(song.artist)}"
                            aria-label="Custom artist for source track ${song.sourceIndex}"
                        >
                    </div>
                `).join('')}
            </div>

            <div class="modal-actions">
                <button class="button" onclick="closeModal()">Cancel</button>
                <button
                    class="button primary"
                    onclick="applyAICleanup()"
                >
                    Apply Metadata
                </button>
            </div>
        </div>
    `);

    const modal = document.getElementById('modal');
    if (modal) {
        modal.classList.add('ai-cleanup-modal');
    }
}

window.applyAICleanup = async function() {
    const review = window.aiCleanupReview;

    if (!review) {
        toast('The AI review is no longer available.');
        return;
    }

    const key = review.key;
    const originalSongs = review.normalizedSongs;

    const album = albums.get(key);

    if (!album) {
        toast('Album is no longer available.');
        return;
    }

    const artistInput = document.getElementById('aiCleanupArtist');
    const albumInput = document.getElementById('aiCleanupAlbum');

    const artist = artistInput?.value.trim() || '';
    const albumName = albumInput?.value.trim() || '';

    if (!artist || !albumName) {
        toast('Artist and album name are required.');
        return;
    }

    const rows = [...document.querySelectorAll('[data-ai-row]')];

    const reviewedSongs = rows.map((row, position) => {
        const source = originalSongs[position] || {};
        const rawTrackNumber = row.querySelector('[data-ai-track-number]')?.value.trim() || '';
        const parsedTrackNumber = Number(rawTrackNumber);

        return {
            sourceIndex: Number(source.sourceIndex) || position + 1,
            trackNumber: Number.isFinite(parsedTrackNumber) && parsedTrackNumber > 0
                ? Math.trunc(parsedTrackNumber)
                : 0,
            title: row.querySelector('[data-ai-title]')?.value.trim() || '',
            artist: row.querySelector('[data-ai-artist]')?.value.trim() || artist
        };
    });

    if (reviewedSongs.some(song => !song.title)) {
        toast('Every song needs a title.');
        return;
    }

    if (reviewedSongs.some(song => !song.trackNumber)) {
        toast('Every song needs a custom positive track number.');
        return;
    }

    const trackNumbers = reviewedSongs.map(song => song.trackNumber);
    const duplicateTrackNumbers = trackNumbers.filter((value, index) =>
        trackNumbers.indexOf(value) !== index
    );

    if (duplicateTrackNumbers.length) {
        toast('Each song needs a unique track number so the album can be ordered correctly.');
        return;
    }

    const mp3Files = album.files.filter(file => /\.mp3$/i.test(file.name));

    if (!mp3Files.length) {
        toast('This album has no MP3 files to update.');
        return;
    }

    let written = 0;
    let skipped = 0;

    try {
        const writable = await ensureWritableAlbumFiles(album);
        for (let index = 0; index < mp3Files.length; index++) {
            const file = mp3Files[index];
            const fileId = trackId(file);

            const originalIndex = album.files
                .filter(isAudioFile)
                .findIndex(candidate => trackId(candidate) === fileId);

            const reviewed = reviewedSongs.find(song => Number(song.sourceIndex) === originalIndex + 1);

            if (!reviewed) {
                skipped++;
                continue;
            }

            const fileKey = normalizeMusicPath(
                file.webkitRelativePath || file.name
            );
            const relativeKey = stripRootFolder(fileKey);
            let handle =
                writable.get(fileKey) ||
                writable.get(relativeKey);

            if (!handle) {
                const candidates = [...writable.entries()].filter(([path]) =>
                    path === fileKey ||
                    path === relativeKey ||
                    path.endsWith('/' + relativeKey)
                );

                if (candidates.length === 1) {
                    handle = candidates[0][1];
                }
            }

            if (!handle) {
                skipped++;
                continue;
            }

            await writeMP3ID3Tag(handle, {
                title: reviewed.title,
                artist: reviewed.artist || artist,
                album: albumName,
                trackNumber: reviewed.trackNumber
            });

            const saved = window.savedTrackState?.[fileId] || {};
            const savedMetadata = {
                ...(saved.metadata || {}),
                title: reviewed.title,
                artist: reviewed.artist || artist,
                album: albumName,
                trackNumber: reviewed.trackNumber
            };

            window.savedTrackState[fileId] = {
                ...saved,
                metadata: savedMetadata
            };

            written++;
        }

        album.name = albumName;
        album.artist = artist;
        album.album = albumName;

        window.savedAlbumState = window.savedAlbumState || {};
        window.savedAlbumState[key] = {
            ...(window.savedAlbumState[key] || {}),
            name: albumName,
            artist,
            album: albumName,
            musicbrainzReleaseId: album.musicbrainzReleaseId || ''
        };

        if (activeAlbumKey === key) {
            tracks.forEach(track => {
                const fileId = trackId(track.file);
                const audioIndex = album.files
                    .filter(isAudioFile)
                    .findIndex(file => trackId(file) === fileId);

                const reviewed = reviewedSongs.find(song => Number(song.sourceIndex) === audioIndex + 1);

                if (!reviewed) return;

                track.title = reviewed.title;
                track.artist = reviewed.artist || artist;
                track.album = albumName;
                track.albumName = albumName;
                track.trackNumber = reviewed.trackNumber;
                track.metadata = {
                    ...(track.metadata || {}),
                    title: reviewed.title,
                    artist: reviewed.artist || artist,
                    album: albumName,
                    trackNumber: reviewed.trackNumber
                };
            });

            tracks.sort((a, b) => {
                const aNumber = Number(a.metadata?.trackNumber ?? a.trackNumber);
                const bNumber = Number(b.metadata?.trackNumber ?? b.trackNumber);
                const aHas = Number.isFinite(aNumber) && aNumber > 0;
                const bHas = Number.isFinite(bNumber) && bNumber > 0;
                if (aHas && bHas && aNumber !== bNumber) return aNumber - bNumber;
                if (aHas !== bHas) return aHas ? -1 : 1;
                return getTrackTitle(a).localeCompare(getTrackTitle(b));
            });
        }

        saveState();
        closeModal();
        renderEverything();
        updatePlayer();

        toast(
            `Updated ${written} MP3 file${written === 1 ? '' : 's'}${skipped ? `; ${skipped} skipped` : ''}.`
        );
    } catch (error) {
        console.error('AI metadata write error:', error);

        toast(
            error?.message ||
            'Could not write the reviewed metadata to the MP3 files.'
        );
    }
};

function showAlbumLibrary() {
    // Only leave the current album view.
    // Do NOT clear the audio player or current track.
    activeAlbumKey = null;

    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) {
        sortSelect.value = 'name';
    }

    const backButton = document.getElementById('albumBackButton');
    if (backButton) backButton.classList.add('hidden');

    document.getElementById('searchInput').value = '';

    renderEverything();
    showPage('library');
}


window.showAlbumLibrary = showAlbumLibrary;


/* =========================================================
   SEARCH
========================================================= */

document
    .getElementById(
        'searchInput'
    )
    .addEventListener(
        'input',
        () => {

            renderLibrary();

        }
    );


/* =========================================================
   SORT / VIEW
========================================================= */

document
    .getElementById(
        'sortSelect'
    )
    .addEventListener(
        'change',
        renderLibrary
    );


document
    .getElementById(
        'viewToggle'
    )
    .addEventListener(
        'click',
        () => {

            gridView =
                !gridView;


            document
                .getElementById(
                    'viewToggle'
                )
                .textContent =
                    gridView
                        ? '<svg class="icon"><use href="#i-queue"/></svg> List'
                        : '<svg class="icon"><use href="#i-grid"/></svg> Grid';


            renderLibrary();

        }
    );


/* =========================================================
   TRACK MENU
========================================================= */

window.showTrackMenu =
    function(index) {

        const track =
            tracks[index];


        openModal(`

            <h2>
                ${escapeHTML(
                    getTrackTitle(track)
                )}
            </h2>

            <div
                style="
                    display:flex;
                    flex-direction:column;
                    gap:8px;
                "
            >

                <button
                    class="button"
                    onclick="playTrack(${index}); closeModal();"
                >
                    <svg class="icon"><use href="#i-play"/></svg> Play
                </button>

                <button
                    class="button"
                    onclick="addToQueue(${index}); closeModal();"
                >
                    + Add to Queue
                </button>

                <button
                    class="button"
                    onclick="editTrackMetadata(${index});"
                >
                    <svg class="icon"><use href="#i-edit"/></svg> Edit Metadata
                </button>

                <button
                    class="button"
                    onclick="choosePlaylist(${index});"
                >
                    <svg class="icon"><use href="#i-playlist"/></svg> Add to Playlist
                </button>

                <button
                    class="button"
                    onclick="setMood(${index});"
                >
                    <svg class="icon"><use href="#i-tag"/></svg> Set Mood
                </button>

            </div>

        `);

    };


/* =========================================================
   METADATA
========================================================= */

window.editTrackMetadata =
    function(index) {

        const track =
            tracks[index];


        openModal(`

            <h2>
                Edit Metadata
            </h2>

            <label>
                Title
            </label>

            <input
                type="text"
                id="metaTitle"
                value="${escapeHTML(
                    getTrackTitle(track)
                )}"
                style="
                    width:100%;
                    margin:7px 0 12px;
                    padding:10px;
                    background:var(--input-bg);
                    border:1px solid var(--border);
                    border-radius:7px;
                    color:var(--text);
                "
            >


            <label>
                Artist
            </label>

            <input
                type="text"
                id="metaArtist"
                value="${escapeHTML(
                    getTrackArtist(track)
                )}"
                style="
                    width:100%;
                    margin:7px 0 12px;
                    padding:10px;
                    background:var(--input-bg);
                    border:1px solid var(--border);
                    border-radius:7px;
                    color:var(--text);
                "
            >


            <label>
                Album
            </label>

            <input
                type="text"
                id="metaAlbum"
                value="${escapeHTML(
                    getTrackAlbum(track)
                )}"
                style="
                    width:100%;
                    margin:7px 0 12px;
                    padding:10px;
                    background:var(--input-bg);
                    border:1px solid var(--border);
                    border-radius:7px;
                    color:var(--text);
                "
            >


            <div class="modal-actions">

                <button
                    class="button"
                    onclick="closeModal()"
                >
                    Cancel
                </button>

                <button
                    class="button primary"
                    onclick="saveTrackMetadata(${index})"
                >
                    Save
                </button>

            </div>

            <p
                style="
                    color:var(--muted);
                    font-size:.8rem;
                    margin-top:15px;
                "
            >
                Changes are written directly to the MP3 file.
                Your browser may ask you to select the music folder and allow file access.
            </p>

        `);

    };


window.saveTrackMetadata =
    async function(index) {

        const track = tracks[index];

        if (!track || !track.file) {
            toast('Track file not found.');
            return;
        }

        const title =
            document
                .getElementById('metaTitle')
                .value
                .trim();

        const artist =
            document
                .getElementById('metaArtist')
                .value
                .trim();

        const album =
            document
                .getElementById('metaAlbum')
                .value
                .trim();

        const activeAlbum =
            albums.get(track.albumKey || activeAlbumKey);

        if (!activeAlbum) {
            toast('Album not found.');
            return;
        }

        try {
            /*
             * Get read/write access to the real MP3 on disk.
             * This uses the same File System Access flow as the
             * MusicBrainz metadata writer, so the browser writes
             * the changes to the actual file instead of only saving
             * them in localStorage.
             */
            const handles = await ensureWritableAlbumFiles(activeAlbum);
            const fileKey = normalizeMusicPath(
                track.file.webkitRelativePath || track.file.name
            );
            const relativeKey = stripRootFolder(fileKey);
            let handle = handles.get(fileKey) || handles.get(relativeKey);

            if (!handle) {
                const candidates = [...handles.entries()].filter(([path]) =>
                    path === fileKey ||
                    path === relativeKey ||
                    path.endsWith('/' + relativeKey)
                );
                if (candidates.length === 1) handle = candidates[0][1];
            }

            if (!handle) {
                throw new Error(
                    'Could not match this track to the MP3 on disk. Select the same music folder you originally loaded into Encore.'
                );
            }

            toast('Writing metadata to MP3...');

            // These are written to the actual MP3. The writer also preserves
            // existing artwork and all other ID3 frames.
            await writeMP3ID3Tag(handle, {
                title,
                artist,
                album
            });

            track.metadata = {
                ...(track.metadata || {}),
                title,
                artist,
                album
            };

            track.title = title;
            track.artist = artist;
            track.album = album;

            window.savedTrackState = window.savedTrackState || {};
            const id = trackId(track.file);
            const saved = window.savedTrackState[id] || {};

            window.savedTrackState[id] = {
                ...saved,
                metadata: {
                    ...(saved.metadata || {}),
                    title,
                    artist,
                    album
                }
            };

            saveState();
            closeModal();
            renderEverything();
            updatePlayer();

            toast('Metadata written to MP3');

        } catch (error) {
            console.error('Could not write track metadata:', error);
            toast(error?.message || 'Could not write metadata to the MP3.');
        }

    };


document
    .getElementById(
        'editMetadata'
    )
    .addEventListener(
        'click',
        () => {

            if (currentTrack) {
                const index = tracks.indexOf(currentTrack);
                if (index !== -1) {
                    editTrackMetadata(index);
                }
            }

        }
    );


/* =========================================================
   MOODS
========================================================= */

window.setMood =
    function(index) {

        const track =
            tracks[index];


        openModal(`

            <h2>
                Set Mood
            </h2>

            <p
                style="
                    color:var(--muted);
                    margin-bottom:15px;
                "
            >
                Assign a mood or tag to this track.
            </p>

            <input
                type="text"
                id="moodInput"
                placeholder="Chill, Energetic, Focus..."
                value="${escapeHTML(
                    getTrackMood(track)
                )}"
                style="
                    width:100%;
                    padding:11px;
                    background:var(--input-bg);
                    color:var(--text);
                    border:1px solid var(--border);
                    border-radius:7px;
                "
            >

            <div class="modal-actions">

                <button
                    class="button"
                    onclick="closeModal()"
                >
                    Cancel
                </button>

                <button
                    class="button primary"
                    onclick="saveMood(${index})"
                >
                    Save
                </button>

            </div>

        `);

    };


window.saveMood =
    function(index) {

        tracks[index].mood =
            document
                .getElementById(
                    'moodInput'
                )
                .value
                .trim();


        saveState();

        closeModal();

        renderEverything();

        toast(
            'Mood saved'
        );

    };


/* =========================================================
   PLAYLISTS
========================================================= */

document
    .getElementById(
        'newPlaylistButton'
    )
    .addEventListener(
        'click',
        createPlaylist
    );


function createPlaylist() {

    openModal(`

        <h2>
            New Playlist
        </h2>

        <input
            type="text"
            id="playlistName"
            placeholder="Playlist name"
            style="
                width:100%;
                padding:11px;
                background:var(--input-bg);
                color:var(--text);
                border:1px solid var(--border);
                border-radius:7px;
            "
        >

        <div class="modal-actions">

            <button
                class="button"
                onclick="closeModal()"
            >
                Cancel
            </button>

            <button
                class="button primary"
                onclick="saveNewPlaylist()"
            >
                Create
            </button>

        </div>

    `);

}


window.saveNewPlaylist =
    function() {

        const name =
            document
                .getElementById(
                    'playlistName'
                )
                .value
                .trim();


        if (!name) {
            return;
        }


        if (!playlists[name]) {
            playlists[name] = [];
        }


        saveState();

        closeModal();

        renderPlaylists();

        toast(
            `Playlist "${name}" created`
        );

    };


function renderPlaylists() {

    const container =
        document.getElementById(
            'playlistsContainer'
        );


    const names =
        Object.keys(
            playlists
        );


    if (!names.length) {

        container.innerHTML =
            `<div class="card">
                No playlists yet.
            </div>`;

        return;

    }


    container.innerHTML =
        names.map(
            name => `

                <div class="setting">

                    <h3>
                        <svg class="icon"><use href="#i-playlist"/></svg> ${escapeHTML(name)}
                    </h3>

                    <p>
                        ${playlists[name].length}
                        track${playlists[name].length === 1 ? '' : 's'}
                    </p>

                    <button
                        class="button"
                        onclick="openPlaylist('${escapeHTML(name)}')"
                    >
                        Open
                    </button>

                    <button
                        class="button danger"
                        onclick="deletePlaylist('${escapeHTML(name)}')"
                    >
                        Delete
                    </button>

                </div>

            `
        ).join('');

}


window.openPlaylist =
    function(name) {

        const ids =
            playlists[name] || [];


        const playlistTracks =
            ids
                .map(
                    id =>
                        tracks.find(
                            track =>
                                track.id === id
                        )
                )
                .filter(Boolean);


        openModal(`

            <h2>
                ${escapeHTML(name)}
            </h2>

            <div class="track-list">

                ${
                    playlistTracks.length
                        ? playlistTracks
                            .map(
                                track => `

                                    <div class="track-row">

                                        <div>
                                            <svg class="icon"><use href="#i-music"/></svg>
                                        </div>

                                        <div class="row-title">

                                            <strong>
                                                ${escapeHTML(
                                                    getTrackTitle(track)
                                                )}
                                            </strong>

                                            <span>
                                                ${escapeHTML(
                                                    getTrackArtist(track)
                                                )}
                                            </span>

                                        </div>

                                        <div></div>
                                        <div></div>

                                        <button
                                            class="button small"
                                            onclick="playTrack(${tracks.indexOf(track)}); closeModal();"
                                        >
                                            <svg class="icon"><use href="#i-play"/></svg>
                                        </button>

                                    </div>

                                `
                            )
                            .join('')
                        : `<div class="card">
                            This playlist is empty.
                           </div>`
                }

            </div>

        `);

    };


window.deletePlaylist =
    function(name) {

        if (
            !confirm(
                `Delete playlist "${name}"?`
            )
        ) {
            return;
        }


        delete playlists[name];

        saveState();

        renderPlaylists();

    };


window.choosePlaylist =
    function(index) {

        const names =
            Object.keys(
                playlists
            );


        if (!names.length) {

            closeModal();

            createPlaylist();

            return;

        }


        openModal(`

            <h2>
                Add to Playlist
            </h2>

            <div
                style="
                    display:flex;
                    flex-direction:column;
                    gap:8px;
                "
            >

                ${
                    names
                        .map(
                            name => `

                                <button
                                    class="button"
                                    onclick="addTrackToPlaylist(${index}, '${escapeHTML(name)}')"
                                >
                                    <svg class="icon"><use href="#i-playlist"/></svg> ${escapeHTML(name)}
                                </button>

                            `
                        )
                        .join('')
                }

            </div>

        `);

    };


window.addTrackToPlaylist =
    function(index, name) {

        const id =
            tracks[index].id;


        if (
            !playlists[name].includes(id)
        ) {

            playlists[name].push(id);

        }


        saveState();

        closeModal();

        renderPlaylists();

        toast(
            'Added to playlist'
        );

    };


/* =========================================================
   RECENT / FAVORITES / STATS
========================================================= */

function renderSimpleList(
    containerId,
    list
) {

    const container =
        document.getElementById(
            containerId
        );


    if (!list.length) {

        container.innerHTML =
            `<div class="card">
                <span style="color:var(--muted);">
                    Nothing here yet.
                </span>
            </div>`;

        return;

    }


    container.innerHTML =
        list.map(
            (track, index) => {

                const realIndex =
                    tracks.indexOf(
                        track
                    );


                return `

                    <div class="track-row">

                        <div>
                            ${index + 1}
                        </div>

                        <div
                            class="row-title"
                            onclick="playTrack(${realIndex})"
                            style="cursor:pointer;"
                        >

                            <strong>
                                ${escapeHTML(
                                    getTrackTitle(track)
                                )}
                            </strong>

                            <span>
                                ${escapeHTML(
                                    getTrackArtist(track)
                                )}
                            </span>

                        </div>

                        <div class="row-muted">
                            ${escapeHTML(
                                getTrackAlbum(track)
                            )}
                        </div>

                        <div class="row-muted">
                            ${formatTime(track.duration)}
                        </div>

                        <div class="row-actions">

                            <button
                                class="button small"
                                onclick="addToQueue(${realIndex})"
                            >
                                +
                            </button>

                        </div>

                    </div>

                `;

            }
        ).join('');

}


function renderFavorites() {

    renderSimpleList(
        'favoritesContainer',
        tracks.filter(
            track =>
                track.favorite
        )
    );

}


function renderRecent() {

    const recent =
        history
            .map(
                id =>
                    tracks.find(
                        track =>
                            track.id === id
                    )
            )
            .filter(Boolean);


    renderSimpleList(
        'recentContainer',
        recent
    );

}


function renderMostPlayed() {

    const list =
        [...tracks]
            .sort(
                (a, b) =>
                    (b.plays || 0) -
                    (a.plays || 0)
            )
            .filter(
                track =>
                    track.plays > 0
            );


    renderSimpleList(
        'mostPlayedContainer',
        list
    );

}


function renderRecentlyAdded() {

    const list =
        [...tracks]
            .sort(
                (a, b) =>
                    b.added - a.added
            );


    renderSimpleList(
        'recentlyAddedContainer',
        list
    );

}


/* =========================================================
   ARTISTS
========================================================= */

function renderArtists() {

    const artists =
        [...new Set(
            tracks.map(
                track =>
                    getTrackArtist(track)
            )
        )]
        .filter(Boolean)
        .sort(
            (a, b) =>
                a.localeCompare(b)
        );


    document
        .getElementById(
            'artistList'
        )
        .innerHTML =
            artists.map(
                artist => `

                    <li
                        onclick="filterArtist('${escapeHTML(artist)}')"
                    >
                        ${escapeHTML(artist)}
                    </li>

                `
            ).join('');

}


window.filterArtist =
    function(artist) {

        showPage('library');

        document
            .getElementById(
                'searchInput'
            )
            .value =
                artist;

        renderLibrary();

    };


/* =========================================================
   NAVIGATION
========================================================= */

document
    .querySelectorAll(
        '.nav-item'
    )
    .forEach(
        button => {

            button.addEventListener(
                'click',
                () => {

                    showPage(
                        button.dataset.page
                    );

                }
            );

        }
    );


function showPage(page) {

    document
        .querySelectorAll(
            '.page'
        )
        .forEach(
            section =>
                section.classList.add(
                    'hidden'
                )
        );


    document
        .getElementById(
            `${page}Page`
        )
        ?.classList.remove(
            'hidden'
        );


    document
        .getElementById(
            'welcomePage'
        )
        .classList.add(
            'hidden'
        );


    document
        .querySelectorAll(
            '.nav-item'
        )
        .forEach(
            button =>
                button.classList.toggle(
                    'active',
                    button.dataset.page === page
                )
        );

    saveUIState();


    if (page === 'library') {
        renderLibrary();
    }

    if (page === 'favorites') {
        renderFavorites();
    }

    if (page === 'recent') {
        renderRecent();
    }

    if (page === 'most-played') {
        renderMostPlayed();
    }

    if (page === 'recently-added') {
        renderRecentlyAdded();
    }

    if (page === 'playlists') {
        renderPlaylists();
    }

    if (page === 'queue') {
        renderQueue();
    }

    if (page === 'statistics') {
        updateStatistics();
    }

}


/* =========================================================
   VISUALIZER
========================================================= */

let audioContext = null;
let analyser = null;
let sourceNode = null;

const visualizer =
    document.getElementById(
        'visualizer'
    );


function initVisualizer() {

    if (audioContext) {
        return;
    }


    try {

        audioContext =
            new (
                window.AudioContext ||
                window.webkitAudioContext
            )();


        sourceNode =
            audioContext.createMediaElementSource(
                audio
            );


        analyser =
            audioContext.createAnalyser();


        analyser.fftSize = 256;


        // Route through the EQ when its filters exist; otherwise use the
        // normal source -> analyser -> speakers path.
        connectAudioGraph();


        drawVisualizer();

    } catch (error) {

        console.warn(
            'Visualizer unavailable.',
            error
        );

    }

}


audio.addEventListener(
    'play',
    () => {

        initVisualizer();

        if (
            audioContext &&
            audioContext.state === 'suspended'
        ) {
            audioContext.resume();
        }

    }
);


function drawVisualizer() {

    if (!visualizer) {
        return;
    }


    const ctx =
        visualizer.getContext(
            '2d'
        );


    const width =
        visualizer.width =
            visualizer.clientWidth * devicePixelRatio;


    const height =
        visualizer.height =
            visualizer.clientHeight * devicePixelRatio;


    function draw() {

        requestAnimationFrame(
            draw
        );


        ctx.clearRect(
            0,
            0,
            width,
            height
        );


        if (!analyser) {
            return;
        }


        const data =
            new Uint8Array(
                analyser.frequencyBinCount
            );


        analyser.getByteFrequencyData(
            data
        );


        const barWidth =
            width /
            data.length;


        data.forEach(
            (value, index) => {

                const barHeight =
                    (
                        value / 255
                    ) * height;


                ctx.fillStyle =
                    getComputedStyle(
                        document.documentElement
                    )
                    .getPropertyValue(
                        '--accent'
                    );


                ctx.fillRect(
                    index * barWidth,
                    height - barHeight,
                    Math.max(
                        1,
                        barWidth - 1
                    ),
                    barHeight
                );

            }
        );

    }


    draw();

}


/* =========================================================
   EQUALIZER
========================================================= */

const frequencies = [
    60,
    120,
    250,
    500,
    1000,
    2000,
    4000,
    8000,
    12000,
    16000
];


let eqFilters = [];
let eqGraphConnected = false;


function setupEqualizer() {

    const container =
        document.getElementById(
            'eqContainer'
        );


    if (!container) {
        return;
    }


    container.innerHTML =
        frequencies.map(
            frequency => `

                <div class="eq-band">

                    <input
                        type="range"
                        min="-12"
                        max="12"
                        value="0"
                        step=".5"
                        data-frequency="${frequency}"
                    >

                    <span>
                        ${frequency >= 1000
                            ? `${frequency / 1000}k`
                            : frequency
                        }
                    </span>

                </div>

            `
        ).join('');


    container
        .querySelectorAll(
            'input'
        )
        .forEach(
            input => {

                input.addEventListener(
                    'input',
                    applyEqualizer
                );

            }
        );

}


function connectAudioGraph() {

    if (
        !audioContext ||
        !sourceNode ||
        !analyser
    ) {
        return false;
    }


    /*
     * The old implementation created the EQ filters but never connected
     * them to the audio signal. That meant moving the sliders changed the
     * filter objects, but the music completely bypassed them.
     *
     * Correct signal path:
     *
     * <audio> -> EQ band 1 -> ... -> EQ band 10 -> analyser -> speakers
     */

    try {

        sourceNode.disconnect();

        analyser.disconnect();

        if (eqFilters.length) {

            eqFilters.forEach(
                filter => {

                    try {
                        filter.disconnect();
                    } catch (error) {}

                }
            );


            sourceNode.connect(
                eqFilters[0]
            );


            for (
                let index = 0;
                index < eqFilters.length - 1;
                index++
            ) {

                eqFilters[index].connect(
                    eqFilters[index + 1]
                );

            }


            eqFilters[
                eqFilters.length - 1
            ].connect(
                analyser
            );

        } else {

            sourceNode.connect(
                analyser
            );

        }


        analyser.connect(
            audioContext.destination
        );


        eqGraphConnected = true;

        return true;

    } catch (error) {

        console.warn(
            'Could not connect equalizer audio graph.',
            error
        );

        eqGraphConnected = false;

        return false;

    }

}


function applyEqualizer() {

    if (!audioContext) {
        initVisualizer();
    }


    if (!audioContext) {
        return;
    }


    if (!analyser || !sourceNode) {
        return;
    }


    /*
     * Create the ten-band parametric EQ once.
     */

    if (
        !eqFilters.length
    ) {

        eqFilters =
            frequencies.map(
                frequency => {

                    const filter =
                        audioContext.createBiquadFilter();


                    filter.type =
                        'peaking';

                    filter.frequency.value =
                        frequency;

                    /*
                     * A slightly wider Q gives smoother transitions between
                     * the ten bands and avoids extremely narrow peaks.
                     */
                    filter.Q.value =
                        1;


                    filter.gain.value =
                        0;


                    return filter;

                }
            );

    }


    const inputs =
        Array.from(
            document.querySelectorAll(
                '#eqContainer input'
            )
        );


    inputs.forEach(
        (input, index) => {

            if (
                eqFilters[index]
            ) {

                eqFilters[index].gain.value =
                    Number(
                        input.value
                    );

            }

        }
    );


    /*
     * Reconnect the actual signal path after creating the filters.
     */
    connectAudioGraph();

}


const eqPresets = {

    flat:
        [0,0,0,0,0,0,0,0,0,0],

    rock:
        [4,3,2,0,-1,1,3,4,4,3],

    pop:
        [-1,1,3,4,2,0,-1,-1,-1,-2],

    classical:
        [3,2,1,0,-1,-1,0,2,3,4],

    bass:
        [8,6,4,2,0,0,0,0,0,0],

    treble:
        [0,0,0,0,0,2,4,6,7,8]

};


document
    .querySelectorAll(
        '[data-eq-preset]'
    )
    .forEach(
        button => {

            button.addEventListener(
                'click',
                () => {

                    const values =
                        eqPresets[
                            button.dataset.eqPreset
                        ];


                    if (!values) {
                        return;
                    }


                    const inputs =
                        document.querySelectorAll(
                            '#eqContainer input'
                        );


                    inputs.forEach(
                        (input, index) => {

                            input.value =
                                values[index] ?? 0;

                        }
                    );


                    applyEqualizer();

                }
            );

        }
    );


setupEqualizer();


/* =========================================================
   SLEEP TIMER
========================================================= */

document
    .getElementById(
        'sleepTimer'
    )
    .addEventListener(
        'change',
        event => {

            const minutes =
                Number(
                    event.target.value
                );


            settings.sleepTimer =
                minutes;


            saveState();


            if (sleepTimerHandle) {

                clearTimeout(
                    sleepTimerHandle
                );

            }


            if (minutes > 0) {

                sleepTimerHandle =
                    setTimeout(
                        () => {

                            pauseAudioByWebsite();

                            toast(
                                'Sleep timer ended.'
                            );

                        },
                        minutes *
                        60 *
                        1000
                    );


                toast(
                    `Sleep timer set for ${minutes} minutes.`
                );

            }

        }
    );


/* =========================================================
   SETTINGS
========================================================= */

document
    .getElementById(
        'themeSelect'
    )
    .addEventListener(
        'change',
        event => {

            settings.theme =
                event.target.value;

            applyTheme();

            saveState();

        }
    );


document
    .getElementById(
        'accentColor'
    )
    .addEventListener(
        'input',
        event => {

            settings.accent =
                event.target.value;

            applyTheme();

            saveState();

        }
    );


document
    .getElementById(
        'speedSelect'
    )
    .addEventListener(
        'change',
        event => {

            settings.speed =
                Number(
                    event.target.value
                );


            audio.playbackRate =
                settings.speed;


            saveState();

        }
    );


document
    .getElementById(
        'crossfadeToggle'
    )
    .addEventListener(
        'change',
        event => {

            settings.crossfade =
                event.target.checked;

            saveState();

        }
    );


document
    .getElementById(
        'gaplessToggle'
    )
    .addEventListener(
        'change',
        event => {

            settings.gapless =
                event.target.checked;

            saveState();

        }
    );


document
    .getElementById(
        'autoplayToggle'
    )
    .addEventListener(
        'change',
        event => {

            settings.autoplay =
                event.target.checked;

            saveState();

        }
    );


function applyTheme() {

    const root = document.documentElement;

    root.dataset.theme = settings.theme || 'dark';
    root.style.setProperty('--accent', settings.accent || '#8257e5');

    const themes = {
        dark: {
            bg: '#121214', panel: '#1e1e24', panel2: '#18181d',
            border: '#29292e', text: '#e1e1e6', muted: '#a8a8b3', muted2: '#737380',
            hover: '#35353c', cardHover: '#232329', active: '#29292e', borderHover: '#44444c',
            accentHover: '#996dff'
        },
        light: {
            bg: '#f4f4f5', panel: '#ffffff', panel2: '#fafafa',
            border: '#dedee3', text: '#18181b', muted: '#62626d', muted2: '#888894',
            hover: '#eeeeF2', cardHover: '#f1f1f4', active: '#e8e8ed', borderHover: '#b9b9c3',
            accentHover: '#7048d9'
        },
        purple: {
            bg: '#160f1f', panel: '#24172f', panel2: '#1d1227',
            border: '#3b2850', text: '#f1eafa', muted: '#bcaeca', muted2: '#8f7da1',
            hover: '#342143', cardHover: '#2b1c39', active: '#392347', borderHover: '#68498a',
            accentHover: '#a979ff'
        },
        midnight: {
            bg: '#08111f', panel: '#101b2d', panel2: '#0c1626',
            border: '#20304a', text: '#e7eef8', muted: '#9eacc0', muted2: '#718097',
            hover: '#18273d', cardHover: '#142238', active: '#1b2b43', borderHover: '#385276',
            accentHover: '#5f9cff'
        }
    };

    const theme = themes[settings.theme] || themes.dark;

    root.style.setProperty('--bg', theme.bg);
    root.style.setProperty('--panel', theme.panel);
    root.style.setProperty('--panel-2', theme.panel2);
    root.style.setProperty('--border', theme.border);
    root.style.setProperty('--text', theme.text);
    root.style.setProperty('--muted', theme.muted);
    root.style.setProperty('--muted-2', theme.muted2);
    root.style.setProperty('--accent-hover', theme.accentHover);
    root.style.setProperty('--sidebar-bg', theme.panel2);
    root.style.setProperty('--button-hover', theme.hover);
    root.style.setProperty('--card-hover', theme.cardHover);
    root.style.setProperty('--card-active', theme.active);
    root.style.setProperty('--track-border-hover', theme.borderHover);
    root.style.setProperty('--button-bg', theme.active);
    root.style.setProperty('--button-text', settings.theme === 'light' ? '#18181b' : '#ffffff');
    root.style.setProperty('--topbar-bg', settings.theme === 'light' ? 'rgba(255,255,255,.92)' : `rgba(${settings.theme === 'purple' ? '22,15,31' : settings.theme === 'midnight' ? '8,17,31' : '18,18,20'},.92)`);
    root.style.setProperty('--player-bg', settings.theme === 'light' ? 'rgba(255,255,255,.97)' : `rgba(${settings.theme === 'purple' ? '29,18,39' : settings.theme === 'midnight' ? '12,22,38' : '24,24,29'},.97)`);
    root.style.setProperty('--visualizer-bg', settings.theme === 'light' ? '#eeeeF2' : settings.theme === 'purple' ? '#0f0a16' : settings.theme === 'midnight' ? '#060c15' : '#121214');
    root.style.setProperty('--modal-backdrop', settings.theme === 'light' ? 'rgba(20,20,24,.38)' : settings.theme === 'purple' ? 'rgba(0,0,0,.68)' : settings.theme === 'midnight' ? 'rgba(0,0,0,.72)' : 'rgba(0,0,0,.65)');
    root.style.setProperty('--shadow-color', settings.theme === 'light' ? 'rgba(30,30,40,.18)' : 'rgba(0,0,0,.30)');
    root.style.setProperty('--subtle-shadow-color', settings.theme === 'light' ? 'rgba(30,30,40,.08)' : 'rgba(0,0,0,.22)');
    root.style.setProperty('--welcome-start', theme.panel);
    root.style.setProperty('--welcome-end', theme.panel2);
    root.style.setProperty('--input-bg', theme.panel);
    root.style.setProperty('--link-hover', settings.theme === 'light' ? '#18181b' : '#ffffff');

}



document
    .getElementById('albumLayoutSelect')
    .addEventListener('change', event => {
        settings.albumLayout = event.target.value;
        saveState();
        renderLibrary();
    });


document
    .getElementById('albumCardSizeSelect')
    .addEventListener('change', event => {
        settings.albumCardSize = event.target.value;
        saveState();
        renderLibrary();
    });


/* =========================================================
   NOTIFICATIONS
========================================================= */

function updateNotificationButton() {

    const button = document.getElementById('notificationButton');
    if (!button) return;

    const supported = 'Notification' in window;
    const granted = supported && Notification.permission === 'granted';
    const enabled = Boolean(settings.notifications && granted);

    button.textContent = enabled
        ? 'Notifications: On'
        : 'Notifications: Off';

    button.setAttribute('aria-pressed', enabled ? 'true' : 'false');

    if (!supported) {
        button.disabled = true;
        button.textContent = 'Notifications: Unsupported';
    } else {
        button.disabled = false;
    }
}


document
    .getElementById('notificationButton')
    .addEventListener(
        'click',
        async () => {

            if (!('Notification' in window)) {
                toast('Notifications are not supported by this browser.');
                updateNotificationButton();
                return;
            }

            // Turning an already-enabled setting off does not require
            // changing the browser permission. It simply stops Encore
            // from creating notifications.
            if (settings.notifications && Notification.permission === 'granted') {
                settings.notifications = false;
                saveState();
                updateNotificationButton();
                toast('Notifications disabled.');
                return;
            }

            let permission = Notification.permission;

            if (permission === 'default') {
                permission = await Notification.requestPermission();
            }

            if (permission === 'granted') {
                settings.notifications = true;
                saveState();
                updateNotificationButton();
                toast('Notifications enabled.');
                return;
            }

            settings.notifications = false;
            saveState();
            updateNotificationButton();

            if (permission === 'denied') {
                toast('Notifications are blocked. Allow them in your browser site settings, then try again.');
            } else {
                toast('Notifications were not enabled.');
            }
        }
    );


function sendNowPlayingNotification(track) {

    if (
        !settings.notifications ||
        !('Notification' in window) ||
        Notification.permission !== 'granted'
    ) {
        return;
    }

    try {
        new Notification(
            getTrackTitle(track),
            {
                body: getTrackArtist(track),
                icon:
                    track.artworkData ||
                    track.metadata?.artworkData ||
                    (track.artwork
                        ? getFileObjectUrl(track.artwork, albumArtUrls)
                        : undefined)
            }
        );
    } catch (e) {}
}



/* =========================================================
   MEDIA SESSION
========================================================= */

function updateMediaSession(track) {

    if (
        !('mediaSession' in navigator)
    ) {
        return;
    }


    try {

        navigator.mediaSession.metadata =
            new MediaMetadata({

                title:
                    getTrackTitle(track),

                artist:
                    getTrackArtist(track),

                album:
                    getTrackAlbum(track),

                artwork:
                    (track.artworkData || track.metadata?.artworkData ||
                    (track.artwork ? getFileObjectUrl(track.artwork, albumArtUrls) : ''))
                        ? [{
                            src: track.artworkData || track.metadata?.artworkData || getFileObjectUrl(track.artwork, albumArtUrls),
                            sizes: '512x512',
                            type: 'image/jpeg'
                        }]
                        : []

            });


        navigator.mediaSession.setActionHandler(
            'play',
            playCurrent
        );


        navigator.mediaSession.setActionHandler(
            'pause',
            pauseCurrent
        );


        navigator.mediaSession.setActionHandler(
            'nexttrack',
            nextTrack
        );


        navigator.mediaSession.setActionHandler(
            'previoustrack',
            previousTrack
        );


        navigator.mediaSession.setActionHandler(
            'seekbackward',
            () => {

                audio.currentTime =
                    Math.max(
                        0,
                        audio.currentTime - 10
                    );

            }
        );


        navigator.mediaSession.setActionHandler(
            'seekforward',
            () => {

                audio.currentTime =
                    Math.min(
                        audio.duration || 0,
                        audio.currentTime + 10
                    );

            }
        );

    } catch (e) {}

}


/* =========================================================
   LYRICS
========================================================= */

document
    .getElementById(
        'lyricsButton'
    )
    .addEventListener(
        'click',
        showLyrics
    );


async function showLyrics() {

    if (!currentTrack) {

        toast(
            'Nothing is playing.'
        );

        return;
    }


    const track =
        currentTrack;


    let lyrics =
        'No local lyrics file found.';


    if (
        track.lyricsFile
    ) {

        try {

            lyrics =
                await track
                    .lyricsFile
                    .text();

        } catch (e) {}

    }


    openModal(`

        <h2>
            Lyrics
        </h2>

        <div class="lyrics">
            ${escapeHTML(lyrics)}
        </div>

    `);

}


/* =========================================================
   A/B LOOP
========================================================= */

let loopA = null;
let loopB = null;


document
    .getElementById(
        'playerTitle'
    )
    .addEventListener(
        'dblclick',
        () => {

            if (
                loopA === null
            ) {

                loopA =
                    audio.currentTime;

                toast(
                    'Loop A set.'
                );

            } else if (
                loopB === null
            ) {

                loopB =
                    audio.currentTime;

                toast(
                    'Loop B set.'
                );

            } else {

                loopA = null;
                loopB = null;

                toast(
                    'A/B loop cleared.'
                );

            }

        }
    );


audio.addEventListener(
    'timeupdate',
    () => {

        if (
            loopA !== null &&
            loopB !== null &&
            audio.currentTime >= loopB
        ) {

            audio.currentTime =
                loopA;

        }

    }
);


/* =========================================================
   RANDOM / SMART SHUFFLE
========================================================= */

document
    .getElementById(
        'randomButton'
    )
    .addEventListener(
        'click',
        surpriseMe
    );


function surpriseMe() {

    if (!tracks.length) {

        toast(
            'Load some music first.'
        );

        return;

    }


    /*
     * Prefer tracks that haven't been played recently.
     */

    const recentSet =
        new Set(
            history.slice(
                0,
                Math.min(
                    10,
                    tracks.length
                )
            )
        );


    let candidates =
        tracks.filter(
            track =>
                !recentSet.has(
                    track.id
                )
        );


    if (!candidates.length) {
        candidates = [...tracks];
    }


    /*
     * Slightly favor tracks with fewer plays.
     */

    candidates.sort(
        (a, b) =>
            (a.plays || 0) -
            (b.plays || 0)
    );


    const limit =
        Math.max(
            1,
            Math.ceil(
                candidates.length / 2
            )
        );


    const track =
        candidates[
            Math.floor(
                Math.random() *
                Math.min(
                    limit,
                    candidates.length
                )
            )
        ];


    playTrack(
        tracks.indexOf(track)
    );

}


/* =========================================================
   COMMAND PALETTE
========================================================= */

const commands = [

    {
        name: 'Play / Pause',
        key: 'Space',
        action: playCurrent
    },

    {
        name: 'Next Track',
        key: 'N',
        action: nextTrack
    },

    {
        name: 'Previous Track',
        key: 'P',
        action: previousTrack
    },

    {
        name: 'Shuffle',
        key: 'S',
        action: () =>
            document
                .getElementById(
                    'shuffleButton'
                )
                .click()
    },

    {
        name: 'Surprise Me',
        key: '',
        action: surpriseMe
    },

    {
        name: 'Open Queue',
        key: '',
        action: () => showPage('queue')
    },

    {
        name: 'Open Library',
        key: '',
        action: () => showPage('library')
    },

    {
        name: 'Open Settings',
        key: '',
        action: () => showPage('settings')
    },

    {
        name: 'Open Now Playing',
        key: '',
        action: () => showPage('now-playing')
    }

];


document
    .getElementById(
        'commandButton'
    )
    .addEventListener(
        'click',
        openCommandPalette
    );


function openCommandPalette() {

    openModal(`

        <h2>
            Command Palette
        </h2>

        <input
            type="search"
            id="commandSearch"
            placeholder="Search commands..."
            style="
                width:100%;
                padding:11px;
                background:var(--input-bg);
                color:var(--text);
                border:1px solid var(--border);
                border-radius:7px;
            "
        >

        <div
            class="command-list"
            id="commandList"
        ></div>

    `);


    renderCommands();


    document
        .getElementById(
            'commandSearch'
        )
        .addEventListener(
            'input',
            renderCommands
        );

}


function renderCommands() {

    const search =
        document
            .getElementById(
                'commandSearch'
            )
            .value
            .toLowerCase();


    const list =
        document.getElementById(
            'commandList'
        );


    list.innerHTML =
        commands
            .filter(
                command =>
                    command.name
                        .toLowerCase()
                        .includes(
                            search
                        )
            )
            .map(
                (command, index) => `

                    <div
                        class="command-item"
                        onclick="runCommand(${index})"
                    >

                        <span>
                            ${escapeHTML(
                                command.name
                            )}
                        </span>

                        <span class="command-key">
                            ${escapeHTML(
                                command.key
                            )}
                        </span>

                    </div>

                `
            )
            .join('');

}


window.runCommand =
    function(index) {

        closeModal();

        commands[index].action();

    };


document
    .getElementById(
        'commandButton'
    )
    .addEventListener(
        'click',
        openCommandPalette
    );


/* =========================================================
   KEYBOARD CONTROLS
========================================================= */

document.addEventListener(
    'keydown',
    event => {

        const activeElement = document.activeElement;
        const tag = activeElement?.tagName;
        const isTextInput =
            tag === 'INPUT' ||
            tag === 'TEXTAREA' ||
            tag === 'SELECT' ||
            activeElement?.isContentEditable ||
            activeElement?.getAttribute?.('role') === 'textbox';

        // Never let global player shortcuts fire while the user is
        // typing into any editable control, including contenteditable
        // fields such as the MusicBrainz custom song-name editor.
        if (isTextInput) {
            return;
        }


        switch (
            event.key.toLowerCase()
        ) {

            case ' ':

                event.preventDefault();

                if (audio.paused) {
                    playCurrent();
                } else {
                    pauseCurrent();
                }

                break;


            case 'n':
                nextTrack();
                break;


            case 'p':
                previousTrack();
                break;


            case 's':

                document
                    .getElementById(
                        'shuffleButton'
                    )
                    .click();

                break;


            case 'arrowleft':

                audio.currentTime =
                    Math.max(
                        0,
                        audio.currentTime - 5
                    );

                break;


            case 'arrowright':

                audio.currentTime =
                    Math.min(
                        audio.duration || 0,
                        audio.currentTime + 5
                    );

                break;


            case 'arrowup':

                event.preventDefault();

                setAudioVolumeByWebsite(
                    Math.min(
                        1,
                        audio.volume + .05
                    )
                );


                volumeSlider.value =
                    audio.volume * 100;

                break;


            case 'arrowdown':

                event.preventDefault();

                setAudioVolumeByWebsite(
                    Math.max(
                        0,
                        audio.volume - .05
                    )
                );


                volumeSlider.value =
                    audio.volume * 100;

                break;

        }

    }
);


/* =========================================================
   MEDIA KEY SUPPORT
========================================================= */

if ('mediaSession' in navigator) {

    /*
     * The Media Session API also handles many
     * physical media keys on supported systems.
     */

}


/* =========================================================
   STATS
========================================================= */

function updateStatistics() {

    const totalPlays =
        tracks.reduce(
            (sum, track) =>
                sum + (track.plays || 0),
            0
        );


    const favoriteCount =
        tracks.filter(
            track =>
                track.favorite
        ).length;


    document
        .getElementById(
            'statPlays'
        )
        .textContent =
            totalPlays;


    document
        .getElementById(
            'statLibrary'
        )
        .textContent =
            `${tracks.length} tracks`;


    document
        .getElementById(
            'statFavorites'
        )
        .textContent =
            `${favoriteCount} tracks`;


    const listenedSeconds =
        history.reduce(
            (total, id) => {

                const track =
                    tracks.find(
                        item =>
                            item.id === id
                    );


                return total +
                    (
                        track?.duration || 0
                    );

            },
            0
        );


    document
        .getElementById(
            'statTime'
        )
        .textContent =
            `${Math.round(
                listenedSeconds / 60
            )} minutes`;


    drawStats();

}


function drawStats() {

    const canvas =
        document.getElementById(
            'statsCanvas'
        );


    if (!canvas) {
        return;
    }


    const ctx =
        canvas.getContext(
            '2d'
        );


    const width =
        canvas.width =
            canvas.clientWidth *
            devicePixelRatio;


    const height =
        canvas.height =
            canvas.clientHeight *
            devicePixelRatio;


    ctx.clearRect(
        0,
        0,
        width,
        height
    );


    const topTracks =
        [...tracks]
            .sort(
                (a, b) =>
                    (b.plays || 0) -
                    (a.plays || 0)
            )
            .slice(0, 10);


    if (!topTracks.length) {
        return;
    }


    const max =
        Math.max(
            1,
            ...topTracks.map(
                track =>
                    track.plays || 0
            )
        );


    const barWidth =
        width /
        topTracks.length;


    topTracks.forEach(
        (track, index) => {

            const value =
                track.plays || 0;


            const barHeight =
                (
                    value / max
                ) *
                (height - 40);


            ctx.fillStyle =
                getComputedStyle(
                    document.documentElement
                )
                .getPropertyValue(
                    '--accent'
                );


            ctx.fillRect(
                index * barWidth + 5,
                height - barHeight - 25,
                barWidth - 10,
                barHeight
            );


            ctx.fillStyle =
                getComputedStyle(
                    document.documentElement
                )
                .getPropertyValue(
                    '--muted'
                );


            ctx.font =
                `${10 * devicePixelRatio}px sans-serif`;


            ctx.fillText(
                String(value),
                index * barWidth + 8,
                height - 8
            );

        }
    );

}


/* =========================================================
   LOCAL FILE / FOLDER HANDLING
========================================================= */

/*
 * The browser's folder picker already recursively supplies
 * files from the selected directory.
 *
 * Drag-and-drop is also supported.
 */

document.addEventListener(
    'dragover',
    event => {

        event.preventDefault();

    }
);


document.addEventListener(
    'drop',
    event => {

        event.preventDefault();


        const files =
            Array.from(
                event.dataTransfer.files
            );


        if (files.length) {

            loadFiles(
                files
            );

        }

    }
);


/* =========================================================
   REFRESH
========================================================= */

document
    .getElementById('refreshLibrary')
    .addEventListener(
        'click',
        async () => {

            const button = document.getElementById('refreshLibrary');
            if (button) button.disabled = true;

            try {
                const handle = await getSavedFolderHandle();

                if (!handle) {
                    renderEverything();
                    toast('Library refreshed. Select a folder to scan it again.');
                    return;
                }

                let permission = await handle.queryPermission({ mode: 'read' });

                if (permission !== 'granted') {
                    permission = await handle.requestPermission({ mode: 'read' });
                }

                if (permission !== 'granted') {
                    toast('Permission to refresh the saved music folder was denied.');
                    return;
                }

                toast(`Refreshing ${handle.name}...`);

                const files = await readDirectoryAudioFiles(handle, handle.name);
                const audioFiles = files.filter(isAudioFile);

                if (!audioFiles.length) {
                    albums.clear();
                    clearActiveAlbum();
                    renderEverything();
                    toast('The saved folder contains no supported music files.');
                    return;
                }

                // Re-index from the current folder contents so deleted and
                // newly-added files are reflected instead of being appended.
                albums.clear();
                clearActiveAlbum();
                loadFiles(audioFiles, true);

                setTimeout(() => {
                    try {
                        autoEmbedAlbumArtwork();
                    } catch (error) {
                        console.warn('Background artwork refresh failed:', error);
                    }
                }, 0);

                toast(`Library refreshed: ${audioFiles.length} music file${audioFiles.length === 1 ? '' : 's'}.`);

            } catch (error) {
                console.error('Library refresh error:', error);
                toast(`Could not refresh the library: ${error?.message || error}`);
            } finally {
                if (button) button.disabled = false;
            }
        }
    );


/* =========================================================
   CLEAR LOCAL DATA
========================================================= */

document
    .getElementById(
        'clearLocalData'
    )
    .addEventListener(
        'click',
        () => {

            if (
                !confirm(
                    'Clear saved favorites, playlists, history and settings?'
                )
            ) {
                return;
            }


            localStorage.removeItem(
                'encore_music_state'
            );

            localStorage.removeItem(
                'encore_music_playlists'
            );

            localStorage.removeItem(
                'encore_music_history'
            );

            localStorage.removeItem(
                'encore_music_settings'
            );

            localStorage.removeItem(
                'encore_music_albums'
            );

            localStorage.removeItem(
                'encore_preferences'
            );

            localStorage.removeItem(
                'encore_ui_state'
            );


            favorites =
                new Set();

            history =
                [];

            playlists =
                {};

            albums =
                new Map();

            activeAlbumKey = null;

            albumArtUrls.forEach(url => {
                try { URL.revokeObjectURL(url); } catch (e) {}
            });
            albumArtUrls.clear();

            tracks = [];

            currentIndex = -1;
            currentTrack = null;
            trackRegistry.clear();
            queue = [];
            localStorage.removeItem('encore_music_queue');

            toast(
                'Saved data cleared.'
            );

        }
    );


/* =========================================================
   MODALS
========================================================= */

function openModal(content) {

    document
        .getElementById(
            'modal'
        )
        .innerHTML =
            content;


    document
        .getElementById(
            'modalBackdrop'
        )
        .classList.remove(
            'hidden'
        );

}


function closeModal() {

    document
        .getElementById(
            'modalBackdrop'
        )
        .classList.add(
            'hidden'
        );

    document.getElementById('modal')?.classList.remove('musicbrainz-wide-modal', 'ai-cleanup-modal');

}


document
    .getElementById(
        'modalBackdrop'
    )
    .addEventListener(
        'click',
        event => {

            if (
                event.target.id ===
                'modalBackdrop'
            ) {

                closeModal();

            }

        }
    );


document.addEventListener(
    'keydown',
    event => {

        if (
            event.key === 'Escape'
        ) {

            closeModal();

        }

    }
);


/* =========================================================
   TOASTS
========================================================= */

function toast(message) {

    const container =
        document.getElementById(
            'toastContainer'
        );


    const element =
        document.createElement(
            'div'
        );


    element.className =
        'toast';


    element.textContent =
        message;


    container.appendChild(
        element
    );


    setTimeout(
        () => {

            element.remove();

        },
        3000
    );

}


/* =========================================================
   UTILITY
========================================================= */

function formatBytes(bytes) {

    if (!bytes) {
        return '0 B';
    }


    const units = [
        'B',
        'KB',
        'MB',
        'GB'
    ];


    const index =
        Math.floor(
            Math.log(bytes) /
            Math.log(1024)
        );


    return (
        Math.round(
            bytes /
            Math.pow(
                1024,
                index
            ) *
            10
        ) / 10
    ) +
    ' ' +
    units[index];

}


/* =========================================================
   RENDER EVERYTHING
========================================================= */

function renderEverything() {

    renderLibrary();

    renderFavorites();

    renderRecent();

    renderMostPlayed();

    renderRecentlyAdded();

    renderPlaylists();

    renderQueue();

    renderArtists();

    updateStatistics();

    updatePlayer();

}


/* =========================================================
   INITIALIZE
========================================================= */

loadState();

applyTheme();

updateRecallFolderButton();


document
    .getElementById(
        'themeSelect'
    )
    .value =
        settings.theme;


document
    .getElementById(
        'accentColor'
    )
    .value =
        settings.accent;


document
    .getElementById(
        'speedSelect'
    )
    .value =
        settings.speed;


document
    .getElementById(
        'crossfadeToggle'
    )
    .checked =
        settings.crossfade;


document
    .getElementById(
        'gaplessToggle'
    )
    .checked =
        settings.gapless;


document
    .getElementById(
        'autoplayToggle'
    )
    .checked =
        settings.autoplay;


document
    .getElementById(
        'sleepTimer'
    )
    .value =
        settings.sleepTimer;


document
    .getElementById('albumLayoutSelect')
    .value = settings.albumLayout || 'grid';


document
    .getElementById('albumCardSizeSelect')
    .value = settings.albumCardSize || 'standard';


updateNotificationButton();

document
    .getElementById('shuffleButton')
    ?.classList.toggle('active', shuffle);

const repeatButton = document.getElementById('repeatButton');
if (repeatButton) {
    repeatButton.innerHTML = repeatMode === 'one'
        ? '<svg class="icon"><use href="#i-repeat"/></svg><small>1</small>'
        : '<svg class="icon"><use href="#i-repeat"/></svg>';
    repeatButton.classList.toggle('active', repeatMode !== 'off');
}

renderEverything();

const savedUIState = loadUIState();
if (tracks.length && savedUIState.activePage) {
    const pageExists = document.getElementById(`${savedUIState.activePage}Page`);
    if (pageExists) {
        showPage(savedUIState.activePage);
    }
}


/* =========================================================
   EXTRA PLAYER BUTTONS
========================================================= */

document
    .getElementById(
        'queueButton'
    )
    .addEventListener(
        'click',
        () => showPage('queue')
    );


document
    .getElementById(
        'miniQueueButton'
    )
    .addEventListener(
        'click',
        () => showPage('queue')
    );


</script>

</body>
</html>
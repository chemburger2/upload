<?php

/*
 * Encore Music - MusicBrainz / Cover Art Archive proxy
 * Place this file beside the main Encore PHP page.
 */

require_once __DIR__ . '/../../config.php';

if (empty($_SESSION['is_admin'])) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Unauthorized.']);
    exit;
}

$type = $_GET['encore_mb'] ?? '';

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

function fetchRemote(
    $url,
    $accept = 'application/json',
    $attempt = 0
) {

    $ch =
        curl_init($url);


    curl_setopt_array(
        $ch,
        [

            CURLOPT_RETURNTRANSFER =>
                true,

            CURLOPT_FOLLOWLOCATION =>
                true,

            CURLOPT_CONNECTTIMEOUT =>
                10,

            CURLOPT_TIMEOUT =>
                30,

            CURLOPT_HTTPHEADER => [

                'Accept: ' .
                    $accept,

                /*
                 * MusicBrainz requires a meaningful
                 * application User-Agent.
                 */
                'User-Agent: ' .
                    'EncoreMusicPlayer/1.0 ' .
                    '(MusicBrainz metadata client)'

            ]

        ]
    );


    $body =
        curl_exec($ch);


    $status =
        curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        );


    $contentType =
        curl_getinfo(
            $ch,
            CURLINFO_CONTENT_TYPE
        );


    $error =
        curl_error($ch);


    curl_close($ch);


    /*
     * Temporary MusicBrainz/server errors.
     */
    $retryable =
        in_array(
            $status,
            [
                429,
                502,
                503,
                504
            ],
            true
        );


    if (
        $retryable &&
        $attempt < 3
    ) {

        /*
         * 1.5s, 3s, 4.5s
         */
        usleep(
            1500000 *
            ($attempt + 1)
        );


        return fetchRemote(
            $url,
            $accept,
            $attempt + 1
        );

    }


    if (
        $body === false ||
        $error
    ) {

        jsonResponse(
            [
                'error' =>
                    'Could not connect to the remote metadata service.'
            ],
            502
        );

    }


    if (
        $status < 200 ||
        $status >= 300
    ) {

        jsonResponse(
            [
                'error' =>
                    'Remote metadata service returned HTTP ' .
                    $status .
                    '.'
            ],
            $status ?: 502
        );

    }


    return [
        $body,
        $contentType
            ?: 'application/octet-stream'
    ];

}
if ($type === 'search') {
    $query = trim($_GET['query'] ?? '');
    if ($query === '') {
        jsonResponse(['error' => 'Missing MusicBrainz search query.'], 400);
    }

    $url = 'https://musicbrainz.org/ws/2/release/?' . http_build_query([
        'query' => $query,
        'fmt' => 'json',
        'limit' => min(10, max(1, (int)($_GET['limit'] ?? 10)))
    ]);

    [$body] = fetchRemote($url);
    header('Content-Type: application/json; charset=utf-8');
    echo $body;
    exit;
}

if ($type === 'release') {
    $id = trim($_GET['id'] ?? '');
    if (!preg_match('/^[0-9a-f-]{36}$/i', $id)) {
        jsonResponse(['error' => 'Invalid MusicBrainz release ID.'], 400);
    }

    $url = 'https://musicbrainz.org/ws/2/release/' . rawurlencode($id) . '?' . http_build_query([
        'inc' => 'media+recordings+artist-credits+release-groups',
        'fmt' => 'json'
    ]);

    [$body] = fetchRemote($url);
    header('Content-Type: application/json; charset=utf-8');
    echo $body;
    exit;
}

if ($type === 'cover') {
    $id = trim($_GET['id'] ?? '');
    if (!preg_match('/^[0-9a-f-]{36}$/i', $id)) {
        jsonResponse(['error' => 'Invalid MusicBrainz release ID.'], 400);
    }

    $url = 'https://coverartarchive.org/release/' . rawurlencode($id);
    [$body] = fetchRemote($url);
    header('Content-Type: application/json; charset=utf-8');
    echo $body;
    exit;
}

if ($type === 'cover_image') {
    $id = trim($_GET['id'] ?? '');
    if (!preg_match('/^[0-9a-f-]{36}$/i', $id)) {
        http_response_code(400);
        exit;
    }

    $url = 'https://coverartarchive.org/release/' . rawurlencode($id) . '/front-500';
    [$body, $contentType] = fetchRemote($url, 'image/*');
    header('Content-Type: ' . $contentType);
    header('Cache-Control: public, max-age=86400');
    echo $body;
    exit;
}

jsonResponse(['error' => 'Unknown metadata request.'], 400);

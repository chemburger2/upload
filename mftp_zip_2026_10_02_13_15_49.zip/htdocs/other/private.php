<?php

/*
 * PRIVATE PAGES
 * Admin-only project launcher
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../project_access.php';


/*
 * Same admin permission system as admin.php
 */
if (empty($_SESSION['user_id'])) {
    header('Location: ../logon.php');
    exit;
}

if (!userHasAnyProjectAccess($pdo, (int)$_SESSION['user_id'])) {
    http_response_code(403);
    exit('Access denied.');
}


$otherDir = __DIR__;

$message = '';
$error = '';


/*
 * Create Project
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['create_project'])) {

        $projectName = trim($_POST['project_name'] ?? '');

        if ($projectName === '') {

            $error = 'Please enter a project name.';

        } elseif (!preg_match('/^[a-zA-Z0-9_-]+$/', $projectName)) {

            $error = 'Project names can only contain letters, numbers, hyphens, and underscores.';

        } elseif (
            $projectName === 'private' ||
            $projectName === 'edit'
        ) {

            $error = 'That project name is reserved.';

        } else {

            $projectPath =
                $otherDir .
                DIRECTORY_SEPARATOR .
                $projectName;

            if (file_exists($projectPath)) {

                $error = 'A project with that name already exists.';

            } elseif (!mkdir($projectPath, 0755, true)) {

                $error = 'Could not create the project folder.';

            } else {

                $starterCode = <<<'PHP'
<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Private Project</title>
</head>
<body>

    <h1>Private Project</h1>

    <p>Start building here.</p>

</body>
</html>
PHP;

                $indexPath =
                    $projectPath .
                    DIRECTORY_SEPARATOR .
                    'index.php';

                if (file_put_contents($indexPath, $starterCode) === false) {

                    $error =
                        'Project folder created, but the starter index.php could not be created.';

                } else {

                    $message =
                        'Project "' .
                        $projectName .
                        '" created successfully.';
                }
            }
        }
    }
}


/*
 * Find projects
 */

$projects = [];

foreach (scandir($otherDir) as $item) {

    if (
        $item === '.' ||
        $item === '..' ||
        $item === 'private.php' ||
        $item === 'edit.php'
    ) {
        continue;
    }

    $path =
        $otherDir .
        DIRECTORY_SEPARATOR .
        $item;

    if (is_dir($path)) {
        $projects[] = $item;
    }
}

sort(
    $projects,
    SORT_NATURAL | SORT_FLAG_CASE
);

// Non-admin users only see projects they have been granted.
if (empty($_SESSION['is_admin'])) {
    $projects = array_values(array_filter(
        $projects,
        fn(string $project): bool => userHasProjectAccess(
            $pdo,
            (int)$_SESSION['user_id'],
            $project
        )
    ));
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Private Pages
    </title>

    <link
        rel="stylesheet"
        href="../style.css"
    >

    <style>

        /*
         * Encore-style private pages
         */

        * {
            box-sizing: border-box;
        }

        body {
            background: #121214;
            color: #e1e1e6;

            font-family:
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Roboto,
                Helvetica,
                Arial,
                sans-serif;

            margin: 0;
            min-height: 100vh;
        }


        .private-container {
            width: 100%;
            max-width: 1000px;

            margin: 0 auto;

            padding: 40px 24px 60px;
        }


        /*
         * Header
         */

        .private-header {
            display: flex;

            justify-content: space-between;
            align-items: center;

            gap: 20px;

            margin-bottom: 32px;
        }


        .private-title {
            margin: 0;

            font-size: 1.8rem;
            font-weight: 700;

            color: #e1e1e6;
        }


        .private-subtitle {
            margin: 6px 0 0;

            color: #a8a8b3;

            font-size: 0.9rem;
        }


        .header-buttons {
            display: flex;

            gap: 10px;

            flex-wrap: wrap;
        }


        /*
         * Buttons
         */

        .private-btn {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            background: #29292e;

            color: #e1e1e6;

            border: none;

            padding: 10px 16px;

            border-radius: 8px;

            text-decoration: none;

            font-size: 0.9rem;
            font-weight: 600;

            cursor: pointer;

            transition:
                background 0.2s,
                transform 0.1s;
        }


        .private-btn:hover {
            background: #323238;

            color: #ffffff;
        }


        .private-btn:active {
            transform: scale(0.97);
        }


        .private-btn-primary {
            background: #8257e5;

            color: #ffffff;
        }


        .private-btn-primary:hover {
            background: #996dff;

            color: #ffffff;
        }


        /*
         * Messages
         */

        .message {
            background: #1e1e24;

            border: 1px solid #29292e;

            border-radius: 10px;

            padding: 14px 16px;

            margin-bottom: 20px;

            color: #e1e1e6;
        }


        .message.error {
            border-color: #5b2b2b;

            color: #ff8f8f;
        }


        /*
         * Main panels
         */

        .private-panel {
            background: #1e1e24;

            border: 1px solid #29292e;

            border-radius: 12px;

            padding: 24px;

            margin-bottom: 24px;
        }


        .panel-heading {
            margin: 0 0 5px;

            font-size: 1.15rem;

            color: #e1e1e6;
        }


        .panel-description {
            margin: 0 0 20px;

            color: #a8a8b3;

            font-size: 0.9rem;
        }


        /*
         * Project grid
         */

        .projects-grid {
            display: grid;

            grid-template-columns:
                repeat(
                    auto-fill,
                    minmax(220px, 1fr)
                );

            gap: 14px;
        }


        .project-card {
            background: #121214;

            border: 1px solid #29292e;

            border-radius: 10px;

            padding: 18px;

            transition:
                border-color 0.2s,
                transform 0.15s;
        }


        .project-card:hover {
            border-color: #8257e5;

            transform: translateY(-2px);
        }


        .project-icon {
            width: 42px;
            height: 42px;

            display: flex;

            align-items: center;
            justify-content: center;

            border-radius: 9px;

            background: #29292e;

            color: #8257e5;

            font-size: 1.2rem;

            margin-bottom: 14px;
        }


        .project-name {
            font-size: 1rem;

            font-weight: 600;

            color: #e1e1e6;

            word-break: break-word;

            margin-bottom: 5px;
        }


        .project-path {
            color: #737380;

            font-size: 0.78rem;

            margin-bottom: 16px;

            word-break: break-all;
        }


        .project-actions {
            display: flex;

            gap: 8px;
        }


        .project-actions .private-btn {
            flex: 1;
        }


        /*
         * Empty state
         */

        .empty {
            text-align: center;

            padding: 35px 20px;

            color: #737380;

            border: 1px dashed #29292e;

            border-radius: 9px;
        }


        /*
         * Create project form
         */

         .create-form {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.create-form .project-input {
    width: 100%;
}

.create-form .private-btn {
    width: 100%;
}


        .project-input {
            flex: 1;

            min-width: 0;

            background: #121214;

            color: #e1e1e6;

            border: 1px solid #29292e;

            border-radius: 8px;

            padding: 11px 13px;

            font-size: 0.9rem;

            outline: none;
        }


        .project-input::placeholder {
            color: #737380;
        }


        .project-input:focus {
            border-color: #8257e5;
        }


        /*
         * Mobile
         */

        @media (max-width: 700px) {

            .private-container {
                padding: 25px 16px 40px;
            }


            .private-header {
                flex-direction: column;

                align-items: flex-start;
            }


            .header-buttons {
                width: 100%;
            }


            .header-buttons .private-btn {
                flex: 1;
            }


            .create-form {
                flex-direction: column;
            }


            .create-form .private-btn {
                width: 100%;
            }

        }

    </style>

</head>

<body>

<div class="private-container">


    <!-- Header -->

    <header class="private-header">

        <div>

            <h1 class="private-title">
                Private Pages
            </h1>

            <p class="private-subtitle">
                Private projects and personal websites
            </p>

        </div>


        <div class="header-buttons">

            <a
                href="../manage.php"
                class="private-btn"
            >
                ← Dashboard
            </a>

            <a
                href="edit.php"
                class="private-btn private-btn-primary"
            >
                Edit Projects
            </a>

        </div>

    </header>


    <!-- Messages -->

    <?php if ($message): ?>

        <div class="message">

            <?= htmlspecialchars($message) ?>

        </div>

    <?php endif; ?>


    <?php if ($error): ?>

        <div class="message error">

            <?= htmlspecialchars($error) ?>

        </div>

    <?php endif; ?>


    <!-- Projects -->

    <section class="private-panel">

        <h2 class="panel-heading">
             Available Projects
        </h2>

        <p class="panel-description">
            If your user account is not marked as admin there may be some options hidden.
        </p>


        <?php if (empty($projects)): ?>

            <div class="empty">

                No private projects yet.

            </div>

        <?php else: ?>

            <div class="projects-grid">

                <?php foreach ($projects as $project): ?>

                    <article class="project-card">

                        <div class="project-icon">
                            ▣
                        </div>


                        <div class="project-name">

                            <?= htmlspecialchars($project) ?>

                        </div>


                        <div class="project-path">

                            /other/<?= htmlspecialchars($project) ?>/

                        </div>


                        <div class="project-actions">

                            <a
                                href="<?= rawurlencode($project) ?>/"
                                class="private-btn private-btn-primary"
                            >
                                Open
                            </a>

                            <a
                                href="edit.php?project=<?= rawurlencode($project) ?>"
                                class="private-btn"
                            >
                                Edit
                            </a>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>


    <?php if (!empty($_SESSION['is_admin'])): ?>

    <!-- Create Project -->

    <section class="private-panel">

        <h2 class="panel-heading">
            Add Another Project
        </h2>

        <p class="panel-description">
            Create a new project folder with a starter index.php.
        </p>


        <form
            method="POST"
            class="create-form"
        >

            <input
                type="text"
                name="project_name"
                class="project-input"
                placeholder="Project name"
                pattern="[a-zA-Z0-9_-]+"
                maxlength="50"
                required
            >


            <button
                type="submit"
                name="create_project"
                class="private-btn private-btn-primary"
            >
                Create Project
            </button>

        </form>

    </section>

    <?php endif; ?>


</div>

</body>

</html>
```

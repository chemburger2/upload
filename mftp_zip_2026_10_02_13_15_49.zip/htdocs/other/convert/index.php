<?php
// index.php - Multiuse CBR Converter (Client-side MOBI & EPUB to CBR)
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiuse CBR Converter</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 100%;
            max-width: 680px;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            padding: 30px;
        }
        h1 {
            font-size: 1.8rem;
            color: #111;
            margin-bottom: 6px;
        }
        .subtitle {
            font-size: 0.95rem;
            color: #666;
            margin-bottom: 24px;
        }
        .card {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .file-input-wrapper {
            border: 2px dashed #ccc;
            border-radius: 6px;
            padding: 24px;
            text-align: center;
            background: #fafafa;
            cursor: pointer;
            transition: border-color 0.2s ease;
        }
        .file-input-wrapper:hover {
            border-color: #0066cc;
        }
        input[type="file"] {
            width: 100%;
            cursor: pointer;
        }
        .file-info {
            background: #eef4fc;
            border: 1px solid #cce0ff;
            border-radius: 6px;
            padding: 12px 16px;
            font-size: 0.9rem;
        }
        .file-info p {
            margin: 4px 0;
        }
        .button-group {
            display: flex;
            gap: 12px;
        }
        .btn {
            flex: 1;
            padding: 10px 16px;
            font-size: 0.95rem;
            font-weight: 600;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .btn-primary {
            background-color: #0066cc;
            color: #ffffff;
        }
        .btn-primary:hover:not(:disabled) {
            background-color: #0052a3;
        }
        .btn-primary:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }
        .btn-secondary {
            background-color: #e0e0e0;
            color: #333333;
        }
        .btn-secondary:hover {
            background-color: #d0d0d0;
        }
        .status-area {
            background: #1e1e1e;
            color: #00ff66;
            font-family: "Courier New", Courier, monospace;
            font-size: 0.85rem;
            padding: 14px;
            border-radius: 6px;
            min-height: 120px;
            max-height: 200px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-break: break-all;
        }
        .notice {
            font-size: 0.8rem;
            color: #777;
            text-align: center;
            margin-top: 8px;
            border-top: 1px solid #eee;
            padding-top: 12px;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Multiuse CBR Converter</h1>
    <p class="subtitle">Convert supported ebook formats into CBR archives entirely in your browser.</p>

    <div class="card">
        <div class="file-input-wrapper">
            <input type="file" id="fileInput" accept=".mobi,.epub">
        </div>

        <div id="fileInfo" class="file-info hidden">
            <p><strong>Selected File:</strong> <span id="fileName">None</span></p>
            <p><strong>Size:</strong> <span id="fileSize">0 KB</span></p>
        </div>

        <div class="button-group">
            <button id="convertBtn" class="btn btn-primary" disabled>Convert to CBR</button>
            <button id="clearBtn" class="btn btn-secondary">Clear</button>
        </div>

        <div id="status" class="status-area">Ready. Select a .mobi or .epub file to begin.</div>

        <div class="notice">
            Notice: Files are processed entirely inside your browser. No files are uploaded to any server.
        </div>
    </div>
</div>

<script>
// --- UTILITIES & ZIP CREATOR ---

const Crc32Table = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    Crc32Table[i] = c;
}

function calculateCRC32(uint8Array) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < uint8Array.length; i++) {
        crc = (crc >>> 8) ^ Crc32Table[(crc ^ uint8Array[i]) & 0xFF];
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
}

function createZipArchive(files) {
    const localHeaders = [];
    const centralDirectoryEntries = [];
    let offset = 0;

    const encoder = new TextEncoder();

    for (const file of files) {
        const fileNameBytes = encoder.encode(file.name);
        const crc = calculateCRC32(file.data);
        const size = file.data.length;

        // Local File Header
        const localHeader = new Uint8Array(30 + fileNameBytes.length);
        const dv = new DataView(localHeader.buffer);
        dv.setUint32(0, 0x04034b50, true); // Local header signature
        dv.setUint16(4, 20, true);         // Version needed
        dv.setUint16(6, 0, true);          // Flags
        dv.setUint16(8, 0, true);          // Compression method (0 = Store)
        dv.setUint16(10, 0, true);         // Mod time
        dv.setUint16(12, 0, true);         // Mod date
        dv.setUint32(14, crc, true);       // CRC32
        dv.setUint32(18, size, true);      // Compressed size
        dv.setUint32(22, size, true);      // Uncompressed size
        dv.setUint16(26, fileNameBytes.length, true);
        dv.setUint16(28, 0, true);         // Extra field length
        localHeader.set(fileNameBytes, 30);

        localHeaders.push({ header: localHeader, data: file.data, offset: offset });

        // Central Directory Entry
        const cdEntry = new Uint8Array(46 + fileNameBytes.length);
        const cdDv = new DataView(cdEntry.buffer);
        cdDv.setUint32(0, 0x02014b50, true); // Central directory signature
        cdDv.setUint16(4, 20, true);          // Version made by
        cdDv.setUint16(6, 20, true);          // Version needed
        cdDv.setUint16(8, 0, true);           // Flags
        cdDv.setUint16(10, 0, true);          // Compression method (0 = Store)
        cdDv.setUint16(12, 0, true);          // Mod time
        cdDv.setUint16(14, 0, true);          // Mod date
        cdDv.setUint32(16, crc, true);        // CRC32
        cdDv.setUint32(20, size, true);       // Compressed size
        cdDv.setUint32(24, size, true);       // Uncompressed size
        cdDv.setUint16(28, fileNameBytes.length, true);
        cdDv.setUint16(30, 0, true);          // Extra field length
        cdDv.setUint16(32, 0, true);          // Comment length
        cdDv.setUint16(34, 0, true);          // Disk start
        cdDv.setUint16(36, 0, true);          // Internal attributes
        cdDv.setUint32(38, 0, true);          // External attributes
        cdDv.setUint32(42, offset, true);     // Local header offset
        cdEntry.set(fileNameBytes, 46);

        centralDirectoryEntries.push(cdEntry);

        offset += localHeader.length + size;
    }

    const cdOffset = offset;
    let cdSize = 0;
    for (const cdEntry of centralDirectoryEntries) {
        cdSize += cdEntry.length;
    }

    // End of Central Directory Record (EOCD)
    const eocd = new Uint8Array(22);
    const eocdDv = new DataView(eocd.buffer);
    eocdDv.setUint32(0, 0x06054b50, true); // EOCD signature
    eocdDv.setUint16(4, 0, true);          // Disk number
    eocdDv.setUint16(6, 0, true);          // Start disk
    eocdDv.setUint16(8, files.length, true);  // Disk entries
    eocdDv.setUint16(10, files.length, true); // Total entries
    eocdDv.setUint32(12, cdSize, true);    // CD size
    eocdDv.setUint32(16, cdOffset, true);  // CD offset
    eocdDv.setUint16(20, 0, true);         // Comment length

    // Assemble full ZIP
    const totalLength = offset + cdSize + eocd.length;
    const zipBuffer = new Uint8Array(totalLength);
    let currentPos = 0;

    for (const item of localHeaders) {
        zipBuffer.set(item.header, currentPos);
        currentPos += item.header.length;
        zipBuffer.set(item.data, currentPos);
        currentPos += item.data.length;
    }

    for (const cdEntry of centralDirectoryEntries) {
        zipBuffer.set(cdEntry, currentPos);
        currentPos += cdEntry.length;
    }

    zipBuffer.set(eocd, currentPos);
    return zipBuffer;
}

function detectImageExtension(data) {
    if (!data || data.length < 4) return 'jpg';
    if (data[0] === 0xFF && data[1] === 0xD8 && data[2] === 0xFF) return 'jpg';
    if (data[0] === 0x89 && data[1] === 0x50 && data[2] === 0x4E && data[3] === 0x47) return 'png';
    if (data[0] === 0x47 && data[1] === 0x49 && data[2] === 0x46) return 'gif';
    if (data[0] === 0x42 && data[1] === 0x4D) return 'bmp';
    if (data[0] === 0x52 && data[1] === 0x49 && data[2] === 0x46 && data[3] === 0x46) return 'webp';
    return 'jpg';
}

// --- ZIP READER (For EPUB) ---

class ZipReader {
    constructor(arrayBuffer) {
        this.buffer = new Uint8Array(arrayBuffer);
        this.dv = new DataView(arrayBuffer);
        this.entries = new Map();
    }

    async parse() {
        const len = this.buffer.length;
        let eocdOffset = -1;

        for (let i = len - 22; i >= Math.max(0, len - 65557); i--) {
            if (this.dv.getUint32(i, true) === 0x06054b50) {
                eocdOffset = i;
                break;
            }
        }

        if (eocdOffset === -1) {
            throw new Error("Invalid ZIP format or corrupt EPUB file.");
        }

        const cdEntriesCount = this.dv.getUint16(eocdOffset + 10, true);
        const cdOffset = this.dv.getUint32(eocdOffset + 16, true);

        let currCdOffset = cdOffset;
        const decoder = new TextDecoder("utf-8");

        for (let i = 0; i < cdEntriesCount; i++) {
            if (this.dv.getUint32(currCdOffset, true) !== 0x02014b50) break;

            const compression = this.dv.getUint16(currCdOffset + 10, true);
            const compressedSize = this.dv.getUint32(currCdOffset + 20, true);
            const uncompressedSize = this.dv.getUint32(currCdOffset + 24, true);
            const fnLen = this.dv.getUint16(currCdOffset + 28, true);
            const extraLen = this.dv.getUint16(currCdOffset + 30, true);
            const commentLen = this.dv.getUint16(currCdOffset + 32, true);
            const localHeaderOffset = this.dv.getUint32(currCdOffset + 42, true);

            const fnBytes = this.buffer.subarray(currCdOffset + 46, currCdOffset + 46 + fnLen);
            const filename = decoder.decode(fnBytes);

            this.entries.set(filename, {
                filename,
                compression,
                compressedSize,
                uncompressedSize,
                localHeaderOffset
            });

            currCdOffset += 46 + fnLen + extraLen + commentLen;
        }
    }

    async getFileData(filename) {
        const entry = this.entries.get(filename);
        if (!entry) return null;

        const lhOffset = entry.localHeaderOffset;
        if (this.dv.getUint32(lhOffset, true) !== 0x04034b50) {
            throw new Error(`Corrupt entry local header for ${filename}`);
        }

        const fnLen = this.dv.getUint16(lhOffset + 26, true);
        const extraLen = this.dv.getUint16(lhOffset + 28, true);
        const dataOffset = lhOffset + 30 + fnLen + extraLen;

        const rawData = this.buffer.subarray(dataOffset, dataOffset + entry.compressedSize);

        if (entry.compression === 0) {
            return rawData;
        } else if (entry.compression === 8) {
            if (typeof DecompressionStream === "undefined") {
                throw new Error("Your browser does not support DecompressionStream('deflate-raw').");
            }
            const ds = new DecompressionStream('deflate-raw');
            const writer = ds.writable.getWriter();
            writer.write(rawData);
            writer.close();
            const response = new Response(ds.readable);
            const decompressedBuffer = await response.arrayBuffer();
            return new Uint8Array(decompressedBuffer);
        } else {
            throw new Error(`Unsupported compression method (${entry.compression}) in EPUB ZIP.`);
        }
    }

    async getFileText(filename) {
        const data = await this.getFileData(filename);
        if (!data) return null;
        return new TextDecoder("utf-8").decode(data);
    }
}

// --- MOBI CONVERTER ---

function decompressPalmDOC(data) {
    const out = [];
    let i = 0;
    while (i < data.length) {
        const c = data[i++];
        if (c >= 1 && c <= 8) {
            for (let k = 0; k < c && i < data.length; k++) {
                out.push(data[i++]);
            }
        } else if (c <= 0x7F) {
            out.push(c);
        } else if (c >= 0xC0) {
            out.push(0x20);
            out.push(c ^ 0x20);
        } else {
            if (i >= data.length) break;
            const c2 = data[i++];
            const dist = ((c & 0x3F) << 5) | (c2 >> 3);
            const len = (c2 & 0x07) + 3;
            for (let k = 0; k < len; k++) {
                if (out.length >= dist) {
                    out.push(out[out.length - dist]);
                }
            }
        }
    }
    return new Uint8Array(out);
}

async function convertMobiToCbr(arrayBuffer, log) {
    log("Parsing PalmDB structure...");
    const dv = new DataView(arrayBuffer);
    const numRecords = dv.getUint16(76, false);
    const recordOffsets = [];

    for (let i = 0; i < numRecords; i++) {
        recordOffsets.push(dv.getUint32(78 + i * 8, false));
    }

    log(`Found ${numRecords} PalmDB records.`);

    // Record 0 Header Parsing
    const rec0Start = recordOffsets[0];
    const compression = dv.getUint16(rec0Start, false);
    const textRecordCount = dv.getUint16(rec0Start + 8, false);

    let firstImageIndex = 0;
    if (rec0Start + 112 <= arrayBuffer.byteLength) {
        firstImageIndex = dv.getUint32(rec0Start + 108, false);
    }

    log(`Compression: ${compression === 2 ? "PalmDOC" : "None/Other"}, Text Records: ${textRecordCount}`);

    // Read and decompress text records
    let fullText = "";
    const textDecoder = new TextDecoder("utf-8");

    for (let i = 1; i <= textRecordCount && i < numRecords; i++) {
        const start = recordOffsets[i];
        const end = (i + 1 < numRecords) ? recordOffsets[i + 1] : arrayBuffer.byteLength;
        const recData = new Uint8Array(arrayBuffer, start, end - start);

        let decompressed;
        if (compression === 2) {
            decompressed = decompressPalmDOC(recData);
        } else {
            decompressed = recData;
        }
        fullText += textDecoder.decode(decompressed);
    }

    // Extract image sequence references from HTML content
    const imgRecIndexes = [];
    const imgRegex = /<img[^>]+(?:recindex|kindle:embed)=["']?(\d+)["']?[^>]*>/gi;
    let match;
    while ((match = imgRegex.exec(fullText)) !== null) {
        const recIdx = parseInt(match[1], 10);
        if (!isNaN(recIdx) && !imgRecIndexes.includes(recIdx)) {
            imgRecIndexes.push(recIdx);
        }
    }

    log(`Discovered ${imgRecIndexes.length} image reference(s) in HTML.`);

    const extractedFiles = [];

    if (imgRecIndexes.length > 0 && firstImageIndex > 0) {
        for (let idx = 0; idx < imgRecIndexes.length; idx++) {
            const relIdx = imgRecIndexes[idx];
            const targetRec = firstImageIndex + relIdx - 1;
            if (targetRec < numRecords) {
                const start = recordOffsets[targetRec];
                const end = (targetRec + 1 < numRecords) ? recordOffsets[targetRec + 1] : arrayBuffer.byteLength;
                const imgData = new Uint8Array(arrayBuffer, start, end - start);
                const ext = detectImageExtension(imgData);
                const filename = `page-${String(idx + 1).padStart(5, '0')}.${ext}`;
                extractedFiles.push({ name: filename, data: imgData });
            }
        }
    } else {
        log("Falling back to sequential image record extraction...");
        let imgSeq = 1;
        const startSearch = firstImageIndex > 0 ? firstImageIndex : textRecordCount + 1;
        for (let i = startSearch; i < numRecords; i++) {
            const start = recordOffsets[i];
            const end = (i + 1 < numRecords) ? recordOffsets[i + 1] : arrayBuffer.byteLength;
            const imgData = new Uint8Array(arrayBuffer, start, end - start);
            const ext = detectImageExtension(imgData);

            if (ext !== 'jpg' || (imgData[0] === 0xFF && imgData[1] === 0xD8)) {
                const filename = `page-${String(imgSeq).padStart(5, '0')}.${ext}`;
                extractedFiles.push({ name: filename, data: imgData });
                imgSeq++;
            }
        }
    }

    if (extractedFiles.length === 0) {
        throw new Error("No images found in MOBI file.");
    }

    log(`Successfully processed ${extractedFiles.length} page image(s). Packaging CBR...`);
    return createZipArchive(extractedFiles);
}

// --- EPUB CONVERTER ---

function resolvePath(basePath, relativePath) {
    const stack = basePath.split('/');
    stack.pop(); // Drop filename
    const parts = relativePath.split('/');
    for (const part of parts) {
        if (part === '.' || part === '') continue;
        if (part === '..') {
            if (stack.length > 0) stack.pop();
        } else {
            stack.push(part);
        }
    }
    return stack.join('/');
}

async function convertEpubToCbr(arrayBuffer, log) {
    log("Reading EPUB ZIP structure...");
    const zip = new ZipReader(arrayBuffer);
    await zip.parse();

    log("Locating META-INF/container.xml...");
    const containerText = await zip.getFileText("META-INF/container.xml");
    if (!containerText) {
        throw new Error("Invalid EPUB: META-INF/container.xml missing.");
    }

    const parser = new DOMParser();
    const containerDoc = parser.parseFromString(containerText, "text/xml");
    const rootfileNode = containerDoc.querySelector("rootfile");
    if (!rootfileNode) {
        throw new Error("Invalid EPUB: Could not locate OPF rootfile.");
    }

    const opfPath = rootfileNode.getAttribute("full-path");
    log(`Found OPF document path: ${opfPath}`);

    const opfText = await zip.getFileText(opfPath);
    if (!opfText) {
        throw new Error(`Invalid EPUB: Could not read OPF file at ${opfPath}`);
    }

    const opfDoc = parser.parseFromString(opfText, "text/xml");

    // Manifest map: id -> resolved path
    const manifest = new Map();
    const itemNodes = opfDoc.querySelectorAll("manifest > item");
    itemNodes.forEach(item => {
        const id = item.getAttribute("id");
        const href = item.getAttribute("href");
        if (id && href) {
            const resolved = resolvePath(opfPath, decodeURIComponent(href));
            manifest.set(id, resolved);
        }
    });

    // Spine reading order
    const spineNodes = opfDoc.querySelectorAll("spine > itemref");
    const orderedHtmlPaths = [];
    spineNodes.forEach(itemref => {
        const idref = itemref.getAttribute("idref");
        if (manifest.has(idref)) {
            orderedHtmlPaths.push(manifest.get(idref));
        }
    });

    log(`Found ${orderedHtmlPaths.length} document entry/entries in spine order.`);

    const orderedImagePaths = [];
    const supportedExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];

    for (const htmlPath of orderedHtmlPaths) {
        const htmlText = await zip.getFileText(htmlPath);
        if (!htmlText) continue;

        const doc = parser.parseFromString(htmlText, "text/html");

        // Standard <img> tags
        const imgTags = doc.querySelectorAll("img");
        imgTags.forEach(img => {
            const src = img.getAttribute("src");
            if (src) {
                const resolved = resolvePath(htmlPath, decodeURIComponent(src));
                if (!orderedImagePaths.includes(resolved)) {
                    orderedImagePaths.push(resolved);
                }
            }
        });

        // SVG <image> tags
        const svgImages = doc.querySelectorAll("image");
        svgImages.forEach(img => {
            const src = img.getAttribute("href") || img.getAttribute("xlink:href");
            if (src) {
                const resolved = resolvePath(htmlPath, decodeURIComponent(src));
                if (!orderedImagePaths.includes(resolved)) {
                    orderedImagePaths.push(resolved);
                }
            }
        });
    }

    // Fallback: If no images referenced in spine XHTML files, search ZIP manifest
    let finalImagePaths = orderedImagePaths.filter(path => {
        const lower = path.toLowerCase();
        return supportedExts.some(ext => lower.endsWith(ext));
    });

    if (finalImagePaths.length === 0) {
        log("No image references found in spine. Searching ZIP directory for images...");
        for (const [path] of zip.entries) {
            const lower = path.toLowerCase();
            if (supportedExts.some(ext => lower.endsWith(ext))) {
                finalImagePaths.push(path);
            }
        }
    }

    if (finalImagePaths.length === 0) {
        throw new Error("This EPUB appears to be text-based with no image pages.");
    }

    log(`Extracting ${finalImagePaths.length} image file(s) in correct sequence...`);

    const extractedFiles = [];
    let pageCount = 1;

    for (const imgPath of finalImagePaths) {
        const imgBytes = await zip.getFileData(imgPath);
        if (!imgBytes) continue;

        const ext = detectImageExtension(imgBytes);
        const filename = `page-${String(pageCount).padStart(5, '0')}.${ext}`;
        extractedFiles.push({ name: filename, data: imgBytes });
        pageCount++;
    }

    if (extractedFiles.length === 0) {
        throw new Error("This EPUB appears to be text-based with no image pages.");
    }

    log(`Extracted ${extractedFiles.length} page(s). Building CBR archive...`);
    return createZipArchive(extractedFiles);
}

// --- UI LOGIC ---

const fileInput = document.getElementById("fileInput");
const fileInfo = document.getElementById("fileInfo");
const fileName = document.getElementById("fileName");
const fileSize = document.getElementById("fileSize");
const convertBtn = document.getElementById("convertBtn");
const clearBtn = document.getElementById("clearBtn");
const status = document.getElementById("status");

let selectedFile = null;

function logStatus(msg) {
    status.innerText += "\n" + msg;
    status.scrollTop = status.scrollHeight;
}

function clearAll() {
    fileInput.value = "";
    selectedFile = null;
    fileInfo.classList.add("hidden");
    convertBtn.disabled = true;
    status.innerText = "Ready. Select a .mobi or .epub file to begin.";
}

fileInput.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
        selectedFile = e.target.files[0];
        fileName.innerText = selectedFile.name;
        fileSize.innerText = (selectedFile.size / 1024).toFixed(2) + " KB";
        fileInfo.classList.remove("hidden");
        convertBtn.disabled = false;
        status.innerText = `Loaded file: ${selectedFile.name}`;
    } else {
        clearAll();
    }
});

clearBtn.addEventListener("click", clearAll);

convertBtn.addEventListener("click", async () => {
    if (!selectedFile) return;

    convertBtn.disabled = true;
    clearBtn.disabled = true;
    status.innerText = "Starting conversion...";

    try {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const ext = selectedFile.name.split('.').pop().toLowerCase();
        let cbrBuffer;

        if (ext === 'mobi') {
            logStatus("Format detected: MOBI");
            cbrBuffer = await convertMobiToCbr(arrayBuffer, logStatus);
        } else if (ext === 'epub') {
            logStatus("Format detected: EPUB");
            cbrBuffer = await convertEpubToCbr(arrayBuffer, logStatus);
        } else {
            throw new Error("Unsupported file extension.");
        }

        logStatus("Conversion complete. Starting download...");

        const blob = new Blob([cbrBuffer], { type: "application/x-cbr" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        const baseName = selectedFile.name.substring(0, selectedFile.name.lastIndexOf('.')) || selectedFile.name;
        a.href = url;
        a.download = `${baseName}.cbr`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        logStatus("Download initiated successfully.");
    } catch (err) {
        logStatus(`ERROR: ${err.message}`);
    } finally {
        convertBtn.disabled = false;
        clearBtn.disabled = false;
    }
});
</script>

</body>
</html>
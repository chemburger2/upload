<?php
declare(strict_types=1);

/*
 * Central request gate for /other/.
 *
 * Apache rewrites requests here before a project file is served.
 * This means direct URLs, nested PHP files, API endpoints, JS, CSS,
 * images, audio, video, etc. all receive the same permission check.
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../project_access.php';

if (empty($_SESSION['user_id'])) {
    header('Location: /logon.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$special = isset($_GET['special']) ? (string)$_GET['special'] : '';
$project = isset($_GET['project']) ? (string)$_GET['project'] : '';
$path = isset($_GET['path']) ? (string)$_GET['path'] : '';

$project = trim(str_replace('\\', '/', $project), '/');
$path = str_replace('\\', '/', $path);
$path = ltrim($path, '/');

/* Never allow traversal or NUL bytes. */
if (
    strpos($project, "\0") !== false ||
    strpos($path, "\0") !== false ||
    strpos($project, '..') !== false ||
    strpos($path, '..') !== false
) {
    http_response_code(404);
    exit('Not found.');
}

/*
 * Special system pages.
 */
if ($special === 'root') {
    if (!userHasAnyProjectAccess($pdo, $userId)) {
        http_response_code(403);
        exit('Access denied.');
    }

    header('Location: /other/private.php');
    exit;
}

if ($special === 'edit') {
    if (!isAdminUser($pdo, $userId)) {
        http_response_code(403);
        exit('Access denied.');
    }

    require __DIR__ . '/edit.php';
    exit;
}

if ($special === 'private') {
    if (!userHasAnyProjectAccess($pdo, $userId)) {
        http_response_code(403);
        exit('Access denied.');
    }

    require __DIR__ . '/private.php';
    exit;
}

/*
 * A direct request to access.php without one of the internally supplied
 * targets should not expose the gate or act as an arbitrary file server.
 */
if ($project === '') {
    http_response_code(404);
    exit('Not found.');
}

/*
 * browser/ is not a normal project. It is an administrator-only tool.
 */
if ($project === 'browser') {
    if (!isAdminUser($pdo, $userId)) {
        http_response_code(403);
        exit('Access denied.');
    }
} else {
    if (!preg_match('/^[A-Za-z0-9_-]+$/', $project)) {
        http_response_code(404);
        exit('Not found.');
    }

    requireProjectAccess($pdo, $project);
}

$projectDir = realpath(
    __DIR__ . DIRECTORY_SEPARATOR . $project
);

if ($projectDir === false || !is_dir($projectDir)) {
    http_response_code(404);
    exit('Not found.');
}

/*
 * Empty path means the project's index.php.
 * A path ending in / means it is a directory request, so try index.php.
 */
if ($path === '') {
    $relative = 'index.php';
} else {
    $relative = $path;
}

$targetCandidate = $projectDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
$target = realpath($targetCandidate);

$projectPrefix = rtrim($projectDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

if (
    $target === false ||
    ($target !== $projectDir && strpos($target, $projectPrefix) !== 0)
) {
    http_response_code(404);
    exit('Not found.');
}

/* Directory requests get their own index.php. */
if (is_dir($target)) {
    $index = realpath(
        $target . DIRECTORY_SEPARATOR . 'index.php'
    );

    if (
        $index === false ||
        strpos($index, rtrim($target, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0 ||
        !is_file($index)
    ) {
        http_response_code(404);
        exit('Not found.');
    }

    $target = $index;
}

if (!is_file($target)) {
    http_response_code(404);
    exit('Not found.');
}

$extension = strtolower(pathinfo($target, PATHINFO_EXTENSION));

/*
 * PHP files are included instead of being sent as source code.
 */
if ($extension === 'php') {
    chdir(dirname($target));
    require $target;
    exit;
}

/*
 * Static files are served from here so Apache never serves them directly
 * without the project permission check.
 */
$mimeMap = [
    'css'   => 'text/css; charset=UTF-8',
    'js'    => 'application/javascript; charset=UTF-8',
    'mjs'   => 'application/javascript; charset=UTF-8',
    'json'  => 'application/json; charset=UTF-8',
    'map'   => 'application/json; charset=UTF-8',
    'html'  => 'text/html; charset=UTF-8',
    'htm'   => 'text/html; charset=UTF-8',
    'svg'   => 'image/svg+xml',
    'txt'   => 'text/plain; charset=UTF-8',
    'xml'   => 'application/xml; charset=UTF-8',
    'csv'   => 'text/csv; charset=UTF-8',
    'png'   => 'image/png',
    'jpg'   => 'image/jpeg',
    'jpeg'  => 'image/jpeg',
    'gif'   => 'image/gif',
    'webp'  => 'image/webp',
    'avif'  => 'image/avif',
    'ico'   => 'image/x-icon',
    'bmp'   => 'image/bmp',
    'mp3'   => 'audio/mpeg',
    'wav'   => 'audio/wav',
    'ogg'   => 'audio/ogg',
    'oga'   => 'audio/ogg',
    'm4a'   => 'audio/mp4',
    'aac'   => 'audio/aac',
    'flac'  => 'audio/flac',
    'mp4'   => 'video/mp4',
    'webm'  => 'video/webm',
    'mov'   => 'video/quicktime',
    'pdf'   => 'application/pdf',
    'zip'   => 'application/zip',
    'woff'  => 'font/woff',
    'woff2' => 'font/woff2',
    'ttf'   => 'font/ttf',
    'otf'   => 'font/otf'
];

$contentType = isset($mimeMap[$extension])
    ? $mimeMap[$extension]
    : 'application/octet-stream';

$size = filesize($target);

header('Content-Type: ' . $contentType);
header('Cache-Control: private, max-age=0, must-revalidate');
header('X-Content-Type-Options: nosniff');

if ($size === false) {
    http_response_code(500);
    exit('Could not read file.');
}

/*
 * Support byte ranges for audio/video and other large files.
 */
$start = 0;
$end = $size - 1;

if (
    isset($_SERVER['HTTP_RANGE']) &&
    preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $matches)
) {
    if ($matches[1] !== '') {
        $start = (int)$matches[1];
    }

    if ($matches[2] !== '') {
        $end = (int)$matches[2];
    }

    if ($matches[1] === '' && $matches[2] !== '') {
        $suffixLength = (int)$matches[2];
        $start = max(0, $size - $suffixLength);
        $end = $size - 1;
    }

    if ($start > $end || $start >= $size) {
        header('Content-Range: bytes */' . $size);
        http_response_code(416);
        exit;
    }

    $end = min($end, $size - 1);
    $length = $end - $start + 1;

    http_response_code(206);
    header('Accept-Ranges: bytes');
    header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    header('Content-Length: ' . $length);
} else {
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . $size);
    $length = $size;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD') {
    exit;
}

$handle = @fopen($target, 'rb');

if ($handle === false) {
    http_response_code(500);
    exit('Could not read file.');
}

if ($start > 0) {
    fseek($handle, $start);
}

$remaining = $length;
$chunkSize = 1024 * 1024;

while ($remaining > 0 && !feof($handle)) {
    $readLength = min($chunkSize, $remaining);
    $data = fread($handle, $readLength);

    if ($data === false || $data === '') {
        break;
    }

    echo $data;
    $remaining -= strlen($data);

    if (function_exists('flush')) {
        flush();
    }
}

fclose($handle);
exit;

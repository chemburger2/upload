<?php
session_start();

/*
 * YouTube Video / Channel Browser
 *
 * Features:
 * - No YouTube API key required
 * - Channel IDs, @handles, and channel URLs load a channel
 * - Plain text searches perform a YouTube-style video search
 * - Uses Invidious for channel/video/search data
 * - 20 videos displayed at a time
 * - Load More continues through the results
 * - YouTube-hosted thumbnails
 * - Direct YouTube video URLs
 */

const VIDEOS_PER_PAGE = 20;

const FALLBACK_INSTANCES = [
    'https://inv.nadeko.net',
    'https://invidious.nerdvpn.de',
    'https://yt.chocolatemoo53.com',
    'https://invidious.tiekoetter.com',
    'https://invidious.f5.si'
];


/* -------------------------------------------------------------
 * HTTP helpers
 * ------------------------------------------------------------- */

function httpGet($url, $timeout = 12) {
    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => 'Mozilla/5.0 YouTube Channel Browser',
        CURLOPT_HTTPHEADER => [
            'Accept: application/json,text/plain,*/*'
        ]
    ]);

    $body = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($body === false || $httpCode < 200 || $httpCode >= 300) {
        return false;
    }

    return $body;
}


function getJson($url, $timeout = 12) {
    $body = httpGet($url, $timeout);

    if ($body === false) {
        return false;
    }

    $data = json_decode($body, true);

    if (!is_array($data)) {
        return false;
    }

    return $data;
}


/* -------------------------------------------------------------
 * Invidious instances
 * ------------------------------------------------------------- */

function getInvidiousInstances() {
    /*
     * Use the known working instances first.
     *
     * This avoids making a large discovery request every time
     * the page is loaded.
     */
    return FALLBACK_INSTANCES;
}


/* -------------------------------------------------------------
 * YouTube input parsing
 * ------------------------------------------------------------- */

function cleanChannelInput($input) {
    return trim($input);
}


function isChannelId($input) {
    return preg_match('/^UC[a-zA-Z0-9_-]{20,}$/', $input);
}


function extractChannelIdFromUrl($input) {
    $parts = parse_url($input);

    if (!$parts || empty($parts['host'])) {
        return false;
    }

    $host = strtolower($parts['host']);

    if (
        $host !== 'youtube.com' &&
        $host !== 'www.youtube.com' &&
        $host !== 'm.youtube.com'
    ) {
        return false;
    }

    $path = isset($parts['path'])
        ? trim($parts['path'], '/')
        : '';

    if (preg_match(
        '#^channel/(UC[a-zA-Z0-9_-]{20,})$#',
        $path,
        $matches
    )) {
        return $matches[1];
    }

    return false;
}


function extractHandle($input) {
    $input = trim($input);

    if (preg_match(
        '/^@([a-zA-Z0-9._-]+)$/',
        $input,
        $matches
    )) {
        return '@' . $matches[1];
    }

    $parts = parse_url($input);

    if (!$parts || empty($parts['host'])) {
        return false;
    }

    $host = strtolower($parts['host']);

    if (
        $host !== 'youtube.com' &&
        $host !== 'www.youtube.com' &&
        $host !== 'm.youtube.com'
    ) {
        return false;
    }

    $path = isset($parts['path'])
        ? trim($parts['path'], '/')
        : '';

    if (preg_match(
        '#^@([a-zA-Z0-9._-]+)$#',
        $path,
        $matches
    )) {
        return '@' . $matches[1];
    }

    return false;
}


/* -------------------------------------------------------------
 * Channel resolution
 * ------------------------------------------------------------- */

function resolveChannelWithInstance($instance, $input) {
    $url =
        $instance .
        '/api/v1/resolveurl?url=' .
        rawurlencode($input);

    $data = getJson($url, 8);

    if (!is_array($data)) {
        return false;
    }

    if (!empty($data['ucid'])) {
        return $data['ucid'];
    }

    if (!empty($data['browseId'])) {
        return $data['browseId'];
    }

    if (
        !empty($data['id']) &&
        isChannelId($data['id'])
    ) {
        return $data['id'];
    }

    return false;
}


function searchChannelWithInstance($instance, $query) {
    $url =
        $instance .
        '/api/v1/search?q=' .
        rawurlencode($query) .
        '&type=channel';

    $data = getJson($url, 10);

    if (!is_array($data)) {
        return false;
    }

    foreach ($data as $result) {
        if (!is_array($result)) {
            continue;
        }

        if (
            isset($result['type']) &&
            $result['type'] === 'channel'
        ) {
            if (!empty($result['authorId'])) {
                return $result['authorId'];
            }

            if (!empty($result['browseId'])) {
                return $result['browseId'];
            }

            if (!empty($result['channelId'])) {
                return $result['channelId'];
            }
        }
    }

    return false;
}


function resolveChannel($input, $instances) {
    $input = cleanChannelInput($input);

    /*
     * Already a channel ID.
     */
    if (isChannelId($input)) {
        return [
            'channelId' => $input,
            'instance' => null
        ];
    }

    /*
     * Direct /channel/UC... URL.
     */
    $directId = extractChannelIdFromUrl($input);

    if ($directId !== false) {
        return [
            'channelId' => $directId,
            'instance' => null
        ];
    }

    $handle = extractHandle($input);

    $searchQuery = $handle !== false
        ? $handle
        : $input;

    /*
     * Try the known instances.
     */
    foreach ($instances as $instance) {

        /*
         * First try resolveurl.
         */
        $resolved = resolveChannelWithInstance(
            $instance,
            $input
        );

        if ($resolved !== false) {
            return [
                'channelId' => $resolved,
                'instance' => $instance
            ];
        }

        /*
         * Then try channel search.
         */
        $searched = searchChannelWithInstance(
            $instance,
            $searchQuery
        );

        if ($searched !== false) {
            return [
                'channelId' => $searched,
                'instance' => $instance
            ];
        }

        /*
         * Try the handle without @ as a final search.
         */
        if ($handle !== false) {
            $searched = searchChannelWithInstance(
                $instance,
                ltrim($handle, '@')
            );

            if ($searched !== false) {
                return [
                    'channelId' => $searched,
                    'instance' => $instance
                ];
            }
        }
    }

    return false;
}


/* -------------------------------------------------------------
 * Video retrieval
 * ------------------------------------------------------------- */

function getVideosFromInstance(
    $instance,
    $channelId,
    $continuation = null
) {
    $url =
        $instance .
        '/api/v1/channels/' .
        rawurlencode($channelId) .
        '/videos';

    $params = [];

    if (
        $continuation !== null &&
        $continuation !== ''
    ) {
        $params['continuation'] = $continuation;
    }

    $params['sort_by'] = 'newest';

    $url .= '?' . http_build_query($params);

    $data = getJson($url, 15);

    if (!is_array($data)) {
        return false;
    }

    if (
        !isset($data['videos']) ||
        !is_array($data['videos'])
    ) {
        return false;
    }

    return $data;
}


/* -------------------------------------------------------------
 * YouTube video search
 * ------------------------------------------------------------- */

function getSearchResultsFromInstance(
    $instance,
    $query,
    $page = 1
) {
    $url =
        $instance .
        '/api/v1/search?q=' .
        rawurlencode($query) .
        '&type=video&page=' .
        max(1, (int)$page);

    $data = getJson($url, 15);

    if (!is_array($data)) {
        return false;
    }

    /*
     * The documented Invidious search endpoint returns an array of
     * result objects. Some older/custom instances may wrap results
     * in an object, so accept those forms too.
     */
    if (isset($data['items']) && is_array($data['items'])) {
        $items = $data['items'];
    } elseif (isset($data['results']) && is_array($data['results'])) {
        $items = $data['results'];
    } elseif (isset($data['videos']) && is_array($data['videos'])) {
        $items = $data['videos'];
    } else {
        $items = $data;
    }

    $videos = [];

    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        /*
         * Only keep actual video results. This makes the result list
         * behave like a video-only YouTube search even if an instance
         * ignores the type=video parameter.
         */
        if (
            isset($item['type']) &&
            $item['type'] !== 'video'
        ) {
            continue;
        }

        if (
            empty($item['videoId']) &&
            empty($item['id'])
        ) {
            continue;
        }

        $videos[] = $item;
    }

    return [
        'videos' => $videos
    ];
}


/* -------------------------------------------------------------
 * YouTube thumbnail
 * ------------------------------------------------------------- */

function getYouTubeThumbnail($videoId) {
    if (!$videoId) {
        return '';
    }

    return 'https://i.ytimg.com/vi/' .
        rawurlencode($videoId) .
        '/mqdefault.jpg';
}


/* -------------------------------------------------------------
 * Session state
 * ------------------------------------------------------------- */

function resetBrowserState() {
    unset($_SESSION['yt_browser']);
}


function initializeBrowserState(
    $mode,
    $instance,
    $continuation = null,
    $buffer = [],
    $query = null,
    $channelId = null,
    $searchPage = 1,
    $searchHasMore = false
) {
    $_SESSION['yt_browser'] = [
        'mode' => $mode,
        'query' => $query,
        'channelId' => $channelId,
        'instance' => $instance,
        'continuation' => $continuation,
        'buffer' => $buffer,
        'searchPage' => $searchPage,
        'searchHasMore' => $searchHasMore,
        'totalShown' => 0
    ];
}


function getBrowserState() {
    if (!isset($_SESSION['yt_browser'])) {
        return false;
    }

    return $_SESSION['yt_browser'];
}


/*
 * IMPORTANT:
 *
 * This function performs AT MOST ONE Invidious API request
 * per call.
 *
 * That keeps Load More lightweight and prevents the server
 * from chaining multiple requests together.
 */
function getNextVideos($count = VIDEOS_PER_PAGE) {
    $state = getBrowserState();

    if ($state === false) {
        return [
            'videos' => [],
            'continuation' => null,
            'error' => 'Nothing has been loaded yet.'
        ];
    }

    $videos = [];

    /*
     * First use anything already in the session buffer.
     */
    while (
        count($videos) < $count &&
        !empty($state['buffer'])
    ) {
        $videos[] = array_shift(
            $state['buffer']
        );
    }

    /*
     * Only make ONE network request if we still need videos.
     */
    $shouldRequestMore =
        count($videos) < $count &&
        (
            (
                isset($state['mode']) &&
                $state['mode'] === 'search' &&
                !empty($state['searchHasMore'])
            ) ||
            (
                (!isset($state['mode']) || $state['mode'] !== 'search') &&
                !empty($state['continuation'])
            )
        );

    if ($shouldRequestMore) {
        if (
            isset($state['mode']) &&
            $state['mode'] === 'search'
        ) {
            $nextPage =
                !empty($state['searchPage'])
                    ? ((int)$state['searchPage'] + 1)
                    : 2;

            $data = getSearchResultsFromInstance(
                $state['instance'],
                $state['query'],
                $nextPage
            );
        } else {
            $data = getVideosFromInstance(
                $state['instance'],
                $state['channelId'],
                $state['continuation']
            );
        }

        if ($data === false) {
            $_SESSION['yt_browser'] = $state;

            return [
                'videos' => $videos,
                'continuation' => $state['continuation'],
                'error' =>
                    'The Invidious instance stopped responding.'
            ];
        }

        if (
            isset($state['mode']) &&
            $state['mode'] === 'search'
        ) {
            $state['searchPage'] =
                !empty($state['searchPage'])
                    ? ((int)$state['searchPage'] + 1)
                    : 2;

            $state['searchHasMore'] =
                !empty($data['videos']);
        }

        /*
         * Add this response's videos.
         */
        if (!empty($data['videos'])) {
            foreach ($data['videos'] as $video) {
                if (count($videos) < $count) {
                    $videos[] = $video;
                } else {
                    /*
                     * Keep anything beyond the current page
                     * in the session buffer.
                     */
                    $state['buffer'][] = $video;
                }
            }
        }

        /*
         * Save the continuation for the NEXT Load More.
         */
        $state['continuation'] =
            !empty($data['continuation'])
                ? $data['continuation']
                : null;
    }

    $state['totalShown'] += count($videos);

    $_SESSION['yt_browser'] = $state;

    return [
        'videos' => $videos,
        'continuation' => $state['continuation'],
        'error' => null
    ];
}


/* -------------------------------------------------------------
 * Formatting
 * ------------------------------------------------------------- */

function formatDate($timestamp) {
    if (!$timestamp) {
        return '';
    }

    if (is_numeric($timestamp)) {
        $timestamp = (int)$timestamp;

        if ($timestamp > 20000000000) {
            $timestamp = (int)($timestamp / 1000);
        }

        return date('M j, Y', $timestamp);
    }

    return '';
}


function formatDuration($video) {
    if (!is_array($video)) {
        return '';
    }

    $seconds = null;

    if (isset($video['lengthSeconds']) && is_numeric($video['lengthSeconds'])) {
        $seconds = (int)$video['lengthSeconds'];
    } elseif (isset($video['duration']) && is_numeric($video['duration'])) {
        $seconds = (int)$video['duration'];
    }

    if ($seconds === null || $seconds < 0) {
        return '';
    }

    $hours = intdiv($seconds, 3600);
    $minutes = intdiv($seconds % 3600, 60);
    $remaining = $seconds % 60;

    if ($hours > 0) {
        return $hours . ':' . str_pad((string)$minutes, 2, '0', STR_PAD_LEFT) . ':' . str_pad((string)$remaining, 2, '0', STR_PAD_LEFT);
    }

    return $minutes . ':' . str_pad((string)$remaining, 2, '0', STR_PAD_LEFT);
}


function getVideoId($video) {
    if (!is_array($video)) {
        return '';
    }

    if (!empty($video['videoId'])) {
        return $video['videoId'];
    }

    if (!empty($video['id'])) {
        return $video['id'];
    }

    return '';
}


/* -------------------------------------------------------------
 * Request handling
 * ------------------------------------------------------------- */

$action = isset($_POST['action'])
    ? $_POST['action']
    : '';

$error = '';
$videos = [];
$hasMore = false;
$totalShown = 0;


/*
 * Load a new channel or perform a video search.
 *
 * Channel-like input is recognized automatically:
 * - UC... channel ID
 * - @handle
 * - youtube.com/channel/...
 * - youtube.com/@...
 *
 * Everything else is treated as an open-ended YouTube video search.
 */
if ($action === 'load_channel' || $action === 'search_videos') {

    resetBrowserState();

    $input = isset($_POST['channel'])
        ? trim($_POST['channel'])
        : '';

    if ($input === '') {

        $error =
            'Enter a YouTube search query, channel URL, @handle, or channel ID.';

    } else {

        $instances = getInvidiousInstances();

        /*
         * Explicit channel identifiers continue to use the channel
         * browser. Plain text is intentionally NOT resolved as a
         * channel, because text such as "cnn" should behave like
         * typing "cnn" into YouTube's search bar.
         */
        $isExplicitChannel =
            isChannelId($input) ||
            extractChannelIdFromUrl($input) !== false ||
            extractHandle($input) !== false;

        if ($isExplicitChannel) {

            $resolved = resolveChannel(
                $input,
                $instances
            );

            if ($resolved === false) {

                $error =
                    'Channel could not be found or all available ' .
                    'Invidious instances failed.';

            } else {

                /*
                 * If we already know the instance, try it first.
                 */
                if (!empty($resolved['instance'])) {

                    $firstPage = getVideosFromInstance(
                        $resolved['instance'],
                        $resolved['channelId'],
                        null
                    );

                    if ($firstPage !== false) {

                        $buffer = !empty($firstPage['videos'])
                            ? $firstPage['videos']
                            : [];

                        initializeBrowserState(
                            'channel',
                            $resolved['instance'],
                            !empty($firstPage['continuation'])
                                ? $firstPage['continuation']
                                : null,
                            $buffer,
                            null,
                            $resolved['channelId']
                        );

                    } else {

                        /*
                         * Try the other known instances.
                         */
                        $worked = false;

                        foreach ($instances as $instance) {

                            if (
                                $instance ===
                                $resolved['instance']
                            ) {
                                continue;
                            }

                            $firstPage =
                                getVideosFromInstance(
                                    $instance,
                                    $resolved['channelId'],
                                    null
                                );

                            if ($firstPage !== false) {

                                $buffer =
                                    !empty($firstPage['videos'])
                                        ? $firstPage['videos']
                                        : [];

                                initializeBrowserState(
                                    'channel',
                                    $instance,
                                    !empty(
                                        $firstPage['continuation']
                                    )
                                        ? $firstPage['continuation']
                                        : null,
                                    $buffer,
                                    null,
                                    $resolved['channelId']
                                );

                                $worked = true;
                                break;
                            }
                        }

                        if (!$worked) {
                            $error =
                                'The channel was found, but its videos ' .
                                'could not be loaded.';
                        }
                    }

                } else {

                    /*
                     * We had a channel ID but no known working instance.
                     */
                    $worked = false;

                    foreach ($instances as $instance) {

                        $firstPage =
                            getVideosFromInstance(
                                $instance,
                                $resolved['channelId'],
                                null
                            );

                        if ($firstPage !== false) {

                            $buffer =
                                !empty($firstPage['videos'])
                                    ? $firstPage['videos']
                                    : [];

                            initializeBrowserState(
                                'channel',
                                $instance,
                                !empty(
                                    $firstPage['continuation']
                                )
                                    ? $firstPage['continuation']
                                    : null,
                                $buffer,
                                null,
                                $resolved['channelId']
                            );

                            $worked = true;
                            break;
                        }
                    }

                    if (!$worked) {
                        $error =
                            'The channel was found, but no available ' .
                            'Invidious instance could load its videos.';
                    }
                }
            }

        } else {

            /*
             * Plain text = YouTube-style video search.
             *
             * Only one instance request is made here. If it fails,
             * the next known instance is tried. This keeps the
             * request lightweight and avoids chaining many searches.
             */
            $worked = false;

            foreach ($instances as $instance) {

                $firstPage =
                    getSearchResultsFromInstance(
                        $instance,
                        $input,
                        null
                    );

                if ($firstPage !== false) {

                    $buffer =
                        !empty($firstPage['videos'])
                            ? $firstPage['videos']
                            : [];

                    initializeBrowserState(
                        'search',
                        $instance,
                        null,
                        $buffer,
                        $input,
                        null,
                        1,
                        !empty($buffer)
                    );

                    $worked = true;
                    break;
                }
            }

            if (!$worked) {
                $error =
                    'The YouTube search failed. All available ' .
                    'Invidious instances stopped responding.';
            }
        }

        /*
         * Give the user the first 20 results.
         */
        if ($error === '') {

            $result =
                getNextVideos(VIDEOS_PER_PAGE);

            $videos =
                $result['videos'];

            $hasMore =
                (
                    isset($_SESSION['yt_browser']['mode']) &&
                    $_SESSION['yt_browser']['mode'] === 'search' &&
                    !empty($_SESSION['yt_browser']['searchHasMore'])
                ) ||
                !empty(
                    $_SESSION['yt_browser']['continuation']
                ) ||
                !empty(
                    $_SESSION['yt_browser']['buffer']
                );

            $totalShown =
                $_SESSION['yt_browser']['totalShown'];

            if (!empty($result['error'])) {
                $error = $result['error'];
            }
        }
    }
}


/*
 * Load another 20.
 */
if ($action === 'load_more') {

    $state = getBrowserState();

    if ($state === false) {

        $error = 'Start a channel or search first.';

    } else {

        $result =
            getNextVideos(VIDEOS_PER_PAGE);

        $videos =
            $result['videos'];

        $hasMore =
            !empty(
                $_SESSION['yt_browser']['continuation']
            ) ||
            !empty(
                $_SESSION['yt_browser']['buffer']
            );

        $totalShown =
            $_SESSION['yt_browser']['totalShown'];

        if (!empty($result['error'])) {
            $error = $result['error'];
        }
    }
}


/*
 * Refreshing the page should retain the channel state.
 */
if (
    $action === '' &&
    getBrowserState() !== false
) {
    $state = getBrowserState();

    $hasMore =
        (
            isset($state['mode']) &&
            $state['mode'] === 'search' &&
            !empty($state['searchHasMore'])
        ) ||
        !empty($state['continuation']) ||
        !empty($state['buffer']);

    $totalShown =
        $state['totalShown'];
}

/*
 * AJAX requests return JSON instead of rendering the whole page.
 * The browser uses fetch() so Search / Load / Load More never reload
 * or navigate away from the current page.
 */
$isAjax =
    isset($_POST['ajax']) &&
    $_POST['ajax'] === '1';

if ($isAjax && ($action === 'load_channel' || $action === 'load_more')) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

    echo json_encode([
        'videos' => $videos,
        'hasMore' => $hasMore,
        'totalShown' => $totalShown,
        'error' => $error
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>YouTube Video Search</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 20px;
            background: #f5f5f5;
            color: #222;
            font-family:
                Arial,
                Helvetica,
                sans-serif;
        }

        .container {
            width: 100%;
            max-width: 1000px;
            margin: 0 auto;
        }

        h1 {
            margin: 0 0 20px;
            font-size: 26px;
        }

        .search-box {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
        }

        .search-form {
            display: flex;
            gap: 10px;
        }

        .search-form input {
            flex: 1;
            min-width: 0;
            padding: 11px 12px;
            border: 1px solid #bbb;
            border-radius: 5px;
            font-size: 15px;
        }

        .search-form button {
            padding: 11px 18px;
            border: 0;
            border-radius: 5px;
            background: #222;
            color: #fff;
            cursor: pointer;
            font-size: 15px;
        }

        .search-form button:hover {
            background: #444;
        }

        .error {
            margin-bottom: 20px;
            padding: 12px 14px;
            border-radius: 6px;
            background: #ffe9e9;
            border: 1px solid #e5aaaa;
            color: #9a0000;
        }

        .status {
            margin-bottom: 12px;
            color: #666;
            font-size: 14px;
        }

        .videos {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .video {
            display: flex;
            align-items: center;
            gap: 12px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 7px;
            min-height: 82px;
        }

        .thumbnail {
            width: 120px;
            height: 68px;
            min-width: 120px;
            object-fit: cover;
            display: block;
            background: #ddd;
            border-radius: 3px;
        }

        .video-info {
            min-width: 0;
            flex: 1;
        }

        .video-title {
            margin-bottom: 5px;
            font-size: 15px;
            font-weight: 600;
            line-height: 1.3;
        }

        .video-title a {
            color: #222;
            text-decoration: none;
        }

        .video-title a:hover {
            text-decoration: underline;
        }

        .video-date {
            color: #777;
            font-size: 12px;
            margin-bottom: 4px;
        }

        .video-duration {
            color: #777;
            font-size: 12px;
            margin-bottom: 4px;
        }

        .video-url {
            font-size: 12px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .video-url a {
            color: #555;
            text-decoration: none;
        }

        .video-url a:hover {
            text-decoration: underline;
        }

        .load-more {
            margin-top: 18px;
            text-align: center;
        }

        .load-more button {
            padding: 11px 24px;
            border: 1px solid #bbb;
            border-radius: 5px;
            background: #fff;
            color: #222;
            cursor: pointer;
            font-size: 14px;
        }

        .load-more button:hover {
            background: #eee;
        }

        button:disabled {
            opacity: 0.6;
            cursor: wait;
        }

        .loading-status {
            margin-bottom: 12px;
            color: #666;
            font-size: 14px;
        }

        .empty {
            padding: 30px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            text-align: center;
            color: #666;
        }

        @media (max-width: 600px) {

            body {
                padding: 15px 10px;
            }

            .search-form {
                flex-direction: column;
            }

            .search-form button {
                width: 100%;
            }

            .video {
                gap: 8px;
            }

            .thumbnail {
                width: 100px;
                height: 56px;
                min-width: 100px;
            }

            .video-title {
                font-size: 14px;
            }

            .video-url {
                font-size: 11px;
            }
        }

    </style>

</head>

<body>

<div class="container">

    <h1>YouTube Video Search</h1>

    <div class="search-box">

        <form
            method="post"
            class="search-form"
            id="search-form"
        >

            <input
                id="search-input"
                type="text"
                name="channel"
                placeholder="Search YouTube, or enter a channel URL, @handle, or channel ID"
                value="<?= isset($_POST['channel'])
                    ? htmlspecialchars($_POST['channel'])
                    : '' ?>"
            >

            <button
                id="search-button"
                type="submit"
                name="action"
                value="load_channel"
            >
                Search / Load
            </button>

        </form>

    </div>


    <?php if ($error !== ''): ?>

        <div class="error" id="error-message">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>


    <?php if (!empty($videos)): ?>

        <div class="status" id="video-status">
            Showing <?= number_format($totalShown) ?> results
        </div>

        <div class="videos" id="videos">

            <?php foreach ($videos as $video): ?>

                <?php

                $videoId = getVideoId($video);

                if ($videoId === '') {
                    continue;
                }

                $title =
                    !empty($video['title'])
                        ? $video['title']
                        : 'Untitled video';

                $date = '';

                if (!empty($video['published'])) {

                    $date =
                        formatDate(
                            $video['published']
                        );

                } elseif (
                    !empty($video['publishedText'])
                ) {

                    $date =
                        $video['publishedText'];
                }

                $duration = formatDuration($video);

                $youtubeUrl =
                    'https://www.youtube.com/watch?v=' .
                    rawurlencode($videoId);

                $thumbnail =
                    getYouTubeThumbnail($videoId);

                ?>

                <div class="video">

                    <a
                        href="<?= htmlspecialchars($youtubeUrl) ?>"
                        target="_blank"
                        rel="noopener noreferrer"
                    >

                        <img
                            class="thumbnail"
                            src="<?= htmlspecialchars($thumbnail) ?>"
                            alt=""
                            loading="lazy"
                            width="120"
                            height="68"
                        >

                    </a>


                    <div class="video-info">

                        <div class="video-title">

                            <a
                                href="<?= htmlspecialchars($youtubeUrl) ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <?= htmlspecialchars($title) ?>
                            </a>

                        </div>


                        <?php if ($date !== ''): ?>

                            <div class="video-date">
                                <?= htmlspecialchars($date) ?>
                            </div>

                        <?php endif; ?>

                        <?php if ($duration !== ''): ?>

                            <div class="video-duration">
                                <?= htmlspecialchars($duration) ?>
                            </div>

                        <?php endif; ?>


                        <div class="video-url">

                            <a
                                href="<?= htmlspecialchars($youtubeUrl) ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <?= htmlspecialchars($youtubeUrl) ?>
                            </a>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>


        <?php if ($hasMore): ?>

            <div class="load-more" id="load-more-container">

                <form method="post" id="load-more-form">

                    <button
                        type="submit"
                        name="action"
                        value="load_more"
                        id="load-more-button"
                    >
                        Load More
                    </button>

                </form>

            </div>

        <?php endif; ?>


    <?php elseif (
        $action === 'load_channel' &&
        $error === ''
    ): ?>

        <div class="empty">
            No videos were found.
        </div>

    <?php endif; ?>

</div>

<script>
(function () {
    'use strict';

    const channelForm = document.getElementById('search-form');
    const channelInput = document.getElementById('search-input');
    let videosContainer = document.getElementById('videos');
    let statusElement = document.getElementById('video-status');
    let loadMoreContainer = document.getElementById('load-more-container');

    let loading = false;

    function ensureResultsArea() {
        const container = document.querySelector('.container');

        if (!container) {
            return false;
        }

        if (!statusElement) {
            statusElement = document.createElement('div');
            statusElement.className = 'status';
            statusElement.id = 'video-status';
            statusElement.style.display = 'none';

            const searchBox = document.querySelector('.search-box');
            if (searchBox) {
                searchBox.insertAdjacentElement('afterend', statusElement);
            } else {
                container.appendChild(statusElement);
            }
        }

        if (!videosContainer) {
            videosContainer = document.createElement('div');
            videosContainer.className = 'videos';
            videosContainer.id = 'videos';

            if (statusElement && statusElement.parentNode) {
                statusElement.insertAdjacentElement('afterend', videosContainer);
            } else {
                container.appendChild(videosContainer);
            }
        }

        return true;
    }

    function escapeHtml(value) {
        const div = document.createElement('div');
        div.textContent = value == null ? '' : String(value);
        return div.innerHTML;
    }

    function formatDuration(video) {
        if (!video || typeof video !== 'object') {
            return '';
        }

        let seconds = null;

        if (video.lengthSeconds !== undefined && !isNaN(video.lengthSeconds)) {
            seconds = Number(video.lengthSeconds);
        } else if (video.duration !== undefined && !isNaN(video.duration)) {
            seconds = Number(video.duration);
        }

        if (seconds === null || seconds < 0) {
            return '';
        }

        seconds = Math.floor(seconds);

        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const remaining = seconds % 60;

        if (hours > 0) {
            return hours + ':' +
                String(minutes).padStart(2, '0') + ':' +
                String(remaining).padStart(2, '0');
        }

        return minutes + ':' +
            String(remaining).padStart(2, '0');
    }

    function getVideoId(video) {
        if (!video || typeof video !== 'object') {
            return '';
        }

        return video.videoId || video.id || '';
    }

    function formatDate(timestamp) {
        if (!timestamp) {
            return '';
        }

        let value = timestamp;

        if (!isNaN(value)) {
            value = Number(value);

            if (value > 20000000000) {
                value = Math.floor(value / 1000);
            }

            const date = new Date(value * 1000);

            if (!isNaN(date.getTime())) {
                return date.toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric'
                });
            }
        }

        return '';
    }

    function videoHtml(video) {
        const videoId = getVideoId(video);

        if (!videoId) {
            return '';
        }

        const title = video.title || 'Untitled video';
        const duration = formatDuration(video);
        let date = '';

        if (video.published) {
            date = formatDate(video.published);
        } else if (video.publishedText) {
            date = video.publishedText;
        }

        const youtubeUrl =
            'https://www.youtube.com/watch?v=' +
            encodeURIComponent(videoId);

        const thumbnail =
            'https://i.ytimg.com/vi/' +
            encodeURIComponent(videoId) +
            '/mqdefault.jpg';

        return `
            <div class="video">
                <a href="${escapeHtml(youtubeUrl)}"
                   target="_blank"
                   rel="noopener noreferrer">
                    <img
                        class="thumbnail"
                        src="${escapeHtml(thumbnail)}"
                        alt=""
                        loading="lazy"
                        width="120"
                        height="68"
                    >
                </a>

                <div class="video-info">
                    <div class="video-title">
                        <a href="${escapeHtml(youtubeUrl)}"
                           target="_blank"
                           rel="noopener noreferrer">
                            ${escapeHtml(title)}
                        </a>
                    </div>

                    ${date !== '' ? `
                        <div class="video-date">
                            ${escapeHtml(date)}
                        </div>
                    ` : ''}

                    ${duration !== '' ? `
                        <div class="video-duration">
                            ${escapeHtml(duration)}
                        </div>
                    ` : ''}

                    <div class="video-url">
                        <a href="${escapeHtml(youtubeUrl)}"
                           target="_blank"
                           rel="noopener noreferrer">
                            ${escapeHtml(youtubeUrl)}
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    function setError(message) {
        const oldError = document.getElementById('error-message');

        if (oldError) {
            oldError.remove();
        }

        if (!message) {
            return;
        }

        const error = document.createElement('div');
        error.className = 'error';
        error.id = 'error-message';
        error.textContent = message;

        const searchBox = document.querySelector('.search-box');

        if (searchBox && searchBox.parentNode) {
            searchBox.parentNode.insertBefore(
                error,
                searchBox.nextSibling
            );
        }
    }

    function setLoading(button, isLoading, text) {
        if (!button) {
            return;
        }

        button.disabled = isLoading;

        if (isLoading) {
            button.dataset.originalText = button.textContent;
            button.textContent = text;
        } else if (button.dataset.originalText) {
            button.textContent = button.dataset.originalText;
            delete button.dataset.originalText;
        }
    }

    async function sendRequest(action, extraData) {
        const formData = new FormData();

        formData.append('ajax', '1');
        formData.append('action', action);

        if (extraData) {
            Object.keys(extraData).forEach(function (key) {
                formData.append(key, extraData[key]);
            });
        }

        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        if (!response.ok) {
            throw new Error(
                'Server returned HTTP ' + response.status + '.'
            );
        }

        return await response.json();
    }

    function showVideos(videos, append) {
        if (!ensureResultsArea()) {
            return;
        }

        const html = (videos || [])
            .map(videoHtml)
            .join('');

        if (append) {
            videosContainer.insertAdjacentHTML('beforeend', html);
        } else {
            videosContainer.innerHTML = html;
        }
    }

    function updateLoadMore(hasMore) {
        if (!loadMoreContainer) {
            return;
        }

        if (!hasMore) {
            loadMoreContainer.remove();
        }
    }

    async function loadChannel(event) {
        event.preventDefault();

        if (loading) {
            return;
        }

        const channel = channelInput
            ? channelInput.value.trim()
            : '';

        if (!channel) {
            setError(
                'Enter a YouTube search query, channel URL, @handle, or channel ID.'
            );
            return;
        }

        loading = true;

        const button =
            document.getElementById('search-button');

        setLoading(button, true, 'Loading...');
        setError('');

        if (videosContainer) {
            videosContainer.innerHTML = '';
        }

        ensureResultsArea();

        if (statusElement) {
            statusElement.style.display = '';
            statusElement.textContent = 'Searching YouTube...';
        }

        if (loadMoreContainer) {
            loadMoreContainer.remove();
        }

        try {
            const data = await sendRequest(
                'load_channel',
                { channel: channel }
            );

            if (data.error) {
                setError(data.error);

                if (statusElement) {
                    statusElement.textContent = '';
                }

                return;
            }

            showVideos(data.videos, false);

            if (statusElement) {
                statusElement.style.display = '';
                statusElement.textContent =
                    'Showing ' +
                    Number(data.totalShown || 0).toLocaleString() +
                    ' results';
            }

            if (data.hasMore) {
                addLoadMoreButton();
            } else if (!data.videos || data.videos.length === 0) {
                showEmptyMessage();
            }
        } catch (error) {
            setError(
                'The request failed: ' + error.message
            );

            if (statusElement) {
                statusElement.textContent = '';
            }
        } finally {
            loading = false;
            setLoading(button, false, '');
        }
    }

    function showEmptyMessage() {
        if (!videosContainer) {
            return;
        }

        if (videosContainer.children.length > 0) {
            return;
        }

        videosContainer.insertAdjacentHTML(
            'afterend',
            '<div class="empty" id="empty-message">' +
            'No videos were found.' +
            '</div>'
        );
    }

    function removeEmptyMessage() {
        const empty = document.getElementById('empty-message');

        if (empty) {
            empty.remove();
        }
    }

    function addLoadMoreButton() {
        removeEmptyMessage();

        let container =
            document.getElementById('load-more-container');

        if (!container) {
            container = document.createElement('div');
            container.className = 'load-more';
            container.id = 'load-more-container';

            container.innerHTML = `
                <form method="post" id="load-more-form">
                    <button
                        type="submit"
                        id="load-more-button"
                    >
                        Load More
                    </button>
                </form>
            `;

            const parent =
                videosContainer
                    ? videosContainer.parentNode
                    : document.querySelector('.container');

            if (parent) {
                parent.appendChild(container);
            }

            container
                .querySelector('#load-more-form')
                .addEventListener('submit', loadMore);
        }
    }

    async function loadMore(event) {
        event.preventDefault();

        if (loading) {
            return;
        }

        loading = true;

        const button =
            document.getElementById('load-more-button');

        setLoading(button, true, 'Loading...');

        try {
            const data = await sendRequest('load_more');

            if (data.error) {
                setError(data.error);
                return;
            }

            showVideos(data.videos, true);
            removeEmptyMessage();

            if (statusElement) {
                statusElement.textContent =
                    'Showing ' +
                    Number(data.totalShown || 0).toLocaleString() +
                    ' results';
            }

            if (data.hasMore) {
                addLoadMoreButton();
            } else {
                updateLoadMore(false);
            }
        } catch (error) {
            setError(
                'The request failed: ' + error.message
            );
        } finally {
            loading = false;

            const currentButton =
                document.getElementById('load-more-button');

            if (currentButton) {
                setLoading(currentButton, false, '');
            }
        }
    }

    if (channelForm) {
        channelForm.addEventListener('submit', loadChannel);
    }

    const existingLoadMoreForm =
        document.getElementById('load-more-form');

    if (existingLoadMoreForm) {
        existingLoadMoreForm.addEventListener('submit', loadMore);
    }
})();
</script>

</body>
</html>
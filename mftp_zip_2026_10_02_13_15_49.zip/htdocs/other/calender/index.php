<?php

declare(strict_types=1);

require_once __DIR__ . '/../../config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header('Location: ../../logon.php');
    exit;
}

$username = $_SESSION['username'] ?? '';
$view = ($_GET['view'] ?? 'home') === 'calendar' ? 'calendar' : 'home';

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Calendar</title>

<style>

* {
    box-sizing: border-box;
}

html,
body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
}

body {
    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #f5f5f7;
    color: #18181b;
}

.app {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.topbar {
    height: 64px;
    background: white;
    border-bottom: 1px solid #dedee3;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 22px;
    flex-shrink: 0;
}

.brand {
    display: flex;
    align-items: center;
    gap: 12px;
}

.brand-icon {
    width: 34px;
    height: 34px;
    border-radius: 9px;
    background: #6366f1;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.brand-title {
    font-size: 18px;
    font-weight: 700;
}

.brand-subtitle {
    font-size: 12px;
    color: #71717a;
    margin-top: 2px;
}

.top-actions {
    display: flex;
    gap: 8px;
}

button,
.button {
    border: 1px solid #d4d4d8;
    background: white;
    color: #27272a;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 14px;
    cursor: pointer;
    text-decoration: none;
    transition:
        background .12s,
        border-color .12s;
}

button:hover,
.button:hover {
    background: #f4f4f5;
}

.primary {
    background: #6366f1;
    border-color: #6366f1;
    color: white;
}

.primary:hover {
    background: #4f46e5;
    border-color: #4f46e5;
}

.danger {
    color: #dc2626;
    border-color: #fecaca;
}

.danger:hover {
    background: #fef2f2;
}

.modal-type-hint {
    margin: -8px 0 16px;
    color: #71717a;
    font-size: 13px;
}

.instance-scope {
    margin: 0 0 16px;
    padding: 11px 12px;
    border: 1px solid #ddd6fe;
    background: #faf9ff;
    border-radius: 9px;
}

.instance-scope-title {
    font-size: 12px;
    font-weight: 700;
    color: #52525b;
    margin-bottom: 7px;
}

.instance-scope-options {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.instance-scope-option {
    flex: 1 1 180px;
    min-width: 0;
    text-align: left;
    padding: 9px 10px;
    border: 1px solid #d4d4d8;
    background: white;
    border-radius: 8px;
}

.instance-scope-option.selected {
    border-color: #6366f1;
    background: #f5f3ff;
    box-shadow: inset 0 0 0 1px #6366f1;
}

.instance-scope-option strong {
    display: block;
    font-size: 12px;
    margin-bottom: 2px;
}

.instance-scope-option span {
    display: block;
    font-size: 11px;
    color: #71717a;
    line-height: 1.35;
}

.main {
    flex: 1 1 auto;
    min-height: 0;
    height: calc(100vh - 64px);
    display: flex;
    align-items: stretch;
    overflow: hidden;
}

.sidebar {
    width: 280px;
    background: white;
    border-right: 1px solid #dedee3;
    padding: 18px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    flex-shrink: 0;
    align-self: stretch;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
}

.sidebar-title {
    font-size: 13px;
    font-weight: 700;
    color: #71717a;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.ai-box {
    border: 1px solid #ddd6fe;
    background: #faf9ff;
    border-radius: 12px;
    padding: 14px;
}

.ai-title {
    font-weight: 700;
    color: #5b21b6;
    margin-bottom: 6px;
}

.ai-description {
    font-size: 12px;
    color: #71717a;
    line-height: 1.45;
    margin-bottom: 10px;
}

.ai-input {
    width: 100%;
    resize: none;
    min-height: 88px;
    border: 1px solid #d4d4d8;
    border-radius: 8px;
    padding: 9px;
    font-family: inherit;
    font-size: 13px;
    outline: none;
}

.ai-input:focus {
    border-color: #8b5cf6;
}

.ai-send {
    width: 100%;
    margin-top: 8px;
}

.ai-result {
    margin-top: 10px;
    font-size: 13px;
    line-height: 1.5;
    color: #3f3f46;
}

.ai-result:empty {
    display: none;
}

.ai-question {
    background: white;
    border: 1px solid #ddd6fe;
    border-radius: 8px;
    padding: 10px;
    margin-top: 8px;
}

.confirm-actions {
    display: flex;
    gap: 7px;
    margin-top: 10px;
}

.sidebar-spacer {
    flex: 1 1 auto;
    min-height: 0;
}

.sidebar-note {
    color: #a1a1aa;
    font-size: 11px;
    line-height: 1.4;
}

.calendar-area {
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.calendar-header {
    height: 62px;
    background: white;
    border-bottom: 1px solid #dedee3;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 18px;
}

.calendar-title {
    font-size: 20px;
    font-weight: 700;
}

.calendar-navigation {
    display: flex;
    align-items: center;
    gap: 6px;
}

.weekdays {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    background: white;
    border-bottom: 1px solid #dedee3;
}

.weekday {
    padding: 9px;
    text-align: right;
    color: #71717a;
    font-size: 12px;
    font-weight: 700;
}

.calendar-grid {
    --calendar-rows: 5;
    flex: 1 1 auto;
    min-height: 0;
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
    grid-template-rows: repeat(var(--calendar-rows), minmax(0, 1fr));
    align-items: stretch;
    background: #dcdce1;
    gap: 1px;
}

.day {
    background: white;
    position: relative;
    min-width: 0;
    overflow: visible;
    padding: 7px;
}

.day.other-month {
    background: #fafafa;
    color: #a1a1aa;
}

.day.today {
    background: #fbfbff;
}

.day-number {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    margin-bottom: 4px;
    font-size: 12px;
    color: #52525b;
}

.today .day-number span {
    width: 25px;
    height: 25px;
    border-radius: 50%;
    background: #6366f1;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
}

.events {
    display: flex;
    flex-direction: column;
    gap: 3px;
    overflow: visible;
}

.event {
    width: 100%;
    border: 0;
    color: white;
    border-radius: 5px;
    padding: 4px 6px;
    text-align: left;
    font-size: 11px;
    line-height: 1.25;
    cursor: pointer;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.event.high {
    box-shadow:
        inset 3px 0 0 rgba(0,0,0,.3);
}

.more-events {
    font-size: 11px;
    color: #71717a;
    padding: 2px 4px;
}

.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.35);
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
    z-index: 100;
}

.modal-overlay.open {
    display: flex;
}

.modal {
    width: min(520px, 100%);
    max-height: 90vh;
    overflow-y: auto;
    background: white;
    border-radius: 14px;
    box-shadow:
        0 20px 60px rgba(0,0,0,.2);
    padding: 22px;
}

.modal h2 {
    margin: 0 0 18px;
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.form-group.full {
    grid-column: 1 / -1;
}

.form-group label {
    font-size: 12px;
    font-weight: 700;
    color: #52525b;
}

.form-group input,
.form-group textarea,
.form-group select {
    width: 100%;
    border: 1px solid #d4d4d8;
    border-radius: 8px;
    padding: 9px;
    font-family: inherit;
    outline: none;
}

.form-group textarea {
    min-height: 90px;
    resize: vertical;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
    border-color: #6366f1;
}

.color-options {
    display: flex;
    gap: 7px;
    flex-wrap: wrap;
}

.color-option {
    width: 25px;
    height: 25px;
    border-radius: 50%;
    border: 2px solid white;
    outline: 2px solid transparent;
    padding: 0;
}

.color-option.selected {
    outline-color: #18181b;
}

.recurrence-days {
    display: flex;
    gap: 7px;
    flex-wrap: wrap;
}

.recurrence-day {
    width: 40px;
    height: 40px;
    border-radius: 999px;
    border: 1px solid #d4d4d8;
    background: white;
    color: #52525b;
    padding: 0;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
}

.recurrence-day:hover {
    background: #f4f4f5;
}

.recurrence-day.selected {
    background: #6366f1;
    border-color: #6366f1;
    color: white;
}

.recurrence-builder {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.recurrence-interval-row {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.recurrence-interval {
    width: 70px;
}

.recurrence-interval-row select {
    min-width: 190px;
}

.recurrence-subsection {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.recurrence-help {
    color: #71717a;
    font-size: 12px;
}

#recurrenceMonthDay {
    width: 90px;
}

.day-details-time {
    color: #52525b;
    font-size: 13px;
    font-weight: 700;
}

.day-details-description {
    margin-top: 7px;
    color: #52525b;
    font-size: 13px;
    line-height: 1.45;
    white-space: pre-wrap;
}

.day-details-location,
.day-details-recurrence {
    margin-top: 7px;
    color: #71717a;
    font-size: 12px;
    white-space: pre-wrap;
}

.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 20px;
}

.delete-area {
    margin-right: auto;
}

.home-main {
    flex: 1;
    min-height: 0;
    overflow: auto;
    padding: 28px;
}

.home-wrap {
    width: min(1180px, 100%);
    margin: 0 auto;
}

.home-hero {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    gap: 20px;
    margin-bottom: 24px;
}

.home-kicker {
    color: #6366f1;
    font-size: 12px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .08em;
    margin-bottom: 7px;
}

.home-title {
    font-size: 30px;
    line-height: 1.1;
    margin: 0;
}

.home-subtitle {
    color: #71717a;
    margin-top: 7px;
    font-size: 14px;
}

.home-quick {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    justify-content: flex-end;
}

.home-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
}

.home-card {
    background: white;
    border: 1px solid #dedee3;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 3px 12px rgba(0,0,0,.035);
}

.home-card-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 17px 18px;
    border-bottom: 1px solid #ededf0;
}

.home-card-actions {
    display: flex;
    align-items: center;
    gap: 7px;
    flex-wrap: wrap;
    justify-content: flex-end;
}

.home-range-label {
    font-size: 11px;
    color: #71717a;
    font-weight: 600;
}

.home-range-select {
    height: 31px;
    border: 1px solid #d4d4d8;
    background: white;
    border-radius: 8px;
    padding: 0 9px;
    font: inherit;
    font-size: 12px;
    color: #27272a;
    outline: none;
    cursor: pointer;
}

.home-range-select:focus {
    border-color: #6366f1;
}

.home-card-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 16px;
    font-weight: 800;
}

.home-card-icon {
    width: 30px;
    height: 30px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f0efff;
    color: #6366f1;
    font-weight: 800;
    font-size: 13px;
}

.home-card-link {
    border: 0;
    padding: 5px 7px;
    font-size: 12px;
    color: #6366f1;
    background: transparent;
}

.home-card-link:hover {
    background: #f5f3ff;
}

.home-list {
    min-height: 205px;
}

.home-row {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 14px 18px;
    border-bottom: 1px solid #f0f0f2;
    cursor: pointer;
}

.home-row:last-child {
    border-bottom: 0;
}

.home-row:hover {
    background: #fafafa;
}

.home-dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    flex: 0 0 auto;
}

.home-row-main {
    min-width: 0;
    flex: 1;
}

.home-row-title {
    font-size: 14px;
    font-weight: 700;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.home-row-meta {
    margin-top: 4px;
    color: #71717a;
    font-size: 12px;
}

.home-row-time {
    color: #52525b;
    font-size: 12px;
    white-space: nowrap;
}

.home-empty {
    min-height: 205px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 28px;
    color: #a1a1aa;
    font-size: 13px;
}

.home-footer {
    margin-top: 18px;
    color: #a1a1aa;
    font-size: 11px;
    text-align: center;
}

.ai-modal .modal {
    width: min(560px, 100%);
}

.ai-modal-title {
    margin: 0;
    font-size: 21px;
}

.ai-modal-subtitle {
    color: #71717a;
    font-size: 13px;
    margin-top: 5px;
    margin-bottom: 14px;
}

.ai-home-input {
    width: 100%;
    min-height: 90px;
    resize: vertical;
    border: 1px solid #d4d4d8;
    border-radius: 10px;
    padding: 11px;
    font: inherit;
    outline: none;
}

.ai-home-input:focus {
    border-color: #6366f1;
}

.ai-home-send {
    width: 100%;
    margin-top: 9px;
}

.ai-home-result {
    margin-top: 10px;
}

/* =========================================================
   CONTINUOUS AI CHAT
   ========================================================= */

.ai-chat {
    display: flex;
    flex-direction: column;
    gap: 7px;
    max-height: 300px;
    overflow-y: auto;
    margin-bottom: 9px;
    padding-right: 2px;
}

.ai-message {
    max-width: 92%;
    padding: 8px 10px;
    border-radius: 9px;
    font-size: 12px;
    line-height: 1.4;
    white-space: pre-wrap;
    word-break: break-word;
}

.ai-message.user {
    align-self: flex-end;
    background: #6366f1;
    color: white;
    border-bottom-right-radius: 3px;
}

.ai-message.assistant {
    align-self: flex-start;
    background: white;
    border: 1px solid #ddd6fe;
    color: #3f3f46;
    border-bottom-left-radius: 3px;
}

.ai-message.system {
    align-self: center;
    color: #71717a;
    font-size: 11px;
    background: transparent;
    padding: 2px;
}

.ai-confirmation {
    width: 100%;
    max-width: 100%;
}

.ai-confirmation .confirm-actions {
    display: flex;
    gap: 7px;
    margin-top: 9px;
}

.ai-confirmation .confirm-actions button {
    flex: 1;
}


.ai-chat:empty {
    display: none;
}

.ai-clear {
    width: 100%;
    margin-top: 7px;
    font-size: 12px;
}

.ai-modal-chat {
    max-height: 350px;
}

.ai-modal .ai-message {
    font-size: 13px;
}

.calendar-navigation {
    display: flex;
    align-items: center;
    gap: 6px;
}

.calendar-nav-button {
    width: 36px;
    height: 36px;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.calendar-today-button {
    height: 36px;
    padding: 0 13px;
    font-weight: 700;
}

.calendar-picker {
    height: 36px;
    border: 1px solid #d4d4d8;
    background: white;
    border-radius: 8px;
    padding: 0 9px;
    font: inherit;
    color: #27272a;
    outline: none;
}

.calendar-picker:focus {
    border-color: #6366f1;
}

@media (max-width: 760px) {

    .home-main {
        padding: 16px;
    }

    .home-hero {
        align-items: flex-start;
        flex-direction: column;
    }

    .home-quick {
        justify-content: flex-start;
    }

    .home-grid {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 900px) {

    .sidebar {
        width: 230px;
    }

}

@media (max-width: 700px) {

    .sidebar {
        display: none;
    }

    .topbar {
        padding: 0 12px;
    }

    .calendar-header {
        padding: 0 10px;
    }

    .calendar-title {
        font-size: 16px;
    }

    .weekday {
        padding: 6px 3px;
        font-size: 10px;
    }

    .day {
        padding: 4px;
    }

    .day-number {
        font-size: 10px;
    }

    .event {
        font-size: 9px;
        padding: 3px;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .form-group.full {
        grid-column: auto;
    }

}

.day-details-modal .modal {
    width: min(560px, 100%);
    max-height: 88vh;
}

.day-details-list {
    display: flex;
    flex-direction: column;
    gap: 9px;
    max-height: 55vh;
    overflow-y: auto;
    padding-right: 2px;
}

.day-details-item {
    border: 1px solid #e4e4e7;
    border-radius: 10px;
    padding: 11px 12px;
    background: #fafafa;
}

.day-details-item-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

.day-details-item-title {
    min-width: 0;
    font-size: 14px;
    font-weight: 700;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.day-details-type {
    flex: 0 0 auto;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .04em;
    color: #6366f1;
}

.day-details-meta {
    margin-top: 5px;
    color: #71717a;
    font-size: 12px;
    line-height: 1.45;
}

.day-details-actions {
    display: flex;
    gap: 8px;
    justify-content: flex-end;
    margin-top: 16px;
}

.day-details-empty {
    padding: 20px 10px;
    text-align: center;
    color: #a1a1aa;
    font-size: 13px;
}

@media (max-width: 700px) {
    .day-details-modal .modal {
        padding: 16px;
    }

    .day-details-list {
        max-height: 50vh;
    }
}

</style>

</head>

<body>

<div class="app">

<header class="topbar">

    <div class="brand">
        <div class="brand-icon">C</div>
        <div>
            <div class="brand-title">Calendar</div>
            <div class="brand-subtitle">Your schedule</div>
        </div>
    </div>

    <div class="top-actions">

        <?php if ($view === 'calendar'): ?>

            <a href="?view=home" class="button">Home</a>

            <button
                class="button"
                onclick="openCreateReminder()"
            >
                New reminder
            </button>

            <button
                class="primary"
                onclick="openCreateForToday()"
            >
                + Event
            </button>

        <?php else: ?>

            <a
                href="?view=calendar"
                class="button primary"
            >
                Calendar
            </a>

            <button
                class="button"
                onclick="openCreateReminder()"
            >
                New reminder
            </button>

            <button
                class="primary"
                onclick="openCreateForToday()"
            >
                + Event
            </button>

        <?php endif; ?>

    </div>

</header>

<?php if ($view === 'home'): ?>

<main class="home-main">

    <div class="home-wrap">

        <div class="home-hero">

            <div>

                <div class="home-kicker">
                    Your schedule
                </div>

                <h1 class="home-title">
                    Welcome back<?php
                        echo $username !== ''
                            ? ', ' . htmlspecialchars(
                                $username,
                                ENT_QUOTES,
                                'UTF-8'
                            )
                            : '';
                    ?>.
                </h1>

                <div class="home-subtitle">
                    Keep up with what's coming next and stay ahead of your reminders.
                </div>

            </div>

            <div class="home-quick">
                <button
                    type="button"
                    class="primary"
                    onclick="openAIInterface()"
                >
                    Auto Manage
                </button>
            </div>

        </div>

        <div class="home-grid">

            <section class="home-card">

                <div class="home-card-head">

                    <div class="home-card-title">

                        <div class="home-card-icon">
                            E
                        </div>

                        Events

                    </div>

                    <div class="home-card-actions">

                        <label
                            class="home-range-label"
                            for="homeEventsRange"
                        >
                            Within
                        </label>

                        <select
                            id="homeEventsRange"
                            class="home-range-select"
                            onchange="renderHomeLists()"
                        >
                            <option value="1">1 day</option>
                            <option value="2">2 days</option>
                            <option value="3">3 days</option>
                            <option value="4">4 days</option>
                            <option value="5">5 days</option>
                            <option value="6">6 days</option>
                            <option value="7" selected>1 week</option>
                            <option value="30">1 month</option>
                        </select>

                        <a
                            href="?view=calendar"
                            class="button home-card-link"
                        >
                            View calendar
                        </a>

                    </div>

                </div>

                <div
                    id="homeEvents"
                    class="home-list"
                >
                    <div class="home-empty">
                        Loading upcoming events...
                    </div>
                </div>

            </section>

            <section class="home-card">

                <div class="home-card-head">

                    <div class="home-card-title">

                        <div class="home-card-icon">
                            R
                        </div>

                        Reminders

                    </div>

                    <div class="home-card-actions">

                        <label
                            class="home-range-label"
                            for="homeRemindersRange"
                        >
                            Within
                        </label>

                        <select
                            id="homeRemindersRange"
                            class="home-range-select"
                            onchange="renderHomeLists()"
                        >
                            <option value="1" selected>1 day</option>
                            <option value="2">2 days</option>
                            <option value="3">3 days</option>
                            <option value="4">4 days</option>
                            <option value="5">5 days</option>
                            <option value="6">6 days</option>
                            <option value="7">1 week</option>
                            <option value="30">1 month</option>
                        </select>

                        <button
                            class="button home-card-link"
                            onclick="openCreateReminder()"
                        >
                            New reminder
                        </button>

                    </div>

                </div>

                <div
                    id="homeReminders"
                    class="home-list"
                >
                    <div class="home-empty">
                        Loading reminders...
                    </div>
                </div>

            </section>

        </div>

    </div>

</main>

<div
    id="aiModal"
    class="modal-overlay ai-modal"
    onclick="closeAIModalOutside(event)"
>

    <div class="modal">

        <h2 class="ai-modal-title">
            Auto Create
        </h2>

        <div class="ai-modal-subtitle">
            Tell me what is happening and I’ll turn it into an event or reminder.
            You can keep clarifying it in the same conversation.
        </div>

        <div
            id="aiChat"
            class="ai-chat ai-modal-chat"
        ></div>

        <textarea
            id="aiInput"
            class="ai-home-input"
            placeholder="Try: I have robotics every Tuesday and Thursday from 4-5:30 PM..."
        ></textarea>

        <button
            class="primary ai-home-send"
            id="aiSend"
            onclick="sendAI()"
        >
            Ask AI
        </button>

        <button
            class="ai-clear"
            onclick="clearAIConversation()"
        >
            Clear conversation
        </button>

        <div class="modal-actions">

            <button
                type="button"
                onclick="closeAIModal()"
            >
                Close
            </button>

        </div>

    </div>

</div>

<?php else: ?>

<div class="main">

    <aside class="sidebar">

        <div class="sidebar-title">
            Calendar Assistant
        </div>

        <div class="ai-box">

            <div class="ai-title">
                Ask Calendar AI
            </div>

            <div class="ai-description">
                Tell me what's happening and keep clarifying it naturally.
            </div>

            <div
                id="aiChat"
                class="ai-chat"
            ></div>

            <textarea
                id="aiInput"
                class="ai-input"
                placeholder="Try: I have chemistry class every Tuesday at 9 AM..."
            ></textarea>

            <button
                class="primary ai-send"
                id="aiSend"
                onclick="sendAI()"
            >
                Ask AI
            </button>

            <button
                class="ai-clear"
                onclick="clearAIConversation()"
            >
                Clear conversation
            </button>

        </div>

        <div class="sidebar-spacer"></div>

    </aside>

    <section class="calendar-area">

        <div class="calendar-header">

            <div
                id="calendarTitle"
                class="calendar-title"
            >
                Loading...
            </div>

            <div class="calendar-navigation">

                <button
                    class="calendar-nav-button"
                    onclick="previousMonth()"
                    title="Previous month"
                    aria-label="Previous month"
                >
                    ‹
                </button>

                <button
                    class="calendar-today-button"
                    onclick="goToday()"
                >
                    Today
                </button>

                <select
                    id="monthPicker"
                    class="calendar-picker"
                    onchange="jumpToSelectedMonth()"
                    aria-label="Choose month"
                ></select>

                <select
                    id="yearPicker"
                    class="calendar-picker"
                    onchange="jumpToSelectedMonth()"
                    aria-label="Choose year"
                ></select>

                <button
                    class="calendar-nav-button"
                    onclick="nextMonth()"
                    title="Next month"
                    aria-label="Next month"
                >
                    ›
                </button>

            </div>

        </div>

        <div class="weekdays">

            <div class="weekday">Sun</div>
            <div class="weekday">Mon</div>
            <div class="weekday">Tue</div>
            <div class="weekday">Wed</div>
            <div class="weekday">Thu</div>
            <div class="weekday">Fri</div>
            <div class="weekday">Sat</div>

        </div>

        <div
            id="calendarGrid"
            class="calendar-grid"
        ></div>

    </section>

</div>

<?php endif; ?>

</div>


<!-- =========================================================
     EVENT MODAL
     ========================================================= -->

<div
    id="eventModal"
    class="modal-overlay"
    onclick="closeModalOutside(event)"
>

    <div class="modal">

        <h2 id="modalTitle">
            New Event
        </h2>

        <div
            id="modalTypeHint"
            class="modal-type-hint"
        >
            Calendar event
        </div>

        <div
            id="instanceScope"
            class="instance-scope"
            style="display:none;"
        >
            <div class="instance-scope-title">
                This item repeats. Apply changes to:
            </div>
            <div class="instance-scope-options">
                <button
                    type="button"
                    id="scopeInstance"
                    class="instance-scope-option selected"
                    onclick="setEditScope('instance')"
                >
                    <strong>This instance only</strong>
                    <span>Change only the occurrence you opened.</span>
                </button>
                <button
                    type="button"
                    id="scopeSeries"
                    class="instance-scope-option"
                    onclick="setEditScope('series')"
                >
                    <strong>All instances</strong>
                    <span>Change the entire repeating series.</span>
                </button>
            </div>
        </div>

        <form
            id="eventForm"
            onsubmit="saveEvent(event)"
        >

            <input
                type="hidden"
                id="eventId"
            >

            <input
                type="hidden"
                id="eventType"
                value="event"
            >

            <div class="form-grid">

                <div class="form-group full">

                    <label>
                        Title
                    </label>

                    <input
                        id="eventTitle"
                        required
                        maxlength="255"
                        placeholder="Event title"
                    >

                </div>

                <div class="form-group">

                    <label>
                        Start
                    </label>

                    <input
                        id="eventStart"
                        type="datetime-local"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>
                        End
                    </label>

                    <input
                        id="eventEnd"
                        type="datetime-local"
                        required
                    >

                </div>

                <div class="form-group full">

                    <label>
                        Location
                    </label>

                    <input
                        id="eventLocation"
                        maxlength="255"
                        placeholder="Optional"
                    >

                </div>

                <div class="form-group full">

                    <label>
                        Description
                    </label>

                    <textarea
                        id="eventDescription"
                        maxlength="5000"
                        placeholder="Optional notes..."
                    ></textarea>

                </div>

                <div class="form-group">

                    <label>
                        Priority
                    </label>

                    <select id="eventPriority">

                        <option value="normal">
                            Normal
                        </option>

                        <option value="high">
                            High
                        </option>

                    </select>

                </div>

                <div class="form-group">

                    <label>
                        Reminder
                    </label>

                    <select id="eventReminder">

                        <option value="">
                            None
                        </option>

                        <option value="5">
                            5 minutes before
                        </option>

                        <option value="15">
                            15 minutes before
                        </option>

                        <option value="30">
                            30 minutes before
                        </option>

                        <option value="60">
                            1 hour before
                        </option>

                        <option value="1440">
                            1 day before
                        </option>

                    </select>

                </div>

                <div class="form-group full">

                    <label>
                        Color
                    </label>

                    <div
                        id="colorOptions"
                        class="color-options"
                    ></div>

                </div>

                <div class="form-group full">

                    <label>

                        <input
                            type="checkbox"
                            id="eventAllDay"
                        >

                        All-day event

                    </label>

                </div>

                <div class="form-group full">

                    <label>
                        Repeat
                    </label>

                    <div class="recurrence-builder">

                        <div class="recurrence-interval-row">

                            <span>Every</span>

                            <input
                                id="recurrenceInterval"
                                type="number"
                                min="1"
                                max="999"
                                value="1"
                                class="recurrence-interval"
                                oninput="updateRecurrenceBuilder()"
                            >

                            <select
                                id="recurrenceUnit"
                                onchange="updateRecurrenceBuilder()"
                            >
                                <option value="none">Does not repeat</option>
                                <option value="days">day(s)</option>
                                <option value="weeks">week(s)</option>
                                <option value="months">month(s)</option>
                            </select>

                        </div>

                        <div
                            id="recurrenceDaysBox"
                            class="recurrence-subsection"
                            style="display:none;"
                        >
                            <div class="recurrence-help">
                                Repeat on
                            </div>

                            <div id="recurrenceDays" class="recurrence-days">
                                <button type="button" class="recurrence-day" data-day="sunday" onclick="toggleRecurrenceDay('sunday')">Su</button>
                                <button type="button" class="recurrence-day" data-day="monday" onclick="toggleRecurrenceDay('monday')">Mo</button>
                                <button type="button" class="recurrence-day" data-day="tuesday" onclick="toggleRecurrenceDay('tuesday')">Tu</button>
                                <button type="button" class="recurrence-day" data-day="wednesday" onclick="toggleRecurrenceDay('wednesday')">We</button>
                                <button type="button" class="recurrence-day" data-day="thursday" onclick="toggleRecurrenceDay('thursday')">Th</button>
                                <button type="button" class="recurrence-day" data-day="friday" onclick="toggleRecurrenceDay('friday')">Fr</button>
                                <button type="button" class="recurrence-day" data-day="saturday" onclick="toggleRecurrenceDay('saturday')">Sa</button>
                            </div>
                        </div>

                        <div
                            id="recurrenceMonthBox"
                            class="recurrence-subsection"
                            style="display:none;"
                        >
                            <label for="recurrenceMonthDay">
                                Day of the month
                            </label>

                            <input
                                id="recurrenceMonthDay"
                                type="number"
                                min="1"
                                max="31"
                                value="1"
                                oninput="updateRecurrenceBuilder()"
                            >

                            <div class="recurrence-help">
                                Months without that date will be skipped.
                            </div>
                        </div>

                    </div>

                    <input type="hidden" id="eventRecurrence" value="">

                </div>

            </div>

            <div class="modal-actions">

                <div
                    id="deleteArea"
                    class="delete-area"
                ></div>

                <button
                    type="button"
                    onclick="closeModal()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="primary"
                >
                    Save Event
                </button>

            </div>

        </form>

    </div>

</div>



<div
    id="dayDetailsModal"
    class="modal-overlay day-details-modal"
    onclick="closeDayDetailsOutside(event)"
>
    <div class="modal">
        <h2 id="dayDetailsTitle">Day</h2>

        <div
            id="dayDetailsList"
            class="day-details-list"
        ></div>

        <div class="day-details-actions">
            <button
                type="button"
                onclick="closeDayDetails()"
            >
                Close
            </button>

            <button
                type="button"
                class="primary"
                onclick="createEventFromDayDetails()"
            >
                New Event
            </button>
        </div>
    </div>
</div>

<script>

const API = 'api.php';

const COLORS = [
    '#6366f1',
    '#3b82f6',
    '#22c55e',
    '#ef4444',
    '#f97316',
    '#a855f7',
    '#ec4899',
    '#14b8a6',
    '#64748b'
];

let currentDate = new Date();

let events = [];

let selectedColor = '#6366f1';

let recurrenceDays = new Set();

let pendingAI = null;

let selectedDayDetailsDate = null;

let editScope = 'series';
let editOccurrenceStart = null;


/* =========================================================
   CONTINUOUS AI CONVERSATION
   ========================================================= */

/*
 * Keep the five most recent exchanges:
 * 5 user messages + 5 assistant messages = 10 messages.
 */
const AI_MAX_CONTEXT = 10;
const AI_STORAGE_KEY = 'ai_calendar_conversation_v2';

let aiConversation = [];


/*
 * Load the conversation from this browser so the chat remains
 * available after navigation or a page refresh.
 */
function loadAIConversation() {

    try {

        const stored =
            localStorage.getItem(
                AI_STORAGE_KEY
            );

        if (!stored) {
            aiConversation = [];
            return;
        }

        const parsed =
            JSON.parse(stored);

        if (!Array.isArray(parsed)) {
            aiConversation = [];
            return;
        }

        aiConversation =
            parsed
                .filter(message =>
                    message &&
                    (
                        message.role === 'user' ||
                        message.role === 'assistant'
                    ) &&
                    String(message.content || '').trim() !== ''
                )
                .slice(-AI_MAX_CONTEXT);

    } catch (error) {

        aiConversation = [];
    }
}


function saveAIConversation() {

    try {

        localStorage.setItem(
            AI_STORAGE_KEY,
            JSON.stringify(
                aiConversation.slice(-AI_MAX_CONTEXT)
            )
        );

    } catch (error) {
        /* Ignore localStorage failures. */
    }
}


/*
 * Add one message to the visible conversation.
 */
function addAIMessage(
    role,
    content
) {

    content =
        String(
            content || ''
        ).trim();

    if (!content) {
        return;
    }

    aiConversation.push({
        role:
            role === 'user'
                ? 'user'
                : 'assistant',

        content:
            content
    });

    if (
        aiConversation.length >
        AI_MAX_CONTEXT
    ) {

        aiConversation =
            aiConversation.slice(
                -AI_MAX_CONTEXT
            );
    }

    saveAIConversation();

    renderAIChat();
}


/*
 * Render the chat without clearing the actual conversation
 * state.
 */
function renderAIChat() {

    const chats =
        document.querySelectorAll(
            '#aiChat'
        );

    chats.forEach(chat => {

        chat.innerHTML = '';

        aiConversation.forEach(
            message => {

                const div =
                    document.createElement(
                        'div'
                    );

                div.className =
                    'ai-message ' +
                    message.role;

                div.textContent =
                    message.content;

                chat.appendChild(
                    div
                );
            }
        );

        /*
         * pendingAI contains changes waiting for confirmation.
         * Rebuild the confirmation controls after rendering the
         * messages so they are not erased by a later render.
         */
        if (
            pendingAI &&
            Array.isArray(pendingAI) &&
            pendingAI.length
        ) {

            const wrapper =
                document.createElement(
                    'div'
                );

            wrapper.className =
                'ai-message assistant ai-confirmation';

            const text =
                document.createElement(
                    'div'
                );

            text.textContent =
                'Confirm these calendar changes?';

            wrapper.appendChild(
                text
            );

            pendingAI.forEach((action, index) => {

                if (action.action !== 'update') {
                    return;
                }

                const existing = events.find(
                    event => Number(event.id) === Number(action.id)
                );

                const recurring =
                    !!existing &&
                    String(existing.recurrence || '').trim() !== '';

                if (!recurring) {
                    return;
                }

                const scopeText =
                    document.createElement('div');

                scopeText.textContent =
                    'Apply update to:';
                scopeText.style.marginTop = '9px';
                scopeText.style.fontSize = '11px';
                scopeText.style.fontWeight = '700';
                scopeText.style.color = '#71717a';

                wrapper.appendChild(scopeText);

                const scopeActions =
                    document.createElement('div');

                scopeActions.className = 'confirm-actions';

                const instance =
                    document.createElement('button');
                instance.type = 'button';
                instance.textContent = 'This instance';
                instance.className =
                    action.scope === 'instance' ? 'primary' : '';
                instance.onclick = function () {
                    action.scope = 'instance';
                    renderAIChat();
                };

                const series =
                    document.createElement('button');
                series.type = 'button';
                series.textContent = 'All instances';
                series.className =
                    action.scope === 'series' ? 'primary' : '';
                series.onclick = function () {
                    action.scope = 'series';
                    renderAIChat();
                };

                scopeActions.appendChild(instance);
                scopeActions.appendChild(series);
                wrapper.appendChild(scopeActions);
            });

            const actions =
                document.createElement('div');

            actions.className = 'confirm-actions';

            const confirm =
                document.createElement('button');
            confirm.type = 'button';
            confirm.className = 'primary';
            confirm.textContent = 'Confirm';
            confirm.onclick = function () {
                applyAI();
            };

            const cancel =
                document.createElement('button');
            cancel.type = 'button';
            cancel.textContent = 'Cancel';
            cancel.onclick = function () {
                cancelAI();
            };

            actions.appendChild(confirm);
            actions.appendChild(cancel);
            wrapper.appendChild(actions);

            chat.appendChild(
                wrapper
            );
        }

        chat.scrollTop =
            chat.scrollHeight;
    });
}



/*
 * Return exactly the previous five exchanges at most.
 */
function getAIContext() {

    return aiConversation
        .slice(-AI_MAX_CONTEXT)
        .map(
            message => ({
                role:
                    message.role,

                content:
                    message.content
            })
        );
}


function clearAIConversation() {

    aiConversation = [];

    pendingAI = null;

    try {
        localStorage.removeItem(
            AI_STORAGE_KEY
        );
    } catch (error) {
        /* Ignore storage errors. */
    }

    renderAIChat();
}


loadAIConversation();

/* =========================================================
   DATE HELPERS
   ========================================================= */

function pad(n) {
    return String(n).padStart(2, '0');
}


function localDateTimeString(date) {

    return date.getFullYear() +
        '-' +
        pad(date.getMonth() + 1) +
        '-' +
        pad(date.getDate()) +
        ' ' +
        pad(date.getHours()) +
        ':' +
        pad(date.getMinutes()) +
        ':00';
}


function inputDateTime(date) {

    return date.getFullYear() +
        '-' +
        pad(date.getMonth() + 1) +
        '-' +
        pad(date.getDate()) +
        'T' +
        pad(date.getHours()) +
        ':' +
        pad(date.getMinutes());
}


function parseDatabaseDate(value) {

    if (!value) {
        return null;
    }

    return new Date(
        value.replace(' ', 'T')
    );
}


/* =========================================================
   CALENDAR
   ========================================================= */

async function loadCalendar() {

    const year =
        currentDate.getFullYear();

    const month =
        currentDate.getMonth();

    const first =
        new Date(
            year,
            month,
            1
        );

    const gridStart =
        new Date(
            year,
            month,
            1 - first.getDay()
        );

    const gridEnd =
        new Date(
            gridStart.getFullYear(),
            gridStart.getMonth(),
            gridStart.getDate() + 34
        );

    const start =
        localDateTimeString(
            gridStart
        );

    const end =
        localDateTimeString(
            new Date(
                gridEnd.getFullYear(),
                gridEnd.getMonth(),
                gridEnd.getDate() + 1
            )
        );

    try {

        const response =
            await fetch(
                API +
                '?action=list&start=' +
                encodeURIComponent(start) +
                '&end=' +
                encodeURIComponent(end)
            );

        const data =
            await response.json();

        if (!data.ok) {
            throw new Error(
                data.error ||
                'Could not load calendar.'
            );
        }

        events =
            Array.isArray(data.events)
                ? data.events
                : [];

        renderCalendar();

    } catch (error) {

        alert(error.message);
    }
}


function renderCalendar() {

    const year =
        currentDate.getFullYear();

    const month =
        currentDate.getMonth();

    const title =
        currentDate.toLocaleString(
            'default',
            {
                month: 'long',
                year: 'numeric'
            }
        );

    document.getElementById(
        'calendarTitle'
    ).textContent = title;

    updateCalendarPickers();

    const grid =
        document.getElementById(
            'calendarGrid'
        );

    grid.innerHTML = '';

    const first =
        new Date(
            year,
            month,
            1
        );

    const start =
        new Date(
            year,
            month,
            1 - first.getDay()
        );

    /*
     * Use the smallest complete set of calendar weeks needed for the
     * month. Most months need 5 rows, while some need 6. The grid rows
     * are then stretched evenly to fill the available calendar area.
     */
    const daysInCurrentMonth =
        new Date(
            year,
            month + 1,
            0
        ).getDate();

    const calendarCellCount =
        Math.max(
            35,
            Math.ceil(
                (first.getDay() + daysInCurrentMonth) / 7
            ) * 7
        );

    grid.style.setProperty(
        '--calendar-rows',
        String(calendarCellCount / 7)
    );

    const today =
        new Date();

    for (
        let i = 0;
        i < calendarCellCount;
        i++
    ) {

        const date =
            new Date(
                start.getFullYear(),
                start.getMonth(),
                start.getDate() + i
            );

        const day =
            document.createElement(
                'div'
            );

        day.className = 'day';

        if (
            date.getMonth() !== month
        ) {
            day.classList.add(
                'other-month'
            );
        }

        if (
            date.getFullYear() === today.getFullYear() &&
            date.getMonth() === today.getMonth() &&
            date.getDate() === today.getDate()
        ) {
            day.classList.add(
                'today'
            );
        }

        day.onclick =
            function(event) {

                if (
                    event.target.closest(
                        '.event'
                    )
                ) {
                    return;
                }

                openDayDetails(
                    date
                );
            };

        const number =
            document.createElement(
                'div'
            );

        number.className =
            'day-number';

        const numberSpan =
            document.createElement(
                'span'
            );

        numberSpan.textContent =
            date.getDate();

        number.appendChild(
            numberSpan
        );

        day.appendChild(
            number
        );

        const eventContainer =
            document.createElement(
                'div'
            );

        eventContainer.className =
            'events';

        const dayEvents =
            getEventsForDay(
                date
            );

        dayEvents
            .forEach(
                event => {

                    const button =
                        document.createElement(
                            'button'
                        );

                    button.className =
                        'event';

                    if (
                        event.priority === 'high'
                    ) {
                        button.classList.add(
                            'high'
                        );
                    }

                    button.style.background =
                        event.color ||
                        '#6366f1';

                    button.textContent =
                        formatEventLabel(
                            event
                        );

                    button.title =
                        'Edit ' + (event.title || 'event');

                    button.setAttribute(
                        'aria-label',
                        'Edit ' + (event.title || 'event')
                    );

                    button.onclick =
                        function(e) {

                            e.preventDefault();
                            e.stopPropagation();

                            openEditEvent(
                                event
                            );
                        };

                    eventContainer.appendChild(
                        button
                    );
                }
            );

        day.appendChild(
            eventContainer
        );

        grid.appendChild(
            day
        );
    }
}


function getEventsForDay(date) {

    const dayStart = new Date(
        date.getFullYear(),
        date.getMonth(),
        date.getDate()
    );

    const dayEnd = new Date(
        date.getFullYear(),
        date.getMonth(),
        date.getDate() + 1
    );

    const weekdayNames = [
        'sunday',
        'monday',
        'tuesday',
        'wednesday',
        'thursday',
        'friday',
        'saturday'
    ];

    const weekday = weekdayNames[date.getDay()];
    const result = [];

    function weeksBetween(a, b) {
        return Math.floor(
            (b.getTime() - a.getTime()) / 604800000
        );
    }

    function monthsBetween(a, b) {
        return (
            (b.getFullYear() - a.getFullYear()) * 12 +
            (b.getMonth() - a.getMonth())
        );
    }

    function daysInMonth(year, month) {
        return new Date(year, month + 1, 0).getDate();
    }

    events.forEach(event => {

        const start = parseDatabaseDate(event.start_time);
        const end = parseDatabaseDate(event.end_time);

        if (!start || !end) return;

        const recurrence = String(event.recurrence || '')
            .trim()
            .toLowerCase();

        let occurs = false;

        if (!recurrence) {
            occurs = start < dayEnd && end > dayStart;
        } else if (recurrence.startsWith('weekly:') ||
                   recurrence.startsWith('biweekly:')) {

            const isBiweekly = recurrence.startsWith('biweekly:');
            const prefix = isBiweekly ? 'biweekly:' : 'weekly:';

            const days = recurrence
                .substring(prefix.length)
                .split(',')
                .map(day => day.trim())
                .filter(Boolean);

            if (days.includes(weekday)) {
                const recurrenceWeekStart = new Date(
                    start.getFullYear(),
                    start.getMonth(),
                    start.getDate() - start.getDay()
                );

                if (dayStart >= recurrenceWeekStart) {
                    const diffWeeks = weeksBetween(
                        recurrenceWeekStart,
                        dayStart
                    );

                    occurs =
                        !isBiweekly ||
                        diffWeeks % 2 === 0;
                }
            }
        } else if (recurrence.startsWith('every:')) {

            const parts = recurrence.split(':');
            const interval = Math.max(1, parseInt(parts[1], 10) || 1);
            const unit = parts[2];

            if (unit === 'days') {
                const anchor = new Date(
                    start.getFullYear(),
                    start.getMonth(),
                    start.getDate()
                );

                const diffDays = Math.floor(
                    (dayStart.getTime() - anchor.getTime()) / 86400000
                );

                occurs =
                    diffDays >= 0 &&
                    diffDays % interval === 0;

            } else if (unit === 'weeks') {
                const days = (parts[3] || '')
                    .split(',')
                    .map(day => day.trim())
                    .filter(Boolean);

                const recurrenceWeekStart = new Date(
                    start.getFullYear(),
                    start.getMonth(),
                    start.getDate() - start.getDay()
                );

                if (
                    dayStart >= recurrenceWeekStart &&
                    days.includes(weekday)
                ) {
                    const diffWeeks = weeksBetween(
                        recurrenceWeekStart,
                        dayStart
                    );

                    occurs =
                        diffWeeks >= 0 &&
                        diffWeeks % interval === 0;
                }

            } else if (unit === 'months') {
                const targetDay = Math.max(
                    1,
                    Math.min(31, parseInt(parts[3], 10) || start.getDate())
                );

                const diffMonths = monthsBetween(
                    new Date(start.getFullYear(), start.getMonth(), 1),
                    new Date(date.getFullYear(), date.getMonth(), 1)
                );

                /*
                 * A monthly event stays on its original day of the month.
                 * If that day does not exist in a month (for example the
                 * 31st), that month simply has no occurrence.
                 */
                occurs =
                    diffMonths >= 0 &&
                    diffMonths % interval === 0 &&
                    date.getDate() === targetDay &&
                    targetDay <= daysInMonth(
                        date.getFullYear(),
                        date.getMonth()
                    );
            }
        }

        if (!occurs) return;

        const duration = Math.max(
            0,
            end.getTime() - start.getTime()
        );

        const occurrenceStart = new Date(dayStart);
        occurrenceStart.setHours(
            start.getHours(),
            start.getMinutes(),
            start.getSeconds(),
            0
        );

        const occurrenceEnd = new Date(
            occurrenceStart.getTime() + duration
        );

        const occurrenceKey = localDateTimeString(occurrenceStart);

        const exceptions = Array.isArray(event.exceptions)
            ? event.exceptions
            : [];

        const exception = exceptions.find(
            item => String(item.occurrence_start || '') === occurrenceKey
        );

        if (exception && Number(exception.is_deleted) === 1) return;

        const occurrence = {
            ...event,
            start_time: localDateTimeString(occurrenceStart),
            end_time: localDateTimeString(occurrenceEnd),
            _recurringOccurrence: true,
            _occurrenceStart: occurrenceKey
        };

        if (
            exception &&
            exception.data &&
            typeof exception.data === 'object'
        ) {
            Object.assign(occurrence, exception.data);
        }

        occurrence.id = event.id;
        occurrence.recurrence = event.recurrence;
        occurrence.exceptions = event.exceptions;
        occurrence._recurringOccurrence = true;
        occurrence._occurrenceStart = occurrenceKey;

        result.push(occurrence);
    });

    result.sort((a, b) => {
        const aStart = parseDatabaseDate(a.start_time);
        const bStart = parseDatabaseDate(b.start_time);

        return (aStart?.getTime() || 0) - (bStart?.getTime() || 0);
    });

    return result;
}

function formatEventLabel(event) {

    if (event.all_day == 1) {
        return event.title;
    }

    const start =
        parseDatabaseDate(
            event.start_time
        );

    if (!start) {
        return event.title;
    }

    const time =
        start.toLocaleTimeString(
            [],
            {
                hour: 'numeric',
                minute: '2-digit'
            }
        );

    return time +
        ' ' +
        event.title;
}


/* =========================================================
   NAVIGATION
   ========================================================= */

function updateCalendarPickers() {

    const monthPicker =
        document.getElementById(
            'monthPicker'
        );

    const yearPicker =
        document.getElementById(
            'yearPicker'
        );

    if (!monthPicker || !yearPicker) {
        return;
    }

    const months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ];

    monthPicker.innerHTML =
        months
            .map(
                (month, index) =>
                    '<option value="' +
                    index +
                    '">' +
                    month +
                    '</option>'
            )
            .join('');

    const currentYear =
        currentDate.getFullYear();

    const minYear =
        currentYear - 5;

    const maxYear =
        currentYear + 5;

    yearPicker.innerHTML = '';

    for (
        let year = minYear;
        year <= maxYear;
        year++
    ) {

        const option =
            document.createElement(
                'option'
            );

        option.value =
            String(year);

        option.textContent =
            String(year);

        yearPicker.appendChild(
            option
        );
    }

    monthPicker.value =
        String(
            currentDate.getMonth()
        );

    yearPicker.value =
        String(
            currentYear
        );
}


function previousMonth() {

    currentDate =
        new Date(
            currentDate.getFullYear(),
            currentDate.getMonth() - 1,
            1
        );

    loadCalendar();
}


function nextMonth() {

    currentDate =
        new Date(
            currentDate.getFullYear(),
            currentDate.getMonth() + 1,
            1
        );

    loadCalendar();
}


function goToday() {

    const now =
        new Date();

    currentDate =
        new Date(
            now.getFullYear(),
            now.getMonth(),
            1
        );

    loadCalendar();
}


function jumpToSelectedMonth() {

    const monthPicker =
        document.getElementById(
            'monthPicker'
        );

    const yearPicker =
        document.getElementById(
            'yearPicker'
        );

    if (!monthPicker || !yearPicker) {
        return;
    }

    currentDate =
        new Date(
            Number(yearPicker.value),
            Number(monthPicker.value),
            1
        );

    loadCalendar();
}


/* =========================================================
   MODAL
   ========================================================= */

function renderColors() {

    const container =
        document.getElementById(
            'colorOptions'
        );

    container.innerHTML = '';

    COLORS.forEach(
        color => {

            const button =
                document.createElement(
                    'button'
                );

            button.type =
                'button';

            button.className =
                'color-option';

            if (
                color === selectedColor
            ) {
                button.classList.add(
                    'selected'
                );
            }

            button.style.background =
                color;

            button.onclick =
                function() {

                    selectedColor =
                        color;

                    renderColors();
                };

            container.appendChild(
                button
            );
        }
    );
}


function renderRecurrenceDays() {

    document
        .querySelectorAll('#recurrenceDays .recurrence-day')
        .forEach(button => {
            const day = button.dataset.day;
            button.classList.toggle(
                'selected',
                recurrenceDays.has(day)
            );
        });
}


function setRecurrenceDays(value) {
    recurrenceDays = new Set();

    const recurrence = String(value || '').trim().toLowerCase();

    if (
        recurrence.startsWith('weekly:') ||
        recurrence.startsWith('biweekly:')
    ) {
        const prefix = recurrence.startsWith('biweekly:')
            ? 'biweekly:'
            : 'weekly:';

        recurrence
            .substring(prefix.length)
            .split(',')
            .map(day => day.trim())
            .filter(Boolean)
            .forEach(day => recurrenceDays.add(day));
    }

    renderRecurrenceDays();
}


function setRecurrenceRule(value) {

    const recurrence = String(value || '').trim().toLowerCase();

    const intervalInput = document.getElementById('recurrenceInterval');
    const unitInput = document.getElementById('recurrenceUnit');
    const monthDayInput = document.getElementById('recurrenceMonthDay');

    recurrenceDays = new Set();

    if (!recurrence) {
        intervalInput.value = '1';
        unitInput.value = 'none';
        monthDayInput.value = '1';
        updateRecurrenceBuilder();
        return;
    }

    if (recurrence.startsWith('weekly:')) {
        intervalInput.value = '1';
        unitInput.value = 'weeks';
        recurrence.substring(7).split(',').forEach(day => {
            if (day.trim()) recurrenceDays.add(day.trim());
        });
    } else if (recurrence.startsWith('biweekly:')) {
        intervalInput.value = '2';
        unitInput.value = 'weeks';
        recurrence.substring(9).split(',').forEach(day => {
            if (day.trim()) recurrenceDays.add(day.trim());
        });
    } else if (recurrence.startsWith('every:')) {
        const parts = recurrence.split(':');
        intervalInput.value = Math.max(1, parseInt(parts[1], 10) || 1);
        unitInput.value = parts[2] || 'none';

        if (parts[2] === 'weeks') {
            (parts[3] || '').split(',').forEach(day => {
                if (day.trim()) recurrenceDays.add(day.trim());
            });
        } else if (parts[2] === 'months') {
            monthDayInput.value = Math.max(
                1,
                Math.min(31, parseInt(parts[3], 10) || 1)
            );
        }
    } else {
        intervalInput.value = '1';
        unitInput.value = 'none';
        monthDayInput.value = '1';
    }

    updateRecurrenceBuilder();
}


function updateRecurrenceBuilder() {

    const unitInput = document.getElementById('recurrenceUnit');
    const intervalInput = document.getElementById('recurrenceInterval');
    const daysBox = document.getElementById('recurrenceDaysBox');
    const monthBox = document.getElementById('recurrenceMonthBox');

    if (!unitInput || !intervalInput) return;

    let unit = unitInput.value;
    let interval = Math.max(
        1,
        Math.min(999, parseInt(intervalInput.value, 10) || 1)
    );

    intervalInput.value = interval;

    daysBox.style.display = unit === 'weeks' ? 'flex' : 'none';
    monthBox.style.display = unit === 'months' ? 'flex' : 'none';

    renderRecurrenceDays();

    document.getElementById('eventRecurrence').value =
        buildRecurrenceValue();
}


function toggleRecurrenceDay(day) {

    if (editScope === 'instance') {
        return;
    }

    if (recurrenceDays.has(day)) {
        recurrenceDays.delete(day);
    } else {
        recurrenceDays.add(day);
    }

    updateRecurrenceBuilder();
}


function buildRecurrenceValue() {

    const unit =
        document.getElementById('recurrenceUnit')?.value || 'none';

    if (unit === 'none') {
        return '';
    }

    const interval = Math.max(
        1,
        Math.min(
            999,
            parseInt(
                document.getElementById('recurrenceInterval')?.value,
                10
            ) || 1
        )
    );

    if (unit === 'days') {
        return 'every:' + interval + ':days';
    }

    if (unit === 'weeks') {
        const order = [
            'sunday',
            'monday',
            'tuesday',
            'wednesday',
            'thursday',
            'friday',
            'saturday'
        ];

        const selected = order.filter(
            day => recurrenceDays.has(day)
        );

        if (!selected.length) {
            return '';
        }

        /*
         * Keep the old formats for weekly and every-other-week
         * so existing calendar data remains compatible.
         */
        if (interval === 1) {
            return 'weekly:' + selected.join(',');
        }

        if (interval === 2) {
            return 'biweekly:' + selected.join(',');
        }

        return 'every:' + interval + ':weeks:' + selected.join(',');
    }

    if (unit === 'months') {
        const day = Math.max(
            1,
            Math.min(
                31,
                parseInt(
                    document.getElementById('recurrenceMonthDay')?.value,
                    10
                ) || 1
            )
        );

        return 'every:' + interval + ':months:' + day;
    }

    return '';
}

function setEditScope(scope) {

    editScope = scope === 'instance'
        ? 'instance'
        : 'series';

    const instanceButton = document.getElementById('scopeInstance');
    const seriesButton = document.getElementById('scopeSeries');

    if (instanceButton) {
        instanceButton.classList.toggle(
            'selected',
            editScope === 'instance'
        );
    }

    if (seriesButton) {
        seriesButton.classList.toggle(
            'selected',
            editScope === 'series'
        );
    }

    const recurrenceDaysBox = document.getElementById('recurrenceDays');
    const recurrenceGroup = recurrenceDaysBox
        ? recurrenceDaysBox.closest('.form-group')
        : null;

    if (recurrenceGroup) {
        recurrenceGroup.style.opacity =
            editScope === 'instance' ? '0.55' : '1';
    }
}

function openModal() {

    document
        .getElementById(
            'eventModal'
        )
        .classList.add(
            'open'
        );
}


function closeModal() {

    document
        .getElementById(
            'eventModal'
        )
        .classList.remove(
            'open'
        );
}


function closeModalOutside(event) {

    if (
        event.target.id ===
        'eventModal'
    ) {
        closeModal();
    }
}


function formatDayDetailsDate(date) {
    return date.toLocaleDateString(
        [],
        {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric'
        }
    );
}


function formatDayDetailsTime(event) {
    if (event.all_day == 1) {
        return 'All day';
    }

    const start =
        parseDatabaseDate(
            event.start_time
        );

    const end =
        parseDatabaseDate(
            event.end_time
        );

    if (!start) {
        return '';
    }

    const startText =
        start.toLocaleTimeString(
            [],
            {
                hour: 'numeric',
                minute: '2-digit'
            }
        );

    if (!end) {
        return startText;
    }

    const endText =
        end.toLocaleTimeString(
            [],
            {
                hour: 'numeric',
                minute: '2-digit'
            }
        );

    return startText +
        ' – ' +
        endText;
}


function describeRecurrence(event) {

    const recurrence =
        String(event.recurrence || '').trim().toLowerCase();

    if (!recurrence) {
        return '';
    }

    const labels = {
        sunday: 'Sun',
        monday: 'Mon',
        tuesday: 'Tue',
        wednesday: 'Wed',
        thursday: 'Thu',
        friday: 'Fri',
        saturday: 'Sat'
    };

    if (
        recurrence.startsWith('weekly:') ||
        recurrence.startsWith('biweekly:')
    ) {
        const isBiweekly = recurrence.startsWith('biweekly:');
        const prefix = isBiweekly ? 'biweekly:' : 'weekly:';

        const days = recurrence
            .substring(prefix.length)
            .split(',')
            .map(day => labels[day.trim()] || day.trim())
            .filter(Boolean);

        return days.length
            ? (
                isBiweekly
                    ? 'Repeats every other week: '
                    : 'Repeats every week: '
            ) + days.join(', ')
            : '';
    }

    if (recurrence.startsWith('every:')) {
        const parts = recurrence.split(':');
        const interval = parseInt(parts[1], 10) || 1;
        const unit = parts[2];

        if (unit === 'days') {
            return interval === 1
                ? 'Repeats every day'
                : 'Repeats every ' + interval + ' days';
        }

        if (unit === 'weeks') {
            const days = (parts[3] || '')
                .split(',')
                .map(day => labels[day.trim()] || day.trim())
                .filter(Boolean);

            const frequency =
                interval === 1
                    ? 'every week'
                    : 'every ' + interval + ' weeks';

            return 'Repeats ' + frequency +
                (days.length ? ' on ' + days.join(', ') : '');
        }

        if (unit === 'months') {
            const day = parseInt(parts[3], 10) || 1;

            return interval === 1
                ? 'Repeats monthly on the ' + day + getOrdinalSuffix(day)
                : 'Repeats every ' + interval +
                    ' months on the ' + day + getOrdinalSuffix(day);
        }
    }

    return '';
}


function getOrdinalSuffix(number) {
    const n = Math.abs(Number(number));
    const mod100 = n % 100;

    if (mod100 >= 11 && mod100 <= 13) {
        return 'th';
    }

    switch (n % 10) {
        case 1: return 'st';
        case 2: return 'nd';
        case 3: return 'rd';
        default: return 'th';
    }
}


function openDayDetails(date) {
    const modal =
        document.getElementById(
            'dayDetailsModal'
        );

    const title =
        document.getElementById(
            'dayDetailsTitle'
        );

    const list =
        document.getElementById(
            'dayDetailsList'
        );

    if (
        !modal ||
        !title ||
        !list
    ) {
        return;
    }

    selectedDayDetailsDate =
        new Date(date);

    title.textContent =
        formatDayDetailsDate(date);

    const dayEvents =
        getEventsForDay(date);

    list.innerHTML = '';

    if (!dayEvents.length) {

        list.innerHTML =
            '<div class="day-details-empty">' +
            'No events or reminders for this day.' +
            '</div>';

    } else {

        dayEvents.forEach(
            event => {

                const item =
                    document.createElement(
                        'div'
                    );

                item.className =
                    'day-details-item';

                const head =
                    document.createElement(
                        'div'
                    );

                head.className =
                    'day-details-item-head';

                const eventTitle =
                    document.createElement(
                        'div'
                    );

                eventTitle.className =
                    'day-details-item-title';

                eventTitle.textContent =
                    event.title ||
                    'Untitled';

                const type =
                    document.createElement(
                        'div'
                    );

                type.className =
                    'day-details-type';

                type.textContent =
                    String(
                        event.item_type ||
                        'event'
                    ) === 'reminder'
                        ? 'Reminder'
                        : 'Event';

                head.appendChild(
                    eventTitle
                );

                head.appendChild(
                    type
                );

                item.appendChild(
                    head
                );

                const time =
                    document.createElement(
                        'div'
                    );

                time.className =
                    'day-details-time';

                time.textContent =
                    formatDayDetailsTime(
                        event
                    );

                item.appendChild(
                    time
                );

                if (event.description) {
                    const description =
                        document.createElement(
                            'div'
                        );

                    description.className =
                        'day-details-description';

                    description.textContent =
                        event.description;

                    item.appendChild(
                        description
                    );
                }

                if (event.location) {
                    const location =
                        document.createElement(
                            'div'
                        );

                    location.className =
                        'day-details-location';

                    location.textContent =
                        'Location: ' +
                        event.location;

                    item.appendChild(
                        location
                    );
                }

                const recurrence =
                    describeRecurrence(
                        event
                    );

                if (recurrence) {
                    const recurrenceText =
                        document.createElement(
                            'div'
                        );

                    recurrenceText.className =
                        'day-details-recurrence';

                    recurrenceText.textContent =
                        recurrence;

                    item.appendChild(
                        recurrenceText
                    );
                }

                const edit =
                    document.createElement(
                        'button'
                    );

                edit.type =
                    'button';

                edit.className =
                    'primary';

                edit.textContent =
                    'Edit';

                edit.style.marginTop =
                    '9px';

                edit.onclick =
                    function () {
                        closeDayDetails();
                        openEditEvent(
                            event
                        );
                    };

                item.appendChild(
                    edit
                );

                list.appendChild(
                    item
                );
            }
        );
    }

    modal.classList.add('open');
}


function closeDayDetails() {
    const modal =
        document.getElementById(
            'dayDetailsModal'
        );

    if (modal) {
        modal.classList.remove(
            'open'
        );
    }
}


function closeDayDetailsOutside(event) {
    if (
        event.target.id ===
        'dayDetailsModal'
    ) {
        closeDayDetails();
    }
}


function createEventFromDayDetails() {
    const date =
        selectedDayDetailsDate ||
        new Date();

    closeDayDetails();

    openCreateForDate(
        date
    );
}


/* =========================================================
   CREATE EVENT
   ========================================================= */

function openCreateForToday() {

    openCreateForDate(
        new Date()
    );
}


function openCreateReminder() {

    editScope = 'series';
    editOccurrenceStart = null;

    const now =
        new Date();

    const minute =
        Math.ceil(
            now.getMinutes() / 5
        ) * 5;

    const start =
        new Date(
            now.getFullYear(),
            now.getMonth(),
            now.getDate(),
            now.getHours(),
            minute,
            0,
            0
        );

    const end =
        new Date(
            start.getTime() +
            5 * 60000
        );

    document.getElementById(
        'modalTitle'
    ).textContent =
        'New Reminder';

    document.getElementById(
        'modalTypeHint'
    ).textContent =
        'Reminder — a prompt to do something, not a scheduled event.';

    document.getElementById(
        'eventType'
    ).value =
        'reminder';

    document.getElementById(
        'eventId'
    ).value =
        '';

    document.getElementById(
        'eventTitle'
    ).value =
        '';

    document.getElementById(
        'eventDescription'
    ).value =
        '';

    document.getElementById(
        'eventLocation'
    ).value =
        '';

    document.getElementById(
        'eventStart'
    ).value =
        inputDateTime(start);

    document.getElementById(
        'eventEnd'
    ).value =
        inputDateTime(end);

    document.getElementById(
        'eventAllDay'
    ).checked =
        false;

    document.getElementById(
        'eventPriority'
    ).value =
        'normal';

    document.getElementById(
        'eventReminder'
    ).value =
        '';

    selectedColor =
        '#f97316';

    setRecurrenceRule('');

    document.getElementById(
        'deleteArea'
    ).innerHTML =
        '';

    renderColors();

    const scopeBox = document.getElementById('instanceScope');
    if (scopeBox) scopeBox.style.display = 'none';

    openModal();
}


function openCreateForDate(date) {

    editScope = 'series';
    editOccurrenceStart = null;

    const start =
        new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            9,
            0
        );

    const end =
        new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            10,
            0
        );

    document.getElementById(
        'modalTitle'
    ).textContent =
        'New Event';

    document.getElementById(
        'modalTypeHint'
    ).textContent =
        'Calendar event';

    document.getElementById(
        'eventType'
    ).value =
        'event';

    document.getElementById(
        'eventId'
    ).value =
        '';

    document.getElementById(
        'eventTitle'
    ).value =
        '';

    document.getElementById(
        'eventDescription'
    ).value =
        '';

    document.getElementById(
        'eventLocation'
    ).value =
        '';

    document.getElementById(
        'eventStart'
    ).value =
        inputDateTime(start);

    document.getElementById(
        'eventEnd'
    ).value =
        inputDateTime(end);

    document.getElementById(
        'eventAllDay'
    ).checked =
        false;

    document.getElementById(
        'eventPriority'
    ).value =
        'normal';

    document.getElementById(
        'eventReminder'
    ).value =
        '';

    selectedColor =
        '#6366f1';

    setRecurrenceRule('');

    document.getElementById(
        'deleteArea'
    ).innerHTML =
        '';

    renderColors();

    const scopeBox = document.getElementById('instanceScope');
    if (scopeBox) scopeBox.style.display = 'none';

    openModal();
}


/* =========================================================
   EDIT EVENT
   ========================================================= */

function openEditEvent(event) {

    editOccurrenceStart =
        event._occurrenceStart ||
        event.start_time ||
        null;

    const isRecurring =
        !!event._recurringOccurrence &&
        String(event.recurrence || '').trim() !== '';

    editScope = isRecurring ? 'instance' : 'series';

    const scopeBox = document.getElementById('instanceScope');
    if (scopeBox) {
        scopeBox.style.display = isRecurring ? 'block' : 'none';
    }

    const isReminder =
        String(
            event.item_type ||
            'event'
        ) === 'reminder';

    document.getElementById(
        'modalTitle'
    ).textContent =
        isReminder
            ? 'Edit Reminder'
            : 'Edit Event';

    document.getElementById(
        'modalTypeHint'
    ).textContent =
        isReminder
            ? 'Reminder — a prompt to do something, not a scheduled event.'
            : 'Calendar event';

    document.getElementById(
        'eventType'
    ).value =
        isReminder
            ? 'reminder'
            : 'event';

    document.getElementById(
        'eventId'
    ).value =
        event.id;

    document.getElementById(
        'eventTitle'
    ).value =
        event.title || '';

    document.getElementById(
        'eventDescription'
    ).value =
        event.description || '';

    document.getElementById(
        'eventLocation'
    ).value =
        event.location || '';

    const start =
        parseDatabaseDate(
            event.start_time
        );

    const end =
        parseDatabaseDate(
            event.end_time
        );

    document.getElementById(
        'eventStart'
    ).value =
        inputDateTime(start);

    document.getElementById(
        'eventEnd'
    ).value =
        inputDateTime(end);

    document.getElementById(
        'eventAllDay'
    ).checked =
        event.all_day == 1;

    document.getElementById(
        'eventPriority'
    ).value =
        event.priority ||
        'normal';

    document.getElementById(
        'eventReminder'
    ).value =
        event.reminder_minutes ||
        '';

    setRecurrenceRule(
        event.recurrence ||
        ''
    );

    selectedColor =
        event.color ||
        '#6366f1';

    /*
     * Restore the currently selected repeat days in the edit menu.
     */
    recurrenceDays =
        new Set();

    const recurrence =
        String(
            event.recurrence ||
            ''
        )
        .trim()
        .toLowerCase();

    if (
        recurrence.startsWith('weekly:')
    ) {
        recurrence
            .substring(
                'weekly:'.length
            )
            .split(',')
            .map(
                day => day.trim()
            )
            .filter(Boolean)
            .forEach(
                day => recurrenceDays.add(day)
            );
    }

    updateRecurrenceButtons();

    document.getElementById(
        'eventRecurrence'
    ).value =
        buildRecurrenceValue();

    document.getElementById(
        'deleteArea'
    ).innerHTML =
        '<button type="button" class="danger" onclick="deleteCurrentEvent()">Delete</button>';

    renderColors();
    setEditScope(editScope);

    openModal();
}



/* =========================================================
   SAVE EVENT
   ========================================================= */

async function saveEvent(event) {

    event.preventDefault();

    const id =
        document.getElementById(
            'eventId'
        ).value;

    const data =
        new FormData();

    data.append(
        'action',
        id ? 'update' : 'create'
    );

    if (id) {

        data.append(
            'id',
            id
        );
    }

    data.append(
        'title',
        document.getElementById(
            'eventTitle'
        ).value
    );

    data.append(
        'description',
        document.getElementById(
            'eventDescription'
        ).value
    );

    data.append(
        'location',
        document.getElementById(
            'eventLocation'
        ).value
    );

    data.append(
        'start_time',
        document.getElementById(
            'eventStart'
        ).value.replace(
            'T',
            ' '
        ) +
        ':00'
    );

    data.append(
        'end_time',
        document.getElementById(
            'eventEnd'
        ).value.replace(
            'T',
            ' '
        ) +
        ':00'
    );

    data.append(
        'all_day',
        document.getElementById(
            'eventAllDay'
        ).checked
            ? '1'
            : '0'
    );

    data.append(
        'color',
        selectedColor
    );

    data.append(
        'priority',
        document.getElementById(
            'eventPriority'
        ).value
    );

    data.append(
        'item_type',
        document.getElementById(
            'eventType'
        ).value ||
        'event'
    );

    data.append(
        'reminder_minutes',
        document.getElementById(
            'eventReminder'
        ).value
    );

    const recurrenceValue =
        buildRecurrenceValue();

    document.getElementById(
        'eventRecurrence'
    ).value =
        recurrenceValue;

    data.append(
        'recurrence',
        recurrenceValue
    );

    if (id) {
        data.append(
            'scope',
            editScope === 'instance'
                ? 'instance'
                : 'series'
        );

        if (editScope === 'instance' && editOccurrenceStart) {
            data.append(
                'occurrence_start',
                editOccurrenceStart
            );
        }
    }

    try {

        const response =
            await fetch(
                API,
                {
                    method: 'POST',
                    body: data
                }
            );

        const result =
            await response.json();

        if (!result.ok) {
            throw new Error(
                result.error ||
                'Could not save event.'
            );
        }

        closeModal();

        if (
            document.getElementById(
                'calendarGrid'
            )
        ) {

            await loadCalendar();

        } else {

            await loadHome();
        }

    } catch (error) {

        alert(error.message);
    }
}


/* =========================================================
   DELETE EVENT
   ========================================================= */

async function deleteCurrentEvent() {

    const id =
        document.getElementById(
            'eventId'
        ).value;

    if (!id) {
        return;
    }

    const deleteInstance =
        editScope === 'instance' &&
        !!editOccurrenceStart;

    if (
        !confirm(
            deleteInstance
                ? 'Delete this instance only?'
                : 'Delete this event and all of its instances?'
        )
    ) {
        return;
    }

    const data =
        new FormData();

    data.append(
        'action',
        'delete'
    );

    data.append(
        'id',
        id
    );

    data.append(
        'scope',
        deleteInstance ? 'instance' : 'series'
    );

    if (deleteInstance) {
        data.append(
            'occurrence_start',
            editOccurrenceStart
        );
    }

    try {

        const response =
            await fetch(
                API,
                {
                    method: 'POST',
                    body: data
                }
            );

        const result =
            await response.json();

        if (!result.ok) {
            throw new Error(
                result.error ||
                'Could not delete event.'
            );
        }

        closeModal();

        if (
            document.getElementById(
                'calendarGrid'
            )
        ) {

            await loadCalendar();

        } else {

            await loadHome();
        }

    } catch (error) {

        alert(error.message);
    }
}


/* =========================================================
   AI
   ========================================================= */

async function sendAI() {

    const inputs =
        document.querySelectorAll(
            '#aiInput'
        );

    let input = null;

    inputs.forEach(
        element => {

            if (
                !input &&
                element.offsetParent !== null
            ) {
                input = element;
            }
        }
    );

    if (!input) {
        input =
            document.getElementById(
                'aiInput'
            );
    }

    if (!input) {
        return;
    }

    const message =
        input.value.trim();

    if (!message) {
        return;
    }

    const buttons =
        document.querySelectorAll(
            '#aiSend'
        );

    buttons.forEach(
        button => {

            button.disabled =
                true;

            button.textContent =
                'Thinking...';
        }
    );


    /*
     * IMPORTANT:
     * Capture the previous conversation BEFORE adding the
     * current message. This prevents sending the current
     * request twice.
     */
    const previousContext =
        getAIContext();


    addAIMessage(
        'user',
        message
    );

    input.value = '';

    const now =
        new Date();

    const data =
        new FormData();

    data.append(
        'action',
        'ai'
    );

    data.append(
        'message',
        message
    );

    data.append(
        'context',
        JSON.stringify(
            previousContext
        )
    );

    data.append(
        'timezone',
        Intl.DateTimeFormat()
            .resolvedOptions()
            .timeZone
    );

    data.append(
        'now',
        localDateTimeString(
            now
        )
    );


    /*
     * Show a temporary thinking message.
     */
    addAIMessage(
        'assistant',
        'Thinking...'
    );

    try {

        const response =
            await fetch(
                API,
                {
                    method: 'POST',
                    body: data,
                    cache: 'no-store'
                }
            );


        const raw =
            await response.text();


        let result;

        try {

            result =
                raw.trim() !== ''
                    ? JSON.parse(raw)
                    : null;

        } catch (jsonError) {

            throw new Error(
                raw.trim() !== ''
                    ? 'The server returned invalid JSON: ' +
                      raw.substring(0, 500)
                    : 'The server returned an empty response. HTTP status ' +
                      response.status + '.'
            );
        }


        /*
         * Remove the temporary thinking message.
         */
        if (
            aiConversation.length &&
            aiConversation[
                aiConversation.length - 1
            ].role === 'assistant' &&
            aiConversation[
                aiConversation.length - 1
            ].content === 'Thinking...'
        ) {

            aiConversation.pop();

            saveAIConversation();
            renderAIChat();
        }


        if (!result) {
            throw new Error(
                'The server returned an empty response. HTTP status ' +
                response.status + '.'
            );
        }


        if (!result.ok) {

            throw new Error(
                result.error ||
                'AI request failed.'
            );
        }


        handleAIResult(
            result.result
        );

    } catch (error) {

        /*
         * Remove temporary thinking text if it is still present.
         */
        if (
            aiConversation.length &&
            aiConversation[
                aiConversation.length - 1
            ].role === 'assistant' &&
            aiConversation[
                aiConversation.length - 1
            ].content === 'Thinking...'
        ) {

            aiConversation.pop();

            saveAIConversation();
        }

        addAIMessage(
            'assistant',
            error.message ||
            'AI request failed.'
        );

    } finally {

        buttons.forEach(
            button => {

                button.disabled =
                    false;

                button.textContent =
                    'Ask AI';
            }
        );

        renderAIChat();
    }
}


function handleAIResult(result) {

    pendingAI = null;

    if (
        !result ||
        typeof result !== 'object'
    ) {

        addAIMessage(
            'assistant',
            'The AI returned an invalid response.'
        );

        return;
    }

    if (
        result.type ===
        'clarify'
    ) {

        const message =
            result.message ||
            'I need a little more information.';

        addAIMessage(
            'assistant',
            message
        );

        return;
    }

    if (
        result.type ===
        'answer'
    ) {

        addAIMessage(
            'assistant',
            result.message || ''
        );

        return;
    }

    const actions =
        Array.isArray(
            result.actions
        )
            ? result.actions
            : [];

    if (!actions.length) {

        addAIMessage(
            'assistant',
            result.message ||
            'I could not determine a calendar action.'
        );

        return;
    }

    pendingAI =
        actions;

    let message =
        result.message ||
        'I prepared these calendar changes.';

    message += '\n\n';

    actions.forEach(
        action => {

            message +=
                describeAIAction(
                    action
                ) +
                '\n';
        }
    );

    addAIMessage(
        'assistant',
        message.trim()
    );

    /*
     * Put the confirmation buttons below the
     * conversation without putting HTML into the
     * actual AI context.
     */
    renderAIConfirmation();
}


function renderAIConfirmation() {
    renderAIChat();
}



function describeAIAction(action) {

    if (
        action.action ===
        'create'
    ) {

        const label =
            action.item_type === 'reminder'
                ? 'Reminder'
                : 'Event';

        return (
            'Create ' +
            label +
            ' "' +
            (
                action.title ||
                label
            ) +
            '" at ' +
            formatAIEventTime(
                action.start,
                action.end
            )
        );
    }

    if (
        action.action ===
        'update'
    ) {

        return (
            (action.scope === 'instance'
                ? 'Update this instance of event #'
                : 'Update all instances of event #') +
            action.id +
            (
                action.title
                    ? ' → "' +
                      action.title +
                      '"'
                    : ''
            )
        );
    }

    if (
        action.action ===
        'delete'
    ) {

        return (
            'Delete event #' +
            action.id
        );
    }

    return (
        action.action ||
        'Calendar change'
    );
}


function formatAIEventTime(
    start,
    end
) {

    if (!start) {
        return '';
    }

    const s =
        new Date(
            start.replace(
                ' ',
                'T'
            )
        );

    const e =
        end
            ? new Date(
                end.replace(
                    ' ',
                    'T'
                )
            )
            : null;

    let text =
        s.toLocaleString(
            [],
            {
                month: 'short',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit'
            }
        );

    if (e) {

        text +=
            ' – ' +
            e.toLocaleTimeString(
                [],
                {
                    hour: 'numeric',
                    minute: '2-digit'
                }
            );
    }

    return text;
}


async function applyAI() {

    if (
        !pendingAI ||
        !pendingAI.length
    ) {
        return;
    }

    const actions =
        pendingAI;

    pendingAI = null;

    addAIMessage(
        'assistant',
        'Applying the calendar changes...'
    );

    try {

        for (
            const action of actions
        ) {

            if (
                action.action ===
                'create'
            ) {

                await executeAICreate(
                    action
                );

            } else if (
                action.action ===
                'update'
            ) {

                await executeAIUpdate(
                    action
                );

            } else if (
                action.action ===
                'delete'
            ) {

                await executeAIDelete(
                    action
                );
            }
        }

        addAIMessage(
            'assistant',
            'Done. The calendar has been updated.'
        );

        if (
            document.getElementById(
                'calendarGrid'
            )
        ) {

            await loadCalendar();

        } else {

            await loadHome();
        }

    } catch (error) {

        addAIMessage(
            'assistant',
            error.message ||
            'Could not apply the calendar changes.'
        );
    }
}


function cancelAI() {

    pendingAI = null;

    document.querySelectorAll(
        '.ai-confirmation'
    ).forEach(
        element => element.remove()
    );

    addAIMessage(
        'assistant',
        'Cancelled.'
    );
}


async function executeAICreate(action) {

    const data =
        new FormData();

    data.append(
        'action',
        'create'
    );

    data.append(
        'title',
        action.title ||
        'Event'
    );

    data.append(
        'description',
        action.description ||
        ''
    );

    data.append(
        'location',
        action.location ||
        ''
    );

    data.append(
        'start_time',
        action.start
    );

    data.append(
        'end_time',
        action.end
    );

    data.append(
        'all_day',
        action.all_day
            ? '1'
            : '0'
    );

    data.append(
        'color',
        action.color ||
        '#6366f1'
    );

    data.append(
        'priority',
        action.priority ||
        'normal'
    );

    data.append(
        'item_type',
        action.item_type ||
        'event'
    );

    data.append(
        'recurrence',
        action.recurrence ||
        ''
    );

    if (
        action.reminder_minutes !==
        undefined &&
        action.reminder_minutes !==
        null
    ) {

        data.append(
            'reminder_minutes',
            action.reminder_minutes
        );
    }

    const response =
        await fetch(
            API,
            {
                method: 'POST',
                body: data
            }
        );

    const result =
        await response.json();

    if (!result.ok) {

        throw new Error(
            result.error ||
            'Could not create event.'
        );
    }
}


async function executeAIUpdate(action) {

    const data =
        new FormData();

    data.append(
        'action',
        'update'
    );

    data.append(
        'id',
        action.id
    );

    const existingResponse =
        await fetch(
            API +
            '?action=get&id=' +
            encodeURIComponent(
                action.id
            )
        );

    const existingData =
        await existingResponse.json();

    if (!existingData.ok) {

        throw new Error(
            existingData.error ||
            'Could not find event.'
        );
    }

    const event =
        existingData.event;

    if (
        action.scope === 'instance' &&
        action.occurrence_start &&
        Array.isArray(event.exceptions)
    ) {
        const existingException = event.exceptions.find(
            item =>
                String(item.occurrence_start || '') ===
                String(action.occurrence_start)
        );

        if (
            existingException &&
            existingException.data &&
            typeof existingException.data === 'object'
        ) {
            Object.assign(
                event,
                existingException.data
            );
        }
    }

    data.append(
        'title',
        action.title ??
        event.title
    );

    data.append(
        'description',
        action.description ??
        event.description ??
        ''
    );

    data.append(
        'location',
        action.location ??
        event.location ??
        ''
    );

    data.append(
        'start_time',
        action.start ??
        event.start_time
    );

    data.append(
        'end_time',
        action.end ??
        event.end_time
    );

    data.append(
        'all_day',
        action.all_day !==
        undefined
            ? (
                action.all_day
                    ? '1'
                    : '0'
            )
            : event.all_day
    );

    data.append(
        'color',
        action.color ??
        event.color
    );

    data.append(
        'priority',
        action.priority ??
        event.priority
    );

    data.append(
        'item_type',
        action.item_type ??
        event.item_type ??
        'event'
    );

    data.append(
        'recurrence',
        action.recurrence ??
        event.recurrence ??
        ''
    );

    data.append(
        'reminder_minutes',
        action.reminder_minutes ??
        event.reminder_minutes ??
        ''
    );

    const scope =
        action.scope === 'instance'
            ? 'instance'
            : 'series';

    data.append('scope', scope);

    if (scope === 'instance') {
        const occurrenceStart =
            action.occurrence_start ||
            action.original_start ||
            event._occurrenceStart ||
            '';

        if (!occurrenceStart) {
            throw new Error(
                'The AI could not determine which recurring occurrence to change.'
            );
        }

        data.append(
            'occurrence_start',
            occurrenceStart
        );
    }

    const response =
        await fetch(
            API,
            {
                method: 'POST',
                body: data
            }
        );

    const result =
        await response.json();

    if (!result.ok) {

        throw new Error(
            result.error ||
            'Could not update event.'
        );
    }
}


async function executeAIDelete(action) {

    const data =
        new FormData();

    data.append(
        'action',
        'delete'
    );

    data.append(
        'id',
        action.id
    );

    const response =
        await fetch(
            API,
            {
                method: 'POST',
                body: data
            }
        );

    const result =
        await response.json();

    if (!result.ok) {

        throw new Error(
            result.error ||
            'Could not delete event.'
        );
    }
}


/* =========================================================
   AI INTERFACE
   ========================================================= */

function openAIInterface() {

    const modal =
        document.getElementById(
            'aiModal'
        );

    if (modal) {

        modal.classList.add(
            'open'
        );

        const input =
            document.getElementById(
                'aiInput'
            );

        if (input) {

            setTimeout(
                () => input.focus(),
                50
            );
        }

        return;
    }

    const sidebarInput =
        document.getElementById(
            'aiInput'
        );

    if (sidebarInput) {

        sidebarInput.focus();

        sidebarInput.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    }
}


function closeAIModal() {

    const modal =
        document.getElementById(
            'aiModal'
        );

    if (modal) {

        modal.classList.remove(
            'open'
        );
    }
}


function closeAIModalOutside(event) {

    if (
        event.target.id ===
        'aiModal'
    ) {

        closeAIModal();
    }
}


/* =========================================================
   HOMEPAGE
   ========================================================= */

function startOfDay(date) {

    return new Date(
        date.getFullYear(),
        date.getMonth(),
        date.getDate()
    );
}


function formatHomeDate(date) {

    const today =
        startOfDay(
            new Date()
        );

    const target =
        startOfDay(
            date
        );

    const diff =
        Math.round(
            (
                target.getTime() -
                today.getTime()
            ) /
            86400000
        );

    if (diff === 0) {
        return 'Today';
    }

    if (diff === 1) {
        return 'Tomorrow';
    }

    return date.toLocaleDateString(
        [],
        {
            weekday: 'short',
            month: 'short',
            day: 'numeric'
        }
    );
}


function formatHomeEventTime(event) {

    if (event.all_day == 1) {
        return 'All day';
    }

    const start =
        parseDatabaseDate(
            event.start_time
        );

    const end =
        parseDatabaseDate(
            event.end_time
        );

    if (!start) {
        return '';
    }

    const startText =
        start.toLocaleTimeString(
            [],
            {
                hour: 'numeric',
                minute: '2-digit'
            }
        );

    if (!end) {
        return startText;
    }

    const endText =
        end.toLocaleTimeString(
            [],
            {
                hour: 'numeric',
                minute: '2-digit'
            }
        );

    return startText +
        ' – ' +
        endText;
}


function getUpcomingOccurrences(days = 60) {

    const list = [];

    const today =
        startOfDay(
            new Date()
        );

    for (
        let i = 0;
        i < days;
        i++
    ) {

        const date =
            new Date(
                today.getFullYear(),
                today.getMonth(),
                today.getDate() + i
            );

        getEventsForDay(
            date
        ).forEach(
            event => {

                list.push({
                    event,
                    date,
                    start:
                        parseDatabaseDate(
                            event.start_time
                        ),
                    end:
                        parseDatabaseDate(
                            event.end_time
                        )
                });
            }
        );
    }

    list.sort(
        (a, b) => {

            return (
                a.start?.getTime() ||
                0
            ) -
            (
                b.start?.getTime() ||
                0
            );
        }
    );

    return list;
}


function getHomeRangeDays(id, fallback = 7) {

    const select =
        document.getElementById(
            id
        );

    const value =
        Number(
            select ? select.value : fallback
        );

    return Number.isFinite(value) && value > 0
        ? value
        : fallback;
}


function renderHomeLists() {

    const eventsBox =
        document.getElementById(
            'homeEvents'
        );

    const remindersBox =
        document.getElementById(
            'homeReminders'
        );

    if (
        !eventsBox ||
        !remindersBox
    ) {
        return;
    }

    const occurrences =
        getUpcomingOccurrences(
            90
        );

    const now =
        new Date();

    const eventsRangeDays =
        getHomeRangeDays(
            'homeEventsRange'
        );

    const remindersRangeDays =
        getHomeRangeDays(
            'homeRemindersRange'
        );

    const eventsRangeEnd =
        new Date(
            startOfDay(now).getTime() +
            eventsRangeDays * 86400000
        );

    const remindersRangeEnd =
        new Date(
            startOfDay(now).getTime() +
            remindersRangeDays * 86400000
        );

    const upcoming =
        occurrences
            .filter(
                item =>
                    item.end &&
                    item.end.getTime() >=
                    now.getTime()
            )
            .filter(
                item =>
                    item.start &&
                    item.start.getTime() <
                    eventsRangeEnd.getTime()
            )
            .filter(
                item =>
                    String(
                        item.event.item_type ||
                        'event'
                    ) ===
                    'event'
            )
            .sort(
                (a, b) =>
                    (a.start?.getTime() || 0) -
                    (b.start?.getTime() || 0)
            );

    if (!upcoming.length) {

        eventsBox.innerHTML =
            '<div class="home-empty">' +
            'Nothing scheduled yet.<br>' +
            'Use + Event or Auto Manage to add something.' +
            '</div>';

    } else {

        eventsBox.innerHTML =
            upcoming
                .map(
                    item => {

                        const event =
                            item.event;

                        return (
                            '<div class="home-row" onclick="openHomeEvent(' +
                            Number(event.id) +
                            ')">' +

                            '<div class="home-dot" style="background:' +
                            escapeHTML(
                                event.color ||
                                '#6366f1'
                            ) +
                            '"></div>' +

                            '<div class="home-row-main">' +

                            '<div class="home-row-title">' +
                            escapeHTML(
                                event.title
                            ) +
                            '</div>' +

                            '<div class="home-row-meta">' +
                            escapeHTML(
                                formatHomeDate(
                                    item.date
                                )
                            ) +
                            (
                                event.location
                                    ? ' · ' +
                                      escapeHTML(
                                          event.location
                                      )
                                    : ''
                            ) +
                            '</div>' +

                            '</div>' +

                            '<div class="home-row-time">' +
                            escapeHTML(
                                formatHomeEventTime(
                                    event
                                )
                            ) +
                            '</div>' +

                            '</div>'
                        );
                    }
                )
                .join('');
    }

    const reminders = [];

    occurrences.forEach(
        item => {

            const event =
                item.event;

            const type =
                String(
                    event.item_type ||
                    'event'
                );

            if (
                type ===
                'reminder'
            ) {

                if (
                    item.start &&
                    item.start.getTime() >=
                    now.getTime() &&
                    item.start.getTime() <
                    remindersRangeEnd.getTime()
                ) {

                    reminders.push({
                        ...item,
                        reminderTime:
                            item.start,
                        standalone:
                            true,
                        minutes:
                            null
                    });
                }

                return;
            }

            const minutes =
                Number(
                    event.reminder_minutes ||
                    0
                );

            if (
                !minutes ||
                !item.start
            ) {
                return;
            }

            const reminderTime =
                new Date(
                    item.start.getTime() -
                    minutes * 60000
                );

            if (
                reminderTime.getTime() >=
                now.getTime() &&
                reminderTime.getTime() <
                remindersRangeEnd.getTime()
            ) {

                reminders.push({
                    ...item,
                    reminderTime,
                    minutes,
                    standalone:
                        false
                });
            }
        }
    );

    reminders.sort(
        (a, b) =>
            a.reminderTime.getTime() -
            b.reminderTime.getTime()
    );

    const topReminders =
        reminders;

    if (!topReminders.length) {

        remindersBox.innerHTML =
            '<div class="home-empty">' +
            'No upcoming reminders.<br>' +
            'Use New reminder to add one.' +
            '</div>';

    } else {

        remindersBox.innerHTML =
            topReminders
                .map(
                    item => {

                        const event =
                            item.event;

                        const reminderLabel =
                            item.standalone
                                ? 'Reminder'
                                : (
                                    item.minutes >=
                                    1440
                                        ? Math.round(
                                            item.minutes /
                                            1440
                                        ) +
                                          ' day' +
                                          (
                                              item.minutes >=
                                              2880
                                                  ? 's'
                                                  : ''
                                          ) +
                                          ' before'

                                        : item.minutes >=
                                          60

                                            ? Math.round(
                                                item.minutes /
                                                60
                                              ) +
                                              ' hour' +
                                              (
                                                  item.minutes >=
                                                  120
                                                      ? 's'
                                                      : ''
                                              ) +
                                              ' before'

                                            : item.minutes +
                                              ' min before'
                                );

                        return (
                            '<div class="home-row" onclick="openHomeEvent(' +
                            Number(event.id) +
                            ')">' +

                            '<div class="home-dot" style="background:' +
                            escapeHTML(
                                event.color ||
                                '#6366f1'
                            ) +
                            '"></div>' +

                            '<div class="home-row-main">' +

                            '<div class="home-row-title">' +
                            escapeHTML(
                                event.title
                            ) +
                            '</div>' +

                            '<div class="home-row-meta">' +
                            escapeHTML(
                                reminderLabel
                            ) +
                            ' · ' +
                            escapeHTML(
                                formatHomeDate(
                                    item.date
                                )
                            ) +
                            '</div>' +

                            '</div>' +

                            '<div class="home-row-time">' +
                            escapeHTML(
                                item.reminderTime.toLocaleTimeString(
                                    [],
                                    {
                                        hour: 'numeric',
                                        minute: '2-digit'
                                    }
                                )
                            ) +
                            '</div>' +

                            '</div>'
                        );
                    }
                )
                .join('');
    }
}


function openHomeEvent(id) {

    const event =
        events.find(
            item =>
                Number(item.id) ===
                Number(id)
        );

    if (event) {

        openEditEvent(
            event
        );

        return;
    }

    window.location.href =
        '?view=calendar';
}


async function loadHome() {

    const startDate =
        startOfDay(
            new Date()
        );

    const endDate =
        new Date(
            startDate.getFullYear(),
            startDate.getMonth(),
            startDate.getDate() +
            90
        );

    try {

        const response =
            await fetch(
                API +
                '?action=list&start=' +
                encodeURIComponent(
                    localDateTimeString(
                        startDate
                    )
                ) +
                '&end=' +
                encodeURIComponent(
                    localDateTimeString(
                        endDate
                    )
                )
            );

        const data =
            await response.json();

        if (!data.ok) {

            throw new Error(
                data.error ||
                'Could not load upcoming events.'
            );
        }

        events =
            Array.isArray(
                data.events
            )
                ? data.events
                : [];

        renderHomeLists();

    } catch (error) {

        const eventsBox =
            document.getElementById(
                'homeEvents'
            );

        const remindersBox =
            document.getElementById(
                'homeReminders'
            );

        const message =
            escapeHTML(
                error.message ||
                'Could not load your schedule.'
            );

        if (eventsBox) {

            eventsBox.innerHTML =
                '<div class="home-empty">' +
                message +
                '</div>';
        }

        if (remindersBox) {

            remindersBox.innerHTML =
                '<div class="home-empty">' +
                'Could not load reminders.' +
                '</div>';
        }
    }
}


/* =========================================================
   SECURITY / DISPLAY
   ========================================================= */

function escapeHTML(value) {

    return String(
        value ?? ''
    )
        .replace(
            /&/g,
            '&amp;'
        )
        .replace(
            /</g,
            '&lt;'
        )
        .replace(
            />/g,
            '&gt;'
        )
        .replace(
            /"/g,
            '&quot;'
        )
        .replace(
            /'/g,
            '&#039;'
        );
}


/* =========================================================
   KEYBOARD
   ========================================================= */

document.addEventListener(
    'keydown',
    function(event) {

        if (
            event.key !==
            'Enter' ||
            event.shiftKey
        ) {
            return;
        }

        const target =
            event.target;

        if (
            !target ||
            target.id !==
            'aiInput'
        ) {
            return;
        }

        event.preventDefault();

        sendAI();
    }
);


/* =========================================================
   INITIALIZE
   ========================================================= */

renderColors();

renderAIChat();

if (
    document.getElementById(
        'calendarGrid'
    )
) {

    updateCalendarPickers();

    loadCalendar();

} else {

    loadHome();
}

</script>

</body>
</html>
<?php

declare(strict_types=1);

/*
 * Mistral AI project configuration.
 *
 * Keep this file on the server.
 * NEVER put the API key in JavaScript.
 *
 * Leanstral 1.5:
 * labs-leanstral-1-5
 */


/*
 * =========================================================
 * MISTRAL API KEY
 * =========================================================
 *
 * Replace the value below with your NEW Mistral API key.
 *
 * IMPORTANT:
 * The old key that was previously posted should be revoked.
 */

define(
    'MISTRAL_API_KEY',
    'IGeQQS1GmX1D2Ol8KN0fgg2B2RIbpuHl'
);


/*
 * =========================================================
 * MODEL
 * =========================================================
 *
 * Mistral Labs Leanstral 1.5.
 */

define(
    'MISTRAL_MODEL',
    'labs-leanstral-1-5'
);


/*
 * =========================================================
 * API ENDPOINT
 * =========================================================
 */

define(
    'MISTRAL_ENDPOINT',
    'https://api.mistral.ai/v1/chat/completions'
);


/*
 * =========================================================
 * REASONING
 * =========================================================
 *
 * Leanstral 1.5 does NOT accept "medium".
 *
 * The error you received showed that this model accepts:
 *
 *     high
 *     none
 *
 * We use high for the calendar assistant.
 */

define(
    'MISTRAL_REASONING_EFFORT',
    'high'
);


/*
 * =========================================================
 * MAXIMUM OUTPUT TOKENS
 * =========================================================
 *
 * Mistral uses "max_tokens".
 */

define(
    'MISTRAL_MAX_TOKENS',
    4096
);


/*
 * =========================================================
 * CALENDAR CONTEXT
 * =========================================================
 *
 * Number of previous calendar prompts/events that the
 * application is willing to provide as context.
 */

define(
    'MISTRAL_CONTEXT_PROMPTS',
    8
);


/*
 * =========================================================
 * ATTACHMENT LIMITS
 * =========================================================
 *
 * Kept here for compatibility with the rest of the project.
 */

define(
    'MISTRAL_MAX_IMAGES',
    5
);

define(
    'MISTRAL_MAX_IMAGE_BYTES',
    4 * 1024 * 1024
);

define(
    'MISTRAL_MAX_FILE_BYTES',
    5 * 1024 * 1024
);

define(
    'MISTRAL_MAX_FILE_CHARS',
    60000
);
?>
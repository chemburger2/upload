```php
<?php
/*
 * PSP Video Converter
 *
 * The PHP portion only serves the page.
 * Video files are processed entirely inside the browser.
 *
 * Nothing is uploaded to this PHP server.
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PSP Video Converter</title>

    <style>
        :root {
            color-scheme: dark;

            --bg: #090b0e;
            --panel: #11151a;
            --panel2: #0d1014;
            --border: #242a31;

            --text: #f1f3f5;
            --muted: #8d96a0;

            --accent: #4d8dff;
            --accent-hover: #649cff;

            --danger: #d9534f;
            --success: #4caf7d;
        }

        * {
            box-sizing: border-box;
        }

        html {
            min-height: 100%;
            background: var(--bg);
        }

        body {
            margin: 0;
            min-height: 100vh;
            background: var(--bg);
            color: var(--text);

            font-family:
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Roboto,
                Helvetica,
                Arial,
                sans-serif;
        }

        button,
        input {
            font: inherit;
        }

        .app {
            width: min(1000px, calc(100% - 30px));
            margin: 0 auto;
            padding: 34px 0 60px;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 20px;
            margin-bottom: 25px;
        }

        .title {
            font-size: 26px;
            font-weight: 700;
            letter-spacing: -0.3px;
        }

        .subtitle {
            margin-top: 5px;
            color: var(--muted);
            font-size: 14px;
        }

        .engine-status {
            padding: 8px 12px;

            border: 1px solid var(--border);
            border-radius: 7px;

            color: var(--muted);
            font-size: 13px;

            white-space: nowrap;
        }

        .panel {
            margin-bottom: 16px;
            padding: 20px;

            background: var(--panel);
            border: 1px solid var(--border);
            border-radius: 9px;
        }

        .section-title {
            margin-bottom: 14px;

            font-size: 14px;
            font-weight: 600;
        }

        .file-controls {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .button {
            padding: 10px 16px;

            border: 1px solid transparent;
            border-radius: 7px;

            cursor: pointer;

            transition:
                background 0.15s ease,
                border-color 0.15s ease,
                opacity 0.15s ease;
        }

        .button:disabled {
            opacity: 0.45;
            cursor: not-allowed;
        }

        .button.primary {
            background: var(--accent);
            color: white;
        }

        .button.primary:hover:not(:disabled) {
            background: var(--accent-hover);
        }

        .button.secondary {
            background: #1a2027;
            border-color: #303740;
            color: var(--text);
        }

        .button.secondary:hover:not(:disabled) {
            background: #222a33;
        }

        .button.danger {
            background: transparent;
            border-color: #5a3030;
            color: #e5827e;
        }

        .button.danger:hover:not(:disabled) {
            background: #261719;
            border-color: var(--danger);
        }

        .selected-files {
            margin-top: 13px;

            color: var(--muted);
            font-size: 13px;
            line-height: 1.5;
        }

        .options {
            margin-top: 20px;
            padding-top: 18px;

            border-top: 1px solid var(--border);
        }

        .checkbox {
            display: flex;
            align-items: center;

            width: fit-content;

            gap: 9px;

            cursor: pointer;

            font-size: 15px;
        }

        .checkbox input {
            width: 17px;
            height: 17px;

            margin: 0;

            accent-color: var(--accent);
        }

        .option-description {
            margin:
                7px 0 0 26px;

            color: var(--muted);
            font-size: 13px;
        }

        .actions {
            display: flex;
            gap: 10px;

            margin-top: 20px;
        }

        .status-row {
            display: flex;
            justify-content: space-between;

            margin-bottom: 9px;

            font-size: 14px;
        }

        .progress-container {
            width: 100%;
            height: 8px;

            overflow: hidden;

            border-radius: 5px;

            background: #07090c;
        }

        .progress-bar {
            width: 0;
            height: 100%;

            background: var(--accent);

            transition: width 0.15s ease;
        }

        .current-file {
            min-height: 20px;

            margin-top: 10px;

            color: var(--muted);
            font-size: 13px;
        }

        .output-list {
            display: flex;
            flex-direction: column;

            gap: 10px;
        }

        .empty {
            padding: 20px;

            border: 1px dashed #2b3239;
            border-radius: 7px;

            color: var(--muted);
            text-align: center;

            font-size: 13px;
        }

        .output {
            padding: 16px;

            background: var(--panel2);

            border: 1px solid var(--border);
            border-radius: 8px;
        }

        .output-top {
            display: flex;
            justify-content: space-between;

            gap: 15px;
        }

        .output-name {
            min-width: 0;

            font-size: 15px;
            font-weight: 600;

            overflow-wrap: anywhere;
        }

        .output-size {
            margin-top: 4px;

            color: var(--muted);
            font-size: 12px;
        }

        .output-status {
            margin-top: 8px;

            color: var(--muted);
            font-size: 13px;
        }

        .output-status.success {
            color: var(--success);
        }

        .output-status.error {
            color: #e5827e;
        }

        .diagnostics {
            display: grid;

            grid-template-columns:
                repeat(2, minmax(0, 1fr));

            gap: 9px 25px;

            margin-top: 15px;
            padding-top: 14px;

            border-top: 1px solid var(--border);
        }

        .diagnostic-label {
            color: var(--muted);

            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        .diagnostic-value {
            margin-top: 2px;

            font-size: 13px;

            overflow-wrap: anywhere;
        }

        .log {
            width: 100%;
            min-height: 90px;
            max-height: 350px;

            margin: 0;
            padding: 14px;

            overflow: auto;

            background: #07090c;

            border-radius: 7px;

            color: #b9c0c8;

            font-family:
                "SFMono-Regular",
                Consolas,
                "Liberation Mono",
                monospace;

            font-size: 12px;
            line-height: 1.55;

            white-space: pre-wrap;
            overflow-wrap: anywhere;
        }

        .info {
            color: #c4c9cf;

            font-size: 14px;
            line-height: 1.55;
        }

        .info p {
            margin: 0 0 10px;
        }

        .info p:last-child {
            margin-bottom: 0;
        }

        .muted {
            color: var(--muted);
        }

        code {
            padding: 2px 5px;

            border-radius: 4px;

            background: #07090c;

            color: #d9dde2;

            font-family:
                "SFMono-Regular",
                Consolas,
                "Liberation Mono",
                monospace;
        }

        @media (max-width: 700px) {
            .app {
                width: calc(100% - 20px);
                padding-top: 20px;
            }

            .header {
                align-items: flex-start;
                flex-direction: column;
            }

            .file-controls {
                align-items: stretch;
                flex-direction: column;
            }

            .diagnostics {
                grid-template-columns: 1fr;
            }

            .output-top {
                align-items: flex-start;
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<main class="app">

    <header class="header">
        <div>
            <div class="title">
                PSP Video Converter
            </div>

            <div class="subtitle">
                Browser-based conversion for PSP 3000
            </div>
        </div>

        <div
            class="engine-status"
            id="engineStatus"
        >
            FFmpeg not loaded
        </div>
    </header>


    <section class="panel">

        <div class="section-title">
            Videos
        </div>

        <div class="file-controls">

            <input
                type="file"
                id="videoInput"
                multiple
                accept="
                    video/*,
                    .mp4,
                    .m4v,
                    .mkv,
                    .avi,
                    .mov,
                    .wmv,
                    .webm,
                    .mpeg,
                    .mpg,
                    .ts
                "
                hidden
            >

            <button
                class="button secondary"
                id="selectButton"
            >
                Select videos
            </button>

        </div>

        <div
            class="selected-files"
            id="selectedFiles"
        >
            No videos selected.
        </div>


        <div class="options">

            <label class="checkbox">

                <input
                    type="checkbox"
                    id="convertCheckbox"
                    checked
                >

                <span>
                    Convert videos for PSP
                </span>

            </label>

            <div class="option-description">
                When disabled, the original files are kept unchanged.
            </div>

        </div>


        <div class="actions">

            <button
                class="button primary"
                id="convertButton"
                disabled
            >
                Convert
            </button>

            <button
                class="button danger"
                id="cancelButton"
                disabled
            >
                Cancel
            </button>

        </div>

    </section>


    <section class="panel">

        <div class="section-title">
            Status
        </div>

        <div class="status-row">

            <span id="statusText">
                Waiting for videos
            </span>

            <span
                class="muted"
                id="progressText"
            >
                0%
            </span>

        </div>

        <div class="progress-container">
            <div
                class="progress-bar"
                id="progressBar"
            ></div>
        </div>

        <div
            class="current-file"
            id="currentFile"
        ></div>

    </section>


    <section class="panel">

        <div class="section-title">
            Output
        </div>

        <div
            class="output-list"
            id="outputList"
        >
            <div class="empty">
                Converted videos will appear here.
            </div>
        </div>

    </section>


    <section class="panel">

        <div class="section-title">
            Conversion log
        </div>

        <pre
            class="log"
            id="log"
        ></pre>

    </section>


    <section class="panel info">

        <div class="section-title">
            PSP-ready output
        </div>

        <p>
            PSP conversion targets MP4 with H.264/AVC video,
            Main Profile, Level 3.0, 480×272 resolution,
            yuv420p video and AAC-LC stereo audio.
        </p>

        <p>
            Put converted files in the PSP's
            <code>VIDEO</code> folder.
        </p>

        <p class="muted">
            Video files are processed locally in this browser.
            They are not uploaded to this PHP server.
        </p>

    </section>

</main>


<script type="module">

/*
 * ============================================================
 * PSP VIDEO CONVERTER
 * ============================================================
 *
 * Everything involving the selected video happens locally.
 *
 * PHP only serves this page.
 */


/* ------------------------------------------------------------
   FFmpeg versions
------------------------------------------------------------ */

const FFMPEG_VERSION = "0.12.15";
const CORE_VERSION = "0.12.10";

const FFMPEG_MODULE_URL =
    `https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@${FFMPEG_VERSION}/dist/esm/index.js`;

const UTIL_MODULE_URL =
    `https://cdn.jsdelivr.net/npm/@ffmpeg/util@0.12.2/dist/esm/index.js`;

const CORE_BASE_URL =
    `https://cdn.jsdelivr.net/npm/@ffmpeg/core@${CORE_VERSION}/dist/esm`;

const CORE_URL =
    `${CORE_BASE_URL}/ffmpeg-core.js`;

const WASM_URL =
    `${CORE_BASE_URL}/ffmpeg-core.wasm`;

const WRAPPER_WORKER_URL =
    `https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@${FFMPEG_VERSION}/dist/esm/worker.js`;

const CONST_URL =
    `https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@${FFMPEG_VERSION}/dist/esm/const.js`;

const ERRORS_URL =
    `https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@${FFMPEG_VERSION}/dist/esm/errors.js`;


/* ------------------------------------------------------------
   PSP target
------------------------------------------------------------ */

const PSP_WIDTH = 480;
const PSP_HEIGHT = 272;

const PSP_VIDEO_BITRATE = "900k";
const PSP_MAXRATE = "1000k";
const PSP_BUFSIZE = "1800k";

const PSP_AUDIO_BITRATE = "128k";
const PSP_AUDIO_RATE = "44100";


/* ------------------------------------------------------------
   DOM
------------------------------------------------------------ */

const selectButton =
    document.getElementById("selectButton");

const videoInput =
    document.getElementById("videoInput");

const convertButton =
    document.getElementById("convertButton");

const cancelButton =
    document.getElementById("cancelButton");

const convertCheckbox =
    document.getElementById("convertCheckbox");

const selectedFiles =
    document.getElementById("selectedFiles");

const statusText =
    document.getElementById("statusText");

const progressText =
    document.getElementById("progressText");

const progressBar =
    document.getElementById("progressBar");

const currentFile =
    document.getElementById("currentFile");

const outputList =
    document.getElementById("outputList");

const logElement =
    document.getElementById("log");

const engineStatus =
    document.getElementById("engineStatus");


/* ------------------------------------------------------------
   State
------------------------------------------------------------ */

let files = [];

let results = [];

let ffmpeg = null;

let ffmpegLoaded = false;

let converting = false;

let cancelRequested = false;


/* ------------------------------------------------------------
   Logging
------------------------------------------------------------ */

function log(message) {

    const time =
        new Date().toLocaleTimeString();

    logElement.textContent +=
        `[${time}] ${message}\n`;

    logElement.scrollTop =
        logElement.scrollHeight;
}


function setStatus(message) {

    statusText.textContent =
        message;
}


function setProgress(percent) {

    const value =
        Math.max(
            0,
            Math.min(
                100,
                Number(percent) || 0
            )
        );

    progressBar.style.width =
        `${value}%`;

    progressText.textContent =
        `${Math.round(value)}%`;
}


/* ------------------------------------------------------------
   Formatting
------------------------------------------------------------ */

function formatBytes(bytes) {

    if (!Number.isFinite(bytes)) {
        return "Unknown";
    }

    if (bytes < 1024) {
        return `${bytes} B`;
    }

    if (bytes < 1024 * 1024) {
        return `${(bytes / 1024).toFixed(1)} KB`;
    }

    if (bytes < 1024 * 1024 * 1024) {
        return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    }

    return `${(
        bytes /
        1024 /
        1024 /
        1024
    ).toFixed(2)} GB`;
}


function formatBitrate(value) {

    const number =
        Number(value);

    if (!Number.isFinite(number)) {
        return "Unknown";
    }

    if (number >= 1000000) {
        return `${(
            number /
            1000000
        ).toFixed(2)} Mbps`;
    }

    return `${Math.round(number / 1000)} kbps`;
}


function parseFPS(value) {

    if (!value) {
        return null;
    }

    const parts =
        String(value).split("/");

    if (parts.length === 2) {

        const numerator =
            Number(parts[0]);

        const denominator =
            Number(parts[1]);

        if (
            Number.isFinite(numerator) &&
            Number.isFinite(denominator) &&
            denominator !== 0
        ) {
            return numerator / denominator;
        }
    }

    const number =
        Number(value);

    return Number.isFinite(number)
        ? number
        : null;
}


function extensionOf(name) {

    const match =
        String(name).match(/(\.[^.]+)$/);

    return match
        ? match[1].toLowerCase()
        : "";
}


function outputNameOf(file) {

    const base =
        file.name.replace(
            /\.[^/.]+$/,
            ""
        );

    const clean =
        base
            .replace(
                /[<>:"/\\|?*\x00-\x1F]/g,
                "_"
            )
            .trim();

    return `${clean || "video"}.mp4`;
}


/* ------------------------------------------------------------
   Load the official FFmpeg wrapper
------------------------------------------------------------ */

/*
 * Chrome blocks some cross-origin Worker constructions.
 *
 * We fetch the official wrapper source and its two small
 * dependencies, remove their module imports/exports, and
 * create a same-origin Blob worker.
 *
 * The actual large FFmpeg core and WASM remain on jsDelivr.
 */

async function createSameOriginWorker() {

    log(
        "Preparing same-origin FFmpeg worker..."
    );

    const [
        workerResponse,
        constResponse,
        errorsResponse
    ] = await Promise.all([
        fetch(WRAPPER_WORKER_URL),
        fetch(CONST_URL),
        fetch(ERRORS_URL)
    ]);

    if (
        !workerResponse.ok ||
        !constResponse.ok ||
        !errorsResponse.ok
    ) {
        throw new Error(
            "Could not download the FFmpeg worker dependencies."
        );
    }

    let workerSource =
        await workerResponse.text();

    let constSource =
        await constResponse.text();

    let errorsSource =
        await errorsResponse.text();


    /*
     * Remove ESM imports from worker.js.
     *
     * The dependency source is placed before worker.js,
     * so its exported names become available globally.
     */

    workerSource =
        workerSource.replace(
            /import\s+\{[\s\S]*?\}\s+from\s+["']\.\/const\.js["'];?/,
            ""
        );

    workerSource =
        workerSource.replace(
            /import\s+\{[\s\S]*?\}\s+from\s+["']\.\/errors\.js["'];?/,
            ""
        );


    /*
     * const.js/errors.js use exports because they normally
     * run as ESM. Remove the export keywords because this
     * Blob worker is a classic worker.
     */

    constSource =
        constSource.replace(
            /\bexport\s+/g,
            ""
        );

    errorsSource =
        errorsSource.replace(
            /\bexport\s+/g,
            ""
        );


    /*
     * Ensure the generated worker has access to the
     * dependency declarations.
     */

    const combined =
        `
        ${constSource}

        ${errorsSource}

        ${workerSource}
        `;


    const blob =
        new Blob(
            [combined],
            {
                type:
                    "application/javascript"
            }
        );


    return URL.createObjectURL(blob);
}


/* ------------------------------------------------------------
   FFmpeg initialization
------------------------------------------------------------ */

async function loadFFmpeg() {

    if (ffmpegLoaded) {
        return;
    }


    engineStatus.textContent =
        "Loading FFmpeg...";

    setStatus(
        "Loading FFmpeg..."
    );


    log(
        `Loading @ffmpeg/ffmpeg ${FFMPEG_VERSION}`
    );

    log(
        `Loading @ffmpeg/core ${CORE_VERSION}`
    );


    const module =
        await import(
            FFMPEG_MODULE_URL
        );

    const FFmpeg =
        module.FFmpeg;


    const workerURL =
        await createSameOriginWorker();


    ffmpeg =
        new FFmpeg();


    ffmpeg.on(
        "log",
        ({ message }) => {

            if (message) {
                log(message);
            }
        }
    );


    ffmpeg.on(
        "progress",
        ({ progress }) => {

            if (!converting) {
                return;
            }

            /*
             * This is the current-file progress.
             * The queue progress is calculated separately.
             */

            const percent =
                Math.max(
                    0,
                    Math.min(
                        100,
                        progress * 100
                    )
                );

            const currentIndex =
                Number(
                    currentFile.dataset.index ||
                    0
                );

            const queuePercent =
                (
                    (
                        currentIndex +
                        progress
                    ) /
                    files.length
                ) *
                100;


            setProgress(
                queuePercent
            );
        }
    );


    /*
     * classWorkerURL is the FFmpeg API's wrapper worker.
     *
     * coreURL points directly to the ESM core.
     * wasmURL points directly to the CDN WASM.
     */

    await ffmpeg.load({
        coreURL: CORE_URL,
        wasmURL: WASM_URL,
        classWorkerURL: workerURL
    });


    ffmpegLoaded = true;


    engineStatus.textContent =
        "FFmpeg ready";

    setStatus(
        "Ready"
    );

    log(
        "FFmpeg initialized successfully."
    );

    log(
        "Video conversion remains entirely local."
    );
}


/* ------------------------------------------------------------
   File picker
------------------------------------------------------------ */

selectButton.addEventListener(
    "click",
    () => {
        videoInput.click();
    }
);


videoInput.addEventListener(
    "change",
    () => {

        files =
            Array.from(
                videoInput.files || []
            );

        renderSelectedFiles();

        convertButton.disabled =
            files.length === 0;
    }
);


function renderSelectedFiles() {

    if (files.length === 0) {

        selectedFiles.textContent =
            "No videos selected.";

        return;
    }


    if (files.length === 1) {

        selectedFiles.textContent =
            `${files[0].name} — ${formatBytes(files[0].size)}`;

        return;
    }


    selectedFiles.textContent =
        `${files.length} videos selected.`;
}


/* ------------------------------------------------------------
   Result rendering
------------------------------------------------------------ */

function renderResults() {

    if (results.length === 0) {

        outputList.innerHTML =
            `
            <div class="empty">
                Converted videos will appear here.
            </div>
            `;

        return;
    }


    outputList.innerHTML = "";


    for (const result of results) {

        const item =
            document.createElement("div");

        item.className =
            "output";


        const top =
            document.createElement("div");

        top.className =
            "output-top";


        const left =
            document.createElement("div");


        const name =
            document.createElement("div");

        name.className =
            "output-name";

        name.textContent =
            result.name;


        const size =
            document.createElement("div");

        size.className =
            "output-size";

        if (result.size) {
            size.textContent =
                formatBytes(result.size);
        }


        left.appendChild(name);
        left.appendChild(size);


        top.appendChild(left);


        if (result.blob) {

            const download =
                document.createElement("button");

            download.className =
                "button secondary";

            download.textContent =
                "Download";


            download.addEventListener(
                "click",
                () => {

                    saveOutput(
                        result.blob,
                        result.name
                    );
                }
            );


            top.appendChild(download);
        }


        item.appendChild(top);


        const status =
            document.createElement("div");

        status.className =
            "output-status";


        if (result.error) {

            status.classList.add(
                "error"
            );

            status.textContent =
                `Error: ${result.error}`;

        } else if (result.complete) {

            status.classList.add(
                "success"
            );

            status.textContent =
                result.converted
                    ? "PSP conversion complete"
                    : "Original file ready";

        } else {

            status.textContent =
                "Processing...";
        }


        item.appendChild(status);


        if (result.diagnostics) {

            item.appendChild(
                createDiagnostics(
                    result.diagnostics
                )
            );
        }


        outputList.appendChild(item);
    }
}


function createDiagnostics(data) {

    const container =
        document.createElement("div");

    container.className =
        "diagnostics";


    const values = [

        [
            "Container",
            data.container
        ],

        [
            "Video",
            data.video
        ],

        [
            "Profile",
            data.profile
        ],

        [
            "Level",
            data.level
        ],

        [
            "Resolution",
            `${data.width}×${data.height}`
        ],

        [
            "FPS",
            data.fps
                ? data.fps.toFixed(3)
                : "Unknown"
        ],

        [
            "Video bitrate",
            data.videoBitrate
        ],

        [
            "Pixel format",
            data.pixelFormat
        ],

        [
            "Audio",
            data.audio
        ],

        [
            "Audio profile",
            data.audioProfile
        ],

        [
            "Channels",
            data.channels
        ],

        [
            "Sample rate",
            data.sampleRate
        ],

        [
            "Audio bitrate",
            data.audioBitrate
        ]
    ];


    for (const [label, value] of values) {

        const item =
            document.createElement("div");


        const labelElement =
            document.createElement("div");

        labelElement.className =
            "diagnostic-label";

        labelElement.textContent =
            label;


        const valueElement =
            document.createElement("div");

        valueElement.className =
            "diagnostic-value";

        valueElement.textContent =
            value;


        item.appendChild(
            labelElement
        );

        item.appendChild(
            valueElement
        );


        container.appendChild(item);
    }


    return container;
}


/* ------------------------------------------------------------
   FFprobe
------------------------------------------------------------ */

async function diagnoseOutput(path) {

    const probePath =
        "diagnostics.json";


    await ffmpeg.ffprobe([
        "-v",
        "quiet",

        "-print_format",
        "json",

        "-show_format",
        "-show_streams",

        path,

        "-o",
        probePath
    ]);


    const data =
        await ffmpeg.readFile(
            probePath,
            "utf8"
        );


    await safeDelete(
        probePath
    );


    let text;


    if (
        typeof data === "string"
    ) {
        text = data;
    } else {
        text =
            new TextDecoder()
                .decode(data);
    }


    const parsed =
        JSON.parse(text);


    const format =
        parsed.format || {};


    const video =
        (
            parsed.streams || []
        ).find(
            stream =>
                stream.codec_type ===
                "video"
        );


    const audio =
        (
            parsed.streams || []
        ).find(
            stream =>
                stream.codec_type ===
                "audio"
        );


    return {

        container:
            format.format_name ||
            "Unknown",

        video:
            video?.codec_name ||
            "None",

        profile:
            video?.profile ||
            "Unknown",

        level:
            video?.level != null
                ? String(video.level)
                : "Unknown",

        width:
            video?.width ??
            "Unknown",

        height:
            video?.height ??
            "Unknown",

        fps:
            parseFPS(
                video?.avg_frame_rate ||
                video?.r_frame_rate
            ),

        videoBitrate:
            formatBitrate(
                video?.bit_rate ||
                format.bit_rate
            ),

        pixelFormat:
            video?.pix_fmt ||
            "Unknown",

        audio:
            audio?.codec_name ||
            "None",

        audioProfile:
            audio?.profile ||
            "Unknown",

        channels:
            audio?.channels ??
            "Unknown",

        sampleRate:
            audio?.sample_rate
                ? `${audio.sample_rate} Hz`
                : "Unknown",

        audioBitrate:
            formatBitrate(
                audio?.bit_rate
            )
    };
}


/* ------------------------------------------------------------
   Filesystem cleanup
------------------------------------------------------------ */

async function safeDelete(path) {

    if (!ffmpeg) {
        return;
    }


    try {

        await ffmpeg.deleteFile(
            path
        );

    } catch {
        /*
         * The file may already have
         * been removed.
         */
    }
}


/* ------------------------------------------------------------
   PSP conversion
------------------------------------------------------------ */

async function convertForPSP(file) {

    const inputPath =
        `input_${Date.now()}${extensionOf(file.name)}`;

    const outputPath =
        `output_${Date.now()}.mp4`;


    try {

        log(
            `Reading ${file.name} locally...`
        );


        const util =
            await import(
                UTIL_MODULE_URL
            );


        await ffmpeg.writeFile(
            inputPath,
            await util.fetchFile(file)
        );


        log(
            `Converting ${file.name}...`
        );


        /*
         * Preserve the source aspect ratio.
         *
         * A 16:9 source becomes 480x270 with one-pixel
         * padding to reach the PSP's 480x272 frame.
         *
         * A 4:3 source becomes approximately 362x272
         * and is centered inside the 480x272 frame.
         */

        const filter =
            [
                "scale=480:272:force_original_aspect_ratio=decrease",
                "pad=480:272:(ow-iw)/2:(oh-ih)/2",
                "setsar=1"
            ].join(",");


        const exitCode =
            await ffmpeg.exec([

                "-threads",
                "3",

                "-i",
                inputPath,

                "-map",
                "0:v:0",

                "-map",
                "0:a:0?",

                "-vf",
                filter,

                "-c:v",
                "libx264",

                "-profile:v",
                "main",

                "-level:v",
                "3.0",

                "-pix_fmt",
                "yuv420p",

                "-preset",
                "veryfast",

                "-b:v",
                PSP_VIDEO_BITRATE,

                "-maxrate",
                PSP_MAXRATE,

                "-bufsize",
                PSP_BUFSIZE,

                "-r",
                "30",

                "-c:a",
                "aac",

                "-profile:a",
                "aac_low",

                "-b:a",
                PSP_AUDIO_BITRATE,

                "-ar",
                PSP_AUDIO_RATE,

                "-ac",
                "2",

                "-movflags",
                "+faststart",

                "-f",
                "mp4",

                outputPath
            ]);


        if (
            exitCode !== 0
        ) {
            throw new Error(
                `FFmpeg exited with code ${exitCode}.`
            );
        }


        if (cancelRequested) {
            throw new Error(
                "Conversion cancelled."
            );
        }


        const data =
            await ffmpeg.readFile(
                outputPath
            );


        if (
            !data ||
            data.length === 0
        ) {
            throw new Error(
                "FFmpeg created an empty output."
            );
        }


        log(
            "Inspecting generated file..."
        );


        const diagnostics =
            await diagnoseOutput(
                outputPath
            );


        log(
            `Output: ${diagnostics.video} ` +
            `${diagnostics.profile}, ` +
            `${diagnostics.width}×${diagnostics.height}`
        );


        log(
            `Audio: ${diagnostics.audio}, ` +
            `${diagnostics.sampleRate}, ` +
            `${diagnostics.channels} channels`
        );


        /*
         * This is the one unavoidable large allocation in
         * the basic FFmpeg.wasm workflow: readFile() gives us
         * the generated output.
         *
         * We keep only one output Blob for the download.
         */

        const blob =
            new Blob(
                [data],
                {
                    type:
                        "video/mp4"
                }
            );


        return {

            name:
                outputNameOf(file),

            blob,

            size:
                data.length,

            diagnostics,

            converted:
                true,

            complete:
                true
        };

    } finally {

        await safeDelete(
            inputPath
        );

        await safeDelete(
            outputPath
        );
    }
}


/* ------------------------------------------------------------
   Original-file mode
------------------------------------------------------------ */

async function keepOriginal(file) {

    return {

        name:
            file.name,

        blob:
            file,

        size:
            file.size,

        converted:
            false,

        complete:
            true
    };
}


/* ------------------------------------------------------------
   Save output
------------------------------------------------------------ */

async function saveOutput(
    blob,
    filename
) {

    /*
     * Chrome/Chromium on Chromebook supports the File System
     * Access API. Prefer this when available so the user can
     * choose exactly where the PSP file is saved.
     */

    if (
        window.showSaveFilePicker
    ) {

        try {

            const handle =
                await window.showSaveFilePicker({

                    suggestedName:
                        filename,

                    types: [
                        {
                            description:
                                "PSP MP4 video",

                            accept: {
                                "video/mp4":
                                    [".mp4"]
                            }
                        }
                    ]
                });


            const writable =
                await handle.createWritable();


            await writable.write(
                blob
            );


            await writable.close();


            log(
                `Saved ${filename}.`
            );


            return;

        } catch (error) {

            if (
                error?.name ===
                "AbortError"
            ) {
                return;
            }

            log(
                `Direct save failed: ${
                    error?.message ||
                    error
                }`
            );
        }
    }


    /*
     * Fallback for browsers without
     * File System Access API.
     */

    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement("a");


    link.href =
        url;

    link.download =
        filename;


    document.body.appendChild(
        link
    );


    link.click();


    link.remove();


    setTimeout(
        () => {
            URL.revokeObjectURL(
                url
            );
        },
        60000
    );
}


/* ------------------------------------------------------------
   Convert queue
------------------------------------------------------------ */

convertButton.addEventListener(
    "click",
    async () => {

        if (
            converting ||
            files.length === 0
        ) {
            return;
        }


        converting = true;
        cancelRequested = false;


        convertButton.disabled =
            true;

        cancelButton.disabled =
            false;

        selectButton.disabled =
            true;


        results = [];

        renderResults();

        setProgress(0);


        try {

            await loadFFmpeg();


            const convert =
                convertCheckbox.checked;


            log(
                convert
                    ? "PSP conversion enabled."
                    : "PSP conversion disabled."
            );


            log(
                `Processing ${files.length} file(s).`
            );


            for (
                let i = 0;
                i < files.length;
                i++
            ) {

                if (
                    cancelRequested
                ) {
                    break;
                }


                const file =
                    files[i];


                currentFile.dataset.index =
                    String(i);


                currentFile.textContent =
                    `${i + 1} of ${files.length}: ${file.name}`;


                setStatus(
                    `Processing ${i + 1} of ${files.length}`
                );


                try {

                    let result;


                    if (convert) {

                        result =
                            await convertForPSP(
                                file
                            );

                    } else {

                        result =
                            await keepOriginal(
                                file
                            );
                    }


                    results.push(
                        result
                    );


                } catch (error) {

                    const message =
                        error?.message ||
                        String(error);


                    log(
                        `${file.name}: ${message}`
                    );


                    results.push({

                        name:
                            convert
                                ? outputNameOf(file)
                                : file.name,

                        error:
                            message,

                        complete:
                            true
                    });
                }


                renderResults();


                setProgress(
                    (
                        (i + 1) /
                        files.length
                    ) *
                    100
                );
            }


            if (
                cancelRequested
            ) {

                setStatus(
                    "Conversion cancelled"
                );

                log(
                    "Conversion queue cancelled."
                );

            } else {

                setStatus(
                    "Conversion complete"
                );

                log(
                    "All selected files have been processed."
                );
            }

        } catch (error) {

            const message =
                error?.message ||
                String(error);


            setStatus(
                "Conversion failed"
            );


            log(
                `Fatal error: ${message}`
            );

        } finally {

            converting = false;

            convertButton.disabled =
                files.length === 0;

            cancelButton.disabled =
                true;

            selectButton.disabled =
                false;
        }
    }
);


/* ------------------------------------------------------------
   Cancel
------------------------------------------------------------ */

cancelButton.addEventListener(
    "click",
    () => {

        if (!converting) {
            return;
        }


        cancelRequested =
            true;


        setStatus(
            "Stopping..."
        );


        log(
            "Cancellation requested."
        );


        /*
         * FFmpeg.wasm's terminate() stops the worker and
         * requires a reload before another FFmpeg operation.
         */

        if (ffmpeg) {

            try {

                ffmpeg.terminate();

            } catch {
                // Ignore termination errors.
            }

            ffmpeg = null;

            ffmpegLoaded =
                false;


            engineStatus.textContent =
                "FFmpeg stopped";
        }
    }
);


/* ------------------------------------------------------------
   Initial state
------------------------------------------------------------ */

log(
    "PSP Video Converter ready."
);

log(
    "Files selected here stay in the browser."
);

log(
    "Target: MP4 / H.264 Main / Level 3.0 / 480x272 / AAC."
);

</script>

</body>
</html>
```

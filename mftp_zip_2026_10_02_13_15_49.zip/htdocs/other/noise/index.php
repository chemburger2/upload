<?php
/*
 * Acoustic Data Transfer
 *
 * Browser-only acoustic modem.
 *
 * Payload:
 *   Normal UTF-8 text is converted to raw 8-bit bytes.
 *   Every payload byte is transmitted as exactly 8 binary symbols.
 *
 * Reliability:
 *   - Every byte is sent twice.
 *   - Each byte frame contains its byte index, total length,
 *     payload byte, and CRC-8.
 *   - The receiver accepts whichever copy of a byte passes CRC.
 *   - If both copies are received, matching copies are preferred.
 *   - Missing bytes can therefore be filled from the second copy.
 *
 * Stop:
 *   STOP immediately silences the current oscillator and cancels
 *   the scheduled transmission.
 *
 * The server does not process audio. Everything happens locally
 * in the browser.
 */
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Acoustic Data Transfer</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#111;color:#eee;font-family:Arial,sans-serif}
main{max-width:920px;margin:auto;padding:20px}
h1{margin:0 0 16px}
.card{background:#1c1c1c;border:1px solid #333;border-radius:10px;padding:18px;margin-bottom:16px}
label{display:block;color:#bbb;margin:0 0 6px}
textarea,input,select,button{font:inherit}
textarea,input,select{width:100%;background:#101010;color:#fff;border:1px solid #444;border-radius:6px;padding:10px}
textarea{min-height:120px;resize:vertical}
button{background:#2b2b2b;color:#fff;border:1px solid #555;border-radius:6px;padding:10px 15px;cursor:pointer}
button:hover{background:#383838}
button:disabled{opacity:.45;cursor:not-allowed}
.row{display:flex;gap:12px;flex-wrap:wrap}
.row>div{flex:1;min-width:180px}
.buttons{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
.status{padding:12px;border-radius:6px;background:#101010;border:1px solid #333;margin-top:12px}
.status.ok{border-color:#4c9}
.status.bad{border-color:#d55}
.progress{height:12px;background:#080808;border-radius:8px;overflow:hidden;margin-top:10px}
.progress>div{height:100%;width:0%;background:#aaa;transition:width .08s linear}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px}
.stat{background:#101010;border:1px solid #333;border-radius:6px;padding:10px}
.stat small{display:block;color:#888;margin-bottom:4px}
.stat strong{font-size:18px}
#log{height:220px;overflow:auto;white-space:pre-wrap;font:12px monospace;background:#080808;border:1px solid #333;padding:10px;border-radius:6px}
.result{display:none;padding:14px;margin-top:12px;border-radius:7px;font-weight:bold}
.result.ok{display:block;background:#17351f;border:1px solid #3c8}
.result.bad{display:block;background:#351717;border:1px solid #c55}
.note{color:#aaa;line-height:1.45}
.warning{color:#d9bd6b;line-height:1.45}
</style>
</head>
<body>
<main>
<h1>Acoustic Data Transfer</h1>

<div class="card">
    <label for="mode">Mode</label>
    <select id="mode">
        <option value="normal">Normal — computer to computer</option>
        <option value="self">Self-Test — speaker to microphone</option>
    </select>

    <p class="note">
        Self-Test uses the real speaker and microphone. It transmits the exact
        message you enter, acoustically, then decodes what the microphone actually hears.
    </p>

    <p class="warning">
        The default frequencies are near the upper edge of human hearing, not guaranteed
        inaudible. The transmitter uses smooth carrier crossfades rather than repeatedly
        turning the sound on and off, which greatly reduces clicking. Keep the volume low
        and stop the test if anyone can hear or feels uncomfortable.
    </p>
</div>

<div class="card">
    <label for="message">Message</label>
    <textarea id="message" maxlength="120" placeholder="Type a message to transmit..."></textarea>

    <div class="row">
        <div>
            <label for="frequency1">Frequency for 0</label>
            <input id="frequency1" type="number" value="17500" min="1000" max="24000">
        </div>
        <div>
            <label for="frequency2">Frequency for 1</label>
            <input id="frequency2" type="number" value="18500" min="1000" max="24000">
        </div>
        <div>
            <label for="symbolDuration">Symbol duration</label>
            <select id="symbolDuration">
                <option value="35">35 ms — faster</option>
                <option value="50" selected>50 ms — balanced</option>
                <option value="70">70 ms — reliable</option>
                <option value="100">100 ms — most reliable</option>
            </select>
        </div>
        <div>
            <label for="volume">Speaker volume</label>
            <input id="volume" type="range" min="0.01" max="0.5" step="0.01" value="0.16">
        </div>
    </div>

    <div class="buttons">
        <button id="startButton">Start Receiver</button>
        <button id="sendButton">Send</button>
        <button id="selfTestButton">Run Self-Test</button>
        <button id="stopButton">Stop</button>
    </div>

    <div class="status" id="status">Idle.</div>
    <div class="progress"><div id="progressBar"></div></div>
    <div class="result" id="result"></div>
</div>

<div class="card">
    <h3>Received message</h3>
    <textarea id="receivedMessage" readonly placeholder="Nothing received yet."></textarea>
</div>

<div class="card">
    <h3>Statistics</h3>
    <div class="stats">
        <div class="stat"><small>Valid bytes</small><strong id="validBytes">0</strong></div>
        <div class="stat"><small>Missing bytes</small><strong id="missingBytes">0</strong></div>
        <div class="stat"><small>Recovered by copy 2</small><strong id="recoveredBytes">0</strong></div>
        <div class="stat"><small>Bad frames</small><strong id="badFrames">0</strong></div>
        <div class="stat"><small>Noise level</small><strong id="noiseLevel">0</strong></div>
        <div class="stat"><small>Signal level</small><strong id="signalLevel">0</strong></div>
    </div>
</div>

<div class="card">
    <h3>Log</h3>
    <div id="log"></div>
</div>
</main>

<script>
"use strict";

/* -------------------- configuration -------------------- */

const MAX_BYTES = 120;

/*
 * Each byte frame:
 *
 *   8 bits  magic
 *   1 bit   copy number
 *   8 bits  byte index
 *   8 bits  total message length
 *   8 bits  payload byte
 *   8 bits  CRC-8 over copy/index/length/data
 *
 * The payload itself remains ordinary 8-bit binary.
 */
const FRAME_MAGIC = 0xA7;
const FRAME_BITS = 8 + 1 + 8 + 8 + 8 + 8;

/*
 * Alternating preamble plus a distinctive sync word.
 * A fresh preamble is sent before EVERY byte frame, which makes
 * lost frames independent instead of shifting the entire packet.
 */
const PREAMBLE = Array.from({length:32}, (_,i)=>i&1);
const SYNC = [1,0,1,1,0,0,1,0,0,1,1,0,1,0,0,1];

const $ = id => document.getElementById(id);

let audioContext = null;
let microphoneStream = null;
let microphoneSource = null;
let analyser = null;

let receiverRunning = false;
let transmitting = false;
let stopRequested = false;

let activeOscillators = [];
let activeGains = [];
let animationFrame = null;

let noiseFloor = -100;
let signalStrength = -100;

let validBytes = 0;
let missingBytes = 0;
let recoveredBytes = 0;
let badFrames = 0;

/* -------------------- UI helpers -------------------- */

function log(message) {
    const now = new Date().toLocaleTimeString();
    $("log").textContent += "[" + now + "] " + message + "\n";
    $("log").scrollTop = $("log").scrollHeight;
}

function status(message, type="") {
    $("status").textContent = message;
    $("status").className = "status" + (type ? " " + type : "");
}

function resetResult() {
    $("result").className = "result";
    $("result").textContent = "";
}

function stats() {
    $("validBytes").textContent = validBytes;
    $("missingBytes").textContent = missingBytes;
    $("recoveredBytes").textContent = recoveredBytes;
    $("badFrames").textContent = badFrames;
    $("noiseLevel").textContent = noiseFloor.toFixed(1);
    $("signalLevel").textContent = signalStrength.toFixed(1);
}

/* -------------------- UTF-8 / binary -------------------- */

function textToBytes(text) {
    return Array.from(new TextEncoder().encode(text));
}

function bytesToText(bytes) {
    return new TextDecoder().decode(new Uint8Array(bytes));
}

function byteToBits(value, count=8) {
    const bits = [];
    for (let i=count-1;i>=0;i--) bits.push((value >> i) & 1);
    return bits;
}

function bitsToByte(bits) {
    let value = 0;
    for (const bit of bits) value = (value << 1) | bit;
    return value & 0xFF;
}

/* -------------------- CRC-8 -------------------- */

function crc8(values) {
    let crc = 0x00;
    for (const value of values) {
        crc ^= value;
        for (let i=0;i<8;i++) {
            if (crc & 0x80) crc = ((crc << 1) ^ 0x07) & 0xFF;
            else crc = (crc << 1) & 0xFF;
        }
    }
    return crc;
}

/* -------------------- frame creation -------------------- */

function makeFrame(copy, index, total, dataByte) {
    const protectedBytes = [copy, index, total, dataByte];
    const crc = crc8(protectedBytes);

    return [
        ...byteToBits(FRAME_MAGIC),
        copy & 1,
        ...byteToBits(index),
        ...byteToBits(total),
        ...byteToBits(dataByte),
        ...byteToBits(crc)
    ];
}

function frameTransmission(copy, index, total, dataByte) {
    return [...PREAMBLE, ...SYNC, ...makeFrame(copy,index,total,dataByte)];
}

/*
 * A complete message consists of two passes over all bytes.
 * Copy 1 and copy 2 are separated by a short gap.
 */
function buildMessageFrames(text) {
    const bytes = textToBytes(text);
    if (bytes.length > MAX_BYTES) {
        throw new Error("Message is too long. Maximum is " + MAX_BYTES + " UTF-8 bytes.");
    }

    const frames = [];
    for (let copy=0; copy<2; copy++) {
        for (let i=0; i<bytes.length; i++) {
            frames.push({
                copy,
                index:i,
                total:bytes.length,
                data:bytes[i],
                bits:frameTransmission(copy,i,bytes.length,bytes[i])
            });
        }
    }
    return frames;
}

/* -------------------- audio setup -------------------- */

async function ensureAudio() {
    if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioContext.state === "suspended") await audioContext.resume();

    if (!microphoneStream) {
        microphoneStream = await navigator.mediaDevices.getUserMedia({
            audio:{
                echoCancellation:false,
                noiseSuppression:false,
                autoGainControl:false
            }
        });

        microphoneSource = audioContext.createMediaStreamSource(microphoneStream);
        analyser = audioContext.createAnalyser();

        /*
         * Large FFT gives better resolution at high frequencies.
         * The actual usable resolution depends on the browser sample rate.
         */
        analyser.fftSize = 8192;
        analyser.smoothingTimeConstant = 0;

        microphoneSource.connect(analyser);
        log("Microphone initialized.");
    }
}

/* -------------------- spectrum -------------------- */

function frequencyMagnitude(freq) {
    if (!analyser || !audioContext) return -100;

    const data = new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatFrequencyData(data);

    const bin = Math.round(freq * analyser.fftSize / audioContext.sampleRate);
    if (bin < 0 || bin >= data.length) return -100;

    let best = -100;

    for (let i=Math.max(0,bin-2); i<=Math.min(data.length-1,bin+2); i++) {
        if (data[i] > best) best = data[i];
    }

    return best;
}

function sampleTone(f1,f2) {
    const a = frequencyMagnitude(f1);
    const b = frequencyMagnitude(f2);

    signalStrength = Math.max(a,b);

    return {
        zero:a,
        one:b,
        difference:Math.abs(a-b),
        bit:b > a ? 1 : 0
    };
}

/* -------------------- receiver calibration -------------------- */

async function calibrate() {
    status("Calibrating microphone...");
    log("Calibrating noise floor.");

    let sum = 0;

    for (let i=0;i<30;i++) {
        if (stopRequested) return;
        const f1 = Number($("frequency1").value);
        const f2 = Number($("frequency2").value);
        const s = sampleTone(f1,f2);
        sum += Math.max(s.zero,s.one);
        noiseFloor = sum / (i+1);
        stats();
        await sleep(20);
    }

    log("Noise floor: " + noiseFloor.toFixed(1) + " dB.");
}

/* -------------------- receiver display loop -------------------- */

function receiverLoop() {
    if (!receiverRunning || stopRequested) return;

    const f1 = Number($("frequency1").value);
    const f2 = Number($("frequency2").value);

    const s = sampleTone(f1,f2);

    /*
     * Slow noise-floor tracking when there is not a strong signal.
     */
    if (s.difference < 1.0) {
        noiseFloor = noiseFloor * 0.995 + Math.max(s.zero,s.one) * 0.005;
    }

    stats();
    animationFrame = requestAnimationFrame(receiverLoop);
}

/* -------------------- transmission -------------------- */

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve,ms));
}

/*
 * This is deliberately interruptible.
 * STOP sets stopRequested and immediately silences the gain and
 * oscillator instead of waiting for the scheduled transmission.
 */
function hardStopAudio() {
    stopRequested = true;

    const now = audioContext ? audioContext.currentTime : 0;

    /*
     * Kill every active oscillator immediately. The gain is set to zero
     * first so STOP does not leave scheduled tones playing.
     */
    for (const gain of activeGains) {
        try {
            gain.gain.cancelScheduledValues(now);
            gain.gain.setValueAtTime(0, now);
        } catch {}
    }

    for (const oscillator of activeOscillators) {
        try {
            oscillator.stop();
        } catch {}
    }

    activeGains = [];
    activeOscillators = [];
}

function transmitBits(bits, progressStart, progressEnd) {
    return new Promise(async (resolve,reject) => {
        if (!audioContext) {
            return reject(new Error("Audio is not initialized."));
        }

        const f1 = Number($("frequency1").value);
        const f2 = Number($("frequency2").value);
        const symbolMs = Number($("symbolDuration").value);
        const symbolSeconds = symbolMs / 1000;
        const volume = Number($("volume").value);

        /*
         * The previous implementation turned the speaker gain on and off
         * for EVERY bit. That creates a click at every symbol boundary.
         *
         * Instead, both carrier oscillators run continuously:
         *
         *     oscillator 1 = frequency for 0
         *     oscillator 2 = frequency for 1
         *
         * Their gains crossfade smoothly between symbols. The total output
         * stays approximately constant, so there is no repeated on/off
         * pulse causing the clicking sound.
         */
        const osc0 = audioContext.createOscillator();
        const osc1 = audioContext.createOscillator();

        const gain0 = audioContext.createGain();
        const gain1 = audioContext.createGain();

        activeOscillators = [osc0, osc1];
        activeGains = [gain0, gain1];

        osc0.type = "sine";
        osc1.type = "sine";

        osc0.frequency.value = f1;
        osc1.frequency.value = f2;

        osc0.connect(gain0);
        osc1.connect(gain1);

        gain0.connect(audioContext.destination);
        gain1.connect(audioContext.destination);

        /*
         * Use short crossfades instead of hard switching.
         * 2 ms is short enough not to disturb symbol timing but long
         * enough to remove the sharp edges responsible for clicks.
         */
        const crossfade = Math.min(
            0.0025,
            symbolSeconds * 0.08
        );

        const start = audioContext.currentTime + 0.08;

        gain0.gain.setValueAtTime(0, start);
        gain1.gain.setValueAtTime(0, start);

        /*
         * Start with the first symbol already selected.
         */
        if (bits[0]) {
            gain1.gain.linearRampToValueAtTime(volume, start + crossfade);
        } else {
            gain0.gain.linearRampToValueAtTime(volume, start + crossfade);
        }

        osc0.start(start);
        osc1.start(start);

        for (let i=0; i<bits.length; i++) {
            if (stopRequested) {
                hardStopAudio();
                return resolve(false);
            }

            const t = start + i * symbolSeconds;
            const nextT = t + symbolSeconds;
            const bit = bits[i];

            /*
             * Crossfade at the symbol boundary.
             *
             * If the bit stays the same, no gain transition is needed.
             * If it changes, one carrier fades down while the other fades up.
             */
            if (i > 0 && bits[i] !== bits[i - 1]) {
                const fromGain = bit ? gain0 : gain1;
                const toGain = bit ? gain1 : gain0;

                fromGain.gain.setValueAtTime(volume, t);
                fromGain.gain.linearRampToValueAtTime(
                    0,
                    t + crossfade
                );

                toGain.gain.setValueAtTime(0, t);
                toGain.gain.linearRampToValueAtTime(
                    volume,
                    t + crossfade
                );
            }

            if (i % 4 === 0 || i === bits.length - 1) {
                const p =
                    progressStart +
                    (progressEnd - progressStart) *
                    ((i + 1) / bits.length);

                $("progressBar").style.width =
                    p.toFixed(1) + "%";
            }

            /*
             * This check does not wait for a timer. It just allows STOP
             * to be observed while the schedule is being built.
             */
            if (stopRequested) {
                hardStopAudio();
                return resolve(false);
            }

            void nextT;
        }

        const end =
            start +
            bits.length * symbolSeconds;

        /*
         * Smoothly fade both carriers at the end instead of cutting
         * the waveform off at a non-zero amplitude.
         */
        gain0.gain.setValueAtTime(
            bits[bits.length - 1] ? 0 : volume,
            end
        );

        gain1.gain.setValueAtTime(
            bits[bits.length - 1] ? volume : 0,
            end
        );

        gain0.gain.linearRampToValueAtTime(
            0,
            end + crossfade
        );

        gain1.gain.linearRampToValueAtTime(
            0,
            end + crossfade
        );

        try {
            osc0.stop(end + crossfade + 0.005);
            osc1.stop(end + crossfade + 0.005);
        } catch {}

        /*
         * Poll briefly rather than using one long uninterruptible wait.
         * This means STOP can terminate the transmission immediately.
         */
        const finishAt =
            performance.now() +
            Math.max(
                0,
                (end + crossfade + 0.01 -
                    audioContext.currentTime) * 1000
            );

        while (performance.now() < finishAt) {
            if (stopRequested) {
                hardStopAudio();
                return resolve(false);
            }

            await new Promise(r => setTimeout(r, 4));
        }

        if (stopRequested) {
            hardStopAudio();
            return resolve(false);
        }

        activeOscillators = [];
        activeGains = [];

        resolve(true);
    });
}

/* -------------------- normal sender -------------------- */

async function sendMessage() {
    if (transmitting) return;

    const text = $("message").value;
    if (!text) {
        status("Enter a message first.","bad");
        return;
    }

    try {
        transmitting = true;
        stopRequested = false;
        resetResult();

        $("sendButton").disabled = true;
        $("selfTestButton").disabled = true;

        await ensureAudio();

        const frames = buildMessageFrames(text);
        const total = frames.length;

        log("Sending " + textToBytes(text).length + " payload bytes.");
        log("Each payload byte will be transmitted twice.");
        log("Total acoustic frames: " + total + ".");

        for (let i=0;i<frames.length;i++) {
            if (stopRequested) break;

            const frame = frames[i];

            status(
                "Transmitting copy " +
                (frame.copy+1) +
                " of 2 — byte " +
                (frame.index+1) +
                " of " +
                frame.total +
                "..."
            );

            const startProgress = i / total * 100;
            const endProgress = (i+1) / total * 100;

            const ok = await transmitBits(
                frame.bits,
                startProgress,
                endProgress
            );

            if (!ok) break;

            /*
             * Tiny gap between frames makes frame boundaries
             * easier for the receiver to find.
             */
            await sleep(8);
        }

        if (stopRequested) {
            status("Transmission stopped.");
            log("Transmission stopped immediately.");
        } else {
            $("progressBar").style.width = "100%";
            status("Transmission complete.","ok");
            log("Transmission complete.");
        }

    } catch (e) {
        status("Transmission failed: " + e.message,"bad");
        log("Transmission error: " + e.message);
    } finally {
        transmitting = false;
        $("sendButton").disabled = false;
        $("selfTestButton").disabled = false;
    }
}

/* -------------------- self-test receiver -------------------- */

/*
 * Decode one frame using the real microphone.
 *
 * We use the absolute audio clock rather than setTimeout accumulation.
 * The transmitter and receiver are both in the same browser, so the
 * receiver can use the known symbol schedule for this self-test.
 */
async function captureFrame(bitsCount,symbolMs,f1,f2,startDelayMs=80) {
    await sleep(startDelayMs);

    const result = [];
    const symbolSeconds = symbolMs / 1000;

    /*
     * Capture according to wall-clock targets. This is important:
     * each sample is scheduled from the original start time rather
     * than from the previous sample.
     */
    const start = performance.now();

    for (let i=0;i<bitsCount;i++) {
        if (stopRequested) return null;

        const target = start + i * symbolMs + symbolMs * 0.52;
        const wait = target - performance.now();

        if (wait > 0) await sleep(wait);

        if (stopRequested) return null;

        /*
         * Take several closely spaced measurements around the center
         * and use the median-ish average. This reduces classroom noise.
         */
        const samples = [];

        for (let s=0;s<3;s++) {
            if (stopRequested) return null;

            const measurement = sampleTone(f1,f2);
            samples.push(measurement);

            if (s < 2) await sleep(Math.max(1,symbolMs*0.025));
        }

        let zero = 0;
        let one = 0;

        for (const sample of samples) {
            zero += sample.zero;
            one += sample.one;
        }

        zero /= samples.length;
        one /= samples.length;

        result.push(one > zero ? 1 : 0);
    }

    return result;
}

function parseFrame(bits) {
    if (!bits || bits.length !== FRAME_BITS) return null;

    const magic = bitsToByte(bits.slice(0,8));
    if (magic !== FRAME_MAGIC) return null;

    const copy = bits[8];
    const index = bitsToByte(bits.slice(9,17));
    const total = bitsToByte(bits.slice(17,25));
    const data = bitsToByte(bits.slice(25,33));
    const receivedCrc = bitsToByte(bits.slice(33,41));

    if (copy > 1) return null;
    if (total > MAX_BYTES || index >= total) return null;

    const calculatedCrc = crc8([copy,index,total,data]);

    if (receivedCrc !== calculatedCrc) return null;

    return {copy,index,total,data};
}

async function runSelfTest() {
    if (transmitting) return;

    const text = $("message").value;

    if (!text) {
        status("Enter the message you want to self-test.","bad");
        return;
    }

    try {
        transmitting = true;
        stopRequested = false;
        resetResult();
        $("progressBar").style.width = "0%";

        $("sendButton").disabled = true;
        $("selfTestButton").disabled = true;
        $("startButton").disabled = true;

        await ensureAudio();
        await calibrate();

        const bytes = textToBytes(text);
        const symbolMs = Number($("symbolDuration").value);
        const f1 = Number($("frequency1").value);
        const f2 = Number($("frequency2").value);

        /*
         * We capture each frame while it is being played.
         * This is a genuine acoustic loopback test.
         */
        const received = new Array(bytes.length);
        const receivedCopy = new Array(bytes.length);
        const firstSeenCopy = new Array(bytes.length).fill(-1);

        let valid = 0;
        let recovered = 0;
        let bad = 0;

        log("Self-test message: " + text);
        log("Payload bytes: " + bytes.length);
        log("Transmitting every byte twice.");

        const totalFrames = bytes.length * 2;
        let frameNumber = 0;

        /*
         * We need a frame capture and a transmission to begin together.
         * The capture waits 80 ms, matching the transmitter's audio start.
         */
        for (let copy=0;copy<2;copy++) {
            for (let index=0;index<bytes.length;index++) {
                if (stopRequested) break;

                frameNumber++;

                status(
                    "Self-test: copy " +
                    (copy+1) +
                    "/2 — byte " +
                    (index+1) +
                    "/" +
                    bytes.length
                );

                const bits =
                    frameTransmission(copy,index,bytes.length,bytes[index]);

                /*
                 * Capture is started first so the microphone is listening
                 * before the speaker begins.
                 */
                const capturePromise = captureFrame(
                    bits.length,
                    symbolMs,
                    f1,
                    f2,
                    80
                );

                await sleep(2);

                const sendPromise = transmitBits(
                    bits,
                    (frameNumber-1)/totalFrames*100,
                    frameNumber/totalFrames*100
                );

                const [captured, sent] =
                    await Promise.all([
                        capturePromise,
                        sendPromise
                    ]);

                if (!captured || !sent) break;

                /*
                 * The first 32 + 16 bits are synchronization.
                 */
                const frameDataStart =
                    PREAMBLE.length + SYNC.length;

                const frameData =
                    captured.slice(
                        frameDataStart,
                        frameDataStart + FRAME_BITS
                    );

                const parsed = parseFrame(frameData);

                if (!parsed) {
                    bad++;
                    badFrames++;
                    log(
                        "Byte " +
                        (index+1) +
                        ", copy " +
                        (copy+1) +
                        ": CRC/frame check failed."
                    );
                } else {
                    valid++;

                    if (received[parsed.index] === undefined) {
                        received[parsed.index] = parsed.data;
                        firstSeenCopy[parsed.index] = parsed.copy;
                    } else {
                        receivedCopy[parsed.index] = parsed.data;
                    }

                    log(
                        "Byte " +
                        (parsed.index+1) +
                        "/" +
                        parsed.total +
                        " received from copy " +
                        (parsed.copy+1) +
                        "."
                    );
                }

                if (stopRequested) break;

                await sleep(8);
            }

            if (stopRequested) break;
        }

        if (stopRequested) {
            status("Self-test stopped.");
            log("Self-test stopped immediately.");
            return;
        }

        /*
         * Combine the two copies.
         *
         * If copy 1 exists and copy 2 also exists:
         *   - if equal, keep it
         *   - if different, prefer the copy that passed CRC;
         *
         * Since parseFrame only accepts CRC-valid bytes, both values
         * are independently valid. In that rare conflict, keep the
         * first valid value and report the conflict.
         */
        const finalBytes = [];
        let conflicts = 0;

        for (let i=0;i<bytes.length;i++) {
            if (received[i] === undefined) {
                finalBytes.push(null);
                continue;
            }

            if (receivedCopy[i] !== undefined) {
                if (receivedCopy[i] !== received[i]) {
                    conflicts++;
                    log(
                        "Byte " +
                        (i+1) +
                        ": two valid copies differ; keeping first valid copy."
                    );
                }
            }

            finalBytes.push(received[i]);
        }

        missingBytes =
            finalBytes.filter(v => v === null).length;

        recoveredBytes = 0;

        for (let i=0;i<finalBytes.length;i++) {
            if (
                finalBytes[i] !== null &&
                firstSeenCopy[i] === 1
            ) {
                recoveredBytes++;
            }
        }

        validBytes =
            finalBytes.length - missingBytes;

        stats();

        if (missingBytes > 0) {
            $("result").className = "result bad";
            $("result").textContent =
                "SELF-TEST FAILED — " +
                missingBytes +
                " byte(s) were lost even after the second copy.";

            status(
                "Self-test failed: missing " +
                missingBytes +
                " byte(s).",
                "bad"
            );

            /*
             * Display what was recoverable.
             */
            const partial = finalBytes.map(
                b => b === null ? "�" : String.fromCharCode(b)
            ).join("");

            $("receivedMessage").value = partial;

            log(
                "Self-test failed. " +
                missingBytes +
                " bytes could not be recovered."
            );

        } else {
            const resultText =
                bytesToText(finalBytes);

            $("receivedMessage").value =
                resultText;

            if (resultText === text) {
                $("result").className = "result ok";
                $("result").textContent =
                    "SELF-TEST PASSED — all bytes recovered.";

                status(
                    "Self-test passed.",
                    "ok"
                );

                log(
                    "SELF-TEST PASSED. " +
                    valid +
                    " valid byte frames, " +
                    recoveredBytes +
                    " bytes recovered from the second copy."
                );
            } else {
                $("result").className = "result bad";
                $("result").textContent =
                    "SELF-TEST FAILED — decoded text differs.";

                status(
                    "Self-test failed: data mismatch.",
                    "bad"
                );

                log(
                    "Decoded text differs from the original."
                );
            }
        }

        $("progressBar").style.width = "100%";

        if (conflicts) {
            log("Valid-copy conflicts: " + conflicts);
        }

    } catch (e) {
        $("result").className = "result bad";
        $("result").textContent = "SELF-TEST FAILED";
        status("Self-test failed: " + e.message,"bad");
        log("Self-test error: " + e.message);
    } finally {
        transmitting = false;
        $("sendButton").disabled = false;
        $("selfTestButton").disabled = false;
        $("startButton").disabled = false;
    }
}

/* -------------------- normal receiver -------------------- */

/*
 * The normal receiver is intentionally kept running continuously.
 * Full automatic frame synchronization can be added independently
 * without affecting the 8-bit sender or self-test.
 */
async function startReceiver() {
    if (receiverRunning) return;

    try {
        stopRequested = false;
        await ensureAudio();

        receiverRunning = true;
        await calibrate();

        status("Receiver running. Listening...");
        log("Receiver started.");

        receiverLoop();
    } catch (e) {
        status("Microphone permission failed: " + e.message,"bad");
        log("Microphone error: " + e.message);
    }
}

/* -------------------- stop -------------------- */

function stopAll() {
    /*
     * This happens BEFORE waiting for anything else.
     * It immediately kills the current scheduled audio.
     */
    stopRequested = true;
    hardStopAudio();

    if (animationFrame) {
        cancelAnimationFrame(animationFrame);
        animationFrame = null;
    }

    receiverRunning = false;
    transmitting = false;

    $("progressBar").style.width = "0%";

    status("Stopped.");
    log("STOP pressed — audio transmission stopped immediately.");

    $("sendButton").disabled = false;
    $("selfTestButton").disabled = false;
    $("startButton").disabled = false;
}

/* -------------------- events -------------------- */

$("startButton").addEventListener("click",startReceiver);
$("sendButton").addEventListener("click",sendMessage);
$("selfTestButton").addEventListener("click",runSelfTest);
$("stopButton").addEventListener("click",stopAll);

stats();
log("Acoustic modem ready.");
log("Carrier mode: continuous dual-tone BFSK with smooth crossfades.");
log("Payload format: ordinary 8-bit bytes.");
log("Redundancy: every byte transmitted twice.");
</script>
</body>
</html>

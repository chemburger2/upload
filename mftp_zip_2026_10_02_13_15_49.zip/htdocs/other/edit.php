```php
<?php

/*
 * PRIVATE PROJECT EDITOR
 * Admin-only access.
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../project_access.php';

if (empty($_SESSION['is_admin'])) {
    header('Location: ../manage.php');
    exit;
}

$otherDir = realpath(__DIR__);
$message = '';
$error = '';

$selectedProject = trim((string)($_GET['project'] ?? $_POST['project'] ?? ''));
$selectedFile = trim((string)($_GET['file'] ?? $_POST['file'] ?? ''));
$currentDir = trim((string)($_GET['dir'] ?? $_POST['dir'] ?? ''), "/\\");

$users = $pdo->query(
    'SELECT id, username, is_admin FROM users ORDER BY username ASC'
)->fetchAll();

/*
 * Normalize a relative path without ever allowing it to escape the project.
 * Empty string means the project root.
 */
function normalizeRelativePath(string $path): string|false
{
    $path = str_replace('\\', '/', trim($path));

    if ($path === '' || $path === '/') {
        return '';
    }

    if (str_contains($path, "\0") || str_starts_with($path, '/')) {
        return false;
    }

    $parts = explode('/', $path);
    $clean = [];

    foreach ($parts as $part) {
        if ($part === '' || $part === '.') {
            continue;
        }

        if ($part === '..' || str_contains($part, "\0")) {
            return false;
        }

        $clean[] = $part;
    }

    return implode('/', $clean);
}

function isInsideBase(string $baseDir, string $fullPath): bool
{
    return $fullPath === $baseDir ||
        str_starts_with($fullPath, $baseDir . DIRECTORY_SEPARATOR);
}

/*
 * Safely resolve an existing file/folder.
 */
function safeExistingPath(string $baseDir, string $relativePath): string|false
{
    $relativePath = normalizeRelativePath($relativePath);

    if ($relativePath === false) {
        return false;
    }

    $fullPath = $relativePath === ''
        ? $baseDir
        : realpath($baseDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath));

    if ($fullPath === false || !isInsideBase($baseDir, $fullPath)) {
        return false;
    }

    return $fullPath;
}

/*
 * Safely construct a path that may not exist yet.
 */
function safeNewPath(string $baseDir, string $relativePath): string|false
{
    $relativePath = normalizeRelativePath($relativePath);

    if ($relativePath === false || $relativePath === '') {
        return false;
    }

    $fullPath = $baseDir . DIRECTORY_SEPARATOR .
        str_replace('/', DIRECTORY_SEPARATOR, $relativePath);

    $parent = dirname($fullPath);

    if (is_dir($parent)) {
        $realParent = realpath($parent);

        if ($realParent === false || !isInsideBase($baseDir, $realParent)) {
            return false;
        }
    } else {
        /*
         * Walk upward until we find an existing parent, then verify that
         * existing parent is still inside the project.
         */
        $check = $parent;

        while (!is_dir($check) && dirname($check) !== $check) {
            $check = dirname($check);
        }

        $realCheck = realpath($check);

        if ($realCheck === false || !isInsideBase($baseDir, $realCheck)) {
            return false;
        }
    }

    return $fullPath;
}

function relativeFromFullPath(string $baseDir, string $fullPath): string
{
    if ($fullPath === $baseDir) {
        return '';
    }

    return str_replace(
        DIRECTORY_SEPARATOR,
        '/',
        ltrim(substr($fullPath, strlen($baseDir)), DIRECTORY_SEPARATOR)
    );
}

function directoryEntries(string $directory): array
{
    $folders = [];
    $files = [];

    foreach (scandir($directory) ?: [] as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }

        $fullPath = $directory . DIRECTORY_SEPARATOR . $item;

        if (is_dir($fullPath)) {
            $folders[] = $item;
        } elseif (is_file($fullPath)) {
            $files[] = $item;
        }
    }

    natcasesort($folders);
    natcasesort($files);

    return [
        'folders' => array_values($folders),
        'files' => array_values($files),
    ];
}

function getAllProjectDirectories(string $projectPath, string $relative = ''): array
{
    $result = [''];

    $directory = $relative === ''
        ? $projectPath
        : $projectPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);

    if (!is_dir($directory)) {
        return $result;
    }

    foreach (scandir($directory) ?: [] as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }

        $fullPath = $directory . DIRECTORY_SEPARATOR . $item;

        if (is_dir($fullPath)) {
            $child = $relative === '' ? $item : $relative . '/' . $item;
            $result[] = $child;
            $result = array_merge(
                $result,
                getAllProjectDirectories($projectPath, $child)
            );
        }
    }

    natcasesort($result);
    return array_values(array_unique($result));
}

function removeDirectoryRecursive(string $directory): bool
{
    foreach (scandir($directory) ?: [] as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }

        $path = $directory . DIRECTORY_SEPARATOR . $item;

        if (is_dir($path)) {
            if (!removeDirectoryRecursive($path)) {
                return false;
            }
        } elseif (!unlink($path)) {
            return false;
        }
    }

    return rmdir($directory);
}

function redirectToBrowser(string $project, string $dir = '', string $file = ''): never
{
    $url = '?project=' . urlencode($project);

    if ($dir !== '') {
        $url .= '&dir=' . urlencode($dir);
    }

    if ($file !== '') {
        $url .= '&file=' . urlencode($file);
    }

    header('Location: ' . $url);
    exit;
}

/*
 * Project list.
 */
$projects = [];

foreach (scandir($otherDir) ?: [] as $item) {
    if (
        $item === '.' ||
        $item === '..' ||
        $item === 'private.php' ||
        $item === 'edit.php'
    ) {
        continue;
    }

    if (is_dir($otherDir . DIRECTORY_SEPARATOR . $item)) {
        $projects[] = $item;
    }
}

sort($projects, SORT_NATURAL | SORT_FLAG_CASE);

if ($selectedProject !== '' && !in_array($selectedProject, $projects, true)) {
    $selectedProject = '';
    $selectedFile = '';
    $currentDir = '';
}

$projectPath = false;

if ($selectedProject !== '') {
    $projectPath = safeExistingPath($otherDir, $selectedProject);

    if ($projectPath === false || !is_dir($projectPath)) {
        $selectedProject = '';
        $selectedFile = '';
        $currentDir = '';
        $error = 'Invalid project.';
    }
}

if ($selectedProject !== '') {
    $normalizedDir = normalizeRelativePath($currentDir);

    if ($normalizedDir === false) {
        $currentDir = '';
        $error = 'Invalid folder path.';
    } else {
        $currentDir = $normalizedDir;
    }

    $currentPath = safeExistingPath($projectPath, $currentDir);

    if ($currentPath === false || !is_dir($currentPath)) {
        $currentDir = '';
        $currentPath = $projectPath;
    }
}

/*
 * POST actions.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    /*
     * Save project access.
     */
    if ($action === 'save_access') {
        if ($selectedProject === '') {
            $error = 'No project selected.';
        } else {
            $allowedUsers = $_POST['access_users'] ?? [];

            if (!is_array($allowedUsers)) {
                $allowedUsers = [];
            }

            $allowedUsers = array_map('intval', $allowedUsers);
            $allowedUsers = array_values(array_unique(array_filter(
                $allowedUsers,
                fn(int $id): bool => $id > 0
            )));

            try {
                $pdo->beginTransaction();

                $delete = $pdo->prepare(
                    'DELETE FROM project_access WHERE project_name = ?'
                );
                $delete->execute([$selectedProject]);

                $insert = $pdo->prepare(
                    'INSERT INTO project_access (user_id, project_name, access)
                     VALUES (?, ?, 1)'
                );

                foreach ($allowedUsers as $userId) {
                    $insert->execute([$userId, $selectedProject]);
                }

                $pdo->commit();
                $message = 'Project access saved successfully.';
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error = 'Could not save project access.';
            }
        }
    }

    /*
     * Create a folder in the current browser directory.
     */
    elseif ($action === 'create_folder') {
        $folderName = trim((string)($_POST['folder_name'] ?? ''));

        if ($selectedProject === '') {
            $error = 'No project selected.';
        } elseif ($folderName === '') {
            $error = 'Please enter a folder name.';
        } elseif (
            str_contains($folderName, "\0") ||
            $folderName === '.' ||
            $folderName === '..' ||
            str_contains($folderName, '/') ||
            str_contains($folderName, '\\')
        ) {
            $error = 'Invalid folder name.';
        } elseif ($currentPath === false || !is_dir($currentPath)) {
            $error = 'Invalid destination folder.';
        } else {
            $newFolder = safeNewPath(
                $projectPath,
                ($currentDir === '' ? '' : $currentDir . '/') . $folderName
            );

            if ($newFolder === false) {
                $error = 'Invalid folder path.';
            } elseif (file_exists($newFolder)) {
                $error = 'That folder already exists.';
            } elseif (!mkdir($newFolder, 0755)) {
                $error = 'Could not create the folder.';
            } else {
                $message = 'Folder created successfully.';
            }
        }
    }

    /*
     * Create a file.
     */
    elseif ($action === 'create_file') {
        $fileName = trim((string)($_POST['new_file'] ?? ''));

        if ($selectedProject === '') {
            $error = 'No project selected.';
        } elseif ($fileName === '') {
            $error = 'Please enter a filename.';
        } elseif (
            str_contains($fileName, "\0") ||
            str_starts_with($fileName, '/') ||
            str_starts_with($fileName, '\\')
        ) {
            $error = 'Invalid file path.';
        } else {
            $base = $currentDir === '' ? '' : $currentDir . '/';

            $newFilePath = safeNewPath(
                $projectPath,
                $base . $fileName
            );

            if ($newFilePath === false) {
                $error = 'Invalid file path.';
            } elseif (file_exists($newFilePath)) {
                $error = 'That file or folder already exists.';
            } else {
                $parent = dirname($newFilePath);

                if (!is_dir($parent) && !mkdir($parent, 0755, true)) {
                    $error = 'Could not create the required folder.';
                } elseif (file_put_contents($newFilePath, '') === false) {
                    $error = 'Could not create the file.';
                } else {
                    $selectedFile = relativeFromFullPath(
                        $projectPath,
                        $newFilePath
                    );

                    $message = 'File created successfully.';
                }
            }
        }
    }

    /*
     * Upload into the current browser directory.
     */
    elseif ($action === 'upload') {
        if ($selectedProject === '') {
            $error = 'No project selected.';
        } elseif (
            !isset($_FILES['upload_file']) ||
            $_FILES['upload_file']['error'] !== UPLOAD_ERR_OK
        ) {
            $error = 'Please select a file to upload.';
        } else {
            $originalName = basename(
                (string)$_FILES['upload_file']['name']
            );

            $fileName = preg_replace(
                '/[^a-zA-Z0-9._-]/',
                '_',
                $originalName
            );

            if ($fileName === '' || $fileName === false) {
                $error = 'Invalid filename.';
            } else {
                $destination = safeNewPath(
                    $projectPath,
                    ($currentDir === '' ? '' : $currentDir . '/') . $fileName
                );

                if ($destination === false) {
                    $error = 'Invalid upload path.';
                } elseif (file_exists($destination)) {
                    $error = 'A file or folder with that name already exists.';
                } elseif (
                    move_uploaded_file(
                        $_FILES['upload_file']['tmp_name'],
                        $destination
                    )
                ) {
                    $selectedFile = relativeFromFullPath(
                        $projectPath,
                        $destination
                    );

                    $message = 'File uploaded successfully.';
                } else {
                    $error = 'Could not upload the file.';
                }
            }
        }
    }

    /*
     * Save an existing file.
     */
    elseif ($action === 'save') {
        if ($selectedProject === '' || $selectedFile === '') {
            $error = 'No file selected.';
        } else {
            $filePath = safeExistingPath(
                $projectPath,
                $selectedFile
            );

            if ($filePath === false || !is_file($filePath)) {
                $error = 'File does not exist.';
            } elseif (
                file_put_contents(
                    $filePath,
                    (string)($_POST['code'] ?? '')
                ) === false
            ) {
                $error = 'Could not save the file.';
            } else {
                $message = 'File saved successfully.';
            }
        }
    }

    /*
     * Rename a file or folder.
     */
    elseif ($action === 'rename') {
        $itemPath = trim((string)($_POST['item'] ?? ''));
        $newName = trim((string)($_POST['new_name'] ?? ''));

        if ($selectedProject === '' || $itemPath === '') {
            $error = 'No item selected.';
        } elseif ($newName === '') {
            $error = 'Please enter a new name.';
        } elseif (
            $newName === '.' ||
            $newName === '..' ||
            str_contains($newName, "\0") ||
            str_contains($newName, '/') ||
            str_contains($newName, '\\')
        ) {
            $error = 'Invalid name.';
        } else {
            $itemFullPath = safeExistingPath(
                $projectPath,
                $itemPath
            );

            if ($itemFullPath === false || $itemFullPath === $projectPath) {
                $error = 'Invalid item.';
            } else {
                $parent = dirname($itemFullPath);
                $destination = $parent . DIRECTORY_SEPARATOR . $newName;

                $realParent = realpath($parent);

                if (
                    $realParent === false ||
                    !isInsideBase($projectPath, $realParent)
                ) {
                    $error = 'Invalid destination.';
                } elseif (file_exists($destination)) {
                    $error = 'An item with that name already exists.';
                } elseif (!rename($itemFullPath, $destination)) {
                    $error = 'Could not rename the item.';
                } else {
                    $oldRelative = relativeFromFullPath(
                        $projectPath,
                        $itemFullPath
                    );

                    $newRelative = relativeFromFullPath(
                        $projectPath,
                        $destination
                    );

                    if (is_dir($destination)) {
                        if (
                            $currentDir === $oldRelative ||
                            str_starts_with(
                                $currentDir,
                                $oldRelative . '/'
                            )
                        ) {
                            $currentDir =
                                $newRelative .
                                substr(
                                    $currentDir,
                                    strlen($oldRelative)
                                );
                        }
                    }

                    if ($selectedFile === $oldRelative) {
                        $selectedFile = $newRelative;
                    }

                    $message = 'Renamed successfully.';
                }
            }
        }
    }

    /*
     * Move a file or folder to another folder.
     */
    elseif ($action === 'move') {
        $itemPath = trim((string)($_POST['item'] ?? ''));
        $destinationDir = trim(
            (string)($_POST['destination_dir'] ?? ''),
            "/\\"
        );

        if ($selectedProject === '' || $itemPath === '') {
            $error = 'No item selected.';
        } else {
            $itemPathNormalized = normalizeRelativePath($itemPath);
            $destinationDirNormalized = normalizeRelativePath(
                $destinationDir
            );

            if (
                $itemPathNormalized === false ||
                $destinationDirNormalized === false
            ) {
                $error = 'Invalid move path.';
            } else {
                $itemFullPath = safeExistingPath(
                    $projectPath,
                    $itemPathNormalized
                );

                $destinationFullPath = safeExistingPath(
                    $projectPath,
                    $destinationDirNormalized
                );

                if (
                    $itemFullPath === false ||
                    $destinationFullPath === false ||
                    $itemFullPath === $projectPath ||
                    !is_dir($destinationFullPath)
                ) {
                    $error = 'Invalid move destination.';
                } else {
                    $itemName = basename($itemFullPath);

                    $destination =
                        $destinationFullPath .
                        DIRECTORY_SEPARATOR .
                        $itemName;

                    /*
                     * Prevent moving a folder into itself or a child.
                     */
                    if (
                        is_dir($itemFullPath) &&
                        (
                            $destinationFullPath === $itemFullPath ||
                            str_starts_with(
                                $destinationFullPath,
                                $itemFullPath . DIRECTORY_SEPARATOR
                            )
                        )
                    ) {
                        $error = 'A folder cannot be moved into itself.';
                    } elseif (file_exists($destination)) {
                        $error =
                            'An item with that name already exists in the destination.';
                    } elseif (!rename($itemFullPath, $destination)) {
                        $error = 'Could not move the item.';
                    } else {
                        $oldRelative = relativeFromFullPath(
                            $projectPath,
                            $itemFullPath
                        );

                        $newRelative = relativeFromFullPath(
                            $projectPath,
                            $destination
                        );

                        if (is_dir($itemFullPath)) {
                            if (
                                $currentDir === $oldRelative ||
                                str_starts_with(
                                    $currentDir,
                                    $oldRelative . '/'
                                )
                            ) {
                                $currentDir =
                                    $newRelative .
                                    substr(
                                        $currentDir,
                                        strlen($oldRelative)
                                    );
                            }
                        }

                        if ($selectedFile === $oldRelative) {
                            $selectedFile = $newRelative;
                        }

                        $message = 'Moved successfully.';
                    }
                }
            }
        }
    }

    /*
     * Delete a file or folder.
     */
    elseif ($action === 'delete_item') {
        $itemPath = trim((string)($_POST['item'] ?? ''));

        if ($selectedProject === '' || $itemPath === '') {
            $error = 'No item selected.';
        } else {
            $itemFullPath = safeExistingPath(
                $projectPath,
                $itemPath
            );

            if (
                $itemFullPath === false ||
                $itemFullPath === $projectPath
            ) {
                $error = 'Invalid item.';
            } elseif (is_dir($itemFullPath)) {
                if (removeDirectoryRecursive($itemFullPath)) {
                    if (
                        $currentDir === $itemPath ||
                        str_starts_with(
                            $currentDir,
                            $itemPath . '/'
                        )
                    ) {
                        $currentDir = dirname($itemPath);

                        if ($currentDir === '.') {
                            $currentDir = '';
                        }
                    }

                    if (
                        $selectedFile === $itemPath ||
                        str_starts_with(
                            $selectedFile,
                            $itemPath . '/'
                        )
                    ) {
                        $selectedFile = '';
                    }

                    $message = 'Folder deleted successfully.';
                } else {
                    $error = 'Could not delete the folder.';
                }
            } elseif (unlink($itemFullPath)) {
                if ($selectedFile === $itemPath) {
                    $selectedFile = '';
                }

                $message = 'File deleted successfully.';
            } else {
                $error = 'Could not delete the file.';
            }
        }
    }

    /*
     * Refresh paths after operations.
     */
    if ($selectedProject !== '') {
        $projectPath = safeExistingPath(
            $otherDir,
            $selectedProject
        );

        if ($projectPath !== false) {
            $currentPath = safeExistingPath(
                $projectPath,
                $currentDir
            );

            if (
                $currentPath === false ||
                !is_dir($currentPath)
            ) {
                $currentDir = '';
                $currentPath = $projectPath;
            }
        }
    }
}

/*
 * Directory contents.
 */
$entries = [
    'folders' => [],
    'files' => [],
];

$allDirectories = [''];

if (
    $selectedProject !== '' &&
    $projectPath !== false
) {
    $entries = directoryEntries($currentPath);
    $allDirectories = getAllProjectDirectories($projectPath);
}

/*
 * Selected file.
 */
$fileContents = '';

if (
    $selectedProject !== '' &&
    $selectedFile !== '' &&
    $projectPath !== false
) {
    $filePath = safeExistingPath(
        $projectPath,
        $selectedFile
    );

    if (
        $filePath !== false &&
        is_file($filePath)
    ) {
        $loaded = file_get_contents($filePath);
        $fileContents = $loaded === false ? '' : $loaded;
    } else {
        $selectedFile = '';
    }
}

/*
 * Access list.
 */
$allowedUserIds = [];

if ($selectedProject !== '') {
    $accessStmt = $pdo->prepare(
        'SELECT user_id
         FROM project_access
         WHERE project_name = ?
         AND access = 1'
    );

    $accessStmt->execute([$selectedProject]);

    $allowedUserIds = array_map(
        'intval',
        $accessStmt->fetchAll(PDO::FETCH_COLUMN)
    );
}

function browserUrl(
    string $project,
    string $dir = '',
    string $file = ''
): string {
    $url = '?project=' . urlencode($project);

    if ($dir !== '') {
        $url .= '&dir=' . urlencode($dir);
    }

    if ($file !== '') {
        $url .= '&file=' . urlencode($file);
    }

    return $url;
}

function displaySize(string $path): string
{
    $size = @filesize($path);

    if ($size === false) {
        return '';
    }

    if ($size < 1024) {
        return $size . ' B';
    }

    if ($size < 1024 * 1024) {
        return number_format($size / 1024, 1) . ' KB';
    }

    return number_format(
        $size / (1024 * 1024),
        1
    ) . ' MB';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Private Project Editor</title>

    <link rel="stylesheet" href="../style.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #121214;
            color: #e1e1e6;
            font-family:
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Roboto,
                Arial,
                sans-serif;
        }

        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin-bottom: 25px;
        }

        .header h1 {
            margin: 0;
        }

        .header-buttons,
        .button-row,
        .editor-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #29292e;
            color: #e1e1e6;
            border: 0;
            border-radius: 8px;
            padding: 10px 15px;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
            font-size: .9rem;
        }

        .button:hover {
            background: #35353c;
            color: #fff;
        }

        .button-primary {
            background: #8257e5;
            color: #fff;
        }

        .button-primary:hover {
            background: #996dff;
            color: #fff;
        }

        .button-danger {
            background: #b83b3b;
            color: #fff;
        }

        .button-danger:hover {
            background: #d04444;
            color: #fff;
        }

        .button-small {
            padding: 7px 10px;
            font-size: .82rem;
        }

        .panel {
            background: #1e1e24;
            border: 1px solid #29292e;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }

        select,
        input[type="text"] {
            width: 100%;
            background: #121214;
            color: #e1e1e6;
            border: 1px solid #29292e;
            border-radius: 8px;
            padding: 11px 12px;
            outline: 0;
            font-size: .9rem;
        }

        select:focus,
        input[type="text"]:focus {
            border-color: #8257e5;
        }

        .project-select {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .workspace {
            display: grid;
            grid-template-columns: 340px 1fr;
            gap: 20px;
            align-items: start;
        }

        .files {
            padding: 15px;
            min-width: 0;
        }

        .files-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }

        .files-header h2 {
            margin: 0;
            font-size: 1rem;
        }

        .path-bar {
            display: flex;
            align-items: center;
            gap: 5px;
            flex-wrap: wrap;
            padding: 8px;
            background: #121214;
            border: 1px solid #29292e;
            border-radius: 8px;
            margin-bottom: 10px;
            font-size: .82rem;
        }

        .path-bar a {
            color: #bba5ff;
            text-decoration: none;
        }

        .path-separator {
            color: #666670;
        }

        .file-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .file-item {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 5px;
            align-items: center;
            margin-bottom: 3px;
            border-radius: 7px;
        }

        .file-item:hover {
            background: #29292e;
        }

        .file-item.active {
            background: #29292e;
        }

        .item-link {
            min-width: 0;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 9px 8px;
            color: #b7b7c2;
            text-decoration: none;
            word-break: break-all;
        }

        .file-item.active .item-link {
            color: #bda5ff;
            font-weight: 600;
        }

        .item-icon {
            flex: 0 0 auto;
            width: 18px;
            text-align: center;
            color: #9999a6;
        }

        .folder .item-icon {
            color: #d0b45b;
        }

        .item-meta {
            color: #686873;
            font-size: .74rem;
            white-space: nowrap;
            padding-right: 5px;
        }

        .item-actions {
            display: flex;
            gap: 4px;
            opacity: 0;
            padding-right: 5px;
        }

        .file-item:hover .item-actions,
        .file-item.active .item-actions {
            opacity: 1;
        }

        .icon-button {
            width: 30px;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 0;
            border-radius: 6px;
            background: #35353c;
            color: #d5d5dc;
            cursor: pointer;
            font-size: 11px;
        }

        .icon-button:hover {
            background: #45454d;
        }

        .empty {
            color: #737380;
            text-align: center;
            padding: 30px 10px;
        }

        .section-title {
            margin: 0 0 6px;
        }

        .section-description {
            color: #a8a8b3;
            margin: 0 0 15px;
            font-size: .9rem;
        }

        .form-row {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .editor {
            min-height: 500px;
        }

        .editor-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
        }

        .filename {
            color: #a8a8b3;
            font-size: .9rem;
            word-break: break-all;
        }

        textarea {
            width: 100%;
            min-height: 560px;
            resize: vertical;
            background: #121214;
            color: #e1e1e6;
            border: 1px solid #29292e;
            border-radius: 8px;
            padding: 15px;
            font-family:
                Consolas,
                Monaco,
                "Courier New",
                monospace;
            font-size: 14px;
            line-height: 1.5;
            outline: 0;
        }

        textarea:focus {
            border-color: #8257e5;
        }

        input[type="file"] {
            width: 100%;
            background: #121214;
            color: #a8a8b3;
            border: 1px solid #29292e;
            border-radius: 8px;
            padding: 10px;
        }

        input[type="file"]::file-selector-button {
            background: #29292e;
            color: #e1e1e6;
            border: 0;
            border-radius: 6px;
            padding: 8px 12px;
            margin-right: 10px;
            cursor: pointer;
            font-weight: 600;
        }

        .message {
            background: #25252c;
            border: 1px solid #35353d;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .error {
            color: #ff8080;
        }

        .access-users {
            display: grid;
            grid-template-columns:
                repeat(auto-fill, minmax(220px, 1fr));
            gap: 8px;
            margin-top: 15px;
        }

        .access-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            background: #121214;
            border: 1px solid #29292e;
            border-radius: 8px;
        }

        .access-user input {
            width: 17px;
            height: 17px;
        }

        .access-user-name {
            font-weight: 600;
        }

        .access-user-admin {
            color: #a8a8b3;
            font-size: .78rem;
            margin-left: auto;
        }

        .tools {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .modal-backdrop {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .65);
            align-items: center;
            justify-content: center;
            padding: 20px;
            z-index: 1000;
        }

        .modal-backdrop.open {
            display: flex;
        }

        .modal {
            width: 100%;
            max-width: 480px;
            background: #1e1e24;
            border: 1px solid #35353d;
            border-radius: 12px;
            padding: 20px;
            box-shadow:
                0 20px 60px rgba(0,0,0,.45);
        }

        .modal h3 {
            margin: 0 0 8px;
        }

        .modal p {
            color: #a8a8b3;
            font-size: .88rem;
            margin: 0 0 15px;
            word-break: break-all;
        }

        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 15px;
        }

        code {
            color: #c8aaff;
            background: #121214;
            padding: 2px 5px;
            border-radius: 4px;
        }

        @media (max-width: 950px) {
            .workspace {
                grid-template-columns: 1fr;
            }

            .tools {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 650px) {
            .container {
                padding: 20px 15px;
            }

            .header {
                align-items: flex-start;
                flex-direction: column;
            }

            .header-buttons {
                width: 100%;
            }

            .header-buttons .button {
                flex: 1;
            }

            .editor-header {
                align-items: flex-start;
                flex-direction: column;
            }

            .item-actions {
                opacity: 1;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <div class="header">

        <div>
            <h1>Project Editor</h1>

            <p style="color:#a8a8b3;margin:6px 0 0;">
                Edit and manage your private projects.
            </p>
        </div>

        <div class="header-buttons">

            <a
                href="private.php"
                class="button"
            >
                Private Pages
            </a>

            <a
                href="../admin.php"
                class="button"
            >
                Admin Panel
            </a>

        </div>

    </div>


    <?php if ($message): ?>

        <div class="message">
            <?= htmlspecialchars($message) ?>
        </div>

    <?php endif; ?>


    <?php if ($error): ?>

        <div class="message error">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>


    <div class="panel">

        <h2 class="section-title">
            Open Project
        </h2>

        <p class="section-description">
            Choose the private project you want to edit.
        </p>

        <form method="GET">

            <div class="project-select">

                <select
                    name="project"
                    required
                >

                    <option value="">
                        Select a project...
                    </option>

                    <?php foreach ($projects as $project): ?>

                        <option
                            value="<?= htmlspecialchars($project) ?>"
                            <?= $project === $selectedProject
                                ? 'selected'
                                : '' ?>
                        >
                            <?= htmlspecialchars($project) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

                <button
                    type="submit"
                    class="button button-primary"
                >
                    Open Project
                </button>

            </div>

        </form>

    </div>


    <?php if ($selectedProject !== ''): ?>


        <div class="panel">

            <h2 class="section-title">
                Project Access
            </h2>

            <p class="section-description">
                Choose which accounts can open this project.
                Administrators always have access.
            </p>

            <form method="POST">

                <input
                    type="hidden"
                    name="action"
                    value="save_access"
                >

                <input
                    type="hidden"
                    name="project"
                    value="<?= htmlspecialchars($selectedProject) ?>"
                >

                <input
                    type="hidden"
                    name="dir"
                    value="<?= htmlspecialchars($currentDir) ?>"
                >

                <div class="access-users">

                    <?php foreach ($users as $user): ?>

                        <label class="access-user">

                            <?php if ((int)$user['is_admin'] === 1): ?>

                                <input
                                    type="checkbox"
                                    checked
                                    disabled
                                >

                            <?php else: ?>

                                <input
                                    type="checkbox"
                                    name="access_users[]"
                                    value="<?= (int)$user['id'] ?>"
                                    <?= in_array(
                                        (int)$user['id'],
                                        $allowedUserIds,
                                        true
                                    )
                                        ? 'checked'
                                        : '' ?>
                                >

                            <?php endif; ?>

                            <span class="access-user-name">
                                <?= htmlspecialchars(
                                    (string)$user['username']
                                ) ?>
                            </span>

                            <?php if ((int)$user['is_admin'] === 1): ?>

                                <span class="access-user-admin">
                                    Admin
                                </span>

                            <?php endif; ?>

                        </label>

                    <?php endforeach; ?>

                </div>

                <div style="margin-top:15px;">

                    <button
                        type="submit"
                        class="button button-primary"
                    >
                        Save Access
                    </button>

                </div>

            </form>

        </div>


        <div class="workspace">


            <!-- FILE BROWSER -->

            <div class="panel files">

                <div class="files-header">

                    <h2>
                        <?= htmlspecialchars($selectedProject) ?>
                    </h2>

                </div>


                <?php
                $pathParts =
                    $currentDir === ''
                        ? []
                        : explode('/', $currentDir);

                $runningPath = '';
                ?>


                <div class="path-bar">

                    <a
                        href="<?= htmlspecialchars(
                            browserUrl($selectedProject)
                        ) ?>"
                    >
                        Project root
                    </a>

                    <?php foreach ($pathParts as $part): ?>

                        <?php
                        $runningPath =
                            $runningPath === ''
                                ? $part
                                : $runningPath . '/' . $part;
                        ?>

                        <span class="path-separator">
                            /
                        </span>

                        <a
                            href="<?= htmlspecialchars(
                                browserUrl(
                                    $selectedProject,
                                    $runningPath
                                )
                            ) ?>"
                        >
                            <?= htmlspecialchars($part) ?>
                        </a>

                    <?php endforeach; ?>

                </div>


                <div
                    class="button-row"
                    style="margin-bottom:10px;"
                >

                    <?php if ($currentDir !== ''): ?>

                        <?php
                        $parentDir = dirname($currentDir);

                        if ($parentDir === '.') {
                            $parentDir = '';
                        }
                        ?>

                        <a
                            class="button button-small"
                            href="<?= htmlspecialchars(
                                browserUrl(
                                    $selectedProject,
                                    $parentDir
                                )
                            ) ?>"
                        >
                            Up
                        </a>

                    <?php endif; ?>


                    <button
                        type="button"
                        class="button button-small"
                        onclick="openModal('create-folder-modal')"
                    >
                        New Folder
                    </button>

                </div>


                <ul class="file-list">


                    <?php if (
                        empty($entries['folders']) &&
                        empty($entries['files'])
                    ): ?>

                        <li class="empty">
                            This folder is empty.
                        </li>

                    <?php endif; ?>


                    <!-- FOLDERS -->

                    <?php foreach ($entries['folders'] as $folder): ?>

                        <?php
                        $folderRelative =
                            $currentDir === ''
                                ? $folder
                                : $currentDir . '/' . $folder;
                        ?>

                        <li class="file-item folder">

                            <a
                                class="item-link"
                                href="<?= htmlspecialchars(
                                    browserUrl(
                                        $selectedProject,
                                        $folderRelative
                                    )
                                ) ?>"
                            >

                                <span class="item-icon">
                                    ▰
                                </span>

                                <span>
                                    <?= htmlspecialchars($folder) ?>
                                </span>

                            </a>


                            <div class="item-actions">

                                <button
                                    type="button"
                                    class="icon-button"
                                    title="Rename folder"
                                    onclick='openRenameModal(
                                        <?= json_encode($folderRelative) ?>,
                                        <?= json_encode($folder) ?>
                                    )'
                                >
                                    Rename
                                </button>


                                <button
                                    type="button"
                                    class="icon-button"
                                    title="Move folder"
                                    onclick='openMoveModal(
                                        <?= json_encode($folderRelative) ?>,
                                        <?= json_encode($folder) ?>
                                    )'
                                >
                                    Move
                                </button>


                                <button
                                    type="button"
                                    class="icon-button"
                                    title="Delete folder"
                                    onclick='deleteItem(
                                        <?= json_encode($folderRelative) ?>,
                                        true
                                    )'
                                >
                                    Delete
                                </button>

                            </div>

                        </li>

                    <?php endforeach; ?>


                    <!-- FILES -->

                    <?php foreach ($entries['files'] as $file): ?>

                        <?php
                        $fileRelative =
                            $currentDir === ''
                                ? $file
                                : $currentDir . '/' . $file;

                        $isActive =
                            $fileRelative === $selectedFile;

                        $fileFullPath =
                            $currentPath .
                            DIRECTORY_SEPARATOR .
                            $file;
                        ?>

                        <li
                            class="file-item
                                <?= $isActive ? 'active' : '' ?>"
                        >

                            <a
                                class="item-link"
                                href="<?= htmlspecialchars(
                                    browserUrl(
                                        $selectedProject,
                                        $currentDir,
                                        $fileRelative
                                    )
                                ) ?>"
                            >

                                <span class="item-icon">
                                    •
                                </span>

                                <span>
                                    <?= htmlspecialchars($file) ?>
                                </span>

                                <span class="item-meta">
                                    <?= htmlspecialchars(
                                        displaySize($fileFullPath)
                                    ) ?>
                                </span>

                            </a>


                            <div class="item-actions">

                                <button
                                    type="button"
                                    class="icon-button"
                                    title="Rename file"
                                    onclick='openRenameModal(
                                        <?= json_encode($fileRelative) ?>,
                                        <?= json_encode($file) ?>
                                    )'
                                >
                                    Rename
                                </button>


                                <button
                                    type="button"
                                    class="icon-button"
                                    title="Move file"
                                    onclick='openMoveModal(
                                        <?= json_encode($fileRelative) ?>,
                                        <?= json_encode($file) ?>
                                    )'
                                >
                                    Move
                                </button>


                                <button
                                    type="button"
                                    class="icon-button"
                                    title="Delete file"
                                    onclick='deleteItem(
                                        <?= json_encode($fileRelative) ?>,
                                        false
                                    )'
                                >
                                    Delete
                                </button>

                            </div>

                        </li>

                    <?php endforeach; ?>


                </ul>

            </div>


            <div>


                <!-- EDITOR -->

                <?php if ($selectedFile !== ''): ?>

                    <div class="panel editor">

                        <div class="editor-header">

                            <div class="filename">
                                <?= htmlspecialchars(
                                    $selectedFile
                                ) ?>
                            </div>


                            <div class="editor-actions">

                                <button
                                    type="button"
                                    class="button button-small"
                                    onclick='openRenameModal(
                                        <?= json_encode($selectedFile) ?>,
                                        <?= json_encode(
                                            basename($selectedFile)
                                        ) ?>
                                    )'
                                >
                                    Rename
                                </button>


                                <button
                                    type="button"
                                    class="button button-small"
                                    onclick='openMoveModal(
                                        <?= json_encode($selectedFile) ?>,
                                        <?= json_encode(
                                            basename($selectedFile)
                                        ) ?>
                                    )'
                                >
                                    Move
                                </button>


                                <button
                                    type="button"
                                    class="button
                                        button-small
                                        button-danger"
                                    onclick='deleteItem(
                                        <?= json_encode($selectedFile) ?>,
                                        false
                                    )'
                                >
                                    Delete
                                </button>

                            </div>

                        </div>


                        <form method="POST">

                            <input
                                type="hidden"
                                name="action"
                                value="save"
                            >

                            <input
                                type="hidden"
                                name="project"
                                value="<?= htmlspecialchars(
                                    $selectedProject
                                ) ?>"
                            >

                            <input
                                type="hidden"
                                name="file"
                                value="<?= htmlspecialchars(
                                    $selectedFile
                                ) ?>"
                            >


                            <textarea
                                name="code"
                                spellcheck="false"
                            ><?= htmlspecialchars(
                                $fileContents
                            ) ?></textarea>


                            <div style="margin-top:12px;">

                                <button
                                    type="submit"
                                    class="button button-primary"
                                >
                                    Save File
                                </button>

                            </div>

                        </form>

                    </div>

                <?php else: ?>

                    <div class="panel empty">
                        Select a file from the project to edit it.
                    </div>

                <?php endif; ?>


                <div class="tools">


                    <!-- NEW FILE -->

                    <div class="panel">

                        <h2 class="section-title">
                            New File
                        </h2>

                        <p class="section-description">
                            Create a file in the current folder.
                            You can also use a relative path such as
                            <code>assets/app.js</code>.
                        </p>


                        <form method="POST">

                            <input
                                type="hidden"
                                name="action"
                                value="create_file"
                            >

                            <input
                                type="hidden"
                                name="project"
                                value="<?= htmlspecialchars(
                                    $selectedProject
                                ) ?>"
                            >

                            <input
                                type="hidden"
                                name="dir"
                                value="<?= htmlspecialchars(
                                    $currentDir
                                ) ?>"
                            >


                            <div class="form-row">

                                <input
                                    type="text"
                                    name="new_file"
                                    placeholder="index.php or assets/app.js"
                                    required
                                >


                                <button
                                    type="submit"
                                    class="button button-primary"
                                >
                                    Create File
                                </button>

                            </div>

                        </form>

                    </div>


                    <!-- UPLOAD -->

                    <div class="panel">

                        <h2 class="section-title">
                            Upload File
                        </h2>

                        <p class="section-description">
                            Upload a file directly into the folder
                            currently open in the browser.
                        </p>


                        <form
                            method="POST"
                            enctype="multipart/form-data"
                        >

                            <input
                                type="hidden"
                                name="action"
                                value="upload"
                            >

                            <input
                                type="hidden"
                                name="project"
                                value="<?= htmlspecialchars(
                                    $selectedProject
                                ) ?>"
                            >

                            <input
                                type="hidden"
                                name="dir"
                                value="<?= htmlspecialchars(
                                    $currentDir
                                ) ?>"
                            >


                            <div class="form-row">

                                <input
                                    type="file"
                                    name="upload_file"
                                    required
                                >


                                <button
                                    type="submit"
                                    class="button button-primary"
                                >
                                    Upload File
                                </button>

                            </div>

                        </form>

                    </div>


                </div>

            </div>

        </div>

    <?php endif; ?>

</div>


<!-- CREATE FOLDER -->

<div
    class="modal-backdrop"
    id="create-folder-modal"
>

    <div class="modal">

        <h3>
            Create Folder
        </h3>

        <p>
            Create a new folder inside the current folder.
        </p>


        <form method="POST">

            <input
                type="hidden"
                name="action"
                value="create_folder"
            >

            <input
                type="hidden"
                name="project"
                value="<?= htmlspecialchars(
                    $selectedProject
                ) ?>"
            >

            <input
                type="hidden"
                name="dir"
                value="<?= htmlspecialchars(
                    $currentDir
                ) ?>"
            >


            <input
                type="text"
                name="folder_name"
                placeholder="Folder name"
                required
                autocomplete="off"
            >


            <div class="modal-actions">

                <button
                    type="button"
                    class="button"
                    onclick="closeModals()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="button button-primary"
                >
                    Create Folder
                </button>

            </div>

        </form>

    </div>

</div>


<!-- RENAME -->

<div
    class="modal-backdrop"
    id="rename-modal"
>

    <div class="modal">

        <h3>
            Rename
        </h3>

        <p id="rename-description"></p>


        <form method="POST">

            <input
                type="hidden"
                name="action"
                value="rename"
            >

            <input
                type="hidden"
                name="project"
                value="<?= htmlspecialchars(
                    $selectedProject
                ) ?>"
            >

            <input
                type="hidden"
                name="dir"
                value="<?= htmlspecialchars(
                    $currentDir
                ) ?>"
            >

            <input
                type="hidden"
                name="item"
                id="rename-item"
            >


            <input
                type="text"
                name="new_name"
                id="rename-name"
                required
                autocomplete="off"
            >


            <div class="modal-actions">

                <button
                    type="button"
                    class="button"
                    onclick="closeModals()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="button button-primary"
                >
                    Rename
                </button>

            </div>

        </form>

    </div>

</div>


<!-- MOVE -->

<div
    class="modal-backdrop"
    id="move-modal"
>

    <div class="modal">

        <h3>
            Move
        </h3>

        <p id="move-description"></p>


        <form method="POST">

            <input
                type="hidden"
                name="action"
                value="move"
            >

            <input
                type="hidden"
                name="project"
                value="<?= htmlspecialchars(
                    $selectedProject
                ) ?>"
            >

            <input
                type="hidden"
                name="dir"
                value="<?= htmlspecialchars(
                    $currentDir
                ) ?>"
            >

            <input
                type="hidden"
                name="item"
                id="move-item"
            >


            <select
                name="destination_dir"
                id="move-destination"
            >

                <?php foreach ($allDirectories as $directory): ?>

                    <option
                        value="<?= htmlspecialchars(
                            $directory
                        ) ?>"
                        <?= $directory === $currentDir
                            ? 'selected'
                            : '' ?>
                    >
                        <?= $directory === ''
                            ? 'Project root'
                            : htmlspecialchars($directory) ?>
                    </option>

                <?php endforeach; ?>

            </select>


            <div class="modal-actions">

                <button
                    type="button"
                    class="button"
                    onclick="closeModals()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="button button-primary"
                >
                    Move Here
                </button>

            </div>

        </form>

    </div>

</div>


<!-- DELETE -->

<form
    method="POST"
    id="delete-form"
    style="display:none;"
>

    <input
        type="hidden"
        name="action"
        value="delete_item"
    >

    <input
        type="hidden"
        name="project"
        value="<?= htmlspecialchars(
            $selectedProject
        ) ?>"
    >

    <input
        type="hidden"
        name="dir"
        value="<?= htmlspecialchars(
            $currentDir
        ) ?>"
    >

    <input
        type="hidden"
        name="item"
        id="delete-item"
    >

</form>


<script>

function closeModals()
{
    document
        .querySelectorAll('.modal-backdrop')
        .forEach(function (modal) {
            modal.classList.remove('open');
        });
}


function openModal(id)
{
    closeModals();

    var modal = document.getElementById(id);

    if (!modal) {
        return;
    }

    modal.classList.add('open');

    var input =
        modal.querySelector(
            'input[type="text"]'
        );

    if (input) {
        setTimeout(function () {
            input.focus();
            input.select();
        }, 50);
    }
}


function openRenameModal(item, name)
{
    document.getElementById(
        'rename-item'
    ).value = item;

    document.getElementById(
        'rename-name'
    ).value = name;

    document.getElementById(
        'rename-description'
    ).textContent =
        'Rename "' +
        item +
        '". The item stays in its current folder.';

    openModal('rename-modal');
}


function openMoveModal(item, name)
{
    document.getElementById(
        'move-item'
    ).value = item;

    document.getElementById(
        'move-description'
    ).textContent =
        'Move "' +
        item +
        '" into another folder in this project.';

    var select =
        document.getElementById(
            'move-destination'
        );

    Array.from(
        select.options
    ).forEach(function (option) {

        var destination = option.value;

        option.disabled =
            destination === item ||
            destination.indexOf(
                item + '/'
            ) === 0;

    });

    openModal('move-modal');
}


function deleteItem(item, isFolder)
{
    var text = isFolder
        ? 'Delete the folder "' +
          item +
          '" and everything inside it?'
        : 'Delete the file "' +
          item +
          '" permanently?';

    if (!confirm(text)) {
        return;
    }

    document.getElementById(
        'delete-item'
    ).value = item;

    document.getElementById(
        'delete-form'
    ).submit();
}


document
    .querySelectorAll('.modal-backdrop')
    .forEach(function (modal) {

        modal.addEventListener(
            'click',
            function (event) {

                if (event.target === modal) {
                    closeModals();
                }

            }
        );

    });


document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {
            closeModals();
        }

    }
);

</script>

</body>
</html>
```

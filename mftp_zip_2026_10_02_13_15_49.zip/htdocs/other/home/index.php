<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Authentication Check
if (!isset($_SESSION['user_id'])) {
    header("Location: /logon.php");
    exit();
}

$userId = (int)$_SESSION['user_id'];

// 2. Load Configuration
$configPath = __DIR__ . '/../../config.php';
if (!file_exists($configPath) && !empty($_SERVER['DOCUMENT_ROOT'])) {
    $configPath = $_SERVER['DOCUMENT_ROOT'] . '/config.php';
}
if (!file_exists($configPath)) {
    die("Database configuration (config.php) missing.");
}

require_once $configPath;

// 3. CSRF Protection Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

// 4. Auto-initialize Database Tables
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_settings (
        user_id INT PRIMARY KEY,
        search_engine VARCHAR(20) NOT NULL DEFAULT 'google',
        theme VARCHAR(10) NOT NULL DEFAULT 'dark',
        time_format VARCHAR(5) NOT NULL DEFAULT '24',
        bg_rotation VARCHAR(10) NOT NULL DEFAULT 'off',
        current_bg VARCHAR(255) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_shortcuts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(100) NOT NULL,
        url VARCHAR(500) NOT NULL,
        position INT NOT NULL DEFAULT 0,
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {
    // Do not silently continue: later queries would otherwise cause a 500 error.
    http_response_code(500);
    exit('Database initialization failed: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}

// Make older installations compatible with the current settings schema.
try {
    $columns = [];
    $colStmt = $pdo->query("SHOW COLUMNS FROM user_settings");
    foreach ($colStmt->fetchAll(PDO::FETCH_ASSOC) as $column) {
        $columns[strtolower($column['Field'])] = true;
    }

    $migrations = [
        'search_engine' => "ALTER TABLE user_settings ADD COLUMN search_engine VARCHAR(20) NOT NULL DEFAULT 'google'",
        'theme'        => "ALTER TABLE user_settings ADD COLUMN theme VARCHAR(10) NOT NULL DEFAULT 'dark'",
        'time_format'  => "ALTER TABLE user_settings ADD COLUMN time_format VARCHAR(5) NOT NULL DEFAULT '24'",
        'bg_rotation'  => "ALTER TABLE user_settings ADD COLUMN bg_rotation VARCHAR(10) NOT NULL DEFAULT 'off'",
        'current_bg'   => "ALTER TABLE user_settings ADD COLUMN current_bg VARCHAR(255) NOT NULL DEFAULT ''"
    ];

    foreach ($migrations as $column => $sql) {
        if (!isset($columns[$column])) {
            $pdo->exec($sql);
        }
    }
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database migration failed: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}

// 5. Secure File Serving Endpoint for Backgrounds
if (isset($_GET['action']) && $_GET['action'] === 'get_bg' && isset($_GET['file'])) {
    $filename = basename($_GET['file']);
    $userBgDir = __DIR__ . '/uploads/bg/' . $userId . '/';
    $filePath = $userBgDir . $filename;
    
    if ($filename !== '' && file_exists($filePath) && is_file($filePath)) {
        $mime = function_exists('mime_content_type') ? mime_content_type($filePath) : 'application/octet-stream';
        $allowedServeMimes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!in_array($mime, $allowedServeMimes, true)) {
            http_response_code(403);
            exit('Invalid image type');
        }
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($filePath));
        header('Cache-Control: private, max-age=86400');
        readfile($filePath);
        exit();
    } else {
        http_response_code(404);
        exit('File not found');
    }
}

// 6. Handle POST Requests (AJAX & Form Actions)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receivedToken = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $receivedToken)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit();
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'save_settings') {
        header('Content-Type: application/json');
        $searchEngine = in_array($_POST['search_engine'] ?? '', ['google', 'bing', 'duckduckgo', 'youtube']) ? $_POST['search_engine'] : 'google';
        $theme = in_array($_POST['theme'] ?? '', ['dark', 'light']) ? $_POST['theme'] : 'dark';
        $timeFormat = in_array($_POST['time_format'] ?? '', ['12', '24']) ? $_POST['time_format'] : '24';
        $bgRotation = in_array($_POST['bg_rotation'] ?? '', ['off', '5m', '15m', '1h']) ? $_POST['bg_rotation'] : 'off';

        $stmt = $pdo->prepare("UPDATE user_settings SET search_engine = ?, theme = ?, time_format = ?, bg_rotation = ? WHERE user_id = ?");
        $stmt->execute([$searchEngine, $theme, $timeFormat, $bgRotation, $userId]);
        echo json_encode(['success' => true]);
        exit();
    }

    if ($action === 'upload_bg') {
        header('Content-Type: application/json');

        if (!isset($_FILES['background_file'])) {
            echo json_encode(['success' => false, 'error' => 'No background files were provided.']);
            exit();
        }

        $allowedMimes = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp'
        ];

        $targetDir = __DIR__ . '/uploads/bg/' . $userId . '/';
        if (!is_dir($targetDir) && !mkdir($targetDir, 0755, true)) {
            echo json_encode(['success' => false, 'error' => 'Could not create the background upload directory.']);
            exit();
        }

        $files = $_FILES['background_file'];
        $isMultiple = is_array($files['name']);
        $count = $isMultiple ? count($files['name']) : 1;
        $uploaded = [];
        $errors = [];
        $lastUploadedFilename = null;

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo === false) {
            echo json_encode(['success' => false, 'error' => 'Server MIME detection is unavailable.']);
            exit();
        }

        for ($i = 0; $i < $count; $i++) {
            $name = $isMultiple ? $files['name'][$i] : $files['name'];
            $tmpName = $isMultiple ? $files['tmp_name'][$i] : $files['tmp_name'];
            $size = $isMultiple ? $files['size'][$i] : $files['size'];
            $error = $isMultiple ? $files['error'][$i] : $files['error'];

            $displayName = is_string($name) ? $name : 'Unknown file';

            if ($error !== UPLOAD_ERR_OK) {
                $errors[] = $displayName . ': upload failed (error ' . (int)$error . ').';
                continue;
            }

            if (!is_uploaded_file($tmpName)) {
                $errors[] = $displayName . ': invalid upload.';
                continue;
            }

            if ($size > 10 * 1024 * 1024) {
                $errors[] = $displayName . ': exceeds the 10MB limit.';
                continue;
            }

            $mime = finfo_file($finfo, $tmpName);
            if (!isset($allowedMimes[$mime])) {
                $errors[] = $displayName . ': invalid format. Only JPG, PNG, and WebP are allowed.';
                continue;
            }

            $ext = $allowedMimes[$mime];
            $newFilename = 'bg_' . bin2hex(random_bytes(8)) . '.' . $ext;

            if (move_uploaded_file($tmpName, $targetDir . $newFilename)) {
                $uploaded[] = $newFilename;
                $lastUploadedFilename = $newFilename;
            } else {
                $errors[] = $displayName . ': failed to save the file.';
            }
        }

        finfo_close($finfo);

        if ($lastUploadedFilename !== null) {
            $stmt = $pdo->prepare("UPDATE user_settings SET current_bg = ? WHERE user_id = ?");
            $stmt->execute([$lastUploadedFilename, $userId]);
        }

        echo json_encode([
            'success' => count($uploaded) > 0,
            'filenames' => $uploaded,
            'filename' => $lastUploadedFilename,
            'errors' => $errors,
            'uploaded_count' => count($uploaded),
            'error_count' => count($errors)
        ]);
        exit();
    }

    if ($action === 'delete_bg') {
        header('Content-Type: application/json');
        $filename = basename($_POST['filename'] ?? '');
        $filePath = __DIR__ . '/uploads/bg/' . $userId . '/' . $filename;
        if ($filename !== '' && file_exists($filePath) && is_file($filePath)) {
            unlink($filePath);
        }
        
        $stmt = $pdo->prepare("SELECT current_bg FROM user_settings WHERE user_id = ?");
        $stmt->execute([$userId]);
        if ($stmt->fetchColumn() === $filename) {
            $stmt = $pdo->prepare("UPDATE user_settings SET current_bg = '' WHERE user_id = ?");
            $stmt->execute([$userId]);
        }
        echo json_encode(['success' => true]);
        exit();
    }

    if ($action === 'select_bg') {
        header('Content-Type: application/json');
        $filename = basename($_POST['filename'] ?? '');
        if ($filename !== '') {
            $filePath = __DIR__ . '/uploads/bg/' . $userId . '/' . $filename;
            if (!file_exists($filePath)) {
                $filename = '';
            }
        }
        $stmt = $pdo->prepare("UPDATE user_settings SET current_bg = ? WHERE user_id = ?");
        $stmt->execute([$filename, $userId]);
        echo json_encode(['success' => true]);
        exit();
    }

    if ($action === 'add_shortcut') {
        header('Content-Type: application/json');
        $title = trim($_POST['title'] ?? '');
        $url = trim($_POST['url'] ?? '');
        if (!$title || !$url) {
            echo json_encode(['success' => false, 'error' => 'Title and URL are required.']);
            exit();
        }
        if (!preg_match("~^https?://~i", $url)) {
            $url = "https://" . $url;
        }
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            echo json_encode(['success' => false, 'error' => 'Invalid URL.']);
            exit();
        }

        $stmt = $pdo->prepare("SELECT COALESCE(MAX(position), -1) FROM user_shortcuts WHERE user_id = ?");
        $stmt->execute([$userId]);
        $nextPos = (int)$stmt->fetchColumn() + 1;

        $stmt = $pdo->prepare("INSERT INTO user_shortcuts (user_id, title, url, position) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $title, $url, $nextPos]);
        $id = $pdo->lastInsertId();

        echo json_encode(['success' => true, 'shortcut' => ['id' => $id, 'title' => $title, 'url' => $url, 'position' => $nextPos]]);
        exit();
    }

    if ($action === 'edit_shortcut') {
        header('Content-Type: application/json');
        $id = (int)($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $url = trim($_POST['url'] ?? '');
        if (!$id || !$title || !$url) {
            echo json_encode(['success' => false, 'error' => 'Invalid parameters.']);
            exit();
        }
        if (!preg_match("~^https?://~i", $url)) {
            $url = "https://" . $url;
        }
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            echo json_encode(['success' => false, 'error' => 'Invalid URL.']);
            exit();
        }

        $stmt = $pdo->prepare("UPDATE user_shortcuts SET title = ?, url = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$title, $url, $id, $userId]);
        echo json_encode(['success' => true]);
        exit();
    }

    if ($action === 'delete_shortcut') {
        header('Content-Type: application/json');
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM user_shortcuts WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $userId]);
        echo json_encode(['success' => true]);
        exit();
    }

    if ($action === 'reorder_shortcuts') {
        header('Content-Type: application/json');
        $order = json_decode($_POST['order'] ?? '[]', true);
        if (is_array($order)) {
            $pos = 0;
            $stmt = $pdo->prepare("UPDATE user_shortcuts SET position = ? WHERE id = ? AND user_id = ?");
            foreach ($order as $id) {
                $stmt->execute([$pos++, (int)$id, $userId]);
            }
        }
        echo json_encode(['success' => true]);
        exit();
    }

    if ($action === 'reset_settings') {
        header('Content-Type: application/json');
        $stmt = $pdo->prepare("UPDATE user_settings SET search_engine = 'google', theme = 'dark', time_format = '24', bg_rotation = 'off', current_bg = '' WHERE user_id = ?");
        $stmt->execute([$userId]);
        echo json_encode(['success' => true]);
        exit();
    }
}

// 7. Load Data for Page Rendering
$stmt = $pdo->prepare("SELECT * FROM user_settings WHERE user_id = ?");
$stmt->execute([$userId]);
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$settings) {
    $stmt = $pdo->prepare("INSERT INTO user_settings (user_id, search_engine, theme, time_format, bg_rotation, current_bg) VALUES (?, 'google', 'dark', '24', 'off', '')");
    $stmt->execute([$userId]);
    $settings = [
        'user_id' => $userId,
        'search_engine' => 'google',
        'theme' => 'dark',
        'time_format' => '24',
        'bg_rotation' => 'off',
        'current_bg' => ''
    ];
}

$stmt = $pdo->prepare("SELECT * FROM user_shortcuts WHERE user_id = ? ORDER BY position ASC, id ASC");
$stmt->execute([$userId]);
$shortcuts = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($shortcuts)) {
    $defaults = [
        ['Google', 'https://www.google.com'],
        ['YouTube', 'https://www.youtube.com'],
        ['GitHub', 'https://github.com'],
        ['Reddit', 'https://www.reddit.com']
    ];
    $ins = $pdo->prepare("INSERT INTO user_shortcuts (user_id, title, url, position) VALUES (?, ?, ?, ?)");
    foreach ($defaults as $i => $d) {
        $ins->execute([$userId, $d[0], $d[1], $i]);
    }
    $stmt = $pdo->prepare("SELECT * FROM user_shortcuts WHERE user_id = ? ORDER BY position ASC, id ASC");
    $stmt->execute([$userId]);
    $shortcuts = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Scan user uploaded backgrounds
$userBgDir = __DIR__ . '/uploads/bg/' . $userId . '/';
$bgFiles = [];
if (is_dir($userBgDir)) {
    $scanned = scandir($userBgDir);
    foreach ($scanned as $f) {
        if ($f !== '.' && $f !== '..' && is_file($userBgDir . $f)) {
            $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $bgFiles[] = $f;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo htmlspecialchars($settings['theme']); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        :root {
            --bg-body: #0e1117;
            --bg-surface: #161b22;
            --bg-surface-hover: #1f242d;
            --bg-overlay: rgba(10, 13, 18, 0.45);
            --border-color: #2b303b;
            --border-focus: #4b5563;
            --text-main: #f0f3f6;
            --text-sub: #9198a1;
            --text-muted: #656d76;
            --accent: #3b82f6;
            --accent-hover: #2563eb;
            --danger: #ef4444;
            --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            --radius-main: 10px;
            --radius-btn: 6px;
        }

        [data-theme="light"] {
            --bg-body: #f6f8fa;
            --bg-surface: #ffffff;
            --bg-surface-hover: #f1f3f5;
            --bg-overlay: rgba(255, 255, 255, 0.4);
            --border-color: #d0d7de;
            --border-focus: #9ca3af;
            --text-main: #1f2328;
            --text-sub: #656d76;
            --text-muted: #8c959f;
            --accent: #2563eb;
            --accent-hover: #1d4ed8;
            --danger: #dc2626;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: var(--font-family);
            background-color: var(--bg-body);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
        }

        /* Background Layer */
        .bg-layer {
            position: fixed;
            inset: 0;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            z-index: -2;
            transition: opacity 0.4s ease;
        }

        .bg-overlay {
            position: fixed;
            inset: 0;
            background: var(--bg-overlay);
            z-index: -1;
            backdrop-filter: blur(2px);
        }

        /* Main Container */
        .container {
            width: 100%;
            max-width: 680px;
            padding: 2rem 1.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            z-index: 1;
        }

        /* Clock & Date */
        .time-display {
            font-size: 5.5rem;
            font-weight: 200;
            letter-spacing: -2px;
            line-height: 1;
            margin-bottom: 0.3rem;
            user-select: none;
            color: var(--text-main);
        }

        .date-display {
            font-size: 1.1rem;
            font-weight: 400;
            color: var(--text-sub);
            margin-bottom: 2.5rem;
            letter-spacing: 0.3px;
            user-select: none;
        }

        /* Search Box */
        .search-form {
            width: 100%;
            display: flex;
            align-items: center;
            background-color: var(--bg-surface);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 4px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
            position: relative;
        }

        .search-form:focus-within {
            border-color: var(--border-focus);
            box-shadow: 0 6px 16px rgba(0,0,0,0.12);
        }

        .engine-selector {
            position: relative;
        }

        .engine-btn {
            display: flex;
            align-items: center;
            gap: 6px;
            background: transparent;
            border: none;
            color: var(--text-sub);
            padding: 10px 12px;
            font-size: 0.88rem;
            font-weight: 500;
            cursor: pointer;
            border-radius: 8px;
            transition: background 0.15s ease, color 0.15s ease;
        }

        .engine-btn:hover {
            background-color: var(--bg-surface-hover);
            color: var(--text-main);
        }

        .engine-dropdown {
            position: absolute;
            top: calc(100% + 6px);
            left: 0;
            background-color: var(--bg-surface);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 4px;
            min-width: 150px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.18);
            display: none;
            flex-direction: column;
            z-index: 10;
        }

        .engine-dropdown.active {
            display: flex;
        }

        .engine-option {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: transparent;
            border: none;
            color: var(--text-main);
            font-size: 0.88rem;
            cursor: pointer;
            border-radius: 6px;
            text-align: left;
            width: 100%;
        }

        .engine-option:hover {
            background-color: var(--bg-surface-hover);
        }

        .search-input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: var(--text-main);
            font-size: 1rem;
            padding: 10px 12px;
        }

        .search-input::placeholder {
            color: var(--text-muted);
        }

        .search-submit-btn {
            background: transparent;
            border: none;
            color: var(--text-sub);
            padding: 10px 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            transition: color 0.15s ease;
        }

        .search-submit-btn:hover {
            color: var(--text-main);
        }

        /* Shortcuts Section */
        .shortcuts-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            width: 100%;
            margin-top: 2rem;
        }

        .shortcut-item {
            display: flex;
            align-items: center;
            gap: 8px;
            background-color: var(--bg-surface);
            border: 1px solid var(--border-color);
            padding: 8px 14px;
            border-radius: 8px;
            color: var(--text-main);
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 500;
            transition: background 0.15s ease, border-color 0.15s ease, transform 0.15s ease;
            max-width: 180px;
        }

        .shortcut-item:hover {
            background-color: var(--bg-surface-hover);
            border-color: var(--border-focus);
            transform: translateY(-1px);
        }

        .shortcut-favicon {
            width: 16px;
            height: 16px;
            border-radius: 3px;
            flex-shrink: 0;
            object-fit: contain;
        }

        .shortcut-fallback-icon {
            width: 16px;
            height: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: var(--bg-surface-hover);
            color: var(--text-sub);
            border-radius: 3px;
            font-size: 0.7rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .shortcut-title {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .add-shortcut-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: transparent;
            border: 1px dashed var(--border-color);
            color: var(--text-sub);
            padding: 8px 12px;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease;
        }

        .add-shortcut-btn:hover {
            border-color: var(--border-focus);
            color: var(--text-main);
            background-color: var(--bg-surface);
        }

        /* Settings Toggle Button */
        .settings-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: var(--bg-surface);
            border: 1px solid var(--border-color);
            color: var(--text-sub);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: color 0.15s ease, border-color 0.15s ease, transform 0.15s ease;
            z-index: 10;
        }

        .settings-toggle:hover {
            color: var(--text-main);
            border-color: var(--border-focus);
            transform: scale(1.05);
        }

        /* Settings Drawer / Modal */
        .settings-modal {
            position: fixed;
            inset: 0;
            background-color: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 100;
            padding: 1rem;
        }

        .settings-modal.active {
            display: flex;
        }

        .settings-panel {
            background-color: var(--bg-surface);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            width: 100%;
            max-width: 540px;
            max-height: 85vh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 16px 32px rgba(0,0,0,0.25);
            overflow: hidden;
        }

        .settings-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border-color);
        }

        .settings-title {
            font-size: 1.05rem;
            font-weight: 600;
            color: var(--text-main);
        }

        .close-btn {
            background: transparent;
            border: none;
            color: var(--text-sub);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 4px;
            border-radius: 4px;
        }

        .close-btn:hover {
            color: var(--text-main);
        }

        .settings-nav {
            display: flex;
            gap: 4px;
            padding: 8px 1.25rem;
            border-bottom: 1px solid var(--border-color);
            background-color: rgba(0,0,0,0.02);
        }

        .nav-tab {
            background: transparent;
            border: none;
            color: var(--text-sub);
            padding: 6px 12px;
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            border-radius: 6px;
            transition: color 0.15s ease, background 0.15s ease;
        }

        .nav-tab:hover {
            color: var(--text-main);
        }

        .nav-tab.active {
            background-color: var(--bg-surface-hover);
            color: var(--text-main);
        }

        .settings-content {
            padding: 1.25rem;
            overflow-y: auto;
            flex: 1;
        }

        .tab-pane {
            display: none;
            flex-direction: column;
            gap: 1.25rem;
        }

        .tab-pane.active {
            display: flex;
        }

        .setting-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .setting-label {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-main);
        }

        .setting-desc {
            font-size: 0.78rem;
            color: var(--text-sub);
        }

        .form-control {
            background-color: var(--bg-body);
            border: 1px solid var(--border-color);
            color: var(--text-main);
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.88rem;
            width: 100%;
            outline: none;
        }

        .form-control:focus {
            border-color: var(--border-focus);
        }

        /* Lists in settings */
        .manage-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .manage-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 8px 12px;
            background-color: var(--bg-body);
            border: 1px solid var(--border-color);
            border-radius: 6px;
        }

        .manage-item-info {
            display: flex;
            align-items: center;
            gap: 10px;
            overflow: hidden;
        }

        .manage-item-actions {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .icon-btn {
            background: transparent;
            border: none;
            color: var(--text-sub);
            padding: 4px 6px;
            cursor: pointer;
            border-radius: 4px;
            display: flex;
            align-items: center;
        }

        .icon-btn:hover {
            color: var(--text-main);
            background-color: var(--bg-surface-hover);
        }

        .icon-btn.danger:hover {
            color: var(--danger);
        }

        /* Background Grid */
        .bg-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 10px;
            margin-top: 8px;
        }

        .bg-thumb-card {
            position: relative;
            aspect-ratio: 16/9;
            border-radius: 6px;
            overflow: hidden;
            border: 2px solid transparent;
            cursor: pointer;
        }

        .bg-thumb-card.active {
            border-color: var(--accent);
        }

        .bg-thumb-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .bg-thumb-delete {
            position: absolute;
            top: 4px;
            right: 4px;
            background: rgba(0,0,0,0.6);
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 2px 4px;
            cursor: pointer;
            display: none;
        }

        .bg-thumb-card:hover .bg-thumb-delete {
            display: flex;
        }

        .btn {
            background-color: var(--accent);
            color: #ffffff;
            border: none;
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.15s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .btn:hover {
            background-color: var(--accent-hover);
        }

        .btn-secondary {
            background-color: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-main);
        }

        .btn-secondary:hover {
            background-color: var(--bg-surface-hover);
        }

        .btn-danger {
            background-color: var(--danger);
            color: #fff;
        }

        .btn-danger:hover {
            opacity: 0.9;
        }

        /* SVG Icons Inline Utility */
        .svg-icon {
            width: 16px;
            height: 16px;
            fill: currentColor;
            flex-shrink: 0;
        }
    </style>
</head>
<body>

    <!-- Background Layers -->
    <div id="bgLayer" class="bg-layer"></div>
    <div class="bg-overlay"></div>

    <!-- Main View -->
    <div class="container">
        <!-- Clock & Date -->
        <div id="timeDisplay" class="time-display">--:--</div>
        <div id="dateDisplay" class="date-display">---</div>

        <!-- Search Bar -->
        <form id="searchForm" class="search-form" action="#" method="GET">
            <div class="engine-selector">
                <button type="button" id="engineBtn" class="engine-btn">
                    <span id="engineIcon"></span>
                    <span id="engineLabel">Google</span>
                    <svg class="svg-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
                </button>
                <div id="engineDropdown" class="engine-dropdown">
                    <button type="button" class="engine-option" data-engine="google">
                        <svg class="svg-icon" viewBox="0 0 24 24"><path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z"/></svg>
                        Google
                    </button>
                    <button type="button" class="engine-option" data-engine="bing">
                        <svg class="svg-icon" viewBox="0 0 24 24"><path d="M5 3v16.5l4.5 2.25 8.25-4.88-3.38-1.57-4.87 2.12V6.23L5 3z"/></svg>
                        Bing
                    </button>
                    <button type="button" class="engine-option" data-engine="duckduckgo">
                        <svg class="svg-icon" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                        DuckDuckGo
                    </button>
                    <button type="button" class="engine-option" data-engine="youtube">
                        <svg class="svg-icon" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                        YouTube
                    </button>
                </div>
            </div>

            <input type="text" id="searchInput" class="search-input" placeholder="Search the web..." autofocus autocomplete="off">
            
            <button type="submit" class="search-submit-btn" aria-label="Search">
                <svg class="svg-icon" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
            </button>
        </form>

        <!-- Shortcuts -->
        <div id="shortcutsGrid" class="shortcuts-grid">
            <?php foreach ($shortcuts as $sc): 
                $parsed = parse_url($sc['url']);
                $domain = $parsed['host'] ?? '';
                $firstLetter = strtoupper(substr($sc['title'], 0, 1));
            ?>
                <a href="<?php echo htmlspecialchars($sc['url']); ?>" class="shortcut-item" title="<?php echo htmlspecialchars($sc['title']); ?>">
                    <?php if ($domain): ?>
                        <img src="https://www.google.com/s2/favicons?domain=<?php echo urlencode($domain); ?>&sz=64" class="shortcut-favicon" alt="" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                        <div class="shortcut-fallback-icon" style="display:none;"><?php echo $firstLetter; ?></div>
                    <?php else: ?>
                        <div class="shortcut-fallback-icon"><?php echo $firstLetter; ?></div>
                    <?php endif; ?>
                    <span class="shortcut-title"><?php echo htmlspecialchars($sc['title']); ?></span>
                </a>
            <?php endforeach; ?>

            <button type="button" id="quickAddShortcutBtn" class="add-shortcut-btn" title="Add Shortcut">
                <svg class="svg-icon" viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            </button>
        </div>
    </div>

    <!-- Unobtrusive Settings Button -->
    <button type="button" id="settingsToggle" class="settings-toggle" aria-label="Settings">
        <svg class="svg-icon" viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
    </button>

    <!-- Settings Modal -->
    <div id="settingsModal" class="settings-modal">
        <div class="settings-panel">
            <div class="settings-header">
                <span class="settings-title">Preferences</span>
                <button type="button" id="closeSettingsBtn" class="close-btn">
                    <svg class="svg-icon" viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
            </div>

            <div class="settings-nav">
                <button type="button" class="nav-tab active" data-tab="tab-general">General</button>
                <button type="button" class="nav-tab" data-tab="tab-shortcuts">Shortcuts</button>
                <button type="button" class="nav-tab" data-tab="tab-backgrounds">Backgrounds</button>
            </div>

            <div class="settings-content">
                <!-- General Tab -->
                <div id="tab-general" class="tab-pane active">
                    <div class="setting-group">
                        <label class="setting-label" for="settingSearchEngine">Default Search Engine</label>
                        <select id="settingSearchEngine" class="form-control">
                            <option value="google" <?php echo $settings['search_engine'] === 'google' ? 'selected' : ''; ?>>Google</option>
                            <option value="bing" <?php echo $settings['search_engine'] === 'bing' ? 'selected' : ''; ?>>Bing</option>
                            <option value="duckduckgo" <?php echo $settings['search_engine'] === 'duckduckgo' ? 'selected' : ''; ?>>DuckDuckGo</option>
                            <option value="youtube" <?php echo $settings['search_engine'] === 'youtube' ? 'selected' : ''; ?>>YouTube</option>
                        </select>
                    </div>

                    <div class="setting-group">
                        <label class="setting-label" for="settingTheme">Appearance Theme</label>
                        <select id="settingTheme" class="form-control">
                            <option value="dark" <?php echo $settings['theme'] === 'dark' ? 'selected' : ''; ?>>Dark</option>
                            <option value="light" <?php echo $settings['theme'] === 'light' ? 'selected' : ''; ?>>Light</option>
                        </select>
                    </div>

                    <div class="setting-group">
                        <label class="setting-label" for="settingTimeFormat">Clock Format</label>
                        <select id="settingTimeFormat" class="form-control">
                            <option value="24" <?php echo $settings['time_format'] === '24' ? 'selected' : ''; ?>>24-Hour (14:30)</option>
                            <option value="12" <?php echo $settings['time_format'] === '12' ? 'selected' : ''; ?>>12-Hour (2:30 PM)</option>
                        </select>
                    </div>

                    <div class="setting-group">
                        <label class="setting-label" for="settingBgRotation">Background Rotation</label>
                        <select id="settingBgRotation" class="form-control">
                            <option value="off" <?php echo $settings['bg_rotation'] === 'off' ? 'selected' : ''; ?>>Off</option>
                            <option value="5m" <?php echo $settings['bg_rotation'] === '5m' ? 'selected' : ''; ?>>Every 5 minutes</option>
                            <option value="15m" <?php echo $settings['bg_rotation'] === '15m' ? 'selected' : ''; ?>>Every 15 minutes</option>
                            <option value="1h" <?php echo $settings['bg_rotation'] === '1h' ? 'selected' : ''; ?>>Every 1 hour</option>
                        </select>
                    </div>

                    <div style="margin-top: 1rem; border-top: 1px solid var(--border-color); padding-top: 1rem;">
                        <button type="button" id="resetSettingsBtn" class="btn btn-secondary btn-danger" style="width: 100%;">Reset Settings to Default</button>
                    </div>
                </div>

                <!-- Shortcuts Tab -->
                <div id="tab-shortcuts" class="tab-pane">
                    <form id="addShortcutForm" style="display: flex; gap: 8px; flex-direction: column; background: var(--bg-body); padding: 10px; border-radius: 8px; border: 1px solid var(--border-color);">
                        <span class="setting-label">Add New Shortcut</span>
                        <input type="text" id="newScTitle" class="form-control" placeholder="Title (e.g. GitHub)" required>
                        <input type="url" id="newScUrl" class="form-control" placeholder="URL (e.g. https://github.com)" required>
                        <button type="submit" class="btn" style="align-self: flex-start;">Add Shortcut</button>
                    </form>

                    <div class="setting-group">
                        <span class="setting-label">Manage Shortcuts</span>
                        <div id="shortcutsManageList" class="manage-list">
                            <!-- Populated by JS -->
                        </div>
                    </div>
                </div>

                <!-- Backgrounds Tab -->
                <div id="tab-backgrounds" class="tab-pane">
                    <div class="setting-group">
                        <span class="setting-label">Upload New Background</span>
                        <span class="setting-desc">Supported formats: JPG, PNG, WebP (Max 10MB)</span>
                        <input type="file" id="bgFileInput" accept="image/jpeg,image/png,image/webp" class="form-control" multiple>
                    </div>

                    <div class="setting-group">
                        <span class="setting-label">Your Backgrounds</span>
                        <div id="bgGrid" class="bg-grid">
                            <!-- Populated by JS -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Inline JS Application Logic -->
    <script>
        // State Initialization
        const CSRF_TOKEN = <?php echo json_encode($csrfToken); ?>;
        let currentSettings = <?php echo json_encode($settings); ?>;
        let shortcutsList = <?php echo json_encode($shortcuts); ?>;
        let bgFilesList = <?php echo json_encode($bgFiles); ?>;

        const engineUrls = {
            google: 'https://www.google.com/search?q=',
            bing: 'https://www.bing.com/search?q=',
            duckduckgo: 'https://duckduckgo.com/?q=',
            youtube: 'https://www.youtube.com/results?search_query='
        };

        const engineIcons = {
            google: `<svg class="svg-icon" viewBox="0 0 24 24"><path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z"/></svg>`,
            bing: `<svg class="svg-icon" viewBox="0 0 24 24"><path d="M5 3v16.5l4.5 2.25 8.25-4.88-3.38-1.57-4.87 2.12V6.23L5 3z"/></svg>`,
            duckduckgo: `<svg class="svg-icon" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>`,
            youtube: `<svg class="svg-icon" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>`
        };

        // DOM Elements
        const timeDisplay = document.getElementById('timeDisplay');
        const dateDisplay = document.getElementById('dateDisplay');
        const searchForm = document.getElementById('searchForm');
        const searchInput = document.getElementById('searchInput');
        const engineBtn = document.getElementById('engineBtn');
        const engineIcon = document.getElementById('engineIcon');
        const engineLabel = document.getElementById('engineLabel');
        const engineDropdown = document.getElementById('engineDropdown');
        const bgLayer = document.getElementById('bgLayer');
        const settingsToggle = document.getElementById('settingsToggle');
        const settingsModal = document.getElementById('settingsModal');
        const closeSettingsBtn = document.getElementById('closeSettingsBtn');
        const shortcutsManageList = document.getElementById('shortcutsManageList');
        const bgGrid = document.getElementById('bgGrid');
        const bgFileInput = document.getElementById('bgFileInput');

        let selectedEngine = currentSettings.search_engine || 'google';
        let rotationTimer = null;

        // Clock Functionality
        function updateClock() {
            const now = new Date();
            const is12 = currentSettings.time_format === '12';
            
            let hours = now.getHours();
            const minutes = String(now.getMinutes()).padStart(2, '0');
            let ampm = '';

            if (is12) {
                ampm = hours >= 12 ? ' PM' : ' AM';
                hours = hours % 12 || 12;
            } else {
                hours = String(hours).padStart(2, '0');
            }

            timeDisplay.textContent = `${hours}:${minutes}${ampm}`;

            const options = { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' };
            dateDisplay.textContent = now.toLocaleDateString(undefined, options);
        }

        setInterval(updateClock, 1000);
        updateClock();

        // Search Engine Selector
        function setSearchEngine(engine) {
            if (!engineUrls[engine]) engine = 'google';
            selectedEngine = engine;
            engineIcon.innerHTML = engineIcons[engine];
            engineLabel.textContent = engine.charAt(0).toUpperCase() + engine.slice(1);
            searchInput.placeholder = `Search ${engineLabel.textContent} or type URL...`;
        }

        setSearchEngine(selectedEngine);

        engineBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            engineDropdown.classList.toggle('active');
        });

        document.querySelectorAll('.engine-option').forEach(opt => {
            opt.addEventListener('click', () => {
                const eng = opt.getAttribute('data-engine');
                setSearchEngine(eng);
                engineDropdown.classList.remove('active');
                
                // Save setting choice
                currentSettings.search_engine = eng;
                saveSettings();
            });
        });

        document.addEventListener('click', () => {
            engineDropdown.classList.remove('active');
        });

        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const query = searchInput.value.trim();
            if (!query) return;

            // Direct URL check
            if (/^(https?:\/\/)?[\w.-]+\.[a-z]{2,}(\/.*)?$/i.test(query)) {
                const targetUrl = query.startsWith('http') ? query : 'https://' + query;
                window.location.href = targetUrl;
            } else {
                window.location.href = engineUrls[selectedEngine] + encodeURIComponent(query);
            }
        });

        // Background Handling
        function setBackground(filename) {
            if (!filename) {
                bgLayer.style.backgroundImage = 'none';
                return;
            }
            bgLayer.style.backgroundImage = `url('index.php?action=get_bg&file=${encodeURIComponent(filename)}')`;
        }

        setBackground(currentSettings.current_bg);

        function setupBgRotation() {
            if (rotationTimer) clearInterval(rotationTimer);
            const mode = currentSettings.bg_rotation;
            if (mode === 'off' || bgFilesList.length <= 1) return;

            let ms = 300000; // 5m default
            if (mode === '15m') ms = 900000;
            if (mode === '1h') ms = 3600000;

            rotationTimer = setInterval(() => {
                let currentIdx = bgFilesList.indexOf(currentSettings.current_bg);
                let nextIdx = (currentIdx + 1) % bgFilesList.length;
                let nextBg = bgFilesList[nextIdx];
                
                currentSettings.current_bg = nextBg;
                setBackground(nextBg);

                // Persist current selection
                const fd = new FormData();
                fd.append('csrf_token', CSRF_TOKEN);
                fd.append('action', 'select_bg');
                fd.append('filename', nextBg);
                fetch('index.php', { method: 'POST', body: fd });
            }, ms);
        }

        setupBgRotation();

        // Theme Application
        function applyTheme(theme) {
            document.documentElement.setAttribute('data-theme', theme);
        }

        // Settings API Calls
        async function saveSettings() {
            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'save_settings');
            fd.append('search_engine', currentSettings.search_engine);
            fd.append('theme', currentSettings.theme);
            fd.append('time_format', currentSettings.time_format);
            fd.append('bg_rotation', currentSettings.bg_rotation);

            const res = await fetch('index.php', { method: 'POST', body: fd });
            const data = await res.json();
            if (data.success) {
                applyTheme(currentSettings.theme);
                updateClock();
                setupBgRotation();
            }
        }

        // Settings Modal UI
        settingsToggle.addEventListener('click', () => {
            settingsModal.classList.add('active');
            renderShortcutsManagement();
            renderBackgroundsGrid();
        });

        closeSettingsBtn.addEventListener('click', () => {
            settingsModal.classList.remove('active');
        });

        settingsModal.addEventListener('click', (e) => {
            if (e.target === settingsModal) {
                settingsModal.classList.remove('active');
            }
        });

        // Tabs Switching
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(tab.getAttribute('data-tab')).classList.add('active');
            });
        });

        // Change Listeners for Settings Controls
        document.getElementById('settingSearchEngine').addEventListener('change', (e) => {
            currentSettings.search_engine = e.target.value;
            setSearchEngine(e.target.value);
            saveSettings();
        });

        document.getElementById('settingTheme').addEventListener('change', (e) => {
            currentSettings.theme = e.target.value;
            applyTheme(e.target.value);
            saveSettings();
        });

        document.getElementById('settingTimeFormat').addEventListener('change', (e) => {
            currentSettings.time_format = e.target.value;
            updateClock();
            saveSettings();
        });

        document.getElementById('settingBgRotation').addEventListener('change', (e) => {
            currentSettings.bg_rotation = e.target.value;
            setupBgRotation();
            saveSettings();
        });

        document.getElementById('resetSettingsBtn').addEventListener('click', async () => {
            if (!confirm('Are you sure you want to reset all settings to default?')) return;
            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'reset_settings');
            const res = await fetch('index.php', { method: 'POST', body: fd });
            if (res.ok) window.location.reload();
        });

        // Manage Shortcuts Logic
        function renderShortcutsManagement() {
            shortcutsManageList.innerHTML = '';
            shortcutsList.forEach((sc, index) => {
                const item = document.createElement('div');
                item.className = 'manage-item';
                item.innerHTML = `
                    <div class="manage-item-info">
                        <strong style="font-size:0.88rem;">${escapeHtml(sc.title)}</strong>
                        <span style="font-size:0.78rem; color:var(--text-sub);">${escapeHtml(sc.url)}</span>
                    </div>
                    <div class="manage-item-actions">
                        <button type="button" class="icon-btn" onclick="moveShortcut(${index}, -1)" ${index === 0 ? 'disabled' : ''}>↑</button>
                        <button type="button" class="icon-btn" onclick="moveShortcut(${index}, 1)" ${index === shortcutsList.length - 1 ? 'disabled' : ''}>↓</button>
                        <button type="button" class="icon-btn danger" onclick="deleteShortcut(${sc.id})">✕</button>
                    </div>
                `;
                shortcutsManageList.appendChild(item);
            });
        }

        document.getElementById('quickAddShortcutBtn').addEventListener('click', () => {
            settingsModal.classList.add('active');
            document.querySelector('[data-tab="tab-shortcuts"]').click();
        });

        document.getElementById('addShortcutForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const title = document.getElementById('newScTitle').value.trim();
            const url = document.getElementById('newScUrl').value.trim();
            if (!title || !url) return;

            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'add_shortcut');
            fd.append('title', title);
            fd.append('url', url);

            const res = await fetch('index.php', { method: 'POST', body: fd });
            const data = await res.json();
            if (data.success) {
                window.location.reload();
            } else {
                alert(data.error || 'Error adding shortcut');
            }
        });

        async function deleteShortcut(id) {
            if (!confirm('Remove this shortcut?')) return;
            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'delete_shortcut');
            fd.append('id', id);

            const res = await fetch('index.php', { method: 'POST', body: fd });
            if (res.ok) window.location.reload();
        }

        async function moveShortcut(index, direction) {
            const targetIndex = index + direction;
            if (targetIndex < 0 || targetIndex >= shortcutsList.length) return;

            const temp = shortcutsList[index];
            shortcutsList[index] = shortcutsList[targetIndex];
            shortcutsList[targetIndex] = temp;

            const order = shortcutsList.map(s => s.id);

            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'reorder_shortcuts');
            fd.append('order', JSON.stringify(order));

            await fetch('index.php', { method: 'POST', body: fd });
            window.location.reload();
        }

        // Manage Backgrounds Logic
        function renderBackgroundsGrid() {
            bgGrid.innerHTML = '';
            
            // "None" option
            const noneCard = document.createElement('div');
            noneCard.className = `bg-thumb-card ${currentSettings.current_bg === '' ? 'active' : ''}`;
            noneCard.style.background = 'var(--bg-body)';
            noneCard.style.display = 'flex';
            noneCard.style.alignItems = 'center';
            noneCard.style.justifyContent = 'center';
            noneCard.style.fontSize = '0.75rem';
            noneCard.style.color = 'var(--text-sub)';
            noneCard.textContent = 'None';
            noneCard.onclick = () => selectBg('');
            bgGrid.appendChild(noneCard);

            bgFilesList.forEach(file => {
                const card = document.createElement('div');
                card.className = `bg-thumb-card ${currentSettings.current_bg === file ? 'active' : ''}`;
                card.innerHTML = `
                    <img src="index.php?action=get_bg&file=${encodeURIComponent(file)}" class="bg-thumb-img" alt="">
                    <button type="button" class="bg-thumb-delete" onclick="event.stopPropagation(); deleteBg('${escapeHtml(file)}')">✕</button>
                `;
                card.onclick = () => selectBg(file);
                bgGrid.appendChild(card);
            });
        }

        async function selectBg(filename) {
            currentSettings.current_bg = filename;
            setBackground(filename);
            renderBackgroundsGrid();

            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'select_bg');
            fd.append('filename', filename);
            await fetch('index.php', { method: 'POST', body: fd });
        }

        async function deleteBg(filename) {
            if (!confirm('Delete this background image?')) return;
            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'delete_bg');
            fd.append('filename', filename);

            const res = await fetch('index.php', { method: 'POST', body: fd });
            if (res.ok) {
                bgFilesList = bgFilesList.filter(f => f !== filename);
                if (currentSettings.current_bg === filename) {
                    currentSettings.current_bg = '';
                    setBackground('');
                }
                renderBackgroundsGrid();
            }
        }

        bgFileInput.addEventListener('change', async () => {
            if (!bgFileInput.files.length) return;

            const files = Array.from(bgFileInput.files);
            const fd = new FormData();
            fd.append('csrf_token', CSRF_TOKEN);
            fd.append('action', 'upload_bg');

            files.forEach(file => {
                fd.append('background_file[]', file);
            });

            bgFileInput.disabled = true;

            try {
                const res = await fetch('index.php', { method: 'POST', body: fd });
                const data = await res.json();

                if (data.success) {
                    const newFiles = Array.isArray(data.filenames) ? data.filenames : [];
                    bgFilesList.push(...newFiles);

                    if (data.filename) {
                        currentSettings.current_bg = data.filename;
                        setBackground(data.filename);
                    }

                    renderBackgroundsGrid();

                    if (data.errors && data.errors.length) {
                        alert('Uploaded ' + (data.uploaded_count || 0) + ' background(s).\n\nSome files were skipped:\n' + data.errors.join('\n'));
                    }
                } else {
                    alert((data.errors && data.errors.length) ? data.errors.join('\n') : (data.error || 'Upload failed.'));
                }
            } catch (error) {
                alert('Background upload failed. Please try again.');
            } finally {
                bgFileInput.disabled = false;
                bgFileInput.value = '';
            }
        });

        function escapeHtml(str) {
            return String(str ?? '').replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
        }
    </script>
</body>
</html>
<?php

/*
 * PHP File Browser
 *
 * Location:
 *   /other/browser/index.php
 *
 * Designed to work with older PHP versions commonly available
 * on shared hosting such as InfinityFree.
 */

require_once __DIR__ . '/../../config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
 * The existing admin session is still required.
 */
if (empty($_SESSION['is_admin'])) {
    header('Location: ../../manage.php');
    exit;
}


/* =========================================================
   CONFIGURATION
   ========================================================= */

// CHANGE THIS PASSWORD.
define('BROWSER_PASSWORD', 'Gameday24!!');

// Maximum upload size.
define('MAX_UPLOAD_SIZE', 50 * 1024 * 1024);

// Files that cannot be modified/deleted.
$PROTECTED_FILES = array(
    'other/browser/index.php'
);

// Editable text file extensions.
$EDITABLE_EXTENSIONS = array(
    'txt',
    'php',
    'html',
    'htm',
    'css',
    'js',
    'json',
    'xml',
    'csv',
    'md',
    'ini',
    'conf',
    'log',
    'sql',
    'svg',
    'yml',
    'yaml'
);


/* =========================================================
   WEBSITE ROOT
   ========================================================= */

$ROOT = realpath(__DIR__ . '/../../');

if ($ROOT === false || !is_dir($ROOT)) {
    die('Website root could not be located.');
}


/* =========================================================
   HELPER FUNCTIONS
   ========================================================= */

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}


/*
 * PHP 7-compatible replacement for str_contains().
 */
function containsText($haystack, $needle)
{
    return strpos($haystack, $needle) !== false;
}


/*
 * Converts a relative path to an absolute path while
 * preventing directory traversal.
 */
function safePath($root, $relative)
{
    $relative = str_replace('\\', '/', $relative);
    $relative = trim($relative, '/');

    if ($relative === '') {
        return $root;
    }

    if (strpos($relative, "\0") !== false) {
        return false;
    }

    $parts = explode('/', $relative);
    $clean = array();

    foreach ($parts as $part) {

        if ($part === '' || $part === '.') {
            continue;
        }

        if ($part === '..') {

            if (empty($clean)) {
                return false;
            }

            array_pop($clean);
            continue;
        }

        $clean[] = $part;
    }

    $candidate = $root . DIRECTORY_SEPARATOR . implode(
        DIRECTORY_SEPARATOR,
        $clean
    );

    $real = realpath($candidate);

    if ($real === false) {
        return false;
    }

    $rootWithSlash = rtrim(
        $root,
        DIRECTORY_SEPARATOR
    ) . DIRECTORY_SEPARATOR;

    if (
        $real !== $root &&
        strpos($real, $rootWithSlash) !== 0
    ) {
        return false;
    }

    return $real;
}


/*
 * Converts an absolute path to a path relative to the website root.
 */
function relativePath($root, $absolute)
{
    $root = rtrim(
        realpath($root),
        DIRECTORY_SEPARATOR
    );

    $absolute = realpath($absolute);

    if ($absolute === false || $absolute === $root) {
        return '';
    }

    $relative = substr(
        $absolute,
        strlen($root)
    );

    return trim(
        str_replace(
            DIRECTORY_SEPARATOR,
            '/',
            $relative
        ),
        '/'
    );
}


/*
 * Format a byte count.
 */
function formatBytes($bytes)
{
    $bytes = (float)$bytes;

    if ($bytes < 1024) {
        return number_format($bytes, 0) . ' B';
    }

    if ($bytes < 1024 * 1024) {
        return number_format($bytes / 1024, 1) . ' KB';
    }

    if ($bytes < 1024 * 1024 * 1024) {
        return number_format(
            $bytes / (1024 * 1024),
            1
        ) . ' MB';
    }

    return number_format(
        $bytes / (1024 * 1024 * 1024),
        2
    ) . ' GB';
}


function fileExtension($name)
{
    return strtolower(
        pathinfo($name, PATHINFO_EXTENSION)
    );
}


function isEditable($name)
{
    global $EDITABLE_EXTENSIONS;

    return in_array(
        fileExtension($name),
        $EDITABLE_EXTENSIONS,
        true
    );
}


function isProtected($absolute, $root)
{
    global $PROTECTED_FILES;

    $relative = relativePath(
        $root,
        $absolute
    );

    foreach ($PROTECTED_FILES as $protected) {

        if (
            strcasecmp(
                $relative,
                $protected
            ) === 0
        ) {
            return true;
        }
    }

    return false;
}


/*
 * Recursively delete a file or directory.
 */
function recursiveDelete($path)
{
    if (is_file($path) || is_link($path)) {
        return @unlink($path);
    }

    if (!is_dir($path)) {
        return false;
    }

    $items = @scandir($path);

    if ($items === false) {
        return false;
    }

    foreach ($items as $item) {

        if (
            $item === '.' ||
            $item === '..'
        ) {
            continue;
        }

        $child =
            $path .
            DIRECTORY_SEPARATOR .
            $item;

        if (!recursiveDelete($child)) {
            return false;
        }
    }

    return @rmdir($path);
}


function flash($message, $type = 'success')
{
    $_SESSION['browser_flash'] = array(
        'message' => $message,
        'type' => $type
    );
}


function getFlash()
{
    $flash = isset($_SESSION['browser_flash'])
        ? $_SESSION['browser_flash']
        : null;

    unset($_SESSION['browser_flash']);

    return $flash;
}


/* =========================================================
   LOGIN / LOGOUT
   ========================================================= */

if (isset($_GET['logout'])) {

    unset($_SESSION['browser_authenticated']);

    header('Location: index.php');
    exit;
}


if (empty($_SESSION['browser_authenticated'])) {

    $loginError = '';

    if (
        $_SERVER['REQUEST_METHOD'] === 'POST' &&
        isset($_POST['login'])
    ) {

        $password = isset($_POST['password'])
            ? $_POST['password']
            : '';

        if (
            hash_equals(
                BROWSER_PASSWORD,
                $password
            )
        ) {

            session_regenerate_id(true);

            $_SESSION['browser_authenticated'] = true;

            header('Location: index.php');
            exit;

        } else {

            $loginError = 'Incorrect password.';
        }
    }

    ?>

    <!DOCTYPE html>
    <html>
    <head>

        <meta charset="UTF-8">

        <meta
            name="viewport"
            content="width=device-width, initial-scale=1"
        >

        <title>File Browser Login</title>

        <style>

            body {
                font-family: Arial, sans-serif;
                background: #f2f2f2;
                margin: 0;
                padding: 40px;
            }

            .login {
                max-width: 400px;
                margin: 100px auto;
                background: white;
                padding: 25px;
                border: 1px solid #ccc;
            }

            input {
                width: 100%;
                box-sizing: border-box;
                padding: 10px;
                margin: 8px 0 15px;
            }

            button {
                padding: 10px 15px;
                cursor: pointer;
            }

            .error {
                color: #b00020;
                margin-bottom: 15px;
            }

        </style>

    </head>

    <body>

        <div class="login">

            <h2>File Browser</h2>

            <?php if ($loginError !== ''): ?>

                <div class="error">
                    <?= h($loginError) ?>
                </div>

            <?php endif; ?>

            <form method="post">

                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    autofocus
                    required
                >

                <button
                    type="submit"
                    name="login"
                >
                    Login
                </button>

            </form>

        </div>

    </body>
    </html>

    <?php

    exit;
}


/* =========================================================
   CSRF
   ========================================================= */

if (empty($_SESSION['browser_csrf'])) {

    $_SESSION['browser_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrf = $_SESSION['browser_csrf'];


function checkCsrf()
{
    $token = isset($_POST['csrf'])
        ? $_POST['csrf']
        : '';

    if (
        empty($_SESSION['browser_csrf']) ||
        !hash_equals(
            $_SESSION['browser_csrf'],
            $token
        )
    ) {

        http_response_code(403);

        die('Invalid security token.');
    }
}


/* =========================================================
   CURRENT DIRECTORY
   ========================================================= */

$requestedPath = isset($_GET['path'])
    ? $_GET['path']
    : '';

$currentPath = safePath(
    $ROOT,
    $requestedPath
);

if (
    $currentPath === false ||
    !is_dir($currentPath)
) {
    $currentPath = $ROOT;
}

$currentRelative = relativePath(
    $ROOT,
    $currentPath
);


/* =========================================================
   POST ACTIONS
   ========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    checkCsrf();

    $action = isset($_POST['action'])
        ? $_POST['action']
        : '';


    /* =====================================================
       CREATE FOLDER
       ===================================================== */

    if ($action === 'mkdir') {

        $name = trim(
            isset($_POST['name'])
                ? $_POST['name']
                : ''
        );

        if ($name === '') {

            flash(
                'Folder name cannot be empty.',
                'error'
            );

        } elseif (
            $name === '.' ||
            $name === '..' ||
            containsText($name, '/') ||
            containsText($name, '\\')
        ) {

            flash(
                'Invalid folder name.',
                'error'
            );

        } else {

            $newFolder =
                $currentPath .
                DIRECTORY_SEPARATOR .
                $name;

            if (file_exists($newFolder)) {

                flash(
                    'A file or folder with that name already exists.',
                    'error'
                );

            } elseif (@mkdir($newFolder, 0755)) {

                flash(
                    'Folder created successfully.'
                );

            } else {

                flash(
                    'Could not create folder.',
                    'error'
                );
            }
        }

        header(
            'Location: ?path=' .
            urlencode($currentRelative)
        );

        exit;
    }


    /* =====================================================
       CREATE FILE
       ===================================================== */

    if ($action === 'create_file') {

        $name = trim(
            isset($_POST['name'])
                ? $_POST['name']
                : ''
        );

        if ($name === '') {

            flash(
                'File name cannot be empty.',
                'error'
            );

        } elseif (
            containsText($name, '/') ||
            containsText($name, '\\') ||
            $name === '.' ||
            $name === '..'
        ) {

            flash(
                'Invalid file name.',
                'error'
            );

        } else {

            $newFile =
                $currentPath .
                DIRECTORY_SEPARATOR .
                $name;

            if (file_exists($newFile)) {

                flash(
                    'A file or folder with that name already exists.',
                    'error'
                );

            } elseif (
                @file_put_contents(
                    $newFile,
                    ''
                ) !== false
            ) {

                flash(
                    'File created successfully.'
                );

            } else {

                flash(
                    'Could not create file.',
                    'error'
                );
            }
        }

        header(
            'Location: ?path=' .
            urlencode($currentRelative)
        );

        exit;
    }


    /* =====================================================
       UPLOAD
       ===================================================== */

    if ($action === 'upload') {

        if (!isset($_FILES['files'])) {

            flash(
                'No files were uploaded.',
                'error'
            );

        } else {

            $files = $_FILES['files'];

            if (is_array($files['name'])) {
                $count = count($files['name']);
            } else {
                $count = 1;
            }

            $uploaded = 0;
            $failed = 0;

            for ($i = 0; $i < $count; $i++) {

                $name = is_array($files['name'])
                    ? $files['name'][$i]
                    : $files['name'];

                $tmp = is_array($files['tmp_name'])
                    ? $files['tmp_name'][$i]
                    : $files['tmp_name'];

                $error = is_array($files['error'])
                    ? $files['error'][$i]
                    : $files['error'];

                $size = is_array($files['size'])
                    ? $files['size'][$i]
                    : $files['size'];

                if ($error !== UPLOAD_ERR_OK) {
                    $failed++;
                    continue;
                }

                if ($size > MAX_UPLOAD_SIZE) {
                    $failed++;
                    continue;
                }

                $name = basename($name);

                if (
                    $name === '' ||
                    $name === '.' ||
                    $name === '..'
                ) {
                    $failed++;
                    continue;
                }

                $destination =
                    $currentPath .
                    DIRECTORY_SEPARATOR .
                    $name;


                /*
                 * Do not overwrite an existing file.
                 */
                if (file_exists($destination)) {

                    $info = pathinfo($name);

                    $base = isset($info['filename'])
                        ? $info['filename']
                        : $name;

                    $extension = isset($info['extension'])
                        ? '.' . $info['extension']
                        : '';

                    $number = 1;

                    do {

                        $newName =
                            $base .
                            ' (' .
                            $number .
                            ')' .
                            $extension;

                        $destination =
                            $currentPath .
                            DIRECTORY_SEPARATOR .
                            $newName;

                        $number++;

                    } while (file_exists($destination));
                }


                if (
                    @move_uploaded_file(
                        $tmp,
                        $destination
                    )
                ) {

                    $uploaded++;

                } else {

                    $failed++;
                }
            }


            if ($failed === 0) {

                flash(
                    $uploaded .
                    ' file(s) uploaded.'
                );

            } else {

                flash(
                    $uploaded .
                    ' uploaded, ' .
                    $failed .
                    ' failed.',
                    'error'
                );
            }
        }

        header(
            'Location: ?path=' .
            urlencode($currentRelative)
        );

        exit;
    }


    /* =====================================================
       RENAME
       ===================================================== */

    if ($action === 'rename') {

        $oldName = isset($_POST['old_name'])
            ? $_POST['old_name']
            : '';

        $newName = trim(
            isset($_POST['new_name'])
                ? $_POST['new_name']
                : ''
        );


        $oldRelative =
            ($currentRelative !== ''
                ? $currentRelative . '/'
                : '') .
            $oldName;


        $oldPath = safePath(
            $ROOT,
            $oldRelative
        );


        if (
            $oldPath === false ||
            !file_exists($oldPath) ||
            isProtected(
                $oldPath,
                $ROOT
            )
        ) {

            flash(
                'That item cannot be renamed.',
                'error'
            );

        } elseif (
            $newName === '' ||
            containsText($newName, '/') ||
            containsText($newName, '\\') ||
            $newName === '.' ||
            $newName === '..'
        ) {

            flash(
                'Invalid new name.',
                'error'
            );

        } else {

            $newPath =
                dirname($oldPath) .
                DIRECTORY_SEPARATOR .
                $newName;

            if (file_exists($newPath)) {

                flash(
                    'An item with that name already exists.',
                    'error'
                );

            } elseif (@rename(
                $oldPath,
                $newPath
            )) {

                flash(
                    'Renamed successfully.'
                );

            } else {

                flash(
                    'Rename failed.',
                    'error'
                );
            }
        }

        header(
            'Location: ?path=' .
            urlencode($currentRelative)
        );

        exit;
    }


    /* =====================================================
       DELETE
       ===================================================== */

    if ($action === 'delete') {

        $name = isset($_POST['name'])
            ? $_POST['name']
            : '';


        $targetRelative =
            ($currentRelative !== ''
                ? $currentRelative . '/'
                : '') .
            $name;


        $target = safePath(
            $ROOT,
            $targetRelative
        );


        if (
            $target === false ||
            !file_exists($target) ||
            isProtected(
                $target,
                $ROOT
            )
        ) {

            flash(
                'That item cannot be deleted.',
                'error'
            );

        } elseif ($target === $ROOT) {

            flash(
                'The website root cannot be deleted.',
                'error'
            );

        } elseif (recursiveDelete($target)) {

            flash(
                'Deleted successfully.'
            );

        } else {

            flash(
                'Could not delete the item.',
                'error'
            );
        }

        header(
            'Location: ?path=' .
            urlencode($currentRelative)
        );

        exit;
    }


    /* =====================================================
       BULK DELETE
       ===================================================== */

    if ($action === 'bulk_delete') {

        $items = isset($_POST['items'])
            ? $_POST['items']
            : array();

        if (!is_array($items)) {
            $items = array();
        }

        $deleted = 0;

        foreach ($items as $name) {

            $targetRelative =
                ($currentRelative !== ''
                    ? $currentRelative . '/'
                    : '') .
                $name;


            $target = safePath(
                $ROOT,
                $targetRelative
            );


            if (
                $target === false ||
                !file_exists($target) ||
                $target === $ROOT ||
                isProtected(
                    $target,
                    $ROOT
                )
            ) {
                continue;
            }


            if (recursiveDelete($target)) {
                $deleted++;
            }
        }


        flash(
            $deleted .
            ' item(s) deleted.'
        );


        header(
            'Location: ?path=' .
            urlencode($currentRelative)
        );

        exit;
    }


    /* =====================================================
       SAVE FILE
       ===================================================== */

    if ($action === 'save_file') {

        $fileName = isset($_POST['file'])
            ? $_POST['file']
            : '';


        $filePath = safePath(
            $ROOT,
            $fileName
        );


        if (
            $filePath === false ||
            !is_file($filePath) ||
            isProtected(
                $filePath,
                $ROOT
            )
        ) {

            flash(
                'That file cannot be edited.',
                'error'
            );

            header(
                'Location: ?path=' .
                urlencode($currentRelative)
            );

            exit;
        }


        if (!isEditable($filePath)) {

            flash(
                'That file type cannot be edited here.',
                'error'
            );

            header(
                'Location: ?path=' .
                urlencode($currentRelative)
            );

            exit;
        }


        $content = isset($_POST['content'])
            ? $_POST['content']
            : '';


        if (
            @file_put_contents(
                $filePath,
                $content
            ) === false
        ) {

            flash(
                'Could not save the file.',
                'error'
            );

        } else {

            flash(
                'File saved successfully.'
            );
        }


        header(
            'Location: ?edit=' .
            urlencode(
                relativePath(
                    $ROOT,
                    $filePath
                )
            )
        );

        exit;
    }
}


/* =========================================================
   DOWNLOAD ENTIRE SERVER AS ZIP
   ========================================================= */

if (isset($_GET['download_all'])) {

    /*
     * Check ZIP support first.
     */
    if (!class_exists('ZipArchive')) {

        http_response_code(500);

        die(
            'ZIP downloads are unavailable because the PHP ZIP extension is not enabled on this server.'
        );
    }


    @set_time_limit(0);


    /*
     * Generate the ZIP in the system temporary directory.
     *
     * This is generally safer on shared hosting than trying
     * to create a large ZIP inside the website directory.
     */
    $tempDir = sys_get_temp_dir();

    if (
        empty($tempDir) ||
        !is_dir($tempDir) ||
        !is_writable($tempDir)
    ) {

        /*
         * Fall back to the website root if the PHP temporary
         * directory cannot be written.
         */
        $tempDir = $ROOT;
    }


    $zipName =
        'server-backup-' .
        date('Y-m-d-H-i-s') .
        '.zip';


    $zipPath =
        rtrim(
            $tempDir,
            DIRECTORY_SEPARATOR
        ) .
        DIRECTORY_SEPARATOR .
        $zipName;


    /*
     * Make sure an old file does not interfere.
     */
    if (file_exists($zipPath)) {
        @unlink($zipPath);
    }


    $zip = new ZipArchive();


    $result = $zip->open(
        $zipPath,
        ZipArchive::CREATE |
        ZipArchive::OVERWRITE
    );


    if ($result !== true) {

        /*
         * Try one more time directly inside the website root.
         */
        $zipPath =
            $ROOT .
            DIRECTORY_SEPARATOR .
            $zipName;


        $result = $zip->open(
            $zipPath,
            ZipArchive::CREATE |
            ZipArchive::OVERWRITE
        );
    }


    if ($result !== true) {

        http_response_code(500);

        die(
            'Could not create the ZIP file. The hosting account does not appear to allow PHP to create ZIP files.'
        );
    }


    $zipError = false;


    try {

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(
                $ROOT,
                FilesystemIterator::SKIP_DOTS
            ),
            RecursiveIteratorIterator::SELF_FIRST
        );


        foreach ($iterator as $file) {

            $absolutePath =
                $file->getPathname();


            /*
             * Ignore symbolic links.
             */
            if ($file->isLink()) {
                continue;
            }


            /*
             * Calculate relative path.
             */
            $relativeZipPath =
                substr(
                    $absolutePath,
                    strlen($ROOT) + 1
                );


            $relativeZipPath =
                str_replace(
                    DIRECTORY_SEPARATOR,
                    '/',
                    $relativeZipPath
                );


            /*
             * Never include this browser itself.
             */
            if (
                strcasecmp(
                    $relativeZipPath,
                    'other/browser/index.php'
                ) === 0
            ) {
                continue;
            }


            /*
             * If we created the ZIP inside the website root,
             * don't put the ZIP inside itself.
             */
            if (
                strcasecmp(
                    $relativeZipPath,
                    $zipName
                ) === 0
            ) {
                continue;
            }


            if ($file->isDir()) {

                /*
                 * Add the directory.
                 */
                if (
                    !$zip->addEmptyDir(
                        $relativeZipPath
                    )
                ) {
                    $zipError = true;
                    break;
                }

            } elseif ($file->isFile()) {

                /*
                 * Add the file.
                 */
                if (
                    !$zip->addFile(
                        $absolutePath,
                        $relativeZipPath
                    )
                ) {
                    $zipError = true;
                    break;
                }
            }
        }

    } catch (Exception $e) {

        $zipError = true;

    } catch (Throwable $e) {

        $zipError = true;
    }


    /*
     * If something failed, clean up.
     */
    if ($zipError) {

        @$zip->close();

        @unlink($zipPath);

        http_response_code(500);

        die(
            'The server could not finish creating the ZIP backup.'
        );
    }


    /*
     * Finalize ZIP.
     */
    if (!$zip->close()) {

        @unlink($zipPath);

        http_response_code(500);

        die(
            'The ZIP file could not be finalized.'
        );
    }


    if (!is_file($zipPath)) {

        http_response_code(500);

        die(
            'The ZIP file could not be created.'
        );
    }


    $zipSize = @filesize($zipPath);


    if ($zipSize === false) {

        @unlink($zipPath);

        http_response_code(500);

        die(
            'Could not determine the ZIP file size.'
        );
    }


    /*
     * Clear output buffers so no PHP/config output corrupts
     * the ZIP download.
     */
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }


    header(
        'Content-Type: application/zip'
    );

    header(
        'Content-Disposition: attachment; filename="' .
        str_replace(
            '"',
            '',
            $zipName
        ) .
        '"'
    );

    header(
        'Content-Length: ' .
        $zipSize
    );

    header(
        'Cache-Control: no-cache, no-store, must-revalidate'
    );

    header(
        'Pragma: no-cache'
    );

    header(
        'Expires: 0'
    );


    /*
     * Send the ZIP.
     */
    $handle = @fopen(
        $zipPath,
        'rb'
    );


    if ($handle !== false) {

        while (!feof($handle)) {

            echo fread(
                $handle,
                1024 * 1024
            );

            flush();
        }

        fclose($handle);

    } else {

        /*
         * Fallback.
         */
        @readfile($zipPath);
    }


    /*
     * Delete temporary ZIP.
     */
    @unlink($zipPath);

    exit;
}


/* =========================================================
   SINGLE FILE DOWNLOAD
   ========================================================= */

if (isset($_GET['download'])) {

    $downloadPath = safePath(
        $ROOT,
        $_GET['download']
    );


    if (
        $downloadPath === false ||
        !is_file($downloadPath)
    ) {

        http_response_code(404);

        die(
            'File not found.'
        );
    }


    if (
        isProtected(
            $downloadPath,
            $ROOT
        )
    ) {

        http_response_code(403);

        die(
            'Access denied.'
        );
    }


    $name = basename(
        $downloadPath
    );


    while (ob_get_level() > 0) {
        @ob_end_clean();
    }


    header(
        'Content-Type: application/octet-stream'
    );

    header(
        'Content-Disposition: attachment; filename="' .
        str_replace(
            '"',
            '',
            $name
        ) .
        '"'
    );


    $size = @filesize(
        $downloadPath
    );

    if ($size !== false) {

        header(
            'Content-Length: ' .
            $size
        );
    }


    @readfile(
        $downloadPath
    );

    exit;
}


/* =========================================================
   EDITOR
   ========================================================= */

$editFile = null;
$editContent = '';


if (isset($_GET['edit'])) {

    $editFile = safePath(
        $ROOT,
        $_GET['edit']
    );


    if (
        $editFile === false ||
        !is_file($editFile) ||
        isProtected(
            $editFile,
            $ROOT
        ) ||
        !isEditable($editFile)
    ) {

        $editFile = null;

        flash(
            'That file cannot be edited.',
            'error'
        );

    } else {

        $editContent =
            @file_get_contents(
                $editFile
            );


        if ($editContent === false) {
            $editContent = '';
        }
    }
}


/* =========================================================
   DIRECTORY LISTING
   ========================================================= */

$items = array();

$scan = @scandir(
    $currentPath
);


if ($scan !== false) {

    foreach ($scan as $name) {

        if (
            $name === '.' ||
            $name === '..'
        ) {
            continue;
        }


        $fullPath =
            $currentPath .
            DIRECTORY_SEPARATOR .
            $name;


        $isDir = is_dir(
            $fullPath
        );


        $items[] = array(
            'name' => $name,
            'path' => relativePath(
                $ROOT,
                $fullPath
            ),
            'directory' => $isDir,
            'size' => $isDir
                ? 0
                : (@filesize($fullPath) ?: 0),
            'modified' => @filemtime(
                $fullPath
            ) ?: 0,
            'extension' => $isDir
                ? ''
                : fileExtension($name),
            'protected' => isProtected(
                $fullPath,
                $ROOT
            )
        );
    }
}


/* =========================================================
   SEARCH
   ========================================================= */

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';


if ($search !== '') {

    $items = array_filter(
        $items,
        function ($item) use ($search) {

            return stripos(
                $item['name'],
                $search
            ) !== false;
        }
    );
}


/* =========================================================
   SORT
   ========================================================= */

$sort = isset($_GET['sort'])
    ? $_GET['sort']
    : 'name';

$order = isset($_GET['order'])
    ? $_GET['order']
    : 'asc';


usort(
    $items,
    function ($a, $b) use (
        $sort,
        $order
    ) {

        /*
         * Folders first.
         */
        if (
            $a['directory'] !==
            $b['directory']
        ) {

            return $a['directory']
                ? -1
                : 1;
        }


        switch ($sort) {

            case 'size':

                if (
                    $a['size'] ==
                    $b['size']
                ) {
                    $result = 0;
                } else {
                    $result =
                        $a['size'] <
                        $b['size']
                        ? -1
                        : 1;
                }

                break;


            case 'type':

                $result =
                    strcasecmp(
                        $a['extension'],
                        $b['extension']
                    );

                break;


            case 'modified':

                if (
                    $a['modified'] ==
                    $b['modified']
                ) {
                    $result = 0;
                } else {
                    $result =
                        $a['modified'] <
                        $b['modified']
                        ? -1
                        : 1;
                }

                break;


            default:

                $result =
                    strcasecmp(
                        $a['name'],
                        $b['name']
                    );

                break;
        }


        if ($order === 'desc') {
            return -$result;
        }

        return $result;
    }
);


$flash = getFlash();


/* =========================================================
   BREADCRUMBS
   ========================================================= */

$breadcrumbs = array();

$parts =
    $currentRelative !== ''
        ? explode(
            '/',
            $currentRelative
        )
        : array();


$running = '';


$breadcrumbs[] = array(
    'name' => 'Website Root',
    'path' => ''
);


foreach ($parts as $part) {

    $running .=
        ($running === ''
            ? ''
            : '/') .
        $part;


    $breadcrumbs[] = array(
        'name' => $part,
        'path' => $running
    );
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>File Browser</title>

<style>

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background: #f4f4f4;
    color: #222;
}

.container {
    max-width: 1400px;
    margin: auto;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
}

.header h1 {
    margin: 0;
}

.toolbar {
    background: white;
    border: 1px solid #ccc;
    padding: 12px;
    margin-bottom: 12px;
}

button,
.button {
    display: inline-block;
    padding: 7px 11px;
    border: 1px solid #aaa;
    background: #eee;
    color: #222;
    text-decoration: none;
    cursor: pointer;
    border-radius: 3px;
}

button:hover,
.button:hover {
    background: #ddd;
}

input[type="text"],
input[type="password"],
input[type="file"] {
    padding: 7px;
    border: 1px solid #aaa;
}

.breadcrumbs {
    background: white;
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 12px;
}

.breadcrumbs a {
    color: #0645ad;
    text-decoration: none;
}

.message {
    padding: 10px;
    margin-bottom: 12px;
    border: 1px solid #aaa;
    background: #eaffea;
}

.message.error {
    background: #ffeaea;
    color: #900;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

th,
td {
    padding: 9px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

th {
    background: #eee;
}

tr:hover {
    background: #fafafa;
}

.name {
    font-weight: bold;
}

.folder {
    color: #0645ad;
}

.protected {
    color: #888;
}

.actions {
    white-space: nowrap;
}

.inline {
    display: inline;
}

.danger {
    color: #a00;
}

.editor {
    background: white;
    border: 1px solid #ccc;
    padding: 15px;
}

.editor textarea {
    width: 100%;
    min-height: 600px;
    box-sizing: border-box;
    font-family: monospace;
    font-size: 14px;
    padding: 10px;
    resize: vertical;
}

.small {
    color: #777;
    font-size: 13px;
}

.forms {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.backup {
    font-weight: bold;
}

@media (max-width: 800px) {

    body {
        padding: 10px;
    }

    table {
        font-size: 13px;
    }

    th:nth-child(3),
    td:nth-child(3),
    th:nth-child(4),
    td:nth-child(4) {
        display: none;
    }

}

</style>

</head>

<body>

<div class="container">


<div class="header">

    <h1>File Browser</h1>

    <a
        class="button"
        href="?logout=1"
    >
        Logout
    </a>

</div>


<?php if ($flash): ?>

    <div
        class="message <?= $flash['type'] === 'error' ? 'error' : '' ?>"
    >

        <?= h($flash['message']) ?>

    </div>

<?php endif; ?>


<?php if ($editFile !== null): ?>


    <!-- =================================================
         EDITOR
         ================================================= -->

    <div class="breadcrumbs">

        <a
            href="?path=<?= urlencode($currentRelative) ?>"
        >
            ← Back to folder
        </a>

    </div>


    <div class="editor">

        <h2>

            Editing:
            <?= h(
                relativePath(
                    $ROOT,
                    $editFile
                )
            ) ?>

        </h2>


        <p class="small">
            Only text-based files can be edited here.
        </p>


        <form method="post">

            <input
                type="hidden"
                name="csrf"
                value="<?= h($csrf) ?>"
            >

            <input
                type="hidden"
                name="action"
                value="save_file"
            >

            <input
                type="hidden"
                name="file"
                value="<?= h(
                    relativePath(
                        $ROOT,
                        $editFile
                    )
                ) ?>"
            >


            <textarea
                name="content"
            ><?= h($editContent) ?></textarea>


            <br>
            <br>


            <button type="submit">
                Save File
            </button>


            <a
                class="button"
                href="?path=<?= urlencode($currentRelative) ?>"
            >
                Cancel
            </a>

        </form>

    </div>


<?php else: ?>


    <!-- =================================================
         BREADCRUMBS
         ================================================= -->

    <div class="breadcrumbs">

        <?php foreach (
            $breadcrumbs
            as $index => $crumb
        ): ?>

            <?php if ($index > 0): ?>
                /
            <?php endif; ?>


            <a
                href="?path=<?= urlencode($crumb['path']) ?>"
            >
                <?= h($crumb['name']) ?>
            </a>


        <?php endforeach; ?>

    </div>


    <!-- =================================================
         TOOLBAR
         ================================================= -->

    <div class="toolbar">

        <div class="forms">


            <!-- UPLOAD -->

            <form
                method="post"
                enctype="multipart/form-data"
            >

                <input
                    type="hidden"
                    name="csrf"
                    value="<?= h($csrf) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="upload"
                >

                <input
                    type="file"
                    name="files[]"
                    multiple
                    required
                >

                <button type="submit">
                    Upload
                </button>

            </form>


            <!-- NEW FOLDER -->

            <form method="post">

                <input
                    type="hidden"
                    name="csrf"
                    value="<?= h($csrf) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="mkdir"
                >

                <input
                    type="text"
                    name="name"
                    placeholder="New folder"
                    required
                >

                <button type="submit">
                    Create Folder
                </button>

            </form>


            <!-- NEW FILE -->

            <form method="post">

                <input
                    type="hidden"
                    name="csrf"
                    value="<?= h($csrf) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="create_file"
                >

                <input
                    type="text"
                    name="name"
                    placeholder="New file"
                    required
                >

                <button type="submit">
                    Create File
                </button>

            </form>


            <!-- DOWNLOAD ENTIRE SERVER -->

            <a
                class="button backup"
                href="?download_all=1"
                onclick="return confirm('Download the entire website as a ZIP? This may take a while.');"
            >
                Download Entire Server (ZIP)
            </a>

        </div>


        <br>


        <!-- SEARCH -->

        <form method="get">

            <input
                type="hidden"
                name="path"
                value="<?= h($currentRelative) ?>"
            >

            <input
                type="text"
                name="search"
                value="<?= h($search) ?>"
                placeholder="Search this folder"
            >

            <button type="submit">
                Search
            </button>


            <?php if ($search !== ''): ?>

                <a
                    class="button"
                    href="?path=<?= urlencode($currentRelative) ?>"
                >
                    Clear
                </a>

            <?php endif; ?>

        </form>

    </div>


    <!-- =================================================
         BULK DELETE
         ================================================= -->

    <form
        method="post"
        id="fileForm"
    >

        <input
            type="hidden"
            name="csrf"
            value="<?= h($csrf) ?>"
        >

        <input
            type="hidden"
            name="action"
            value="bulk_delete"
        >


        <button
            type="submit"
            onclick="return confirmBulkDelete();"
        >
            Delete Selected
        </button>


        <br>
        <br>


        <!-- =================================================
             FILE TABLE
             ================================================= -->

        <table>

            <thead>

                <tr>

                    <th style="width:30px;">

                        <input
                            type="checkbox"
                            id="selectAll"
                            onclick="toggleAll(this)"
                        >

                    </th>


                    <th>

                        <a
                            href="?path=<?= urlencode($currentRelative) ?>&sort=name&order=<?= $sort === 'name' && $order === 'asc' ? 'desc' : 'asc' ?>"
                        >
                            Name
                        </a>

                    </th>


                    <th>

                        <a
                            href="?path=<?= urlencode($currentRelative) ?>&sort=size&order=<?= $sort === 'size' && $order === 'asc' ? 'desc' : 'asc' ?>"
                        >
                            Size
                        </a>

                    </th>


                    <th>

                        <a
                            href="?path=<?= urlencode($currentRelative) ?>&sort=type&order=<?= $sort === 'type' && $order === 'asc' ? 'desc' : 'asc' ?>"
                        >
                            Type
                        </a>

                    </th>


                    <th>

                        <a
                            href="?path=<?= urlencode($currentRelative) ?>&sort=modified&order=<?= $sort === 'modified' && $order === 'asc' ? 'desc' : 'asc' ?>"
                        >
                            Modified
                        </a>

                    </th>


                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php if ($currentRelative !== ''): ?>

                <tr>

                    <td></td>

                    <td colspan="5">

                        <?php

                        $parent =
                            dirname(
                                $currentRelative
                            );

                        if ($parent === '.') {
                            $parent = '';
                        }

                        ?>


                        <a
                            href="?path=<?= urlencode($parent) ?>"
                        >
                            ← ..
                        </a>

                    </td>

                </tr>

            <?php endif; ?>


            <?php if (empty($items)): ?>

                <tr>

                    <td colspan="6">
                        This folder is empty.
                    </td>

                </tr>

            <?php endif; ?>


            <?php foreach ($items as $item): ?>

                <tr>


                    <td>

                        <?php if (!$item['protected']): ?>

                            <input
                                type="checkbox"
                                name="items[]"
                                value="<?= h($item['name']) ?>"
                            >

                        <?php endif; ?>

                    </td>


                    <td class="name">

                        <?php if ($item['directory']): ?>

                            <span class="folder">
                                [DIR]
                            </span>


                            <a
                                href="?path=<?= urlencode($item['path']) ?>"
                            >
                                <?= h($item['name']) ?>
                            </a>


                        <?php else: ?>

                            <?= h($item['name']) ?>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?= $item['directory']
                            ? '—'
                            : h(
                                formatBytes(
                                    $item['size']
                                )
                            ) ?>

                    </td>


                    <td>

                        <?= $item['directory']
                            ? 'Folder'
                            : h(
                                strtoupper(
                                    $item['extension']
                                    ? $item['extension']
                                    : 'File'
                                )
                            ) ?>

                    </td>


                    <td>

                        <?= $item['modified']
                            ? h(
                                date(
                                    'Y-m-d H:i:s',
                                    $item['modified']
                                )
                            )
                            : '—' ?>

                    </td>


                    <td class="actions">


                        <?php if (!$item['directory']): ?>


                            <!-- DOWNLOAD -->

                            <a
                                class="button"
                                href="?download=<?= urlencode($item['path']) ?>"
                            >
                                Download
                            </a>


                            <!-- EDIT -->

                            <?php if (
                                isEditable(
                                    $item['name']
                                ) &&
                                !$item['protected']
                            ): ?>

                                <a
                                    class="button"
                                    href="?edit=<?= urlencode($item['path']) ?>"
                                >
                                    Edit
                                </a>

                            <?php endif; ?>


                        <?php endif; ?>


                        <?php if (!$item['protected']): ?>


                            <!-- RENAME -->

                            <button
                                type="button"
                                onclick="renameItem(<?= htmlspecialchars(
                                    json_encode($item['name']),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>)"
                            >
                                Rename
                            </button>


                            <!-- DELETE -->

                            <form
                                method="post"
                                class="inline"
                                onsubmit="return confirm('Delete <?= h(addslashes($item['name'])) ?>? This cannot be undone.');"
                            >

                                <input
                                    type="hidden"
                                    name="csrf"
                                    value="<?= h($csrf) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="action"
                                    value="delete"
                                >

                                <input
                                    type="hidden"
                                    name="name"
                                    value="<?= h($item['name']) ?>"
                                >

                                <button
                                    type="submit"
                                    class="danger"
                                >
                                    Delete
                                </button>

                            </form>


                        <?php else: ?>

                            <span class="protected">
                                Protected
                            </span>

                        <?php endif; ?>


                    </td>

                </tr>

            <?php endforeach; ?>


            </tbody>

        </table>


    </form>


<?php endif; ?>


</div>


<script>


function toggleAll(source) {

    var boxes =
        document.querySelectorAll(
            '#fileForm input[type="checkbox"][name="items[]"]'
        );


    for (
        var i = 0;
        i < boxes.length;
        i++
    ) {

        boxes[i].checked =
            source.checked;
    }
}



function confirmBulkDelete() {

    var selected =
        document.querySelectorAll(
            '#fileForm input[name="items[]"]:checked'
        );


    if (selected.length === 0) {

        alert(
            'Select at least one item.'
        );

        return false;
    }


    return confirm(
        'Delete ' +
        selected.length +
        ' selected item(s)? This cannot be undone.'
    );
}



function renameItem(oldName) {

    var newName =
        prompt(
            'Enter a new name for "' +
            oldName +
            '":',
            oldName
        );


    if (
        newName === null ||
        newName.trim() === '' ||
        newName === oldName
    ) {
        return;
    }


    var form =
        document.createElement('form');


    form.method = 'POST';


    var csrf =
        document.createElement('input');

    csrf.type = 'hidden';
    csrf.name = 'csrf';
    csrf.value =
        <?= json_encode($csrf) ?>;


    var action =
        document.createElement('input');

    action.type = 'hidden';
    action.name = 'action';
    action.value = 'rename';


    var oldInput =
        document.createElement('input');

    oldInput.type = 'hidden';
    oldInput.name = 'old_name';
    oldInput.value = oldName;


    var newInput =
        document.createElement('input');

    newInput.type = 'hidden';
    newInput.name = 'new_name';
    newInput.value = newName;


    form.appendChild(csrf);
    form.appendChild(action);
    form.appendChild(oldInput);
    form.appendChild(newInput);


    document.body.appendChild(form);


    form.submit();
}


</script>


</body>
</html>
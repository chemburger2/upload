<?php
/*
 * RemoteJoyLite Web
 *
 * PSP-3000 / firmware 6.60 / ARK-5
 *
 * RemoteJoyLite USB:
 *   VID  0x054C
 *   PID  0x01C9
 *
 * Interface:
 *   0 / alternate 0
 *
 * Endpoints:
 *   USB 0x81 -> WebUSB endpoint 1 IN
 *   USB 0x02 -> WebUSB endpoint 2 OUT / HostFS
 *   USB 0x03 -> WebUSB endpoint 3 OUT / RemoteJoy
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>RemoteJoyLite Web</title>

<style>
* {
    box-sizing: border-box;
}

html,
body {
    margin: 0;
    padding: 0;
    min-height: 100%;
}

body {
    background: #101114;
    color: #e7e7e7;
    font-family: Arial, Helvetica, sans-serif;
    overflow-y: auto;
}

.container {
    width: min(1100px, calc(100% - 30px));
    margin: 0 auto;
    padding: 25px 0 40px;
}

header {
    margin-bottom: 20px;
}

h1 {
    margin: 0;
    font-size: 28px;
    font-weight: 600;
}

.subtitle {
    margin-top: 6px;
    color: #9297a1;
    font-size: 14px;
}

.toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin-bottom: 18px;
}

button {
    border: 1px solid #383b42;
    background: #202329;
    color: #eeeeee;
    border-radius: 6px;
    padding: 10px 15px;
    font-size: 14px;
    cursor: pointer;
}

button:hover {
    background: #292d34;
}

button:active {
    background: #181a1e;
}

button:disabled {
    opacity: 0.45;
    cursor: default;
}

.panel {
    border: 1px solid #2d3036;
    background: #17191d;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 15px;
}

.panelTitle {
    font-size: 14px;
    color: #aeb3bd;
    margin-bottom: 10px;
}

.statusRow {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.statusItem {
    min-width: 180px;
}

.statusLabel {
    color: #777d88;
    font-size: 12px;
    margin-bottom: 4px;
}

.statusValue {
    font-size: 14px;
}

#status {
    color: #d5d7dc;
}

#deviceInfo {
    color: #aeb3bd;
}

.screenWrap {
    width: 100%;
    overflow: auto;
    background: #000;
    border: 1px solid #303238;
    border-radius: 6px;
    text-align: center;
    padding: 12px;
}

#screen {
    display: block;
    width: 480px;
    height: 272px;
    max-width: 100%;
    margin: 0 auto;
    background: #000;
    image-rendering: pixelated;
}

.controls {
    display: flex;
    justify-content: center;
    margin-top: 16px;
}

.dpad {
    width: 160px;
    height: 160px;
    position: relative;
}

.controlButton {
    position: absolute;
    width: 52px;
    height: 52px;
    padding: 0;
    font-size: 20px;
    user-select: none;
    touch-action: none;
}

.up {
    left: 54px;
    top: 0;
}

.down {
    left: 54px;
    bottom: 0;
}

.left {
    left: 0;
    top: 54px;
}

.right {
    right: 0;
    top: 54px;
}

.center {
    left: 54px;
    top: 54px;
    background: #181a1f;
    border-color: #272a30;
}

.debug {
    height: 280px;
    overflow-y: auto;
    overflow-x: auto;
    background: #0b0c0e;
    border: 1px solid #25282d;
    border-radius: 5px;
    padding: 10px;
    font-family: Consolas, "Courier New", monospace;
    font-size: 12px;
    line-height: 1.5;
    white-space: pre-wrap;
    word-break: break-word;
}

.log {
    color: #bfc3ca;
}

.log.good {
    color: #a9d6a9;
}

.log.error {
    color: #e99b9b;
}

.log.warn {
    color: #e2c58b;
}

@media (max-width: 600px) {
    .container {
        width: calc(100% - 18px);
        padding-top: 15px;
    }

    h1 {
        font-size: 23px;
    }

    .screenWrap {
        padding: 6px;
    }

    #screen {
        width: 480px;
        height: 272px;
    }
}
</style>
</head>

<body>

<div class="container">

    <header>
        <h1>RemoteJoyLite Web</h1>
        <div class="subtitle">Browser-based PSP display and control</div>
    </header>

    <div class="toolbar">
        <button id="connectBtn" onclick="connectPSP()">Connect PSP</button>
        <button id="disconnectBtn" onclick="disconnectPSP()" disabled>Disconnect</button>
        <button id="fullscreenBtn" onclick="fullscreenScreen()">Fullscreen</button>
        <button onclick="clearDebug()">Clear Debug</button>
    </div>

    <div class="panel">
        <div class="panelTitle">Connection</div>

        <div class="statusRow">

            <div class="statusItem">
                <div class="statusLabel">Status</div>
                <div class="statusValue" id="status">
                    Waiting for Connect PSP.
                </div>
            </div>

            <div class="statusItem">
                <div class="statusLabel">Device</div>
                <div class="statusValue" id="deviceInfo">
                    Not connected
                </div>
            </div>

        </div>
    </div>

    <div class="panel">
        <div class="panelTitle">PSP Screen</div>

        <div class="screenWrap" id="screenWrap">
            <canvas id="screen" width="480" height="272"></canvas>
        </div>

        <div class="controls">
            <div class="dpad">

                <button
                    class="controlButton up"
                    data-button="UP"
                >▲</button>

                <button
                    class="controlButton left"
                    data-button="LEFT"
                >◀</button>

                <button
                    class="controlButton center"
                    data-button="CENTER"
                ></button>

                <button
                    class="controlButton right"
                    data-button="RIGHT"
                >▶</button>

                <button
                    class="controlButton down"
                    data-button="DOWN"
                >▼</button>

            </div>
        </div>
    </div>

    <div class="panel">
        <div class="panelTitle">Debug</div>
        <div id="debug" class="debug"></div>
    </div>

</div>

<script>
'use strict';

const PSP_VID = 0x054C;
const PSP_PID = 0x01C9;

const INTERFACE_NUMBER = 0;
const ALTERNATE_SETTING = 0;

const EP_SCREEN_IN = 1;
const EP_HOSTFS_OUT = 2;
const EP_REMOTEJOY_OUT = 3;

const HOSTFS_MAGIC = 0x782F0812;
const HOSTFS_RESPONSE_MAGIC = 0x8FFC00BE;

const REMOTEJOY_MAGIC = 0x909ACCEF;

const SCREEN_WIDTH = 480;
const SCREEN_HEIGHT = 272;

let device = null;
let connected = false;
let frameReaderRunning = false;
let interfaceNumber = INTERFACE_NUMBER;
let usbResetting = false;

const canvas =
    document.getElementById('screen');

const ctx =
    canvas.getContext('2d');

ctx.imageSmoothingEnabled = false;


/*
 * ------------------------------------------------------------
 * Logging
 * ------------------------------------------------------------
 */

function log(message, type = '') {

    const debug =
        document.getElementById('debug');

    const line =
        document.createElement('div');

    line.className =
        'log' + (
            type ? ' ' + type : ''
        );

    const now = new Date();

    const time =
        '[' +
        now.toLocaleTimeString([], {
            hour12: false
        }) +
        '] ';

    line.textContent =
        time + message;

    debug.appendChild(line);

    debug.scrollTop =
        debug.scrollHeight;
}

function setStatus(text) {
    document.getElementById(
        'status'
    ).textContent = text;
}

function setDeviceInfo(text) {
    document.getElementById(
        'deviceInfo'
    ).textContent = text;
}

function clearDebug() {
    document.getElementById(
        'debug'
    ).innerHTML = '';
}

function bytesToHex(bytes, max = 64) {

    const count =
        Math.min(bytes.length, max);

    let result = '';

    for (
        let i = 0;
        i < count;
        i++
    ) {

        if (i) {
            result += ' ';
        }

        result +=
            bytes[i]
                .toString(16)
                .padStart(2, '0')
                .toUpperCase();
    }

    if (bytes.length > max) {
        result += ' ...';
    }

    return result;
}

function u32(bytes, offset) {

    return (
        bytes[offset] |
        (bytes[offset + 1] << 8) |
        (bytes[offset + 2] << 16) |
        (bytes[offset + 3] << 24)
    ) >>> 0;
}


/*
 * ------------------------------------------------------------
 * USB descriptors
 * ------------------------------------------------------------
 */

function describeEndpoint(endpoint) {

    if (!endpoint) {
        return 'null';
    }

    return (
        'number=' +
        endpoint.endpointNumber +
        ' direction=' +
        endpoint.direction +
        ' type=' +
        endpoint.type +
        ' packetSize=' +
        (
            endpoint.packetSize !== undefined
                ? endpoint.packetSize
                : 'unknown'
        )
    );
}

function dumpUSBDescriptors() {

    if (
        !device ||
        !device.configuration
    ) {

        log(
            'No active USB configuration for descriptor dump.',
            'warn'
        );

        return;
    }

    log(
        'USB configuration value: ' +
        device.configuration.configurationValue
    );

    log(
        'USB configuration interfaces: ' +
        device.configuration.interfaces.length
    );

    for (
        const iface of
        device.configuration.interfaces
    ) {

        log(
            'Interface ' +
            iface.interfaceNumber +
            ': ' +
            iface.alternates.length +
            ' alternate setting(s)'
        );

        for (
            const alternate of
            iface.alternates
        ) {

            log(
                '  Alt ' +
                alternate.alternateSetting +
                ' class=' +
                alternate.interfaceClass +
                ' subclass=' +
                alternate.interfaceSubclass +
                ' protocol=' +
                alternate.interfaceProtocol
            );

            for (
                const endpoint of
                alternate.endpoints
            ) {

                log(
                    '    Endpoint: ' +
                    describeEndpoint(endpoint)
                );
            }
        }
    }
}


/*
 * ------------------------------------------------------------
 * Find interface
 * ------------------------------------------------------------
 */

function findRemoteJoyInterface() {

    if (
        !device ||
        !device.configuration
    ) {
        return null;
    }

    for (
        const iface of
        device.configuration.interfaces
    ) {

        if (
            iface.interfaceNumber !==
            INTERFACE_NUMBER
        ) {
            continue;
        }

        for (
            const alternate of
            iface.alternates
        ) {

            if (
                alternate.alternateSetting !==
                ALTERNATE_SETTING
            ) {
                continue;
            }

            let inEndpoint = null;
            let hostFsEndpoint = null;
            let remoteJoyEndpoint = null;

            for (
                const endpoint of
                alternate.endpoints
            ) {

                if (
                    endpoint.direction === 'in' &&
                    endpoint.endpointNumber ===
                        EP_SCREEN_IN
                ) {

                    inEndpoint =
                        endpoint;
                }

                if (
                    endpoint.direction === 'out' &&
                    endpoint.endpointNumber ===
                        EP_HOSTFS_OUT
                ) {

                    hostFsEndpoint =
                        endpoint;
                }

                if (
                    endpoint.direction === 'out' &&
                    endpoint.endpointNumber ===
                        EP_REMOTEJOY_OUT
                ) {

                    remoteJoyEndpoint =
                        endpoint;
                }
            }

            if (
                inEndpoint &&
                hostFsEndpoint &&
                remoteJoyEndpoint
            ) {

                return {
                    interfaceNumber:
                        iface.interfaceNumber,

                    alternate:
                        alternate,

                    inEndpoint:
                        inEndpoint,

                    hostFsEndpoint:
                        hostFsEndpoint,

                    remoteJoyEndpoint:
                        remoteJoyEndpoint
                };
            }
        }
    }

    return null;
}


/*
 * ------------------------------------------------------------
 * Open device
 * ------------------------------------------------------------
 */

async function selectPSP() {

    if (!navigator.usb) {

        throw new Error(
            'WebUSB is not available in this browser.'
        );
    }

    log(
        'Opening WebUSB device picker...'
    );

    device =
        await navigator.usb.requestDevice({
            filters: []
        });

    log(
        'Device selected. VID: 0x' +
        device.vendorId
            .toString(16)
            .padStart(4, '0')
            .toUpperCase() +
        ' PID: 0x' +
        device.productId
            .toString(16)
            .padStart(4, '0')
            .toUpperCase()
    );

    if (
        device.vendorId === PSP_VID &&
        device.productId === PSP_PID
    ) {

        log(
            'Detected Sony RemoteJoyLite USB identity.',
            'good'
        );

    } else {

        log(
            'Warning: selected device does not match RemoteJoyLite VID/PID.',
            'warn'
        );
    }

    await openPSP();
}


/*
 * ------------------------------------------------------------
 * Open and initialize USB
 * ------------------------------------------------------------
 */

async function openPSP() {

    if (!device) {
        throw new Error(
            'No USB device selected.'
        );
    }

    await device.open();

    log(
        'USB device opened.'
    );

    if (device.configuration) {

        log(
            'USB configuration currently reported as: ' +
            device.configuration.configurationValue
        );

    } else {

        log(
            'USB device currently has no selected configuration.'
        );
    }

    /*
     * IMPORTANT
     *
     * The official RemoteJoyLite client explicitly calls:
     *
     *     usb_set_configuration(1)
     *
     * before claiming interface 0.
     *
     * WebUSB normally treats an already-selected configuration
     * as already initialized, so we explicitly reset the device
     * here to force a fresh USB configuration/endpoint state.
     */

    log(
        'Resetting USB device to reproduce RemoteJoyLite initialization...'
    );

    usbResetting = true;

    try {

        await device.reset();

        log(
            'USB device reset completed.',
            'good'
        );

    } catch (error) {

        log(
            'USB reset returned an error: ' +
            error.message,
            'warn'
        );

    } finally {

        usbResetting = false;
    }

    /*
     * A reset can cause the browser backend to close the
     * handle on some systems. Re-open if necessary.
     */

    if (!device.opened) {

        log(
            'USB handle closed during reset; reopening...'
        );

        await device.open();

        log(
            'USB device reopened.',
            'good'
        );
    }

    /*
     * Give the PSP USB stack a moment to finish reinitializing.
     */

    await new Promise(
        resolve =>
            setTimeout(
                resolve,
                300
            )
    );

    /*
     * Now explicitly select configuration 1.
     */

    if (
        !device.configuration ||
        device.configuration.configurationValue !== 1
    ) {

        log(
            'Selecting USB configuration 1...'
        );

        await device.selectConfiguration(1);

        log(
            'USB configuration 1 selected.',
            'good'
        );

    } else {

        /*
         * After the reset the configuration can already be
         * reported as 1. Do not claim that this recreates
         * SET_CONFIGURATION; the reset above is what forces
         * the fresh endpoint state in this case.
         */

        log(
            'USB configuration is 1 after reset.'
        );
    }

    dumpUSBDescriptors();

    const iface =
        findRemoteJoyInterface();

    if (!iface) {

        throw new Error(
            'RemoteJoyLite interface 0 was not found.'
        );
    }

    log(
        'Found RemoteJoyLite interface ' +
        iface.interfaceNumber +
        ' alt ' +
        iface.alternate.alternateSetting +
        ' IN 0x' +
        iface.inEndpoint.endpointNumber
            .toString(16)
            .padStart(2, '0') +
        ' OUT 0x' +
        iface.hostFsEndpoint.endpointNumber
            .toString(16)
            .padStart(2, '0') +
        ' / 0x' +
        iface.remoteJoyEndpoint.endpointNumber
            .toString(16)
            .padStart(2, '0')
    );

    /*
     * Alternate setting 0.
     */

    await device.selectAlternateInterface(
        iface.interfaceNumber,
        ALTERNATE_SETTING
    );

    log(
        'USB alternate setting 0 selected.',
        'good'
    );

    /*
     * Claim interface.
     */

    await device.claimInterface(
        iface.interfaceNumber
    );

    interfaceNumber =
        iface.interfaceNumber;

    log(
        'USB interface claimed.',
        'good'
    );

    /*
     * After claiming, clear a possible stale halt on
     * endpoint 2. A bulk endpoint halt is cleared with
     * clearHalt(), when supported by WebUSB.
     */

    try {

        log(
            'Clearing any possible halt on HostFS endpoint 2...'
        );

        await device.clearHalt(
            'out',
            EP_HOSTFS_OUT
        );

        log(
            'HostFS endpoint 2 halt cleared.',
            'good'
        );

    } catch (error) {

        log(
            'Endpoint 2 clearHalt returned: ' +
            error.message,
            'warn'
        );
    }

    /*
     * Give the PSP USB task a little time after claiming.
     */

    await new Promise(
        resolve =>
            setTimeout(
                resolve,
                100
            )
    );

    log(
        'Final USB state: opened=' +
        device.opened +
        ' configuration=' +
        (
            device.configuration
                ? device.configuration.configurationValue
                : 'none'
        )
    );

    log(
        'Final endpoints: IN ' +
        EP_SCREEN_IN +
        ', HostFS OUT ' +
        EP_HOSTFS_OUT +
        ', RemoteJoy OUT ' +
        EP_REMOTEJOY_OUT
    );
}


/*
 * ------------------------------------------------------------
 * HostFS hello
 * ------------------------------------------------------------
 */

async function startHostFsHandshake() {

    /*
     * Exact 4-byte packet sent by the official client:
     *
     * 12 08 2F 78
     */

    const hello =
        new Uint8Array([
            0x12,
            0x08,
            0x2F,
            0x78
        ]);

    log(
        'Preparing RemoteJoyLite HostFS hello...'
    );

    log(
        'HostFS endpoint: 2'
    );

    log(
        'HostFS hello length: ' +
        hello.length +
        ' bytes'
    );

    log(
        'HostFS OUT bytes: ' +
        bytesToHex(hello)
    );

    const iface =
        findRemoteJoyInterface();

    if (!iface) {

        throw new Error(
            'RemoteJoyLite interface disappeared before HostFS transfer.'
        );
    }

    log(
        'Endpoint 2 descriptor: ' +
        describeEndpoint(
            iface.hostFsEndpoint
        )
    );

    if (
        iface.hostFsEndpoint.endpointNumber !==
        EP_HOSTFS_OUT
    ) {

        throw new Error(
            'Endpoint 2 is not the detected HostFS endpoint.'
        );
    }

    if (
        iface.hostFsEndpoint.direction !==
        'out'
    ) {

        throw new Error(
            'Endpoint 2 is not an OUT endpoint.'
        );
    }

    if (
        iface.hostFsEndpoint.type !==
        'bulk'
    ) {

        throw new Error(
            'Endpoint 2 is not a bulk endpoint.'
        );
    }

    log(
        'USB state before HostFS hello: opened=' +
        device.opened +
        ' configuration=' +
        (
            device.configuration
                ? device.configuration.configurationValue
                : 'none'
        )
    );

    log(
        'Interface 0 claimed: ' +
        (
            device.configuration &&
            device.configuration.interfaces &&
            device.configuration.interfaces[0]
                ? device.configuration.interfaces[0].claimed
                : 'unknown'
        )
    );

    log(
        'Sending exact 4-byte RemoteJoyLite HostFS hello...'
    );

    let result;

    const start =
        performance.now();

    try {

        result =
            await device.transferOut(
                EP_HOSTFS_OUT,
                hello
            );

    } catch (error) {

        const elapsed =
            Math.round(
                performance.now() -
                start
            );

        log(
            'HostFS transferOut threw after ' +
            elapsed +
            ' ms.',
            'error'
        );

        log(
            'Error name: ' +
            (
                error &&
                error.name
                    ? error.name
                    : 'unknown'
            ),
            'error'
        );

        log(
            'Error message: ' +
            (
                error &&
                error.message
                    ? error.message
                    : String(error)
            ),
            'error'
        );

        throw error;
    }

    const elapsed =
        Math.round(
            performance.now() -
            start
        );

    log(
        'HostFS transferOut completed after ' +
        elapsed +
        ' ms.'
    );

    if (!result) {

        throw new Error(
            'HostFS transferOut returned no result.'
        );
    }

    log(
        'HostFS transfer status: ' +
        result.status
    );

    log(
        'HostFS bytes written: ' +
        (
            result.bytesWritten !== undefined
                ? result.bytesWritten
                : 'unknown'
        )
    );

    if (
        result.status === 'stall'
    ) {

        log(
            'HostFS endpoint stalled; clearing halt...',
            'warn'
        );

        try {

            await device.clearHalt(
                'out',
                EP_HOSTFS_OUT
            );

            log(
                'HostFS halt cleared.',
                'good'
            );

        } catch (error) {

            log(
                'Could not clear HostFS halt: ' +
                error.message,
                'error'
            );
        }

        throw new Error(
            'HostFS endpoint stalled.'
        );
    }

    if (
        result.status !== 'ok'
    ) {

        throw new Error(
            'HostFS hello failed: ' +
            result.status
        );
    }

    if (
        result.bytesWritten !== undefined &&
        result.bytesWritten !== hello.length
    ) {

        throw new Error(
            'Only ' +
            result.bytesWritten +
            '/' +
            hello.length +
            ' HostFS bytes were written.'
        );
    }

    log(
        'HostFS hello successfully transferred.',
        'good'
    );

    log(
        'Waiting for PSP HostFS response...'
    );

    while (connected) {

        let inResult;

        try {

            inResult =
                await device.transferIn(
                    EP_SCREEN_IN,
                    0x200
                );

        } catch (error) {

            if (!connected) {
                break;
            }

            log(
                'HostFS response read error: ' +
                error.message,
                'error'
            );

            throw error;
        }

        if (
            !inResult ||
            !inResult.data
        ) {
            continue;
        }

        const bytes =
            new Uint8Array(
                inResult.data.buffer
            );

        if (
            bytes.length < 4
        ) {
            continue;
        }

        log(
            'USB IN ' +
            bytes.length +
            ' bytes: ' +
            bytesToHex(bytes, 32)
        );

        if (
            bytes.length < 12
        ) {
            continue;
        }

        const magic =
            u32(bytes, 0);

        const responseMagic =
            u32(bytes, 4);

        if (
            magic === HOSTFS_MAGIC &&
            responseMagic ===
                HOSTFS_RESPONSE_MAGIC
        ) {

            log(
                'PSP HostFS response received.',
                'good'
            );

            await sendHostFsResponse();

            return;
        }
    }

    throw new Error(
        'HostFS handshake stopped.'
    );
}


/*
 * ------------------------------------------------------------
 * HostFS response
 * ------------------------------------------------------------
 */

async function sendHostFsResponse() {

    /*
     * Exact 12-byte response used by the official client:
     *
     * 12 08 2F 78
     * BE 00 FC 8F
     * 00 00 00 00
     */

    const response =
        new Uint8Array([
            0x12,
            0x08,
            0x2F,
            0x78,

            0xBE,
            0x00,
            0xFC,
            0x8F,

            0x00,
            0x00,
            0x00,
            0x00
        ]);

    log(
        'Sending HostFS response on endpoint 2...'
    );

    log(
        'HostFS response bytes: ' +
        bytesToHex(response)
    );

    const result =
        await device.transferOut(
            EP_HOSTFS_OUT,
            response
        );

    if (
        result.status !==
        'ok'
    ) {

        throw new Error(
            'HostFS response failed: ' +
            result.status
        );
    }

    log(
        'HostFS response sent.',
        'good'
    );
}


/*
 * ------------------------------------------------------------
 * RemoteJoy command
 * ------------------------------------------------------------
 */

function buildScreenCommand() {

    const packet =
        new Uint8Array(24);

    const view =
        new DataView(
            packet.buffer
        );

    view.setUint32(
        0,
        REMOTEJOY_MAGIC,
        true
    );

    view.setUint32(
        4,
        0,
        true
    );

    view.setUint32(
        8,
        packet.length,
        true
    );

    view.setUint32(
        12,
        1,
        true
    );

    return packet;
}

async function sendScreenCommand() {

    const packet =
        buildScreenCommand();

    log(
        'Sending RemoteJoy command on endpoint 3...'
    );

    log(
        'RemoteJoy OUT: ' +
        bytesToHex(packet)
    );

    const result =
        await device.transferOut(
            EP_REMOTEJOY_OUT,
            packet
        );

    if (
        result.status !==
        'ok'
    ) {

        throw new Error(
            'RemoteJoy command failed: ' +
            result.status
        );
    }

    log(
        'RemoteJoy command sent.',
        'good'
    );
}


/*
 * ------------------------------------------------------------
 * Frame drawing
 * ------------------------------------------------------------
 */

function drawRGB565(
    bytes,
    offset,
    width,
    height
) {

    const image =
        ctx.createImageData(
            width,
            height
        );

    const out =
        image.data;

    let src = offset;
    let dst = 0;

    const pixelCount =
        width * height;

    for (
        let i = 0;
        i < pixelCount;
        i++
    ) {

        if (
            src + 1 >=
            bytes.length
        ) {
            break;
        }

        const value =
            bytes[src] |
            (bytes[src + 1] << 8);

        src += 2;

        const r =
            ((value >> 11) & 0x1F) *
            255 / 31;

        const g =
            ((value >> 5) & 0x3F) *
            255 / 63;

        const b =
            (value & 0x1F) *
            255 / 31;

        out[dst++] = r;
        out[dst++] = g;
        out[dst++] = b;
        out[dst++] = 255;
    }

    ctx.putImageData(
        image,
        0,
        0
    );
}

function drawARGB8888(
    bytes,
    offset,
    width,
    height
) {

    const image =
        ctx.createImageData(
            width,
            height
        );

    const out =
        image.data;

    let src = offset;
    let dst = 0;

    const pixelCount =
        width * height;

    for (
        let i = 0;
        i < pixelCount;
        i++
    ) {

        if (
            src + 3 >=
            bytes.length
        ) {
            break;
        }

        const b =
            bytes[src++];

        const g =
            bytes[src++];

        const r =
            bytes[src++];

        const a =
            bytes[src++];

        out[dst++] = r;
        out[dst++] = g;
        out[dst++] = b;
        out[dst++] = a;
    }

    ctx.putImageData(
        image,
        0,
        0
    );
}

function drawFrame(frame) {

    if (
        !frame ||
        frame.length < 12
    ) {
        return;
    }

    const magic =
        u32(frame, 0);

    if (
        magic !==
        0x782F0814
    ) {

        log(
            'Unknown frame packet magic: 0x' +
            magic
                .toString(16)
                .padStart(8, '0')
        );

        return;
    }

    const totalSize =
        u32(frame, 8);

    log(
        'RemoteJoy frame packet: ' +
        frame.length +
        ' bytes, declared size ' +
        totalSize
    );

    const payloadOffset = 12;

    const payloadBytes =
        frame.length -
        payloadOffset;

    const rgb565Size =
        SCREEN_WIDTH *
        SCREEN_HEIGHT *
        2;

    const argbSize =
        SCREEN_WIDTH *
        SCREEN_HEIGHT *
        4;

    if (
        payloadBytes >=
        rgb565Size
    ) {

        drawRGB565(
            frame,
            payloadOffset,
            SCREEN_WIDTH,
            SCREEN_HEIGHT
        );

        return;
    }

    if (
        payloadBytes >=
        argbSize
    ) {

        drawARGB8888(
            frame,
            payloadOffset,
            SCREEN_WIDTH,
            SCREEN_HEIGHT
        );

        return;
    }

    log(
        'Frame payload too small: ' +
        payloadBytes +
        ' bytes',
        'warn'
    );
}


/*
 * ------------------------------------------------------------
 * Frame reader
 * ------------------------------------------------------------
 */

async function readFrameLoop() {

    if (frameReaderRunning) {
        return;
    }

    frameReaderRunning = true;

    try {

        while (connected) {

            let result;

            try {

                result =
                    await device.transferIn(
                        EP_SCREEN_IN,
                        0x200
                    );

            } catch (error) {

                if (!connected) {
                    break;
                }

                log(
                    'USB screen read error: ' +
                    error.message,
                    'error'
                );

                break;
            }

            if (
                !result ||
                !result.data
            ) {
                continue;
            }

            const first =
                new Uint8Array(
                    result.data.buffer
                );

            if (
                first.length === 0
            ) {
                continue;
            }

            log(
                'Screen IN: ' +
                first.length +
                ' bytes'
            );

            if (
                first.length >= 4
            ) {

                const magic =
                    u32(first, 0);

                if (
                    magic ===
                    HOSTFS_MAGIC
                ) {

                    log(
                        'Received HostFS packet during frame loop.'
                    );

                    continue;
                }

                if (
                    magic ===
                    0x782F0813
                ) {

                    log(
                        'Received RemoteJoy command packet.'
                    );

                    continue;
                }

                if (
                    magic !==
                    0x782F0814
                ) {

                    log(
                        'Unknown IN packet magic: 0x' +
                        magic
                            .toString(16)
                            .padStart(8, '0')
                    );

                    continue;
                }
            }

            if (
                first.length < 12
            ) {
                continue;
            }

            const declaredSize =
                u32(first, 8);

            if (
                declaredSize <=
                first.length
            ) {

                drawFrame(first);

                continue;
            }

            const chunks = [
                first
            ];

            let received =
                first.length;

            while (
                connected &&
                received <
                declaredSize
            ) {

                const remaining =
                    declaredSize -
                    received;

                const requestSize =
                    Math.min(
                        remaining,
                        0x10000
                    );

                const part =
                    await device.transferIn(
                        EP_SCREEN_IN,
                        requestSize
                    );

                if (
                    !part ||
                    !part.data
                ) {
                    break;
                }

                const bytes =
                    new Uint8Array(
                        part.data.buffer
                    );

                if (
                    bytes.length === 0
                ) {
                    break;
                }

                chunks.push(bytes);

                received +=
                    bytes.length;
            }

            if (
                received >=
                declaredSize
            ) {

                const frame =
                    new Uint8Array(
                        declaredSize
                    );

                let offset = 0;

                for (
                    const chunk of chunks
                ) {

                    const amount =
                        Math.min(
                            chunk.length,
                            declaredSize -
                            offset
                        );

                    frame.set(
                        chunk.subarray(
                            0,
                            amount
                        ),
                        offset
                    );

                    offset += amount;

                    if (
                        offset >=
                        declaredSize
                    ) {
                        break;
                    }
                }

                drawFrame(frame);
            }
        }

    } finally {

        frameReaderRunning = false;
    }
}


/*
 * ------------------------------------------------------------
 * Controller
 * ------------------------------------------------------------
 */

const buttonCodes = {
    UP: 0x0001,
    DOWN: 0x0002,
    LEFT: 0x0004,
    RIGHT: 0x0008,
    CENTER: 0x0000
};

async function sendButton(
    button,
    pressed
) {

    if (
        !connected ||
        !device
    ) {
        return;
    }

    const code =
        buttonCodes[button] || 0;

    const packet =
        new Uint8Array(24);

    const view =
        new DataView(
            packet.buffer
        );

    view.setUint32(
        0,
        REMOTEJOY_MAGIC,
        true
    );

    view.setUint32(
        4,
        0,
        true
    );

    view.setUint32(
        8,
        packet.length,
        true
    );

    view.setUint32(
        12,
        1,
        true
    );

    view.setUint32(
        16,
        code,
        true
    );

    view.setUint32(
        20,
        pressed ? 1 : 0,
        true
    );

    try {

        const result =
            await device.transferOut(
                EP_REMOTEJOY_OUT,
                packet
            );

        if (
            result.status !==
            'ok'
        ) {

            log(
                'Controller transfer failed: ' +
                result.status,
                'error'
            );
        }

    } catch (error) {

        log(
            'Controller transfer error: ' +
            error.message,
            'error'
        );
    }
}

function setupControls() {

    const buttons =
        document.querySelectorAll(
            '.controlButton'
        );

    buttons.forEach(button => {

        const name =
            button.dataset.button;

        button.addEventListener(
            'pointerdown',
            event => {

                event.preventDefault();

                button.setPointerCapture(
                    event.pointerId
                );

                sendButton(
                    name,
                    true
                );
            }
        );

        button.addEventListener(
            'pointerup',
            event => {

                event.preventDefault();

                sendButton(
                    name,
                    false
                );
            }
        );

        button.addEventListener(
            'pointercancel',
            event => {

                event.preventDefault();

                sendButton(
                    name,
                    false
                );
            }
        );

        button.addEventListener(
            'pointerleave',
            event => {

                if (
                    event.buttons === 0
                ) {

                    sendButton(
                        name,
                        false
                    );
                }
            }
        );
    });
}


/*
 * ------------------------------------------------------------
 * Fullscreen
 * ------------------------------------------------------------
 */

async function fullscreenScreen() {

    const element =
        document.getElementById(
            'screenWrap'
        );

    try {

        if (
            document.fullscreenElement
        ) {

            await document.exitFullscreen();

        } else {

            await element.requestFullscreen();
        }

    } catch (error) {

        log(
            'Fullscreen error: ' +
            error.message,
            'error'
        );
    }
}


/*
 * ------------------------------------------------------------
 * Cleanup
 * ------------------------------------------------------------
 */

async function closeUSB() {

    if (!device) {
        return;
    }

    const currentDevice =
        device;

    device = null;

    try {

        if (
            currentDevice.opened &&
            currentDevice.configuration
        ) {

            try {

                await currentDevice.releaseInterface(
                    interfaceNumber
                );

                log(
                    'USB interface released.'
                );

            } catch (error) {

                log(
                    'Interface release: ' +
                    error.message,
                    'warn'
                );
            }
        }

    } finally {

        try {

            if (
                currentDevice.opened
            ) {

                await currentDevice.close();

                log(
                    'USB device closed.'
                );
            }

        } catch (error) {

            log(
                'USB close: ' +
                error.message,
                'warn'
            );
        }
    }
}


/*
 * ------------------------------------------------------------
 * Connect
 * ------------------------------------------------------------
 */

async function connectPSP() {

    if (connected) {
        return;
    }

    document.getElementById(
        'connectBtn'
    ).disabled = true;

    try {

        log(
            'RemoteJoyLite Web ready.'
        );

        log(
            'Target: PSP-3000 / firmware 6.60 / ARK-5'
        );

        log(
            'WebUSB filter: NONE'
        );

        log(
            'Expected RemoteJoyLite VID/PID: 0x054C:0x01C9'
        );

        log(
            'Interface: 0'
        );

        log(
            'Screen IN: WebUSB endpoint 1 (USB 0x81)'
        );

        log(
            'HostFS OUT: WebUSB endpoint 2 (USB 0x02)'
        );

        log(
            'RemoteJoy OUT: WebUSB endpoint 3 (USB 0x03)'
        );

        log(
            'HostFS magic: 0x782F0812'
        );

        log(
            'RemoteJoy magic: 0x909ACCEF'
        );

        setStatus(
            'Opening USB connection...'
        );

        connected = true;

        await selectPSP();

        setDeviceInfo(
            'PSP-3000 / 0x054C:0x01C9'
        );

        document.getElementById(
            'disconnectBtn'
        ).disabled = false;

        setStatus(
            'USB initialized. Starting RemoteJoyLite handshake...'
        );

        await startHostFsHandshake();

        if (!connected) {
            return;
        }

        setStatus(
            'HostFS connected. Starting RemoteJoyLite...'
        );

        await sendScreenCommand();

        if (!connected) {
            return;
        }

        setStatus(
            'RemoteJoyLite connected.'
        );

        log(
            'RemoteJoyLite connection established.',
            'good'
        );

        readFrameLoop();

    } catch (error) {

        log(
            'Connection error: ' +
            (
                error &&
                error.message
                    ? error.message
                    : String(error)
            ),
            'error'
        );

        connected = false;

        setStatus(
            'Connection failed.'
        );

        document.getElementById(
            'connectBtn'
        ).disabled = false;

        document.getElementById(
            'disconnectBtn'
        ).disabled = true;

        await closeUSB();
    }
}


/*
 * ------------------------------------------------------------
 * Disconnect
 * ------------------------------------------------------------
 */

async function disconnectPSP() {

    connected = false;

    setStatus(
        'Disconnecting...'
    );

    document.getElementById(
        'disconnectBtn'
    ).disabled = true;

    await closeUSB();

    setDeviceInfo(
        'Not connected'
    );

    setStatus(
        'Disconnected.'
    );

    document.getElementById(
        'connectBtn'
    ).disabled = false;

    log(
        'USB device disconnected.'
    );
}


/*
 * ------------------------------------------------------------
 * Browser disconnect handling
 * ------------------------------------------------------------
 */

if (navigator.usb) {

    navigator.usb.addEventListener(
        'disconnect',
        event => {

            if (
                usbResetting
            ) {

                log(
                    'USB disconnect event occurred during device reset.'
                );

                return;
            }

            if (
                device &&
                event.device ===
                device
            ) {

                connected = false;

                log(
                    'PSP USB device was disconnected.',
                    'warn'
                );

                setStatus(
                    'USB device disconnected.'
                );

                setDeviceInfo(
                    'Not connected'
                );

                document.getElementById(
                    'connectBtn'
                ).disabled = false;

                document.getElementById(
                    'disconnectBtn'
                ).disabled = true;

                device = null;
            }
        }
    );
}


/*
 * ------------------------------------------------------------
 * Startup
 * ------------------------------------------------------------
 */

setupControls();

log(
    'RemoteJoyLite Web ready.'
);

log(
    'Target: PSP-3000 / firmware 6.60 / ARK-5'
);

log(
    'WebUSB filter: NONE'
);

log(
    'Expected RemoteJoyLite VID/PID: 0x054C:0x01C9'
);

log(
    'Interface: 0'
);

log(
    'Screen IN: WebUSB endpoint 1 (USB 0x81)'
);

log(
    'HostFS OUT: WebUSB endpoint 2 (USB 0x02)'
);

log(
    'RemoteJoy OUT: WebUSB endpoint 3 (USB 0x03)'
);

log(
    'HostFS magic: 0x782F0812'
);

log(
    'RemoteJoy magic: 0x909ACCEF'
);

log(
    'Waiting for Connect PSP.'
);
</script>

</body>
</html>
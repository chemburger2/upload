<?php
declare(strict_types=1);

session_start();

const QUESTION_FILE = __DIR__ . '/arkansas_permit_question_bank_680.csv';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function loadQuestions(): array {
    if (!is_file(QUESTION_FILE)) {
        http_response_code(500);
        exit('Question bank CSV is missing.');
    }

    $h = fopen(QUESTION_FILE, 'rb');
    if ($h === false) {
        http_response_code(500);
        exit('Could not open question bank.');
    }

    fgetcsv($h);
    $questions = [];

    while (($r = fgetcsv($h)) !== false) {
        if (count($r) < 7) continue;

        // New format:
        // id, topic, question, A, B, C, D, answer
        // The topic is kept in the question object so the bank can be
        // expanded by topic without changing the quiz logic.
        if (count($r) >= 8) {
            $questions[(string)$r[0]] = [
                'id' => (string)$r[0],
                'topic' => $r[1],
                'question' => $r[2],
                'A' => $r[3],
                'B' => $r[4],
                'C' => $r[5],
                'D' => $r[6],
                'answer' => strtoupper(trim($r[7]))
            ];
        } elseif (count($r) >= 7) {
            // Backward compatibility with the old CSV format:
            // id, question, A, B, C, D, answer
            $questions[(string)$r[0]] = [
                'id' => (string)$r[0],
                'topic' => '',
                'question' => $r[1],
                'A' => $r[2],
                'B' => $r[3],
                'C' => $r[4],
                'D' => $r[5],
                'answer' => strtoupper(trim($r[6]))
            ];
        }
    }

    fclose($h);
    return $questions;
}

function getStats(): array {
    $attempted = (int)($_SESSION['attempted'] ?? 0);
    $correct = (int)($_SESSION['correct'] ?? 0);

    return [
        'attempted' => $attempted,
        'correct' => $correct,
        'percent' => $attempted > 0
            ? round(($correct / $attempted) * 100, 1)
            : 0
    ];
}

function jsonResponse(array $data): never {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$questions = loadQuestions();

$_SESSION['used'] ??= [];
$_SESSION['attempted'] ??= 0;
$_SESSION['correct'] ??= 0;

$action = $_GET['action'] ?? '';

/*
 * Return a random question that has not been used in this 300-question cycle.
 */
if ($action === 'question') {
    if (count($_SESSION['used']) >= count($questions)) {
        $_SESSION['used'] = [];
    }

    $available = array_values(array_diff(
        array_keys($questions),
        array_keys($_SESSION['used'])
    ));

    if (!$available) {
        $_SESSION['used'] = [];
        $available = array_keys($questions);
    }

    $id = (string)$available[array_rand($available)];
    $_SESSION['current'] = $id;

    $q = $questions[$id];

    jsonResponse([
        'ok' => true,
        'question' => [
            'id' => $q['id'],
            'topic' => $q['topic'],
            'text' => $q['question'],
            'answers' => [
                'A' => $q['A'],
                'B' => $q['B'],
                'C' => $q['C'],
                'D' => $q['D']
            ]
        ],
        'cycle_used' => count($_SESSION['used']),
        'cycle_total' => count($questions),
        'remaining' => count($questions) - count($_SESSION['used']),
        'stats' => getStats()
    ]);
}

/*
 * Grade an answer without reloading the page.
 */
if ($action === 'answer' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (string)($_POST['question_id'] ?? '');
    $given = strtoupper((string)($_POST['answer'] ?? ''));

    if (
        !isset($questions[$id]) ||
        !isset($_SESSION['current']) ||
        $_SESSION['current'] !== $id ||
        !in_array($given, ['A', 'B', 'C', 'D'], true)
    ) {
        jsonResponse(['ok' => false, 'error' => 'Invalid question or answer.']);
    }

    $q = $questions[$id];
    $correct = hash_equals($q['answer'], $given);

    $_SESSION['attempted']++;
    if ($correct) {
        $_SESSION['correct']++;
    }

    $_SESSION['used'][$id] = true;
    unset($_SESSION['current']);

    jsonResponse([
        'ok' => true,
        'correct' => $correct,
        'given' => $given,
        'correct_answer' => $q['answer'],
        'correct_text' => $q[$q['answer']],
        'stats' => getStats(),
        'remaining' => count($questions) - count($_SESSION['used'])
    ]);
}

/*
 * Reset score and the no-repeat cycle.
 */
if ($action === 'reset') {
    $_SESSION['used'] = [];
    $_SESSION['attempted'] = 0;
    $_SESSION['correct'] = 0;
    unset($_SESSION['current']);

    jsonResponse([
        'ok' => true,
        'stats' => getStats(),
        'remaining' => count($questions)
    ]);
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Arkansas Permit Practice</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#f3f4f6;color:#111827;font-family:Arial,Helvetica,sans-serif}
.wrap{max-width:850px;margin:auto;padding:24px 16px 50px}
.top{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:18px}
h1{margin:0;font-size:28px}.sub{color:#6b7280;margin-top:5px}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:18px}
.stat{background:#fff;border-radius:12px;padding:14px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.stat strong{display:block;font-size:22px;margin-bottom:3px}
.card{background:#fff;border-radius:16px;padding:24px;box-shadow:0 4px 18px rgba(0,0,0,.08)}
.number{color:#6b7280;font-size:14px;margin-bottom:12px}
.question{font-size:22px;line-height:1.4;margin:0 0 22px}
.answers{display:grid;gap:11px}.answer{position:relative}
.answer input{position:absolute;opacity:0}
.answer label{display:block;padding:16px 18px;border:2px solid #e5e7eb;border-radius:11px;cursor:pointer;transition:.15s}
.answer label:hover{background:#f9fafb;border-color:#9ca3af}
.answer input:checked+label{background:#eff6ff;border-color:#2563eb}
.answer input:disabled+label{cursor:default}
button{border:0;border-radius:10px;padding:13px 18px;font-weight:700;cursor:pointer}
.submit{background:#2563eb;color:#fff;margin-top:18px;width:100%;font-size:16px}
.submit:hover{background:#1d4ed8}
.submit:disabled{opacity:.6;cursor:default}
.reset{background:#e5e7eb;color:#111827;font-size:13px}
.result{margin-top:18px;padding:16px;border-radius:10px;line-height:1.5}
.correct{background:#ecfdf5;border:1px solid #a7f3d0}
.wrong{background:#fef2f2;border:1px solid #fecaca}
.next{display:block;width:100%;margin-top:12px;background:#111827;color:#fff}
.next:hover{background:#374151}
.progress{text-align:center;color:#6b7280;margin-top:12px;font-size:14px}
.loading{text-align:center;padding:45px;color:#6b7280}
@media(max-width:600px){.stats{grid-template-columns:1fr}.card{padding:18px}.question{font-size:20px}}
</style>
</head>
<body>
<div class="wrap">
<div class="top">
  <div>
    <h1>Arkansas Permit Practice</h1>
    <div class="sub"><span id="bankDescription">Loading question bank...</span></div>
  </div>
  <button class="reset" id="resetBtn" type="button">Reset score</button>
</div>

<div class="stats">
  <div class="stat"><strong id="correctStat">0</strong>Correct</div>
  <div class="stat"><strong id="attemptedStat">0</strong>Attempted</div>
  <div class="stat"><strong id="percentStat">0%</strong>Accuracy</div>
</div>
<div class="progress" id="bankSize" style="margin-bottom:14px"></div>

<div class="card">
  <div id="quiz">
    <div class="loading">Loading question...</div>
  </div>
</div>
</div>

<script>
let currentQuestion = null;
let answered = false;

const quiz = document.getElementById('quiz');
const correctStat = document.getElementById('correctStat');
const attemptedStat = document.getElementById('attemptedStat');
const percentStat = document.getElementById('percentStat');
const resetBtn = document.getElementById('resetBtn');
const bankDescription = document.getElementById('bankDescription');
const bankSize = document.getElementById('bankSize');

function updateStats(stats) {
    correctStat.textContent = stats.correct;
    attemptedStat.textContent = stats.attempted;
    percentStat.textContent = stats.percent + '%';
}

async function getQuestion() {
    answered = false;
    quiz.innerHTML = '<div class="loading">Loading question...</div>';

    try {
        const response = await fetch('?action=question', {
            cache: 'no-store',
            headers: {'X-Requested-With': 'XMLHttpRequest'}
        });

        const data = await response.json();

        if (!data.ok) throw new Error(data.error || 'Could not load question.');

        currentQuestion = data.question;
        updateStats(data.stats);

        const total = Number(data.cycle_total) || 0;
        bankDescription.textContent =
            `${total}-question random bank • no repeats until all ${total} are used`;
        bankSize.textContent =
            `${total} questions currently loaded from the CSV`;

        renderQuestion(data);
    } catch (error) {
        quiz.innerHTML =
            '<div class="result wrong">Could not load the question. Please try again.</div>' +
            '<button class="next" type="button" onclick="getQuestion()">Try again</button>';
    }
}

function renderQuestion(data) {
    const q = data.question;

    let html = `
        <div class="number">
            Question ${data.cycle_used + 1} of ${data.cycle_total} in this cycle
            ${q.topic ? ' • ' + escapeHtml(q.topic) : ''}
        </div>
        <h2 class="question">${escapeHtml(q.text)}</h2>
        <form id="answerForm">
            <input type="hidden" name="question_id" value="${escapeHtml(q.id)}">
            <div class="answers">
    `;

    for (const letter of ['A','B','C','D']) {
        html += `
            <div class="answer">
                <input required type="radio" id="ans${letter}" name="answer" value="${letter}">
                <label for="ans${letter}">
                    <strong>${letter}.</strong> ${escapeHtml(q.answers[letter])}
                </label>
            </div>
        `;
    }

    html += `
            </div>
            <button class="submit" id="submitBtn" type="submit">Submit Answer</button>
        </form>
        <div class="progress">${data.remaining} unique questions remain in this cycle.</div>
    `;

    quiz.innerHTML = html;

    document.getElementById('answerForm').addEventListener('submit', submitAnswer);
}

async function submitAnswer(event) {
    event.preventDefault();

    if (answered) return;

    const form = event.currentTarget;
    const submit = document.getElementById('submitBtn');
    const selected = form.querySelector('input[name="answer"]:checked');

    if (!selected) return;

    answered = true;
    submit.disabled = true;

    form.querySelectorAll('input').forEach(input => input.disabled = true);

    const body = new URLSearchParams();
    body.set('question_id', currentQuestion.id);
    body.set('answer', selected.value);

    try {
        const response = await fetch('?action=answer', {
            method: 'POST',
            body,
            cache: 'no-store',
            headers: {'X-Requested-With': 'XMLHttpRequest'}
        });

        const data = await response.json();

        if (!data.ok) throw new Error(data.error || 'Could not grade answer.');

        updateStats(data.stats);

        const resultClass = data.correct ? 'correct' : 'wrong';
        const resultText = data.correct
            ? '<strong>Correct!</strong>'
            : '<strong>Incorrect.</strong><br>Correct answer: ' +
              escapeHtml(data.correct_answer) + ' — ' +
              escapeHtml(data.correct_text);

        quiz.insertAdjacentHTML('beforeend',
            `<div class="result ${resultClass}">${resultText}</div>` +
            `<button class="next" type="button" id="nextBtn">Next question</button>`
        );

        document.getElementById('nextBtn').addEventListener('click', getQuestion);

    } catch (error) {
        answered = false;
        submit.disabled = false;
        form.querySelectorAll('input').forEach(input => input.disabled = false);

        quiz.insertAdjacentHTML('beforeend',
            '<div class="result wrong">There was a problem submitting the answer. Please try again.</div>'
        );
    }
}

resetBtn.addEventListener('click', async () => {
    if (!confirm('Reset your score and start a fresh question cycle?')) return;

    resetBtn.disabled = true;

    try {
        const response = await fetch('?action=reset', {
            cache: 'no-store',
            headers: {'X-Requested-With': 'XMLHttpRequest'}
        });

        const data = await response.json();

        if (!data.ok) throw new Error();

        updateStats(data.stats);
        await getQuestion();
    } catch (error) {
        alert('Could not reset the quiz.');
    } finally {
        resetBtn.disabled = false;
    }
});

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

// Load the first question without reloading the page.
getQuestion();
</script>
</body>
</html>

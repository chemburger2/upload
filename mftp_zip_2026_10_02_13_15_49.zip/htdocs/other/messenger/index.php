<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config.php';

if (empty($_SESSION['user_id'])) {
    header('Location: ../../logon.php');
    exit;
}

$currentUserId = (int) $_SESSION['user_id'];

$stmt = $pdo->prepare(
    'SELECT id, username FROM users WHERE id = ? LIMIT 1'
);

$stmt->execute([$currentUserId]);

$currentUser = $stmt->fetch();

if (!$currentUser) {
    session_destroy();
    header('Location: ../../logon.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<link rel="icon" type="image/x-icon" href="favicon.ico">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Home - Classroom</title>

    <style>

        * {
            box-sizing: border-box;
        }

        html,
        body {
            height: 100%;
            margin: 0;
        }

        body {
            font-family:
                Inter,
                system-ui,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background: #f4f6f8;
            color: #17202a;
        }

        button,
        input,
        textarea {
            font: inherit;
        }

        .app {
            height: 100vh;
            display: flex;
            overflow: hidden;
            background: #fff;
        }

        /* =========================
           SIDEBAR
        ========================= */

        .sidebar {
            width: 290px;
            flex: 0 0 290px;

            border-right: 1px solid #e5e7eb;

            background: #fafafa;

            display: flex;
            flex-direction: column;
        }

        .sidebar-header {
            padding: 20px;

            border-bottom: 1px solid #e5e7eb;
        }

        .brand {
            font-size: 21px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .account {
            color: #6b7280;
            font-size: 13px;
        }

        .search {
            margin-top: 15px;

            width: 100%;

            border: 1px solid #dddfe3;

            border-radius: 10px;

            padding: 10px 12px;

            outline: none;

            background: white;
        }

        .search:focus {
            border-color: #9ca3af;
        }

        .users {
            overflow-y: auto;

            padding: 8px;

            flex: 1;
        }

        .user-button {
            width: 100%;

            border: 0;

            background: transparent;

            padding: 11px 12px;

            border-radius: 10px;

            display: flex;
            align-items: center;

            gap: 11px;

            cursor: pointer;

            text-align: left;

            color: #17202a;
        }

        .user-button:hover {
            background: #eef0f2;
        }

        .user-button.active {
            background: #e7eaee;
        }

        .avatar {
            width: 40px;
            height: 40px;

            flex: 0 0 40px;

            border-radius: 50%;

            background: #d9dde2;

            display: grid;
            place-items: center;

            font-weight: 700;

            color: #374151;
        }

        .user-name {
            overflow: hidden;

            text-overflow: ellipsis;

            white-space: nowrap;

            font-size: 14px;

            font-weight: 600;
        }

        .empty-users {
            padding: 25px 15px;

            text-align: center;

            color: #8a9199;

            font-size: 14px;
        }

        /* =========================
           CHAT
        ========================= */

        .chat {
            flex: 1;

            min-width: 0;

            display: flex;
            flex-direction: column;
        }

        .chat-header {
            height: 70px;

            flex: 0 0 70px;

            padding: 0 24px;

            border-bottom: 1px solid #e5e7eb;

            display: flex;
            align-items: center;

            gap: 12px;
        }

        .chat-title {
            font-weight: 700;
        }

        /* =========================
           BLOCK BUTTON
        ========================= */

        .block-button {
            display: none;

            margin-left: auto;

            border: 0;

            border-radius: 9px;

            padding: 8px 12px;

            background: #eef0f2;

            color: #17202a;

            cursor: pointer;

            font-weight: 600;
        }

        .block-button:hover {
            background: #e1e4e7;
        }

        .block-button:disabled {
            opacity: .55;

            cursor: default;
        }

        /* =========================
           MESSAGES
        ========================= */

        .messages {
            flex: 1;

            min-height: 0;

            overflow-y: auto;
            overflow-anchor: none;

            padding: 24px;

            background: #fff;

            display: block;
        }

        .welcome,
        .no-messages {
            height: 100%;

            display: grid;

            place-items: center;

            color: #8a9199;

            text-align: center;

            padding: 30px;
        }

        /* =========================
           MESSAGE ROW
        ========================= */

        .message-row {
            display: block;

            width: 100%;

            height: auto;

            min-height: 0;

            margin: 5px 0;

            padding: 0;

            line-height: normal;
        }

        .message-row:not(.mine) {
            text-align: left;
        }

        .message-row.mine {
            text-align: right;
        }

        /* =========================
           MESSAGE BUBBLE
        ========================= */

        .bubble {
            position: relative;

            display: inline-block;

            width: auto;

            height: auto;

            min-width: 0;

            min-height: 0;

            max-width: min(70%, 650px);

            margin: 0;

            padding: 8px 10px;

            border-radius: 14px;

            background: #eef0f2;

            font-size: 14px;

            line-height: 18px;

            text-align: left;

            vertical-align: top;

            white-space: normal;

            overflow-wrap: anywhere;
        }

        .mine .bubble {
            background: #1f2937;

            color: white;
        }

        /* =========================
           MESSAGE TEXT
        ========================= */

        .message-text {
            display: block;

            width: auto;

            height: auto;

            min-height: 18px;

            margin: 0;

            padding: 0;

            font-size: 14px;

            line-height: 18px;

            white-space: pre-wrap;

            overflow-wrap: anywhere;
        }

        /* =========================
           TIMESTAMP
        ========================= */

        .time {
            display: block;

            width: 100%;

            height: 10px;

            min-height: 10px;

            margin: 2px 0 0;

            padding: 0;

            font-size: 9px;

            line-height: 10px;

            opacity: .55;

            white-space: nowrap;

            text-align: right;
        }

        /* =========================
           COMPOSER
        ========================= */

        .composer {
            position: relative;
            padding: 14px 18px;

            border-top: 1px solid #e5e7eb;

            display: flex;

            gap: 10px;

            background: #fff;
        }

        .composer textarea {
            flex: 1;

            min-height: 44px;

            max-height: 130px;

            resize: none;

            border: 1px solid #dfe2e6;

            border-radius: 12px;

            padding: 11px 13px;

            outline: none;
        }

        .composer textarea:focus {
            border-color: #9ca3af;
        }

        .send {
            border: 0;

            border-radius: 11px;

            padding: 0 18px;

            background: #1f2937;

            color: white;

            cursor: pointer;

            font-weight: 600;
        }

        .send:disabled {
            opacity: .45;

            cursor: default;
        }


        /* =========================
           MESSAGE ACTIONS / REPLIES
        ========================= */

        .bubble-wrap {
            position: relative;
            display: inline-block;
            max-width: min(70%, 650px);
            text-align: left;
        }

        .bubble-wrap .bubble {
            max-width: 100%;
        }

        .message-actions {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            align-items: center;
            opacity: 0;
            pointer-events: none;
            transition: opacity .12s ease;
        }

        .message-row:not(.mine) .message-actions {
            left: calc(100% + 8px);
        }

        .message-row.mine .message-actions {
            right: calc(100% + 8px);
        }

        .message-row:hover .message-actions,
        .message-actions:focus-within {
            opacity: 1;
            pointer-events: auto;
        }

        .message-action {
            width: 32px;
            height: 32px;
            border: 1px solid #dfe2e6;
            border-radius: 9px;
            background: #fff;
            color: #374151;
            display: grid;
            place-items: center;
            padding: 0;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .08);
        }

        .message-action:hover {
            background: #f4f5f6;
        }

        .message-action svg {
            width: 16px;
            height: 16px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .reply-quote {
            margin: -1px 0 7px;
            padding: 7px 9px;
            border-left: 3px solid #9ca3af;
            border-radius: 6px;
            background: rgba(0, 0, 0, .05);
            font-size: 12px;
            line-height: 16px;
            overflow: hidden;
        }

        .mine .reply-quote {
            background: rgba(255, 255, 255, .10);
            border-left-color: rgba(255, 255, 255, .65);
        }

        .reply-quote-label {
            font-weight: 700;
            margin-bottom: 2px;
        }

        .reply-quote-text {
            opacity: .82;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .attachment-image {
            display: block;
            width: auto;
            max-width: 360px;
            max-height: 720px;
            border-radius: 10px;
            margin-bottom: 7px;
            cursor: pointer;
            background: #f3f4f6;
        }

        .attachment-file {
            display: flex;
            align-items: center;
            gap: 9px;
            min-width: 210px;
            max-width: 340px;
            padding: 9px 10px;
            margin-bottom: 7px;
            border-radius: 9px;
            background: rgba(0, 0, 0, .06);
            color: inherit;
            text-decoration: none;
        }

        .mine .attachment-file {
            background: rgba(255, 255, 255, .10);
        }

        .attachment-file svg {
            width: 19px;
            height: 19px;
            flex: 0 0 19px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .attachment-file-info {
            min-width: 0;
            display: block;
            line-height: 15px;
        }

        .attachment-file-name {
            display: block;
            max-width: 270px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 12px;
            color: #6b7280;
        }

        .mine .attachment-file-name {
            color: #aeb5bf;
        }

        .attachment-file-size {
            display: block;
            font-size: 11px;
            color: #9ca3af;
        }

        .mine .attachment-file-size {
            color: #8f98a5;
        }

        .attachment-download-icon {
            margin-left: auto;
            color: #6b7280;
        }

        .mine .attachment-download-icon {
            color: #aeb5bf;
        }

        .composer {
            position: relative;
            flex-wrap: wrap;
        }

        .composer-tools {
            position: relative;
            z-index: 30;
            flex: 0 0 100%;
            width: auto;
            min-width: 0;
            display: flex;
            align-items: center;
            gap: 9px;
            min-height: 34px;
        }

        .attachment-button {
            width: 34px;
            height: 34px;
            border: 1px solid #dfe2e6;
            border-radius: 9px;
            background: #fff;
            color: #374151;
            display: grid;
            place-items: center;
            padding: 0;
            cursor: pointer;
        }

        .attachment-button:hover:not(:disabled) {
            background: #f4f5f6;
        }

        .attachment-button:disabled {
            opacity: .45;
            cursor: default;
        }

        .attachment-button svg {
            width: 17px;
            height: 17px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .gif-button {
            position: relative;
            z-index: 31;
            width: 34px;
            height: 34px;
            min-width: 34px;
            min-height: 34px;
            flex: 0 0 34px;
            border: 1px solid #dfe2e6;
            border-radius: 9px;
            background: #fff;
            color: #374151;
            display: grid;
            place-items: center;
            padding: 0;
            cursor: pointer;
            flex: 0 0 auto;
        }

        .gif-button:hover:not(:disabled) {
            background: #f4f5f6;
        }

        .gif-button:disabled {
            opacity: .45;
            cursor: default;
        }

        .gif-button svg {
            pointer-events: none;
            display: block;
            width: 19px;
            height: 19px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .gif-menu {
            position: absolute;
            left: 8px;
            bottom: 58px;
            width: min(420px, calc(100% - 16px));
            height: 390px;
            display: none;
            flex-direction: column;
            background: #fff;
            border: 1px solid #dfe2e6;
            border-radius: 12px;
            box-shadow: 0 12px 30px rgba(0,0,0,.14);
            overflow: hidden;
            z-index: 20;
        }

        .gif-menu.show {
            display: flex;
        }

        .gif-search {
            display: flex;
            gap: 8px;
            padding: 10px;
            border-bottom: 1px solid #eceef1;
        }

        .gif-search input {
            flex: 1;
            min-width: 0;
            border: 1px solid #dfe2e6;
            border-radius: 8px;
            padding: 8px 10px;
            font: inherit;
            outline: none;
        }

        .gif-search input:focus {
            border-color: #9ca3af;
        }

        .gif-search button {
            border: 1px solid #dfe2e6;
            border-radius: 8px;
            background: #f7f8f9;
            padding: 0 12px;
            cursor: pointer;
        }

        .gif-results {
            flex: 1 1 auto;
            min-height: 0;
            overflow-y: auto;
            padding: 8px;
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            grid-auto-rows: 120px;
            gap: 7px;
            align-content: start;
        }

        .gif-result {
            display: block;
            width: 100%;
            height: 120px;
            min-width: 0;
            min-height: 120px;
            border: 0;
            padding: 0;
            margin: 0;
            background: #f3f4f6;
            border-radius: 7px;
            overflow: hidden;
            cursor: pointer;
            position: relative;
        }

        .gif-result:hover {
            opacity: .85;
        }

        .gif-result img {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            display: block;
            object-fit: cover;
        }

        .gif-status {
            grid-column: 1 / -1;
            padding: 24px 10px;
            text-align: center;
            color: #6b7280;
            font-size: 13px;
        }

        .gif-attribution {
            padding: 6px 10px;
            border-top: 1px solid #eceef1;
            color: #9ca3af;
            font-size: 10px;
            text-align: right;
        }

        .gif-message {
            display: block;
            width: 300px;
            max-width: 100%;
            border-radius: 9px;
            overflow: hidden;
            margin-bottom: 5px;
            background: #f3f4f6;
        }

        .gif-message img {
            display: block;
            width: 100%;
            height: auto;
            max-height: 480px;
            object-fit: contain;
            background: #f3f4f6;
        }

        .message-media-image {
            visibility: hidden;
        }

        .message-media-image.media-loaded {
            visibility: visible;
        }

        .selected-file {
            display: none;
            align-items: center;
            gap: 7px;
            min-width: 0;
            font-size: 12px;
            color: #6b7280;
        }

        .selected-file.show {
            display: flex;
        }

        .selected-file-name {
            max-width: 260px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .clear-file {
            border: 0;
            background: transparent;
            color: #6b7280;
            padding: 2px 4px;
            cursor: pointer;
        }

        .reply-composer {
            display: none;
            width: 100%;
            padding: 7px 9px;
            border-left: 3px solid #9ca3af;
            border-radius: 7px;
            background: #f4f5f6;
            color: #4b5563;
            font-size: 12px;
            line-height: 16px;
        }

        .reply-composer.show {
            display: block;
        }

        .reply-composer-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 2px;
        }

        .reply-composer-label {
            font-weight: 700;
        }

        .cancel-reply {
            border: 0;
            background: transparent;
            color: #6b7280;
            padding: 0 2px;
            cursor: pointer;
        }

        /* =========================
           MOBILE
        ========================= */

        .mobile-users {
            display: none;

            border: 0;

            background: transparent;

            font-size: 21px;

            cursor: pointer;
        }

        @media (max-width: 700px) {

            .sidebar {
                position: fixed;

                z-index: 10;

                top: 0;
                bottom: 0;
                left: 0;

                transform: translateX(-100%);

                transition:
                    transform .18s ease;

                box-shadow:
                    8px 0 25px rgba(0, 0, 0, .08);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .mobile-users {
                display: block;
            }

            .chat-header {
                padding: 0 14px;
            }

            .messages {
                padding: 15px;
            }

            .bubble-wrap {
                max-width: 82%;
            }

            .bubble {
                max-width: 100%;
            }

            .message-actions {
                top: -8px;
                right: auto !important;
                left: auto !important;
            }

            .message-row:not(.mine) .message-actions {
                right: -8px;
                left: auto;
            }

            .message-row.mine .message-actions {
                left: -8px;
                right: auto;
            }

            .composer {
            position: relative;
                padding: 10px;
            }
        }

    </style>
</head>

<body>

<div class="app">

    <!-- =========================
         SIDEBAR
    ========================== -->

    <aside
        class="sidebar"
        id="sidebar"
    >

        <div class="sidebar-header">

            <div class="brand">
                Messenger
            </div>

            <div class="account">

                Signed in as

                <?= htmlspecialchars(
                    (string)$currentUser['username'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>

            </div>

            <input
                class="search"
                id="search"
                type="search"
                placeholder="Search people..."
                autocomplete="off"
            >

        </div>

        <div
            class="users"
            id="users"
        >

            <div class="empty-users">
                Loading accounts...
            </div>

        </div>

    </aside>


    <!-- =========================
         CHAT
    ========================== -->

    <main class="chat">

        <header class="chat-header">

            <button
                class="mobile-users"
                id="mobileUsers"
                aria-label="Open people"
                type="button"
            >
                <svg viewBox="0 0 24 24" aria-hidden="true" style="width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;">
                    <path d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>

            <div
                class="avatar"
                id="chatAvatar"
            >
                ?
            </div>

            <div
                class="chat-title"
                id="chatTitle"
            >
                Select someone to message
            </div>

            <button
                class="block-button"
                id="blockButton"
                type="button"
            >
                Block
            </button>

        </header>


        <section
            class="messages"
            id="messages"
        >

            <div class="welcome">

                Choose an account from the left
                to start a conversation.

            </div>

        </section>


        <!-- =========================
             COMPOSER
        ========================== -->

        <form
            class="composer"
            id="composer"
            enctype="multipart/form-data"
        >

            <div class="reply-composer" id="replyComposer">
                <div class="reply-composer-top">
                    <span class="reply-composer-label">Replying</span>
                    <button class="cancel-reply" id="cancelReply" type="button" aria-label="Cancel reply">Cancel</button>
                </div>
                <div id="replyComposerText"></div>
            </div>

            <div class="composer-tools">
                <button
                    class="attachment-button"
                    id="attachmentButton"
                    type="button"
                    aria-label="Attach a file"
                    disabled
                >
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M21.4 11.1 12.9 19.6a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 1 1-2.8-2.8l8.5-8.5"/>
                    </svg>
                </button>

                <button
                    class="gif-button"
                    id="gifButton"
                    type="button"
                    aria-label="Choose a GIF"
                    title="GIF"
                    disabled
                >
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <rect x="3" y="5" width="18" height="14" rx="2"/>
                        <path d="M7 12h2"/>
                        <path d="M12 9v6"/>
                        <path d="M16 9h-2v6"/>
                        <path d="M14 12h2"/>
                    </svg>
                </button>

                <div class="gif-menu" id="gifMenu">
                    <div class="gif-search">
                        <input id="gifSearchInput" type="text" placeholder="Search GIPHY GIFs..." autocomplete="off">
                        <button id="gifSearchButton" type="button">Search</button>
                    </div>
                    <div class="gif-results" id="gifResults">
                        <div class="gif-status">Search for a GIF.</div>
                    </div>
                    <div class="gif-attribution">Powered by GIPHY</div>
                </div>

                <input
                    id="fileInput"
                    type="file"
                    hidden
                >

                <div class="selected-file" id="selectedFile">
                    <span class="selected-file-name" id="selectedFileName"></span>
                    <button class="clear-file" id="clearFile" type="button" aria-label="Remove attachment">Remove</button>
                </div>
            </div>

            <textarea
                id="messageInput"
                placeholder="Select someone first..."
                maxlength="5000"
                disabled
            ></textarea>

            <button
                class="send"
                id="sendButton"
                type="submit"
                disabled
            >
                Send
            </button>

        </form>

    </main>

</div>


<script>

const currentUserId =
    <?= json_encode($currentUserId) ?>;

const GIPHY_API_KEY = 'PjqF1BaKetRwFAGcdNtC3TsAWoZFD1WH';

let selectedUserId = null;

let selectedUsername = '';

let pollTimer = null;


const usersEl =
    document.getElementById('users');

const searchEl =
    document.getElementById('search');

const messagesEl =
    document.getElementById('messages');

const titleEl =
    document.getElementById('chatTitle');

const avatarEl =
    document.getElementById('chatAvatar');

const inputEl =
    document.getElementById('messageInput');

const sendEl =
    document.getElementById('sendButton');

const sidebarEl =
    document.getElementById('sidebar');

const blockButton =
    document.getElementById('blockButton');


/* =========================
   ESCAPE HTML
========================= */

function escapeHtml(value) {

    return String(value).replace(
        /[&<>'"]/g,
        c => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#039;',
            '"': '&quot;'
        }[c])
    );

}


/* =========================
   INITIALS
========================= */

function initials(name) {

    const parts =
        String(name)
            .trim()
            .split(/\s+/)
            .filter(Boolean);

    return (
        parts.length > 1
            ? parts[0][0] +
              parts[parts.length - 1][0]
            : (parts[0]?.[0] || '?')
    ).toUpperCase();

}


/* =========================
   API
========================= */

async function api(
    action,
    options = {}
) {

    const params =
        new URLSearchParams({
            action,
            ...options
        });

    const response =
        await fetch(
            'api.php?' +
            params.toString(),
            {
                cache: 'no-store',
                credentials: 'same-origin'
            }
        );

    const data =
        await response.json();

    if (
        !response.ok ||
        !data.ok
    ) {

        throw new Error(
            data.error ||
            'Request failed'
        );

    }

    return data;

}


/* =========================
   SEND MESSAGE
========================= */

const MAX_FILE_SIZE = 15 * 1024 * 1024;
const CHAT_STORAGE_LIMIT = 45 * 1024 * 1024;

let selectedReplyId = null;
let selectedFile = null;
let selectedGif = null;

const attachmentButton =
    document.getElementById('attachmentButton');

const fileInput =
    document.getElementById('fileInput');

const selectedFileEl =
    document.getElementById('selectedFile');

const selectedFileNameEl =
    document.getElementById('selectedFileName');

const clearFileButton =
    document.getElementById('clearFile');

const gifButton =
    document.getElementById('gifButton');

const gifMenu =
    document.getElementById('gifMenu');

const gifSearchInput =
    document.getElementById('gifSearchInput');

const gifSearchButton =
    document.getElementById('gifSearchButton');

const gifResults =
    document.getElementById('gifResults');

const replyComposer =
    document.getElementById('replyComposer');

const replyComposerText =
    document.getElementById('replyComposerText');

const cancelReplyButton =
    document.getElementById('cancelReply');

function formatBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) {
        return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB'];
    let value = bytes;
    let index = 0;

    while (value >= 1024 && index < units.length - 1) {
        value /= 1024;
        index++;
    }

    return `${value.toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
}

async function sendMessage(text) {

    const formData = new FormData();

    formData.append('action', 'send');
    formData.append('user_id', String(selectedUserId));
    formData.append('message', text);

    if (selectedReplyId) {
        formData.append('reply_to_id', String(selectedReplyId));
    }

    if (selectedGif) {
        formData.append('gif_url', selectedGif.url);
        formData.append('gif_preview_url', selectedGif.preview_url || selectedGif.url);
        formData.append('gif_title', selectedGif.title || 'GIF');
    }

    if (selectedFile) {
        formData.append('file', selectedFile, selectedFile.name);
        formData.append('original_name', selectedFile.name);
    }

    const response =
        await fetch(
            'api.php',
            {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            }
        );

    const data = await response.json();

    if (!response.ok || !data.ok) {
        throw new Error(
            data.error ||
            'Could not send message'
        );
    }

    return data;
}

function clearSelectedFile() {
    selectedFile = null;
    fileInput.value = '';
    selectedFileNameEl.textContent = '';
    selectedFileEl.classList.remove('show');
}

function clearSelectedGif() {
    selectedGif = null;
    gifMenu.classList.remove('show');
    gifSearchInput.value = '';
    gifResults.innerHTML = '<div class="gif-status">Search for a GIF.</div>';
}

let gifSearchQuery = '';
let gifSearchOffset = 0;
let gifSearchTotalLoaded = 0;
let gifSearchLoading = false;
let gifSearchHasMore = false;
let gifSearchRequestId = 0;
let gifImageObserver = null;
let messageImageObserver = null;
let lastMessageSignature = '';
const GIF_PAGE_SIZE = 24;
const GIF_MAX_RESULTS = 1000;

function setupGifImageObserver() {
    if (gifImageObserver) {
        gifImageObserver.disconnect();
    }

    gifImageObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            const image = entry.target;
            const src = image.dataset.src || '';

            if (!src) return;

            if (entry.isIntersecting) {
                if (image.src !== src) {
                    image.src = src;
                }
            } else {
                // Release the image resource once it is well outside the
                // visible area. Scrolling back will load it again.
                if (image.src === src) {
                    image.removeAttribute('src');
                }
            }
        });
    }, {
        root: gifResults,
        rootMargin: '300px 0px',
        threshold: 0
    });
}

function observeGifImages() {
    if (!gifImageObserver) {
        setupGifImageObserver();
    }

    gifResults.querySelectorAll('.gif-result img[data-src]').forEach(image => {
        gifImageObserver.observe(image);
    });
}

function renderGifResults() {
    const buttons = gifResults.querySelectorAll('.gif-result');
    buttons.forEach(button => button.remove());

    if (!gifSearchResults.length) {
        gifResults.innerHTML = '<div class="gif-status">No GIFs found.</div>';
        return;
    }

    gifResults.innerHTML = gifSearchResults.map(gif => `
        <button class="gif-result" type="button" data-gif-id="${escapeHtml(gif.id)}" title="${escapeHtml(gif.title || 'GIF')}">
            <img data-src="${escapeHtml(gif.preview_url || gif.url)}" alt="${escapeHtml(gif.title || 'GIF')}" loading="lazy">
        </button>
    `).join('');

    gifResults.querySelectorAll('.gif-result').forEach(button => {
        button.addEventListener('click', async () => {
            const id = button.dataset.gifId;
            const gif = gifSearchResults.find(item => String(item.id) === String(id));
            if (!gif) return;

            selectedGif = gif;
            gifMenu.classList.remove('show');
            gifSearchInput.value = '';

            if (!selectedUserId || inputEl.disabled) {
                selectedGif = null;
                return;
            }

            const text = inputEl.value.trim();
            sendEl.disabled = true;
            attachmentButton.disabled = true;
            gifButton.disabled = true;

            try {
                await sendMessage(text);

                inputEl.value = '';
                clearReply();
                clearSelectedFile();
                clearSelectedGif();

                await loadMessages(false);
                messagesEl.scrollTop = messagesEl.scrollHeight;
                await loadUsers();
            } catch (error) {
                alert(error.message);
            } finally {
                await loadBlockStatus();

                if (!inputEl.disabled) {
                    sendEl.disabled = false;
                    attachmentButton.disabled = false;
                    gifButton.disabled = false;
                }

                inputEl.focus();
            }
        });
    });

    observeGifImages();
}

let gifSearchResults = [];

async function loadMoreGifs(reset = false) {
    if (gifSearchLoading || !gifSearchQuery) return;
    if (!reset && (!gifSearchHasMore || gifSearchResults.length >= GIF_MAX_RESULTS)) return;

    const requestId = gifSearchRequestId;
    gifSearchLoading = true;

    const remaining = GIF_MAX_RESULTS - gifSearchResults.length;
    const limit = Math.min(GIF_PAGE_SIZE, remaining);

    if (reset) {
        gifResults.innerHTML = '<div class="gif-status">Searching...</div>';
    } else {
        const loading = document.createElement('div');
        loading.className = 'gif-status gif-loading-more';
        loading.textContent = 'Loading more GIFs...';
        gifResults.appendChild(loading);
    }

    try {
        const response = await fetch('https://api.giphy.com/v1/gifs/search?' + new URLSearchParams({
            api_key: GIPHY_API_KEY,
            q: gifSearchQuery,
            limit: String(limit),
            offset: String(gifSearchOffset),
            rating: 'pg-13',
            lang: 'en',
            bundle: 'messaging_non_clips'
        }).toString(), {
            cache: 'no-store'
        });

        const data = await response.json();

        if (requestId !== gifSearchRequestId) return;

        if (!response.ok || data.meta?.status !== 200) {
            throw new Error(data.meta?.msg || 'GIPHY search failed.');
        }

        const results = (data.data || []).map(item => ({
            id: String(item.id || ''),
            url: item.images?.original?.url || '',
            preview_url: item.images?.fixed_width_small?.url || item.images?.preview_gif?.url || item.images?.original?.url || '',
            title: item.title || 'GIF'
        })).filter(item => item.id && item.url);

        if (reset) {
            gifSearchResults = results;
        } else {
            const existing = new Set(gifSearchResults.map(item => item.id));
            gifSearchResults.push(...results.filter(item => !existing.has(item.id)));
        }

        gifSearchOffset += Number(data.pagination?.count || results.length || 0);
        gifSearchTotalLoaded = gifSearchResults.length;

        const totalAvailable = Number(data.pagination?.total_count || 0);
        gifSearchHasMore =
            gifSearchResults.length < GIF_MAX_RESULTS &&
            results.length > 0 &&
            gifSearchOffset < totalAvailable;

        if (gifSearchResults.length >= GIF_MAX_RESULTS || !gifSearchHasMore) {
            gifSearchHasMore = false;
        }

        renderGifResults();

        if (gifSearchHasMore) {
            const endMarker = document.createElement('div');
            endMarker.className = 'gif-status gif-scroll-hint';
            endMarker.textContent = 'Scroll for more';
            gifResults.appendChild(endMarker);
        }
    } catch (error) {
        if (requestId !== gifSearchRequestId) return;

        if (reset || !gifSearchResults.length) {
            gifResults.innerHTML = `<div class="gif-status">${escapeHtml(error.message)}</div>`;
        } else {
            const loading = gifResults.querySelector('.gif-loading-more');
            if (loading) {
                loading.textContent = error.message;
            }
        }
    } finally {
        if (requestId === gifSearchRequestId) {
            gifSearchLoading = false;
        }
    }
}

async function searchGifs() {
    const query = gifSearchInput.value.trim().slice(0, 50);

    if (!query) {
        gifSearchRequestId++;
        gifSearchQuery = '';
        gifSearchResults = [];
        gifSearchOffset = 0;
        gifSearchHasMore = false;
        gifResults.innerHTML = '<div class="gif-status">Type something to search.</div>';
        return;
    }

    gifSearchRequestId++;
    gifSearchQuery = query;
    gifSearchResults = [];
    gifSearchOffset = 0;
    gifSearchTotalLoaded = 0;
    gifSearchHasMore = true;
    gifSearchLoading = false;

    if (gifImageObserver) {
        gifImageObserver.disconnect();
    }

    await loadMoreGifs(true);
}

gifResults.addEventListener('scroll', () => {
    if (!gifSearchHasMore || gifSearchLoading) return;

    const distanceFromBottom =
        gifResults.scrollHeight - gifResults.scrollTop - gifResults.clientHeight;

    if (distanceFromBottom < 250) {
        loadMoreGifs(false);
    }
});


function clearReply() {
    selectedReplyId = null;
    replyComposerText.textContent = '';
    replyComposer.classList.remove('show');
}

function beginReply(message) {
    selectedReplyId = Number(message.id);

    const text =
        String(message.message || '').trim() ||
        (message.attachment_name || 'Attachment');

    replyComposerText.textContent = text;
    replyComposer.classList.add('show');
    inputEl.focus();
}

async function deleteMessage(messageId) {
    const confirmed = confirm(
        'Delete this message? It will be removed for both you and the recipient.'
    );

    if (!confirmed) {
        return;
    }

    try {
        const response = await fetch(
            'api.php',
            {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type':
                        'application/x-www-form-urlencoded;charset=UTF-8'
                },
                body: new URLSearchParams({
                    action: 'delete',
                    id: String(messageId)
                })
            }
        );

        const data = await response.json();

        if (!response.ok || !data.ok) {
            throw new Error(
                data.error ||
                'Could not delete message'
            );
        }

        await loadMessages(false);
        await loadUsers();

    } catch (error) {
        alert(error.message);
    }
}

gifButton.addEventListener('click', () => {
    if (!selectedUserId || inputEl.disabled) return;
    gifMenu.classList.toggle('show');
    if (gifMenu.classList.contains('show')) {
        gifSearchInput.focus();
    }
});

gifSearchButton.addEventListener('click', searchGifs);

gifSearchInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') {
        event.preventDefault();
        searchGifs();
    }
});

document.addEventListener('click', event => {
    if (!gifMenu.contains(event.target) && event.target !== gifButton) {
        gifMenu.classList.remove('show');
    }
});

attachmentButton.addEventListener(
    'click',
    () => {
        if (!selectedUserId || inputEl.disabled) {
            return;
        }
        fileInput.click();
    }
);

fileInput.addEventListener(
    'change',
    () => {
        const file = fileInput.files && fileInput.files[0];

        if (!file) {
            clearSelectedFile();
            return;
        }

        if (file.size > MAX_FILE_SIZE) {
            alert('That file is larger than 15 MB.');
            clearSelectedFile();
            return;
        }

        selectedFile = file;
        selectedFileNameEl.textContent =
            `${file.name} (${formatBytes(file.size)})`;
        selectedFileEl.classList.add('show');
    }
);

clearFileButton.addEventListener(
    'click',
    clearSelectedFile
);

cancelReplyButton.addEventListener(
    'click',
    clearReply
);

/* =========================
   LOAD USERS
========================= */

async function loadUsers() {

    try {

        const data =
            await api('users');

        renderUsers(
            data.users
        );

    } catch (error) {

        usersEl.innerHTML =
            '<div class="empty-users">' +
            'Could not load accounts.' +
            '</div>';

    }

}


/* =========================
   RENDER USERS
========================= */

function renderUsers(users) {

    const query =
        searchEl.value
            .trim()
            .toLowerCase();

    const filtered =
        users.filter(
            user =>
                user.username
                    .toLowerCase()
                    .includes(query)
        );


    if (!filtered.length) {

        usersEl.innerHTML =
            '<div class="empty-users">' +
            'No other accounts found.' +
            '</div>';

        return;

    }


    usersEl.innerHTML =
        filtered.map(
            user => `

                <button
                    class="user-button ${
                        Number(user.id) ===
                        Number(selectedUserId)
                            ? 'active'
                            : ''
                    }"
                    data-id="${user.id}"
                    data-name="${escapeHtml(
                        user.username
                    )}"
                    type="button"
                >

                    <div class="avatar">
                        ${escapeHtml(
                            initials(
                                user.username
                            )
                        )}
                    </div>

                    <div class="user-name">
                        ${escapeHtml(
                            user.username
                        )}
                    </div>

                </button>

            `
        ).join('');


    usersEl
        .querySelectorAll(
            '.user-button'
        )
        .forEach(button => {

            button.addEventListener(
                'click',
                () =>
                    selectUser(
                        Number(
                            button.dataset.id
                        ),
                        button.dataset.name
                    )
            );

        });

}


/* =========================
   LOAD BLOCK STATUS
========================= */

async function loadBlockStatus() {

    if (!selectedUserId) {

        blockButton.style.display =
            'none';

        return;

    }


    try {

        const data =
            await api(
                'block_status',
                {
                    user_id:
                        selectedUserId
                }
            );


        blockButton.style.display =
            'block';


        attachmentButton.disabled = data.blocked;
        gifButton.disabled = data.blocked;

        if (data.blocked) {

            if (data.blocked_by_me) {

                blockButton.textContent =
                    'Unblock';

                blockButton.disabled =
                    false;

            } else {

                blockButton.textContent =
                    'Blocked';

                blockButton.disabled =
                    true;

            }


            inputEl.disabled =
                true;

            sendEl.disabled =
                true;

            inputEl.placeholder =
                data.blocked_by_me
                    ? 'Unblock this user to message them...'
                    : 'This conversation is blocked...';

        } else {

            blockButton.textContent =
                'Block';

            blockButton.disabled =
                false;

            inputEl.disabled =
                false;

            sendEl.disabled =
                false;

            attachmentButton.disabled =
                false;

            gifButton.disabled =
                false;

            inputEl.placeholder =
                `Message ${selectedUsername}...`;

        }

    } catch (error) {

        blockButton.style.display =
            'none';

    }

}


/* =========================
   BLOCK / UNBLOCK
========================= */

blockButton.addEventListener(
    'click',
    async () => {

        if (!selectedUserId) {
            return;
        }


        const isUnblocking =
            blockButton.textContent ===
            'Unblock';


        if (!isUnblocking) {

            const confirmed =
                confirm(
                    `Block ${selectedUsername}? They will not be able to send messages to you, and you will not be able to send messages to them.`
                );


            if (!confirmed) {
                return;
            }

        }


        blockButton.disabled =
            true;


        try {

            const action =
                isUnblocking
                    ? 'unblock'
                    : 'block';


            await fetch(
                'api.php',
                {
                    method: 'POST',

                    credentials:
                        'same-origin',

                    headers: {
                        'Content-Type':
                            'application/x-www-form-urlencoded;charset=UTF-8'
                    },

                    body:
                        new URLSearchParams({
                            action,
                            user_id:
                                selectedUserId
                        })
                }
            );


            await loadBlockStatus();

        } catch (error) {

            alert(
                error.message
            );

            blockButton.disabled =
                false;

        }

    }
);


/* =========================
   SELECT USER
========================= */

async function selectUser(
    userId,
    username
) {

    selectedUserId =
        userId;

    selectedUsername =
        username;


    titleEl.textContent =
        username;

    avatarEl.textContent =
        initials(username);


    inputEl.disabled =
        false;

    sendEl.disabled =
        false;


    inputEl.placeholder =
        `Message ${username}...`;


    clearReply();
    clearSelectedFile();
    clearSelectedGif();
    lastMessageSignature = '';


    sidebarEl.classList.remove(
        'open'
    );


    /*
     * Load the selected conversation directly.
     * No user-list reload happens here.
     */
    await loadMessages(true);

    await loadBlockStatus();


    clearInterval(
        pollTimer
    );


    pollTimer =
        setInterval(
            () => loadMessages(false),
            2500
        );


    inputEl.focus();

}


/* =========================
   LOAD MESSAGES
========================= */

async function loadMessages(
    initial
) {

    if (!selectedUserId) {
        return;
    }

    try {

        const data =
            await api(
                'messages',
                {
                    user_id:
                        selectedUserId
                }
            );

        const messages = Array.isArray(data.messages) ? data.messages : [];

        /* Do not rebuild the DOM during polling when nothing changed. */
        const signature = JSON.stringify(
            messages.map(message => ({
                id: message.id,
                message: message.message,
                created_at_unix: message.created_at_unix,
                attachment_name: message.attachment_name,
                attachment_size: message.attachment_size,
                attachment_mime: message.attachment_mime,
                attachment_url: message.attachment_url,
                gif_url: message.gif_url,
                gif_preview_url: message.gif_preview_url,
                gif_title: message.gif_title,
                reply_to_id: message.reply_to_id,
                reply_message: message.reply_message,
                reply_sender_id: message.reply_sender_id,
                reply_sender_username: message.reply_sender_username,
                reply_attachment_name: message.reply_attachment_name
            }))
        );

        const wasNearBottom =
            messagesEl.scrollHeight -
            messagesEl.scrollTop -
            messagesEl.clientHeight
            < 100;

        if (signature === lastMessageSignature && !initial) {
            return;
        }

        const previousScrollTop = messagesEl.scrollTop;
        const previousScrollHeight = messagesEl.scrollHeight;

        renderMessages(messages);

        if (initial || wasNearBottom) {
            messagesEl.scrollTop = messagesEl.scrollHeight;
        } else {
            const heightDelta = messagesEl.scrollHeight - previousScrollHeight;
            messagesEl.scrollTop = previousScrollTop + heightDelta;
        }

        lastMessageSignature = signature;

    } catch (error) {

        // Ignore temporary polling failures.

    }

}


/* =========================
   RENDER MESSAGES
========================= */

function setupMessageImageObserver() {
    if (messageImageObserver) {
        messageImageObserver.disconnect();
    }

    messageImageObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            const image = entry.target;
            const src = image.dataset.src || '';

            if (!src) return;

            if (entry.isIntersecting) {
                if (image.dataset.loading === '1' || image.dataset.loaded === '1') {
                    return;
                }

                image.dataset.loading = '1';
                image.dataset.beforeBottom = String(
                    messagesEl.scrollHeight - messagesEl.scrollTop
                );

                image.addEventListener('load', () => {
                    image.dataset.loaded = '1';
                    image.dataset.loading = '0';
                    image.classList.add('media-loaded');

                    const rect = image.getBoundingClientRect();
                    const containerRect = messagesEl.getBoundingClientRect();
                    const beforeBottom = Number(image.dataset.beforeBottom);

                    if (Number.isFinite(beforeBottom)) {
                        const wasNearBottom =
                            beforeBottom - messagesEl.clientHeight < 100;

                        if (wasNearBottom) {
                            messagesEl.scrollTop = messagesEl.scrollHeight;
                        } else if (rect.bottom < containerRect.top + 5) {
                            const afterBottom = messagesEl.scrollHeight - messagesEl.scrollTop;
                            const delta = afterBottom - beforeBottom;
                            if (Math.abs(delta) > 0.5) {
                                messagesEl.scrollTop -= delta;
                            }
                        }
                    }
                }, { once: true });

                image.src = src;
            }
        });
    }, {
        root: messagesEl,
        rootMargin: '300px 0px',
        threshold: 0
    });

    messagesEl.querySelectorAll('.message-media-image[data-src]').forEach(image => {
        messageImageObserver.observe(image);
    });
}

function gifMarkup(message) {
    if (!message.gif_url) {
        return '';
    }

    // Always use the full GIPHY GIF URL for messages.
    // The search preview URL is intentionally smaller and can use a
    // shortened/optimized animation, which can make longer GIFs appear
    // truncated or loop at odd points.
    const gifUrl = message.gif_url;
    const title = message.gif_title || 'GIF';

    return `
        <a
            class="gif-message"
            href="${escapeHtml(gifUrl)}"
            target="_blank"
            rel="noopener"
        >
            <img
                class="message-media-image"
                data-src="${escapeHtml(gifUrl)}"
                alt="${escapeHtml(title)}"
            >
        </a>
    `;
}

function attachmentMarkup(message) {

    if (!message.attachment_name) {
        return '';
    }

    const url =
        message.attachment_url ||
        `api.php?action=download&id=${encodeURIComponent(message.id)}`;

    const mime =
        String(message.attachment_mime || '').toLowerCase();

    if (mime.startsWith('image/')) {
        return `
            <a href="${escapeHtml(url)}" target="_blank" rel="noopener">
                <img
                    class="attachment-image message-media-image"
                    data-src="${escapeHtml(url)}"
                    alt="${escapeHtml(message.attachment_name)}"
                >
            </a>
        `;
    }

    const fileSize = formatBytes(Number(message.attachment_size || 0));

    return `
        <a
            class="attachment-file"
            href="${escapeHtml(url)}"
            target="_blank"
            rel="noopener"
            download
            title="Download ${escapeHtml(message.attachment_name)}"
        >
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <path d="M14 2v6h6"/>
                <path d="M8 13h8M8 17h6"/>
            </svg>
            <span class="attachment-file-info">
                <span class="attachment-file-name">${escapeHtml(message.attachment_name)}</span>
                <span class="attachment-file-size">${escapeHtml(fileSize)}</span>
            </span>
            <svg class="attachment-download-icon" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 3v11"/>
                <path d="m8 10 4 4 4-4"/>
                <path d="M5 21h14"/>
            </svg>
        </a>
    `;
}

function replyMarkup(message) {

    if (!message.reply_to_id) {
        return '';
    }

    const name =
        Number(message.reply_sender_id) === Number(currentUserId)
            ? 'You'
            : (message.reply_sender_username || 'Message');

    const text =
        String(message.reply_message || '').trim() ||
        (message.reply_attachment_name || 'Attachment');

    return `
        <div class="reply-quote">
            <div class="reply-quote-label">${escapeHtml(name)}</div>
            <div class="reply-quote-text">${escapeHtml(text)}</div>
        </div>
    `;
}

function renderMessages(messages) {

    if (!messages.length) {
        messagesEl.innerHTML =
            '<div class="no-messages">' +
            'No messages yet. Say hello!' +
            '</div>';
        return;
    }

    messagesEl.innerHTML =
        messages.map(message => {

            const mine =
                Number(message.sender_id) ===
                Number(currentUserId);

            const timestamp = Number(message.created_at_unix);
            const date = Number.isFinite(timestamp)
                ? new Date(timestamp * 1000)
                : new Date(
                    String(message.created_at || '').replace(' ', 'T') + 'Z'
                );

            const time =
                isNaN(date.getTime())
                    ? message.created_at
                    : date.toLocaleString(
                        [],
                        {
                            dateStyle: 'short',
                            timeStyle: 'short'
                        }
                    );

            return `
                <div class="message-row ${mine ? 'mine' : ''}">
                    <div class="bubble-wrap">
                        <div class="message-actions">
                            <button
                                class="message-action reply-button"
                                type="button"
                                aria-label="Reply"
                                title="Reply"
                                data-message-id="${escapeHtml(message.id)}"
                            >
                                <svg viewBox="0 0 24 24" aria-hidden="true">
                                    <path d="M9 17 4 12l5-5"/>
                                    <path d="M4 12h10a6 6 0 0 1 6 6"/>
                                </svg>
                            </button>
                            ${mine ? `
                                <button
                                    class="message-action delete-button"
                                    type="button"
                                    aria-label="Delete message"
                                    title="Delete message"
                                    data-message-id="${escapeHtml(message.id)}"
                                >
                                    <svg viewBox="0 0 24 24" aria-hidden="true">
                                        <path d="M4 7h16"/>
                                        <path d="M10 11v6"/>
                                        <path d="M14 11v6"/>
                                        <path d="M6 7l1 14h10l1-14"/>
                                        <path d="M9 7V4h6v3"/>
                                    </svg>
                                </button>
                            ` : ''}
                        </div>

                        <div class="bubble">
                            ${replyMarkup(message)}
                            ${gifMarkup(message)}
                            ${attachmentMarkup(message)}
                            ${message.message ? `<div class="message-text">${escapeHtml(message.message)}</div>` : ''}
                            <div class="time">${escapeHtml(time)}</div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

    messagesEl
        .querySelectorAll('.reply-button')
        .forEach(button => {
            button.addEventListener('click', () => {
                const id = Number(button.dataset.messageId);
                const message = messages.find(item => Number(item.id) === id);
                if (message) {
                    beginReply(message);
                }
            });
        });


    messagesEl
        .querySelectorAll('.delete-button')
        .forEach(button => {
            button.addEventListener('click', () => {
                const id = Number(button.dataset.messageId);
                const message = messages.find(item => Number(item.id) === id);

                if (message && Number(message.sender_id) === Number(currentUserId)) {
                    deleteMessage(id);
                }
            });
        });

    setupMessageImageObserver();
}


/* =========================
   SEARCH
========================= */

searchEl.addEventListener(
    'input',
    loadUsers
);


/* =========================
   SEND
========================= */

document
    .getElementById('composer')
    .addEventListener(
        'submit',
        async event => {

            event.preventDefault();

            const text = inputEl.value.trim();

            if (
                !selectedUserId ||
                (!text && !selectedFile && !selectedGif)
            ) {
                return;
            }

            sendEl.disabled = true;
            attachmentButton.disabled = true;

            try {

                await sendMessage(text);

                inputEl.value = '';
                clearReply();
                clearSelectedFile();
                clearSelectedGif();

                await loadMessages(false);

                messagesEl.scrollTop =
                    messagesEl.scrollHeight;

                await loadUsers();

            } catch (error) {

                alert(error.message);

            } finally {

                await loadBlockStatus();

                if (!inputEl.disabled) {
                    sendEl.disabled = false;
                }

                inputEl.focus();
            }
        }
    );


/* =========================
   ENTER TO SEND
========================= */

inputEl.addEventListener(
    'keydown',
    event => {

        if (
            event.key === 'Enter' &&
            !event.shiftKey
        ) {

            event.preventDefault();

            document
                .getElementById(
                    'composer'
                )
                .requestSubmit();

        }

    }
);


/* =========================
   MOBILE
========================= */

document
    .getElementById(
        'mobileUsers'
    )
    .addEventListener(
        'click',
        () => {

            sidebarEl.classList.toggle(
                'open'
            );

        }
    );


/* =========================
   START
========================= */

loadUsers();

</script>

</body>
</html>
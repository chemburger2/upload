<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

const MAX_FILE_SIZE = 15728640;       // 15 MiB
const CHAT_STORAGE_LIMIT = 47185920;  // 45 MiB

function respond(array $data, int $status = 200): never
{
    http_response_code($status);

    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    exit;
}

if (empty($_SESSION['user_id'])) {
    respond(
        [
            'ok' => false,
            'error' => 'Not logged in.'
        ],
        401
    );
}

$currentUserId = (int) $_SESSION['user_id'];

$action =
    $_POST['action'] ??
    $_GET['action'] ??
    '';

function ensureTable(PDO $pdo): void
{
    static $done = false;

    if ($done) {
        return;
    }

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS messenger_messages (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            sender_id INT UNSIGNED NOT NULL,
            receiver_id INT UNSIGNED NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX idx_conversation (sender_id, receiver_id, id),
            INDEX idx_receiver_sender (receiver_id, sender_id, id)
        )
        ENGINE=InnoDB
        DEFAULT CHARSET=utf8mb4
        COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS messenger_blocks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            blocker_id INT UNSIGNED NOT NULL,
            blocked_id INT UNSIGNED NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_block (blocker_id, blocked_id),
            INDEX idx_blocker (blocker_id),
            INDEX idx_blocked (blocked_id)
        )
        ENGINE=InnoDB
        DEFAULT CHARSET=utf8mb4
        COLLATE=utf8mb4_unicode_ci"
    );

    $columns = [];
    $columnStmt = $pdo->query('SHOW COLUMNS FROM messenger_messages');

    foreach ($columnStmt->fetchAll(PDO::FETCH_ASSOC) as $column) {
        $columns[(string)$column['Field']] = true;
    }

    $addColumns = [
        'reply_to_id' => 'ADD COLUMN reply_to_id BIGINT UNSIGNED NULL AFTER message',
        'attachment_name' => 'ADD COLUMN attachment_name VARCHAR(255) NULL AFTER reply_to_id',
        'attachment_path' => 'ADD COLUMN attachment_path VARCHAR(255) NULL AFTER attachment_name',
        'attachment_mime' => 'ADD COLUMN attachment_mime VARCHAR(150) NULL AFTER attachment_path',
        'attachment_size' => 'ADD COLUMN attachment_size BIGINT UNSIGNED NULL AFTER attachment_mime',
        'gif_url' => 'ADD COLUMN gif_url VARCHAR(1000) NULL AFTER attachment_size',
        'gif_preview_url' => 'ADD COLUMN gif_preview_url VARCHAR(1000) NULL AFTER gif_url',
        'gif_title' => 'ADD COLUMN gif_title VARCHAR(255) NULL AFTER gif_preview_url'
    ];

    foreach ($addColumns as $name => $sql) {
        if (!isset($columns[$name])) {
            $pdo->exec('ALTER TABLE messenger_messages ' . $sql);
        }
    }

    $done = true;
}

function isConversationBlocked(PDO $pdo, int $userA, int $userB): bool
{
    $stmt = $pdo->prepare(
        'SELECT id
         FROM messenger_blocks
         WHERE
            (blocker_id = ? AND blocked_id = ?)
            OR
            (blocker_id = ? AND blocked_id = ?)
         LIMIT 1'
    );

    $stmt->execute([
        $userA,
        $userB,
        $userB,
        $userA
    ]);

    return (bool)$stmt->fetchColumn();
}

function userExists(PDO $pdo, int $userId): bool
{
    $stmt = $pdo->prepare(
        'SELECT id FROM users WHERE id = ? LIMIT 1'
    );

    $stmt->execute([$userId]);

    return (bool)$stmt->fetchColumn();
}

function conversationStorage(PDO $pdo, int $userA, int $userB): int
{
    $stmt = $pdo->prepare(
        "SELECT COALESCE(SUM(attachment_size), 0)
         FROM messenger_messages
         WHERE
            ((sender_id = ? AND receiver_id = ?)
             OR
             (sender_id = ? AND receiver_id = ?))
            AND attachment_size IS NOT NULL"
    );

    $stmt->execute([
        $userA,
        $userB,
        $userB,
        $userA
    ]);

    return (int)$stmt->fetchColumn();
}

function deleteMessageFiles(array $ids, PDO $pdo): void
{
    if (!$ids) {
        return;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    $stmt = $pdo->prepare(
        "SELECT attachment_path
         FROM messenger_messages
         WHERE id IN ($placeholders)
           AND attachment_path IS NOT NULL"
    );

    $stmt->execute($ids);

    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $path) {
        if (is_string($path) && $path !== '') {
            deleteAttachmentFile($path);
        }
    }
}


function safeDownloadName(string $name): string
{
    // Only ever use the basename. This removes any client-supplied directory
    // components while preserving the actual filename and extension.
    $name = str_replace("\0", '', $name);
    $name = str_replace("\\", '/', $name);
    $name = basename($name);
    $name = trim($name);

    // Replace only characters that cannot safely be used in a filename.
    // Do NOT replace a missing/invalid name with "download" because that can
    // hide an upstream filename problem and causes every upload to be named
    // download.ext.
    $name = preg_replace('/[\x00-\x1F\x7F\/:*?"<>|]+/u', '_', $name);
    $name = trim((string)$name, " .");

    if ($name === '' || $name === '.' || $name === '..') {
        return 'file';
    }

    // Keep the extension and as much of the original name as possible.
    return function_exists('mb_substr')
        ? mb_substr($name, 0, 180, 'UTF-8')
        : substr($name, 0, 180);
}

function getUploadedOriginalName(array $fileInfo): string
{
    // PHP's multipart parser provides the browser's File.name here. This is
    // the authoritative upload filename. Do not prefer a separate POST field,
    // because a stale/incorrect original_name value can rename every upload.
    $name = isset($fileInfo['name']) && is_string($fileInfo['name'])
        ? $fileInfo['name']
        : '';

    $name = trim($name);

    if ($name === '') {
        throw new RuntimeException('The uploaded file did not include a filename.');
    }

    return safeDownloadName($name);
}

function chatFolderId(int $userA, int $userB): string
{
    $ids = [$userA, $userB];
    sort($ids, SORT_NUMERIC);
    return $ids[0] . '_' . $ids[1];
}

function deleteAttachmentFile(string $relativePath): void
{
    $relativePath = str_replace('\\', '/', $relativePath);
    $relativePath = ltrim($relativePath, '/');

    if ($relativePath === '' || str_contains($relativePath, '../') || str_contains($relativePath, '..\\')) {
        return;
    }

    $base = realpath(__DIR__ . '/uploads');
    if ($base === false) {
        return;
    }

    $path = __DIR__ . '/uploads/' . $relativePath;
    $real = realpath($path);
    if ($real === false || !is_file($real)) {
        return;
    }

    $prefix = rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    if (strncmp($real, $prefix, strlen($prefix)) !== 0) {
        return;
    }

    @unlink($real);

    // Clean up the empty message folder and then the empty chat folder.
    $messageDir = dirname($real);
    $chatDir = dirname($messageDir);

    if (is_dir($messageDir)) {
        $items = @scandir($messageDir);
        if ($items !== false && count($items) <= 2) {
            @rmdir($messageDir);
        }
    }

    if (is_dir($chatDir)) {
        $items = @scandir($chatDir);
        if ($items !== false && count($items) <= 2) {
            @rmdir($chatDir);
        }
    }
}

function validateOtherUser(PDO $pdo, int $currentUserId, ?int $otherUserId): void
{
    if (!$otherUserId || $otherUserId === $currentUserId) {
        respond(
            [
                'ok' => false,
                'error' => 'Invalid recipient.'
            ],
            400
        );
    }

    if (!userExists($pdo, $otherUserId)) {
        respond(
            [
                'ok' => false,
                'error' => 'User not found.'
            ],
            404
        );
    }
}

function tenorApiRequest(string $url): array
{
    $body = false;
    $status = 0;
    $error = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);

        if ($ch !== false) {
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_HTTPHEADER => [
                    'Accept: application/json'
                ],
                CURLOPT_USERAGENT => 'Encore Messenger/1.0'
            ]);

            $body = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
        }
    }

    // Some shared hosts do not have PHP cURL enabled. Fall back to the
    // normal HTTPS stream wrapper when it is available.
    if ($body === false || $body === '') {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 15,
                'ignore_errors' => true,
                'header' => "Accept: application/json\r\nUser-Agent: Encore Messenger/1.0\r\n"
            ]
        ]);

        $streamBody = @file_get_contents($url, false, $context);

        if ($streamBody !== false) {
            $body = $streamBody;

            if (isset($http_response_header) && is_array($http_response_header)) {
                foreach ($http_response_header as $header) {
                    if (preg_match('/^HTTP\/\d+(?:\.\d+)?\s+(\d+)/i', $header, $match)) {
                        $status = (int)$match[1];
                    }
                }
            }
        }
    }

    if ($body === false || $body === '') {
        throw new RuntimeException(
            'The GIF service could not be reached' .
            ($error !== '' ? ': ' . $error : '.')
        );
    }

    if ($status < 200 || $status >= 300) {
        $decodedError = json_decode($body, true);
        $detail = '';

        if (is_array($decodedError)) {
            $detail = trim((string)(
                $decodedError['error']['message'] ??
                $decodedError['error'] ??
                ''
            ));
        }

        throw new RuntimeException(
            'The GIF service returned HTTP ' . $status .
            ($detail !== '' ? ': ' . $detail : '.')
        );
    }

    $data = json_decode($body, true);

    if (!is_array($data)) {
        throw new RuntimeException('The GIF service returned invalid data.');
    }

    return $data;
}

function giphyMediaUrlIsAllowed(string $url): bool
{
    $parts = parse_url($url);

    if (!is_array($parts)) {
        return false;
    }

    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    $host = strtolower((string)($parts['host'] ?? ''));

    return $scheme === 'https'
        && ($host === 'giphy.com' || str_ends_with($host, '.giphy.com'));
}


try {
    ensureTable($pdo);

    $uploadDir = __DIR__ . '/uploads';

    if (!is_dir($uploadDir)) {
        if (!@mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            respond(
                [
                    'ok' => false,
                    'error' => 'The upload directory could not be created.'
                ],
                500
            );
        }
    }

    if ($action === 'users') {
        $stmt = $pdo->prepare(
            "SELECT
                u.id,
                u.username,
                latest.latest_message_id,
                latest.latest_message_at
             FROM users u
             LEFT JOIN (
                SELECT
                    CASE
                        WHEN sender_id = ? THEN receiver_id
                        ELSE sender_id
                    END AS other_user_id,
                    MAX(id) AS latest_message_id,
                    MAX(created_at) AS latest_message_at
                FROM messenger_messages
                WHERE sender_id = ? OR receiver_id = ?
                GROUP BY
                    CASE
                        WHEN sender_id = ? THEN receiver_id
                        ELSE sender_id
                    END
             ) latest
                ON latest.other_user_id = u.id
             WHERE u.id <> ?
             ORDER BY
                CASE
                    WHEN latest.latest_message_id IS NULL THEN 1
                    ELSE 0
                END ASC,
                latest.latest_message_id DESC,
                u.username ASC"
        );

        $stmt->execute([
            $currentUserId,
            $currentUserId,
            $currentUserId,
            $currentUserId,
            $currentUserId
        ]);

        respond([
            'ok' => true,
            'users' => $stmt->fetchAll()
        ]);
    }

    if ($action === 'block_status') {
        $otherUserId = filter_input(
            INPUT_GET,
            'user_id',
            FILTER_VALIDATE_INT
        );

        validateOtherUser($pdo, $currentUserId, $otherUserId ?: null);

        $blocked = isConversationBlocked(
            $pdo,
            $currentUserId,
            (int)$otherUserId
        );

        $mineStmt = $pdo->prepare(
            'SELECT id
             FROM messenger_blocks
             WHERE blocker_id = ? AND blocked_id = ?
             LIMIT 1'
        );

        $mineStmt->execute([
            $currentUserId,
            (int)$otherUserId
        ]);

        respond([
            'ok' => true,
            'blocked' => $blocked,
            'blocked_by_me' => (bool)$mineStmt->fetchColumn()
        ]);
    }

    if ($action === 'block') {
        $otherUserId = filter_input(
            INPUT_POST,
            'user_id',
            FILTER_VALIDATE_INT
        );

        validateOtherUser($pdo, $currentUserId, $otherUserId ?: null);

        if (isConversationBlocked($pdo, $currentUserId, (int)$otherUserId)) {
            respond([
                'ok' => true,
                'blocked' => true
            ]);
        }

        $stmt = $pdo->prepare(
            'INSERT INTO messenger_blocks (blocker_id, blocked_id)
             VALUES (?, ?)'
        );

        $stmt->execute([
            $currentUserId,
            (int)$otherUserId
        ]);

        respond([
            'ok' => true,
            'blocked' => true
        ]);
    }

    if ($action === 'unblock') {
        $otherUserId = filter_input(
            INPUT_POST,
            'user_id',
            FILTER_VALIDATE_INT
        );

        validateOtherUser($pdo, $currentUserId, $otherUserId ?: null);

        $stmt = $pdo->prepare(
            'DELETE FROM messenger_blocks
             WHERE blocker_id = ? AND blocked_id = ?'
        );

        $stmt->execute([
            $currentUserId,
            (int)$otherUserId
        ]);

        respond([
            'ok' => true,
            'blocked' => isConversationBlocked(
                $pdo,
                $currentUserId,
                (int)$otherUserId
            )
        ]);
    }


    if ($action === 'messages') {
        $otherUserId = filter_input(
            INPUT_GET,
            'user_id',
            FILTER_VALIDATE_INT
        );

        validateOtherUser($pdo, $currentUserId, $otherUserId ?: null);

        $stmt = $pdo->prepare(
            "SELECT
                m.id,
                m.sender_id,
                m.receiver_id,
                m.message,
                m.reply_to_id,
                m.attachment_name,
                m.attachment_path,
                m.attachment_mime,
                m.attachment_size,
                m.gif_url,
                m.gif_preview_url,
                m.gif_title,
                m.created_at,
                UNIX_TIMESTAMP(m.created_at) AS created_at_unix,
                r.message AS reply_message,
                r.sender_id AS reply_sender_id,
                r.attachment_name AS reply_attachment_name,
                ru.username AS reply_sender_username
             FROM messenger_messages m
             LEFT JOIN messenger_messages r
                ON r.id = m.reply_to_id
             LEFT JOIN users ru
                ON ru.id = r.sender_id
             WHERE
                (m.sender_id = ? AND m.receiver_id = ?)
                OR
                (m.sender_id = ? AND m.receiver_id = ?)
             ORDER BY m.id DESC
             LIMIT 50"
        );

        $stmt->execute([
            $currentUserId,
            (int)$otherUserId,
            (int)$otherUserId,
            $currentUserId
        ]);

        $messages = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));

        foreach ($messages as &$message) {
            $message['gif_url'] = !empty($message['gif_url']) ? (string)$message['gif_url'] : null;
            $message['gif_preview_url'] = !empty($message['gif_preview_url']) ? (string)$message['gif_preview_url'] : null;

        $message['attachment_url'] =
                !empty($message['attachment_path'])
                    ? 'api.php?action=download&id=' . rawurlencode((string)$message['id'])
                    : null;

            unset($message['attachment_path']);
        }
        unset($message);

        respond([
            'ok' => true,
            'messages' => $messages,
            'storage_used' => conversationStorage(
                $pdo,
                $currentUserId,
                (int)$otherUserId
            ),
            'storage_limit' => CHAT_STORAGE_LIMIT
        ]);
    }

    if ($action === 'download') {
        $messageId = filter_input(
            INPUT_GET,
            'id',
            FILTER_VALIDATE_INT
        );

        if (!$messageId) {
            respond([
                'ok' => false,
                'error' => 'Invalid file.'
            ], 400);
        }

        $stmt = $pdo->prepare(
            'SELECT
                sender_id,
                receiver_id,
                attachment_name,
                attachment_path,
                attachment_mime,
                attachment_size
             FROM messenger_messages
             WHERE id = ?
             LIMIT 1'
        );

        $stmt->execute([$messageId]);
        $file = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$file) {
            respond([
                'ok' => false,
                'error' => 'File not found.'
            ], 404);
        }

        if (
            (int)$file['sender_id'] !== $currentUserId &&
            (int)$file['receiver_id'] !== $currentUserId
        ) {
            respond([
                'ok' => false,
                'error' => 'You do not have access to this file.'
            ], 403);
        }

        $relativePath = str_replace('\\', '/', (string)($file['attachment_path'] ?? ''));
        $relativePath = ltrim($relativePath, '/');

        if (
            $relativePath === '' ||
            str_contains($relativePath, '../') ||
            str_contains($relativePath, '..\\')
        ) {
            respond([
                'ok' => false,
                'error' => 'File is no longer available.'
            ], 404);
        }

        $path = __DIR__ . '/uploads/' . $relativePath;

        if (!is_file($path)) {
            respond([
                'ok' => false,
                'error' => 'File is no longer available.'
            ], 404);
        }

        $mime = (string)($file['attachment_mime'] ?? 'application/octet-stream');
        $name = safeDownloadName((string)($file['attachment_name'] ?? 'download'));
        $inline = str_starts_with(strtolower($mime), 'image/');

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (string)filesize($path));
        header(
            'Content-Disposition: ' .
            ($inline ? 'inline' : 'attachment') .
            '; filename="' . addcslashes($name, "\\\"") . '"'
        );
        header('X-Content-Type-Options: nosniff');

        readfile($path);
        exit;
    }

    if ($action === 'delete') {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            respond([
                'ok' => false,
                'error' => 'Invalid request method.'
            ], 405);
        }

        $messageId = filter_input(
            INPUT_POST,
            'id',
            FILTER_VALIDATE_INT
        );

        if (!$messageId) {
            respond([
                'ok' => false,
                'error' => 'Invalid message.'
            ], 400);
        }

        $stmt = $pdo->prepare(
            'SELECT sender_id, attachment_path
             FROM messenger_messages
             WHERE id = ?
             LIMIT 1'
        );

        $stmt->execute([$messageId]);
        $messageRow = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$messageRow) {
            respond([
                'ok' => false,
                'error' => 'Message not found.'
            ], 404);
        }

        // A message can only be deleted by the account that sent it.
        if ((int)$messageRow['sender_id'] !== $currentUserId) {
            respond([
                'ok' => false,
                'error' => 'You can only delete your own messages.'
            ], 403);
        }

        $deleteStmt = $pdo->prepare(
            'DELETE FROM messenger_messages
             WHERE id = ? AND sender_id = ?
             LIMIT 1'
        );

        $deleteStmt->execute([
            $messageId,
            $currentUserId
        ]);

        if ($deleteStmt->rowCount() !== 1) {
            respond([
                'ok' => false,
                'error' => 'The message could not be deleted.'
            ], 409);
        }

        $attachmentPath = (string)($messageRow['attachment_path'] ?? '');
        if ($attachmentPath !== '') {
            deleteAttachmentFile($attachmentPath);
        }

        respond([
            'ok' => true,
            'deleted_id' => $messageId
        ]);
    }

    if ($action === 'send') {
        $otherUserId = filter_input(
            INPUT_POST,
            'user_id',
            FILTER_VALIDATE_INT
        );

        validateOtherUser($pdo, $currentUserId, $otherUserId ?: null);
        $otherUserId = (int)$otherUserId;

        if (isConversationBlocked($pdo, $currentUserId, $otherUserId)) {
            respond([
                'ok' => false,
                'error' => 'Messaging is blocked for this conversation.'
            ], 403);
        }

        $message = trim((string)($_POST['message'] ?? ''));

        if (mb_strlen($message) > 5000) {
            respond([
                'ok' => false,
                'error' => 'Message is too long.'
            ], 400);
        }

        $replyToId = filter_input(
            INPUT_POST,
            'reply_to_id',
            FILTER_VALIDATE_INT
        );

        if ($replyToId) {
            $replyStmt = $pdo->prepare(
                'SELECT id
                 FROM messenger_messages
                 WHERE id = ?
                   AND ((sender_id = ? AND receiver_id = ?)
                        OR (sender_id = ? AND receiver_id = ?))
                 LIMIT 1'
            );

            $replyStmt->execute([
                $replyToId,
                $currentUserId,
                $otherUserId,
                $otherUserId,
                $currentUserId
            ]);

            if (!$replyStmt->fetchColumn()) {
                respond([
                    'ok' => false,
                    'error' => 'The message you are replying to was not found.'
                ], 400);
            }
        } else {
            $replyToId = null;
        }

        $gifUrl = trim((string)($_POST['gif_url'] ?? ''));
        $gifPreviewUrl = trim((string)($_POST['gif_preview_url'] ?? ''));
        $gifTitle = trim((string)($_POST['gif_title'] ?? ''));

        if ($gifUrl !== '') {
            if (!giphyMediaUrlIsAllowed($gifUrl)) {
                respond([
                    'ok' => false,
                    'error' => 'Invalid GIPHY URL.'
                ], 400);
            }

            if ($gifPreviewUrl !== '' && !giphyMediaUrlIsAllowed($gifPreviewUrl)) {
                respond([
                    'ok' => false,
                    'error' => 'Invalid GIPHY preview URL.'
                ], 400);
            }

            if (mb_strlen($gifTitle) > 255) {
                $gifTitle = mb_substr($gifTitle, 0, 255);
            }
        } else {
            $gifPreviewUrl = null;
            $gifTitle = null;
        }

        $fileInfo = $_FILES['file'] ?? null;
        $storedFileName = null;
        $originalFileName = null;
        $fileMime = null;
        $fileSize = null;
        $storedPath = null;

        if ($fileInfo && isset($fileInfo['error']) && $fileInfo['error'] !== UPLOAD_ERR_NO_FILE) {
            if ((int)$fileInfo['error'] !== UPLOAD_ERR_OK) {
                respond([
                    'ok' => false,
                    'error' => 'The file upload failed.'
                ], 400);
            }

            $fileSize = (int)$fileInfo['size'];

            if ($fileSize <= 0) {
                respond([
                    'ok' => false,
                    'error' => 'The selected file is empty.'
                ], 400);
            }

            if ($fileSize > MAX_FILE_SIZE) {
                respond([
                    'ok' => false,
                    'error' => 'Files are limited to 15 MB.'
                ], 400);
            }

            $tmpName = (string)$fileInfo['tmp_name'];

            if (!is_uploaded_file($tmpName)) {
                respond([
                    'ok' => false,
                    'error' => 'The uploaded file could not be verified.'
                ], 400);
            }

            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $fileMime = $finfo->file($tmpName) ?: 'application/octet-stream';

            $blockedMimes = [
                'text/html',
                'application/xhtml+xml',
                'application/x-httpd-php',
                'application/x-php',
                'text/x-php',
                'application/javascript',
                'text/javascript',
                'application/x-sh',
                'text/x-shellscript'
            ];

            if (in_array(strtolower($fileMime), $blockedMimes, true)) {
                respond([
                    'ok' => false,
                    'error' => 'That file type cannot be uploaded.'
                ], 400);
            }

            // IMPORTANT: use the actual multipart filename supplied by the
            // browser in $_FILES['file']['name']. The separate original_name
            // POST field is intentionally ignored because it can be wrong and
            // was causing uploads to be stored as download.ext.
            try {
                $originalFileName = getUploadedOriginalName($fileInfo);
            } catch (RuntimeException $e) {
                respond([
                    'ok' => false,
                    'error' => $e->getMessage()
                ], 400);
            }

            $extension = strtolower(
                (string)pathinfo($originalFileName, PATHINFO_EXTENSION)
            );

            if ($extension === '') {
                $mimeExtensions = [
                    'application/pdf' => 'pdf',
                    'text/plain' => 'txt',
                    'application/zip' => 'zip',
                    'application/x-7z-compressed' => '7z',
                    'application/x-rar-compressed' => 'rar',
                    'application/msword' => 'doc',
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
                    'application/vnd.ms-excel' => 'xls',
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
                    'application/vnd.ms-powerpoint' => 'ppt',
                    'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
                    'audio/mpeg' => 'mp3',
                    'audio/wav' => 'wav',
                    'audio/ogg' => 'ogg',
                    'video/mp4' => 'mp4',
                    'video/webm' => 'webm',
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/gif' => 'gif',
                    'image/webp' => 'webp'
                ];

                $guessedExtension = $mimeExtensions[strtolower($fileMime)] ?? '';

                if ($guessedExtension !== '') {
                    $originalFileName .= '.' . $guessedExtension;
                    $extension = $guessedExtension;
                }
            }

            // Keep the actual filename on disk. Each message gets its own folder,
            // so identical filenames from different messages cannot collide.
            $storedFileName = $originalFileName;
        }

        if ($message === '' && $storedFileName === null && $gifUrl === '') {
            respond([
                'ok' => false,
                'error' => 'Message cannot be empty.'
            ], 400);
        }

        $pdo->beginTransaction();

        $freedAttachmentPaths = [];

        try {
            if ($storedFileName !== null && $fileSize !== null) {
                $storageUsed = conversationStorage(
                    $pdo,
                    $currentUserId,
                    $otherUserId
                );

                $requiredFree = max(
                    0,
                    ($storageUsed + $fileSize) - CHAT_STORAGE_LIMIT
                );

                if ($requiredFree > 0) {
                    // Free enough space by removing the oldest attachments in
                    // this conversation. The messages themselves remain.
                    $oldAttachmentStmt = $pdo->prepare(
                        "SELECT id, attachment_path, attachment_size
                         FROM messenger_messages
                         WHERE
                            ((sender_id = ? AND receiver_id = ?)
                             OR
                             (sender_id = ? AND receiver_id = ?))
                            AND attachment_path IS NOT NULL
                            AND attachment_size IS NOT NULL
                         ORDER BY id ASC
                         FOR UPDATE"
                    );

                    $oldAttachmentStmt->execute([
                        $currentUserId,
                        $otherUserId,
                        $otherUserId,
                        $currentUserId
                    ]);

                    $freedBytes = 0;
                    $attachmentsToClear = [];

                    foreach ($oldAttachmentStmt->fetchAll(PDO::FETCH_ASSOC) as $oldAttachment) {
                        $oldId = (int)$oldAttachment['id'];
                        $oldSize = (int)$oldAttachment['attachment_size'];
                        $oldPath = (string)$oldAttachment['attachment_path'];

                        $attachmentsToClear[] = $oldId;
                        if ($oldPath !== '') {
                            $freedAttachmentPaths[] = $oldPath;
                        }

                        $freedBytes += max(0, $oldSize);

                        if ($freedBytes >= $requiredFree) {
                            break;
                        }
                    }

                    if ($freedBytes < $requiredFree) {
                        throw new RuntimeException(
                            'Not enough attachment storage could be freed.'
                        );
                    }

                    $clearStmt = $pdo->prepare(
                        "UPDATE messenger_messages
                         SET attachment_name = NULL,
                             attachment_path = NULL,
                             attachment_mime = NULL,
                             attachment_size = NULL
                         WHERE id IN (" . implode(',', array_fill(0, count($attachmentsToClear), '?')) . ")"
                    );

                    $clearStmt->execute($attachmentsToClear);
                }
            }

            $insert = $pdo->prepare(
                'INSERT INTO messenger_messages
                    (sender_id, receiver_id, message, reply_to_id,
                     attachment_name, attachment_path, attachment_mime,
                     attachment_size, gif_url, gif_preview_url, gif_title)
                 VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?)'
            );

            $insert->execute([
                $currentUserId,
                $otherUserId,
                $message,
                $replyToId,
                $originalFileName,
                $fileMime,
                $fileSize,
                $gifUrl !== '' ? $gifUrl : null,
                $gifPreviewUrl !== '' ? $gifPreviewUrl : null,
                $gifTitle !== '' ? $gifTitle : null
            ]);

            $messageId = (int)$pdo->lastInsertId();

            if ($storedFileName !== null) {
                $chatFolderId = chatFolderId($currentUserId, $otherUserId);
                $messageFolder = __DIR__ . '/uploads/' . $chatFolderId . '/' . $messageId;

                if (!is_dir($messageFolder) && !@mkdir($messageFolder, 0755, true) && !is_dir($messageFolder)) {
                    throw new RuntimeException('The attachment folder could not be created.');
                }

                $destination = $messageFolder . '/' . $storedFileName;
                if (!@move_uploaded_file($tmpName, $destination)) {
                    throw new RuntimeException('The uploaded file could not be saved.');
                }

                $storedRelativePath = $chatFolderId . '/' . $messageId . '/' . $storedFileName;
                $pathUpdate = $pdo->prepare(
                    'UPDATE messenger_messages SET attachment_path = ? WHERE id = ?'
                );
                $pathUpdate->execute([
                    $storedRelativePath,
                    $messageId
                ]);
            }

            $countStmt = $pdo->prepare(
                "SELECT COUNT(*)
                 FROM messenger_messages
                 WHERE
                    (sender_id = ? AND receiver_id = ?)
                    OR
                    (sender_id = ? AND receiver_id = ?)"
            );

            $countStmt->execute([
                $currentUserId,
                $otherUserId,
                $otherUserId,
                $currentUserId
            ]);

            $count = (int)$countStmt->fetchColumn();

            if ($count >= 60) {
                $oldestStmt = $pdo->prepare(
                    "SELECT id
                     FROM messenger_messages
                     WHERE
                        (sender_id = ? AND receiver_id = ?)
                        OR
                        (sender_id = ? AND receiver_id = ?)
                     ORDER BY id ASC
                     LIMIT 10"
                );

                $oldestStmt->execute([
                    $currentUserId,
                    $otherUserId,
                    $otherUserId,
                    $currentUserId
                ]);

                $oldestIds = $oldestStmt->fetchAll(PDO::FETCH_COLUMN);

                if ($oldestIds) {
                    deleteMessageFiles($oldestIds, $pdo);

                    $placeholders = implode(
                        ',',
                        array_fill(0, count($oldestIds), '?')
                    );

                    $delete = $pdo->prepare(
                        "DELETE FROM messenger_messages
                         WHERE id IN ($placeholders)"
                    );

                    $delete->execute($oldestIds);
                }
            }

            $pdo->commit();

            foreach ($freedAttachmentPaths as $oldPath) {
                deleteAttachmentFile($oldPath);
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if (!empty($messageId)) {
                $newPathStmt = $pdo->prepare(
                    'SELECT attachment_path FROM messenger_messages WHERE id = ? LIMIT 1'
                );
                $newPathStmt->execute([$messageId]);
                $newRelativePath = (string)($newPathStmt->fetchColumn() ?: '');
                if ($newRelativePath !== '') {
                    deleteAttachmentFile($newRelativePath);
                }
            }

            throw $e;
        }

        respond([
            'ok' => true,
            'storage_used' => conversationStorage(
                $pdo,
                $currentUserId,
                $otherUserId
            ),
            'storage_limit' => CHAT_STORAGE_LIMIT
        ]);
    }

    respond([
        'ok' => false,
        'error' => 'Unknown action.'
    ], 400);
} catch (Throwable $e) {
    respond([
        'ok' => false,
        'error' => $e instanceof RuntimeException ? $e->getMessage() : 'Server error.'
    ], 500);
}

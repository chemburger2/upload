<?php
require 'config.php';

if (empty($_SESSION['is_admin'])) {
    header('Location: manage.php');
    exit;
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['update_user'])) {

        $user_id  = $_POST['user_id'];
        $username = trim($_POST['username']);
        $is_admin = isset($_POST['is_admin']) ? 1 : 0;
        $new_pass = trim($_POST['new_password']);

        if (!empty($username)) {

            try {

                if (!empty($new_pass)) {

                    $hashed_pass = password_hash(
                        $new_pass,
                        PASSWORD_DEFAULT
                    );

                    $stmt = $pdo->prepare(
                        "UPDATE users
                         SET username = ?, is_admin = ?, password = ?
                         WHERE id = ?"
                    );

                    $stmt->execute([
                        $username,
                        $is_admin,
                        $hashed_pass,
                        $user_id
                    ]);

                } else {

                    $stmt = $pdo->prepare(
                        "UPDATE users
                         SET username = ?, is_admin = ?
                         WHERE id = ?"
                    );

                    $stmt->execute([
                        $username,
                        $is_admin,
                        $user_id
                    ]);
                }

                if ($user_id == $_SESSION['user_id']) {
                    $_SESSION['is_admin'] = $is_admin;
                }

                $message = "User updated successfully.";

            } catch (PDOException $e) {

                $error =
                    "Failed to update user. Username may already be taken.";
            }
        }

    } elseif (isset($_POST['delete_user'])) {

        $target_user_id = $_POST['user_id'];

        if ($target_user_id == $_SESSION['user_id']) {

            $error =
                "You cannot delete your active admin account.";

        } else {

            $stmt = $pdo->prepare(
                "DELETE blocks
                 FROM blocks
                 JOIN portfolios
                 ON blocks.portfolio_id = portfolios.id
                 WHERE portfolios.user_id = ?"
            );

            $stmt->execute([
                $target_user_id
            ]);


            $stmt = $pdo->prepare(
                "DELETE FROM portfolios WHERE user_id = ?"
            );

            $stmt->execute([
                $target_user_id
            ]);


            $stmt = $pdo->prepare(
                "DELETE FROM users WHERE id = ?"
            );

            $stmt->execute([
                $target_user_id
            ]);


            $message =
                "User account and all associated portfolios were permanently deleted.";
        }

    } elseif (isset($_POST['delete_portfolio'])) {

        $portfolio_id = $_POST['portfolio_id'];

        $stmt = $pdo->prepare(
            "DELETE FROM blocks WHERE portfolio_id = ?"
        );

        $stmt->execute([
            $portfolio_id
        ]);


        $stmt = $pdo->prepare(
            "DELETE FROM portfolios WHERE id = ?"
        );

        $stmt->execute([
            $portfolio_id
        ]);


        $message =
            "Portfolio and all its associated blocks were permanently deleted.";

    } elseif (isset($_POST['delete_block'])) {

        $block_id = $_POST['block_id'];

        $stmt = $pdo->prepare(
            "DELETE FROM blocks WHERE id = ?"
        );

        $stmt->execute([
            $block_id
        ]);


        $message =
            "Block deleted successfully.";
    }
}


/*
 * Load users
 */

$stmt = $pdo->query(
    "SELECT id, username, is_admin
     FROM users
     ORDER BY id ASC"
);

$users = $stmt->fetchAll();


/*
 * Load portfolios
 */

$stmt = $pdo->query("
    SELECT portfolios.*, users.username
    FROM portfolios
    JOIN users
    ON portfolios.user_id = users.id
    ORDER BY portfolios.id DESC
");

$portfolios = $stmt->fetchAll();


/*
 * Load blocks
 */

$stmt = $pdo->query(
    "SELECT *
     FROM blocks
     ORDER BY id DESC"
);

$all_blocks = $stmt->fetchAll();


/*
 * Group blocks by portfolio
 */

$blocks_by_portfolio = [];

foreach ($all_blocks as $b) {

    $blocks_by_portfolio[
        $b['portfolio_id']
    ][] = $b;
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>
        Admin Panel - Control Center
    </title>

    <link
        rel="stylesheet"
        href="style.css"
    >

    <style>

        .nav-btn {
            background-color: #18181b;
            color: #ffffff;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: background-color 0.15s ease;
            display: inline-block;
        }

        .nav-btn:hover {
            background-color: #27272a;
            color: #ffffff;
        }

        .nav-btn-secondary {
            background-color: #e4e4e7;
            color: #18181b;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: background-color 0.15s ease;
            display: inline-block;
        }

        .nav-btn-secondary:hover {
            background-color: #d4d4d8;
            color: #18181b;
        }

        .admin-card {
            background: #ffffff;
            border: 1px solid #e4e4e7;
            border-radius: 8px;
            padding: 1.25rem;
            margin-bottom: 1.5rem;
        }

        .user-form {
            display: grid;
            grid-template-columns: 1.5fr 1.5fr 1fr auto auto;
            gap: 12px;
            align-items: center;
        }

        @media (max-width: 768px) {
            .user-form {
                grid-template-columns: 1fr;
            }
        }

        .portfolio-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e4e4e7;
            padding-bottom: 0.75rem;
            margin-bottom: 1rem;
        }

        .block-item {
            background: #f4f4f5;
            border: 1px solid #e4e4e7;
            border-radius: 6px;
            padding: 0.75rem;
            margin-bottom: 0.75rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .block-preview {
            flex-grow: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 0.9rem;
            color: #27272a;
        }

        .block-type {
            background: #e4e4e7;
            color: #3f3f46;
            padding: 0.15rem 0.4rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: bold;
            text-transform: uppercase;
            margin-right: 0.5rem;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
            border: none;
            padding: 0.4rem 0.8rem;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            width: auto;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .private-btn {
            background-color: #7c3aed;
            color: #ffffff;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: background-color 0.15s ease;
            display: inline-block;
        }

        .private-btn:hover {
            background-color: #6d28d9;
            color: #ffffff;
        }

    </style>

</head>

<body>

<div class="container">


    <!-- Header -->

    <div
        style="
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:2rem;
        "
    >

        <h1 style="margin:0;">
            Admin Control Panel
        </h1>


        <div
            style="
                display:flex;
                gap:10px;
                flex-wrap:wrap;
            "
        >

            <a
                href="manage.php"
                class="nav-btn"
            >
                ← Dashboard
            </a>


            <a
                href="other/private.php"
                class="private-btn"
            >
                Private Pages
            </a>


            <a
                href="index.php"
                class="nav-btn-secondary"
            >
                Public Home
            </a>

        </div>

    </div>


    <!-- Messages -->

    <?php if ($message): ?>

        <p
            style="
                color:#16a34a;
                font-weight:bold;
            "
        >
            <?= htmlspecialchars($message) ?>
        </p>

    <?php endif; ?>


    <?php if ($error): ?>

        <p
            style="
                color:#ef4444;
                font-weight:bold;
            "
        >
            <?= htmlspecialchars($error) ?>
        </p>

    <?php endif; ?>


    <!-- Users -->

    <h2>
        User Accounts
    </h2>


    <?php foreach ($users as $u): ?>

        <div class="admin-card">

            <form
                method="POST"
                class="user-form"
            >

                <input
                    type="hidden"
                    name="user_id"
                    value="<?= $u['id'] ?>"
                >


                <div>

                    <label>
                        <small>
                            Username
                        </small>
                    </label>

                    <input
                        type="text"
                        name="username"
                        value="<?= htmlspecialchars($u['username']) ?>"
                        required
                        style="margin:0;"
                    >

                </div>


                <div>

                    <label>
                        <small>
                            Reset Password (optional)
                        </small>
                    </label>

                    <input
                        type="password"
                        name="new_password"
                        placeholder="New Password"
                        style="margin:0;"
                    >

                </div>


                <div
                    style="
                        display:flex;
                        align-items:center;
                        gap:5px;
                        margin-top:1rem;
                    "
                >

                    <input
                        type="checkbox"
                        name="is_admin"
                        id="admin_<?= $u['id'] ?>"
                        value="1"
                        <?= $u['is_admin'] ? 'checked' : '' ?>
                        style="
                            width:auto;
                            margin:0;
                        "
                    >

                    <label
                        for="admin_<?= $u['id'] ?>"
                    >
                        <small>
                            Admin Access
                        </small>
                    </label>

                </div>


                <div style="margin-top:1rem;">

                    <button
                        type="submit"
                        name="update_user"
                        style="
                            background:#2563eb;
                            color:white;
                            width:auto;
                            padding:0.5rem 1rem;
                        "
                    >
                        Save
                    </button>

                </div>


                <div style="margin-top:1rem;">

                    <?php if ($u['id'] != $_SESSION['user_id']): ?>

                        <button
                            type="submit"
                            name="delete_user"
                            onclick="
                                return confirm(
                                    'Delete this user account and all their portfolios?'
                                );
                            "
                            class="btn-danger"
                        >
                            Delete
                        </button>

                    <?php else: ?>

                        <span
                            style="
                                font-size:0.85rem;
                                color:#71717a;
                                font-weight:bold;
                            "
                        >
                            (Current You)
                        </span>

                    <?php endif; ?>

                </div>

            </form>

        </div>

    <?php endforeach; ?>


    <!-- Portfolios -->

    <h2 style="margin-top:2.5rem;">
        Manage Portfolios & Blocks
    </h2>


    <?php if (empty($portfolios)): ?>

        <div class="admin-card">

            <p
                style="
                    margin:0;
                    color:#71717a;
                "
            >
                No portfolios exist yet.
            </p>

        </div>

    <?php else: ?>


        <?php foreach ($portfolios as $p): ?>

            <div class="admin-card">


                <div class="portfolio-header">

                    <div>

                        <h3
                            style="
                                margin:0 0 0.25rem 0;
                            "
                        >
                            <?= htmlspecialchars($p['title']) ?>
                        </h3>


                        <small style="color:#71717a;">

                            By

                            <strong>
                                <?= htmlspecialchars($p['username']) ?>
                            </strong>

                            |

                            URL:

                            <a
                                href="<?= htmlspecialchars($p['slug']) ?>"
                                target="_blank"
                            >
                                /<?= htmlspecialchars($p['slug']) ?>
                            </a>

                        </small>

                    </div>


                    <form
                        method="POST"
                        style="margin:0;"
                    >

                        <input
                            type="hidden"
                            name="portfolio_id"
                            value="<?= $p['id'] ?>"
                        >

                        <button
                            type="submit"
                            name="delete_portfolio"
                            onclick="
                                return confirm(
                                    'Delete this portfolio and ALL of its content blocks?'
                                );
                            "
                            class="btn-danger"
                        >
                            Delete Portfolio
                        </button>

                    </form>

                </div>


                <h4
                    style="
                        margin:1rem 0 0.5rem 0;
                        font-size:0.9rem;
                        color:#52525b;
                    "
                >
                    Content Blocks
                </h4>


                <?php if (empty($blocks_by_portfolio[$p['id']])): ?>

                    <p
                        style="
                            font-size:0.85rem;
                            color:#a1a1aa;
                            font-style:italic;
                            margin:0;
                        "
                    >
                        No blocks in this portfolio.
                    </p>

                <?php else: ?>


                    <?php foreach ($blocks_by_portfolio[$p['id']] as $b): ?>

                        <div class="block-item">

                            <div class="block-preview">

                                <span class="block-type">
                                    <?= htmlspecialchars($b['block_type']) ?>
                                </span>

                                <?= htmlspecialchars($b['content']) ?>

                            </div>


                            <form
                                method="POST"
                                style="margin:0;"
                            >

                                <input
                                    type="hidden"
                                    name="block_id"
                                    value="<?= $b['id'] ?>"
                                >


                                <button
                                    type="submit"
                                    name="delete_block"
                                    onclick="
                                        return confirm(
                                            'Delete this content block?'
                                        );
                                    "
                                    class="btn-danger"
                                    style="
                                        font-size:0.75rem;
                                        padding:0.25rem 0.5rem;
                                    "
                                >
                                    Delete Block
                                </button>

                            </form>

                        </div>

                    <?php endforeach; ?>

                <?php endif; ?>


            </div>

        <?php endforeach; ?>

    <?php endif; ?>


</div>

</body>

</html>
```

<?php
require 'config.php';

$username = $_GET['u'] ?? '';
$is_editing = isset($_GET['edit']) && $_GET['edit'] === '1';

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$profile_user = $stmt->fetch();

if (!$profile_user) {
    header("HTTP/1.0 404 Not Found");
    echo "User profile not found.";
    exit;
}

$is_owner = isset($_SESSION['user_id']) && ($_SESSION['user_id'] == $profile_user['id']);
$message = '';

if ($is_owner && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    $display_name = trim($_POST['display_name'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $avatar_url   = trim($_POST['avatar_url'] ?? '');
    $website_url  = trim($_POST['website_url'] ?? '');
    $location     = trim($_POST['location'] ?? '');
    $bio          = trim($_POST['bio'] ?? '');

    try {
        $stmt = $pdo->prepare("UPDATE users SET display_name = ?, email = ?, avatar_url = ?, website_url = ?, location = ?, bio = ? WHERE id = ?");
        $stmt->execute([$display_name, $email, $avatar_url, $website_url, $location, $bio, $profile_user['id']]);

        $profile_user['display_name'] = $display_name;
        $profile_user['email']        = $email;
        $profile_user['avatar_url']   = $avatar_url;
        $profile_user['website_url']  = $website_url;
        $profile_user['location']     = $location;
        $profile_user['bio']          = $bio;

        $is_editing = false;
        $message = "Profile updated successfully.";
    } catch (PDOException $e) {
        $message = "Failed to update profile details.";
    }
}

$stmt = $pdo->prepare("SELECT title, slug FROM portfolios WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$profile_user['id']]);
$user_portfolios = $stmt->fetchAll();

$shown_name = !empty($profile_user['display_name']) ? $profile_user['display_name'] : $profile_user['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($shown_name) ?>'s Profile</title>
    <link rel="stylesheet" href="/style.css">
    <style>
        .nav-btn { background-color: #18181b; color: #ffffff; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem; transition: background-color 0.15s ease; display: inline-block; }
        .nav-btn:hover { background-color: #27272a; color: #ffffff; }
        .nav-btn-secondary { background-color: #e4e4e7; color: #18181b; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem; transition: background-color 0.15s ease; display: inline-block; }
        .nav-btn-secondary:hover { background-color: #d4d4d8; color: #18181b; }
        .action-btn { background-color: #2563eb; color: #ffffff; padding: 0.5rem 1.25rem; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem; transition: background-color 0.15s ease; display: inline-block; }
        .action-btn:hover { background-color: #1d4ed8; color: #ffffff; }
    </style>
</head>
<body class="theme-<?= htmlspecialchars($profile_user['theme'] ?? 'light') ?>">
<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 2rem;">
        <a href="/index.php" class="nav-btn">← Back to Home</a>

        <?php if ($is_owner): ?>
            <?php if ($is_editing): ?>
                <a href="/user/<?= urlencode($profile_user['username']) ?>" class="nav-btn-secondary">View Mode</a>
            <?php else: ?>
                <a href="/user/<?= urlencode($profile_user['username']) ?>?edit=1" class="action-btn">✏️ Edit Profile</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <?php if ($message): ?>
        <p style="color:#16a34a; font-weight:bold;"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <div class="block">
        <?php if ($is_owner && $is_editing): ?>
            <h2>Edit Profile</h2>
            <form method="POST">
                <label style="display:block; margin-bottom:0.25rem; font-weight:bold;">Display Name</label>
                <input type="text" name="display_name" value="<?= htmlspecialchars($profile_user['display_name'] ?? '') ?>" placeholder="Display Name" style="width:100%; margin-bottom:1rem;">

                <label style="display:block; margin-bottom:0.25rem; font-weight:bold;">Profile Picture URL</label>
                <input type="url" name="avatar_url" value="<?= htmlspecialchars($profile_user['avatar_url'] ?? '') ?>" placeholder="https://example.com/image.png" style="width:100%; margin-bottom:1rem;">

                <label style="display:block; margin-bottom:0.25rem; font-weight:bold;">Contact Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($profile_user['email'] ?? '') ?>" placeholder="email@example.com" style="width:100%; margin-bottom:1rem;">

                <label style="display:block; margin-bottom:0.25rem; font-weight:bold;">Website URL</label>
                <input type="url" name="website_url" value="<?= htmlspecialchars($profile_user['website_url'] ?? '') ?>" placeholder="https://yourwebsite.com" style="width:100%; margin-bottom:1rem;">

                <label style="display:block; margin-bottom:0.25rem; font-weight:bold;">Location</label>
                <input type="text" name="location" value="<?= htmlspecialchars($profile_user['location'] ?? '') ?>" placeholder="City, Country" style="width:100%; margin-bottom:1rem;">

                <label style="display:block; margin-bottom:0.25rem; font-weight:bold;">Bio</label>
                <textarea name="bio" placeholder="Write a brief intro..." style="width:100%; height:120px; margin-bottom:1rem;"><?= htmlspecialchars($profile_user['bio'] ?? '') ?></textarea>

                <div style="display:flex; gap:10px;">
                    <button type="submit" name="save_profile" style="background:#16a34a; color:white; width:auto; padding:0.5rem 1.2rem;">Save Profile</button>
                    <a href="/user/<?= urlencode($profile_user['username']) ?>" style="padding:0.5rem 1rem; color:#4b5563; text-decoration:none;">Cancel</a>
                </div>
            </form>

        <?php else: ?>
            <div style="display:flex; gap:1.5rem; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap;">
                <?php if (!empty($profile_user['avatar_url'])): ?>
                    <img src="<?= htmlspecialchars($profile_user['avatar_url']) ?>" alt="Profile Picture" style="width:96px; height:96px; border-radius:50%; object-fit:cover; border:2px solid #e4e4e7;">
                <?php endif; ?>
                <div>
                    <h1 style="margin:0; font-size:1.75rem;"><?= htmlspecialchars($shown_name) ?></h1>
                    <small style="color:#6b7280; font-size:0.9rem;">@<?= htmlspecialchars($profile_user['username']) ?></small>
                    
                    <?php if (!empty($profile_user['location'])): ?>
                        <div style="color:#4b5563; font-size:0.85rem; margin-top:0.25rem;">Location: <?= htmlspecialchars($profile_user['location']) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!empty($profile_user['bio'])): ?>
                <p style="font-size:1rem; line-height:1.5; color:#374151; margin-bottom:1.5rem;"><?= nl2br(htmlspecialchars($profile_user['bio'])) ?></p>
            <?php else: ?>
                <p style="color:#6b7280; font-style:italic; margin-bottom:1.5rem;">No bio provided yet.</p>
            <?php endif; ?>

            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <?php if (!empty($profile_user['email'])): ?>
                    <a href="mailto:<?= htmlspecialchars($profile_user['email']) ?>" style="background:#2563eb; color:white; padding:0.5rem 1rem; border-radius:6px; text-decoration:none; font-weight:bold; font-size:0.9rem;">Email Creator</a>
                <?php endif; ?>

                <?php if (!empty($profile_user['website_url'])): ?>
                    <a href="<?= htmlspecialchars($profile_user['website_url']) ?>" target="_blank" rel="noopener" style="background:#4b5563; color:white; padding:0.5rem 1rem; border-radius:6px; text-decoration:none; font-weight:bold; font-size:0.9rem;">Website</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="block" style="margin-top:1.5rem;">
        <h3 style="margin-top:0;">Portfolios by <?= htmlspecialchars($shown_name) ?></h3>
        <?php if (empty($user_portfolios)): ?>
            <p style="color:#6b7280;">No public portfolios published yet.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($user_portfolios as $p): ?>
                    <li><a href="/<?= htmlspecialchars($p['slug']) ?>"><?= htmlspecialchars($p['title']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'sql202.infinityfree.com';
$db   = 'if0_42756288_hi';
$user = 'if0_42756288';
$pass = '83pPJnIgm2PgoNn'; // Replace with your actual vPanel password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}